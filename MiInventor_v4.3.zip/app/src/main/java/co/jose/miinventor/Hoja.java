package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

/** Versión 4.3: un boceto con su plano (piso, frente, lado o la cara de una pieza), como en Inventor. */
public class Hoja {
    public int id;
    public String nombre = "Boceto";
    public String plano = "Piso (XY)";
    public Boceto b = new Boceto();
    public boolean visible = true;
    public float[] o = {0, 0, 0}, ex = {1, 0, 0}, ey = {0, 1, 0};

    public float[] normal() {
        return new float[]{ex[1] * ey[2] - ex[2] * ey[1], ex[2] * ey[0] - ex[0] * ey[2], ex[0] * ey[1] - ex[1] * ey[0]};
    }

    /** Un punto del boceto (mm) en el mundo 3D. */
    public float[] mundo(double x, double y) {
        return new float[]{(float) (o[0] + ex[0] * x + ey[0] * y), (float) (o[1] + ex[1] * x + ey[1] * y), (float) (o[2] + ex[2] * x + ey[2] * y)};
    }

    /** Un punto del mundo en coordenadas del boceto. */
    public double[] local(float[] p) {
        float dx = p[0] - o[0], dy = p[1] - o[1], dz = p[2] - o[2];
        return new double[]{dx * ex[0] + dy * ex[1] + dz * ex[2], dx * ey[0] + dy * ey[1] + dz * ey[2]};
    }

    public static Hoja nueva(int id, int tipo) {
        Hoja h = new Hoja();
        h.id = id;
        h.nombre = "Boceto " + id;
        if (tipo == 1) { h.plano = "Frente (XZ)"; h.ex = new float[]{1, 0, 0}; h.ey = new float[]{0, 0, 1}; }
        else if (tipo == 2) { h.plano = "Lado (YZ)"; h.ex = new float[]{0, 1, 0}; h.ey = new float[]{0, 0, 1}; }
        return h;
    }

    public JSONObject json() throws Exception {
        JSONObject j = new JSONObject();
        j.put("id", id); j.put("nombre", nombre); j.put("plano", plano); j.put("vis", visible);
        j.put("o", arr(o)); j.put("ex", arr(ex)); j.put("ey", arr(ey));
        j.put("b", b.json());
        return j;
    }

    public static Hoja deJson(JSONObject j) throws Exception {
        Hoja h = new Hoja();
        h.id = j.optInt("id", 1);
        h.nombre = j.optString("nombre", "Boceto " + h.id);
        h.plano = j.optString("plano", "Piso (XY)");
        h.visible = j.optBoolean("vis", true);
        h.o = vec(j.optJSONArray("o"), h.o); h.ex = vec(j.optJSONArray("ex"), h.ex); h.ey = vec(j.optJSONArray("ey"), h.ey);
        h.b = Boceto.deJson(j.optJSONObject("b"));
        return h;
    }

    private static JSONArray arr(float[] v) throws Exception {
        JSONArray a = new JSONArray();
        for (float x : v) a.put((double) x);
        return a;
    }

    private static float[] vec(JSONArray a, float[] d) {
        if (a == null || a.length() < 3) return d;
        return new float[]{(float) a.optDouble(0, 0), (float) a.optDouble(1, 0), (float) a.optDouble(2, 0)};
    }
}
