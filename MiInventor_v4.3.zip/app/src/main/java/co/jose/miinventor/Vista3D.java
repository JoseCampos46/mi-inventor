package co.jose.miinventor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Dibujo en 3D (vista sin perspectiva, como los planos). Versión 2: un dedo corre la vista (o gira con 🔄,
 * o arrastra la pieza con ✋ Mover), dos dedos acercan y corren.
 * Tocar una pieza la escoge.
 */
public class Vista3D extends View {

    public interface AlEscoger { void escogida(int id); }
    /** Versión 2: el dedo arrastró la pieza escogida (mm en X, Y, Z). */
    public interface AlMover { void mover(int id, float dx, float dy, float dz); void soltar(); }

    /** Versión 2: 0 = un dedo corre la vista · 1 = un dedo gira (orbitar) · 2 = un dedo arrastra la pieza. */
    public static final int CORRER = 0, GIRAR = 1, MOVER = 2;
    public int modo = CORRER;
    public AlMover alMover;
    private float acX, acY, acZ;   // lo arrastrado que falta pasar (se pasa de 5 en 5 mm)

    public List<Pieza> piezas = new ArrayList<>();
    public int escogida = -1;
    public AlEscoger alEscoger;

    private float giro = -35, elev = 25;   // grados
    private float zoom = 1, panX, panY;
    private float escalaBase = 0.1f;
    private final float[] centro = {0, 0, 0};

    private final Paint pCara = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBorde = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTxt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pEje = new Paint(Paint.ANTI_ALIAS_FLAG);

    public Vista3D(Context c) {
        super(c);
        pBorde.setStyle(Paint.Style.STROKE);
        pBorde.setStrokeWidth(dp(0.8f));
        pBorde.setColor(0x66000000);
        pTxt.setTextSize(dp(12));
        pTxt.setFakeBoldText(true);
        pEje.setStrokeWidth(dp(2));
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    public void vista(float g, float e) { giro = g; elev = e; encuadrar(); }

    /** Pone todo el trabajo dentro de la pantalla. Versión 3: mide lo que se ve de verdad, para que llene la pantalla. */
    public void encuadrar() {
        zoom = 1; panX = 0; panY = 0;
        float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, mx = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        Map<Integer, Pieza> mapa = mapa();
        List<float[]> pts = new ArrayList<>();
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] e = {s[0] + d[0] * p.largo, s[1] + d[1] * p.largo, s[2] + d[2] * p.largo};
            float r = Math.max(p.a, p.b) / 2;
            if (p.tipo == Pieza.PLACA && p.contorno != null) {
                float[][] ee = ejes(p);
                for (float[] q : p.contorno) for (float[] o : new float[][]{s, e})
                    pts.add(new float[]{o[0] + ee[1][0] * q[0] + ee[2][0] * q[1], o[1] + ee[1][1] * q[0] + ee[2][1] * q[1], o[2] + ee[1][2] * q[0] + ee[2][2] * q[1]});
                continue;
            }
            for (float[] q : new float[][]{s, e})
                for (int k = 0; k < 8; k++) pts.add(new float[]{q[0] + ((k & 1) == 0 ? -r : r), q[1] + ((k & 2) == 0 ? -r : r), q[2] + ((k & 4) == 0 ? -r : r)});
        }
        if (pts.isEmpty()) { pts.add(new float[]{0, 0, 0}); pts.add(new float[]{1000, 1000, 1000}); }
        for (float[] q : pts) for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], q[k]); mx[k] = Math.max(mx[k], q[k]); }
        for (int k = 0; k < 3; k++) centro[k] = (mn[k] + mx[k]) / 2f;
        pivote = false;
        // lo que ocupa en la pantalla con este giro (a escala 1)
        double g = Math.toRadians(giro), el = Math.toRadians(elev);
        float cg1 = (float) Math.cos(g), sg1 = (float) Math.sin(g), ce1 = (float) Math.cos(el), se1 = (float) Math.sin(el);
        float x0 = Float.MAX_VALUE, x1 = -Float.MAX_VALUE, y0 = Float.MAX_VALUE, y1 = -Float.MAX_VALUE;
        for (float[] q : pts) {
            float x = q[0] - centro[0], y = q[1] - centro[1], z = q[2] - centro[2];
            float px = x * cg1 - y * sg1, yy = x * sg1 + y * cg1, arriba = z * ce1 + yy * se1;
            x0 = Math.min(x0, px); x1 = Math.max(x1, px); y0 = Math.min(y0, arriba); y1 = Math.max(y1, arriba);
        }
        float w = getWidth() > 0 ? getWidth() : dp(360), h = getHeight() > 0 ? getHeight() : dp(300);
        float anchoMm = Math.max(150, x1 - x0), altoMm = Math.max(150, y1 - y0);
        escalaBase = Math.min(w * 0.88f / anchoMm, (h - dp(40)) * 0.86f / altoMm);
        panX = -(x0 + x1) / 2 * escalaBase;
        panY = (y0 + y1) / 2 * escalaBase - dp(6);
        invalidate();
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        // versión 4.1: solo la primera vez; si sale una barrita abajo, la vista se queda donde estaba
        if (ow == 0 || oh == 0) encuadrar();
        else { panY += (h - oh) / 2f; invalidate(); }
    }

    // ---------------- Proyección ----------------

    private float cg, sg, ce, se, esc;

    private void prepararCamara() {
        double g = Math.toRadians(giro), e = Math.toRadians(elev);
        cg = (float) Math.cos(g); sg = (float) Math.sin(g);
        ce = (float) Math.cos(e); se = (float) Math.sin(e);
        esc = escalaBase * zoom;
    }

    /** Devuelve {x pantalla, y pantalla, profundidad}. */
    private float[] proyectar(float x, float y, float z) {
        x -= centro[0]; y -= centro[1]; z -= centro[2];
        float x1 = x * cg - y * sg;
        float y1 = x * sg + y * cg;
        float arriba = z * ce + y1 * se;
        float prof = y1 * ce - z * se;
        return new float[]{getWidth() / 2f + pxEf + x1 * esc, getHeight() / 2f + pyEf - arriba * esc, prof};
    }

    /** Qué tan de frente se ve una cara (para darle luz). */
    private float deFrente(float[] n) {
        float y1 = n[0] * sg + n[1] * cg;
        return y1 * ce - n[2] * se;   // negativo: mira hacia uno
    }

    private static class Cara {
        float[] xs, ys;
        float[][] hx, hy;        // versión 4: huecos de la cara (placas)
        float prof;
        int color;
        boolean borde = true;
        int pieza = -1, tipo;    // versión 4: de qué pieza es · 0 costado, 5 punta final, 6 punta inicio, 9 hueco
        float[] nrm, p0;         // normal y un punto de la cara (mm)
    }

    // ---------------- Versión 4: tocar caras ----------------

    /** Lo que se tocó: pieza, tipo de cara (0 costado, 5 punta final, 6 punta inicio), normal y el punto exacto (mm). */
    public interface AlTocarCara { void tocada(int pieza, int tipo, float[] nrm, float[] punto); }

    public AlTocarCara pideCara;              // mientras no sea null, tocar escoge caras
    /** Versión 4.3: tocar la pantalla para escoger una figura de un boceto. */
    public interface AlTocarPlano { void tocado(float x, float y); }
    public AlTocarPlano pideToque;
    public List<Hoja> hojas = new ArrayList<>();
    public int hojaResaltada = -1;

    /** El punto del plano (p0, n) que queda bajo el dedo. */
    public float[] enPlano(float x, float y, float[] p0, float[] n) { return desproyectar(x, y, p0, n); }
    public int resA = -1, resB = -1;          // caras resaltadas (naranja y azul)
    public float[] resNrmA, resNrmB;
    private final List<Cara> vistas = new ArrayList<>();   // las caras que se dibujaron (para tocar)

    private boolean esResaltada(int pieza, float[] n, int cual) {
        int id = cual == 0 ? resA : resB;
        float[] r = cual == 0 ? resNrmA : resNrmB;
        return id == pieza && r != null && n != null && r[0] * n[0] + r[1] * n[1] + r[2] * n[2] > 0.995f;
    }

    /** El punto (mm) sobre el plano de la cara que queda bajo el dedo. */
    private float[] desproyectar(float x, float y, float[] p0, float[] n) {
        prepararCamara();
        float x1 = (x - getWidth() / 2f - pxEf) / esc, arriba = -(y - getHeight() / 2f - pyEf) / esc;
        // punto = A + prof·B
        float[] A = mundo(x1, arriba, 0), B = mundo(x1, arriba, 1);
        float[] dB = {B[0] - A[0], B[1] - A[1], B[2] - A[2]};
        float den = dB[0] * n[0] + dB[1] * n[1] + dB[2] * n[2];
        if (Math.abs(den) < 1e-6) return A;
        float t = ((p0[0] - A[0]) * n[0] + (p0[1] - A[1]) * n[1] + (p0[2] - A[2]) * n[2]) / den;
        return new float[]{A[0] + dB[0] * t, A[1] + dB[1] * t, A[2] + dB[2] * t};
    }

    private float[] mundo(float x1, float arriba, float prof) {
        float y1 = arriba * se + prof * ce, z = arriba * ce - prof * se;
        float x = x1 * cg + y1 * sg, y = -x1 * sg + y1 * cg;
        return new float[]{x + centro[0], y + centro[1], z + centro[2]};
    }

    private static boolean dentro(float[] xs, float[] ys, float x, float y) {
        boolean d = false;
        for (int i = 0, j = xs.length - 1; i < xs.length; j = i++)
            if ((ys[i] > y) != (ys[j] > y) && x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]) d = !d;
        return d;
    }

    /** La cara más cercana bajo el dedo (la que se dibujó de última). */
    private boolean tocarCara(float x, float y) {
        for (int i = vistas.size() - 1; i >= 0; i--) {
            Cara k = vistas.get(i);
            if (k.pieza < 0 || k.tipo == 9 || !dentro(k.xs, k.ys, x, y)) continue;
            boolean enHueco = false;
            if (k.hx != null) for (int h = 0; h < k.hx.length; h++) if (dentro(k.hx[h], k.hy[h], x, y)) enHueco = true;
            if (enHueco) continue;
            float[] q = desproyectar(x, y, k.p0, k.nrm);
            pideCara.tocada(k.pieza, k.tipo, k.nrm, q);
            return true;
        }
        return false;
    }

    private static float[] suma(float[] a, float[] b, float k) { return new float[]{a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k}; }

    private static float[] cruz(float[] a, float[] b) {
        return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static float[] unir(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return l < 1e-6 ? new float[]{0, 0, 1} : new float[]{v[0] / l, v[1] / l, v[2] / l};
    }

    /** Los ejes de la sección: s (ancho) y u (alto), perpendiculares a la pieza. */
    static float[][] ejes(Pieza p) {
        if (p.marco != null) {
            float[] m = p.marco;
            return new float[][]{{m[9], m[10], m[11]}, {m[3], m[4], m[5]}, {m[6], m[7], m[8]}};
        }
        float[] d = p.direccion();
        float[] u;
        if (Math.abs(d[2]) < 0.95f) u = unir(new float[]{-d[0] * d[2], -d[1] * d[2], 1 - d[2] * d[2]});
        else u = unir(new float[]{-d[0] * d[1], 1 - d[1] * d[1], -d[2] * d[1]});
        float[] s = unir(cruz(d, u));
        for (int k = 0; k < (p.giro & 3); k++) { float[] ns = u; u = new float[]{-s[0], -s[1], -s[2]}; s = ns; }
        return new float[][]{d, s, u};
    }

    /** La forma de la sección, como uno o dos polígonos en (s, u). */
    static List<float[][]> seccion(Pieza p) {
        List<float[][]> r = new ArrayList<>();
        float a = p.a, b = p.b, t = Math.max(1, p.t);
        if (p.tipo == Pieza.PLACA) {
            if (p.contorno != null && p.contorno.length >= 3) r.add(p.contorno);
            else r.add(rect(0, 0, 100, 100));
            return r;
        }
        switch (p.tipo) {
            case 2: {
                int n = 12;
                float[][] pol = new float[n][2];
                for (int i = 0; i < n; i++) { double an = 2 * Math.PI * i / n; pol[i][0] = (float) Math.cos(an) * a / 2; pol[i][1] = (float) Math.sin(an) * a / 2; }
                r.add(pol);
                break;
            }
            case 3:
                r.add(rect(-a / 2, -b / 2, a / 2, -b / 2 + t));
                r.add(rect(-a / 2, -b / 2 + t, -a / 2 + t, b / 2));
                break;
            case 4:
                r.add(rect(-a / 2, -t / 2, a / 2, t / 2));
                break;
            default:
                r.add(rect(-a / 2, -b / 2, a / 2, b / 2));
        }
        return r;
    }

    private static float[][] rect(float s0, float u0, float s1, float u1) {
        return new float[][]{{s0, u0}, {s1, u0}, {s1, u1}, {s0, u1}};
    }

    // ---------------- Dibujo ----------------

    // Versión 3: lupa mientras el dedo está quieto encima (o arrastrando una pieza)
    private boolean lupa, enLupa;
    private float dedoX, dedoY, pxEf, pyEf;
    private int candidata = -1;

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D1018);
        prepararCamara();
        pxEf = panX; pyEf = panY;
        escena(c);
        // versión 4.2: el punto 0,0,0 de referencia
        float[] o = proyectar(0, 0, 0);
        Paint po = new Paint(Paint.ANTI_ALIAS_FLAG);
        po.setStrokeWidth(dp(2));
        po.setColor(0xFFE57373); c.drawLine(o[0], o[1], proyectar(300, 0, 0)[0], proyectar(300, 0, 0)[1], po);
        po.setColor(0xFF81C784); c.drawLine(o[0], o[1], proyectar(0, 300, 0)[0], proyectar(0, 300, 0)[1], po);
        po.setColor(0xFF64B5F6); c.drawLine(o[0], o[1], proyectar(0, 0, 300)[0], proyectar(0, 0, 300)[1], po);
        po.setColor(Color.WHITE);
        c.drawCircle(o[0], o[1], dp(4), po);
        po.setTextSize(dp(11));
        c.drawText("0,0,0", o[0] + dp(5), o[1] + dp(14), po);
        dibujarHojas(c);
        if (pivote) {
            float[] q = proyectar(centro[0], centro[1], centro[2]);
            Paint pv = new Paint(Paint.ANTI_ALIAS_FLAG);
            pv.setStyle(Paint.Style.STROKE);
            pv.setStrokeWidth(dp(2.2f));
            pv.setColor(0xFFFF9800);
            c.drawCircle(q[0], q[1], dp(9), pv);
            c.drawLine(q[0] - dp(13), q[1], q[0] + dp(13), q[1], pv);
            c.drawLine(q[0], q[1] - dp(13), q[0], q[1] + dp(13), pv);
        }
        dibujarEjes(c);
        if (lupa && !dos) dibujarLupa(c);
    }

    private void dibujarLupa(Canvas c) {
        float R = dp(64), k = 3f;
        float cx = dedoX < getWidth() / 2f ? getWidth() - R - dp(10) : R + dp(10);
        float cy = R + dp(10);
        if (dedoY < cy + R + dp(20)) cy = getHeight() - R - dp(10);
        Path circ = new Path();
        circ.addCircle(cx, cy, R, Path.Direction.CW);
        c.save();
        c.clipPath(circ);
        c.drawColor(0xFF0D1018);
        prepararCamara();
        esc *= k;
        enLupa = true;
        // el punto bajo el dedo queda en el centro de la lupa
        pxEf = cx + (getWidth() / 2f + panX - dedoX) * k - getWidth() / 2f;
        pyEf = cy + (getHeight() / 2f + panY - dedoY) * k - getHeight() / 2f;
        escena(c);
        enLupa = false;
        c.restore();
        prepararCamara();
        pxEf = panX; pyEf = panY;
        pEje.setColor(0x88FFB300);
        pEje.setStrokeWidth(dp(1));
        c.drawLine(cx - R, cy, cx + R, cy, pEje);
        c.drawLine(cx, cy - R, cx, cy + R, pEje);
        Paint borde = new Paint(Paint.ANTI_ALIAS_FLAG);
        borde.setStyle(Paint.Style.STROKE);
        borde.setStrokeWidth(dp(3));
        borde.setColor(0xFFFFB300);
        c.drawCircle(cx, cy, R, borde);
        pEje.setStrokeWidth(dp(2));
        String s = "Lupa ×3" + (candidata >= 0 ? " · T" + candidata : "");
        pTxt.setColor(Color.WHITE);
        c.drawText(s, cx - pTxt.measureText(s) / 2, cy + R + dp(16), pTxt);
    }

    private void escena(Canvas c) {
        Map<Integer, Pieza> mapa = mapa();
        List<Cara> caras = new ArrayList<>();
        for (Pieza p : piezas) if (!p.oculta) armarCaras(p, mapa, caras);
        Collections.sort(caras, (x, y) -> Float.compare(y.prof, x.prof));
        if (!enLupa) { vistas.clear(); vistas.addAll(caras); }
        Path path = new Path();
        for (Cara k : caras) {
            path.reset();
            path.moveTo(k.xs[0], k.ys[0]);
            for (int i = 1; i < k.xs.length; i++) path.lineTo(k.xs[i], k.ys[i]);
            path.close();
            if (k.hx != null) {
                path.setFillType(Path.FillType.EVEN_ODD);
                for (int h = 0; h < k.hx.length; h++) {
                    path.moveTo(k.hx[h][0], k.hy[h][0]);
                    for (int i = 1; i < k.hx[h].length; i++) path.lineTo(k.hx[h][i], k.hy[h][i]);
                    path.close();
                }
            } else path.setFillType(Path.FillType.WINDING);
            pCara.setColor(k.color);
            c.drawPath(path, pCara);
            if (k.borde) c.drawPath(path, pBorde);
        }
        // nombres de las piezas
        for (Pieza p : piezas) {
            if (p.oculta) continue;
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] m = proyectar(s[0] + d[0] * p.largo / 2, s[1] + d[1] * p.largo / 2, s[2] + d[2] * p.largo / 2);
            if (p.tipo == Pieza.PLACA && p.contorno != null) {
                float cs = 0, cu = 0;
                for (float[] q : p.contorno) { cs += q[0]; cu += q[1]; }
                cs /= p.contorno.length; cu /= p.contorno.length;
                float[][] ee = ejes(p);
                m = proyectar(s[0] + d[0] * p.largo + ee[1][0] * cs + ee[2][0] * cu, s[1] + d[1] * p.largo + ee[1][1] * cs + ee[2][1] * cu,
                        s[2] + d[2] * p.largo + ee[1][2] * cs + ee[2][2] * cu);
            }
            String nom = p.nombre();
            float w = pTxt.measureText(nom);
            pCara.setColor(p.id == escogida ? 0xEEFFB300 : 0xCC263238);
            c.drawRoundRect(m[0] - w / 2 - dp(4), m[1] - dp(18), m[0] + w / 2 + dp(4), m[1] - dp(2), dp(4), dp(4), pCara);
            pTxt.setColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            c.drawText(nom, m[0] - w / 2, m[1] - dp(6), pTxt);
        }
    }

    private void armarCaras(Pieza p, Map<Integer, Pieza> mapa, List<Cara> caras) {
        float[][] e = ejes(p);
        float[] d = e[0], s = e[1], u = e[2];
        float[] ini = p.inicio(mapa, 0);
        float[] fin = suma(ini, d, p.largo);
        int base = p.id == escogida ? 0xFFFFB300 : p.id == candidata && lupa ? 0xFFFF7043 : p.tipo == 3 ? 0xFFEF9F27 : p.tipo == 4 ? 0xFF90A4AE
                : p.tipo == Pieza.PLACA ? 0xFF64B5F6 : 0xFF5DCAA5;
        // versión 4: puntas cortadas inclinadas
        float ti = (float) Math.tan(Math.toRadians(Math.max(-75, Math.min(75, p.corteIni))));
        float tf = (float) Math.tan(Math.toRadians(Math.max(-75, Math.min(75, p.corteFin))));
        float[] wi = unir(new float[]{s[0] * p.ciS + u[0] * p.ciU, s[1] * p.ciS + u[1] * p.ciU, s[2] * p.ciS + u[2] * p.ciU});
        float[] wf = unir(new float[]{s[0] * p.cfS + u[0] * p.cfU, s[1] * p.cfS + u[1] * p.cfU, s[2] * p.cfS + u[2] * p.cfU});
        float[] nIni = unir(new float[]{-d[0] + ti * wi[0], -d[1] + ti * wi[1], -d[2] + ti * wi[2]});
        float[] nFin = unir(new float[]{d[0] + tf * wf[0], d[1] + tf * wf[1], d[2] + tf * wf[2]});
        boolean placa = p.tipo == Pieza.PLACA;
        List<float[][]> secs = seccion(p);
        // las placas tienen huecos: del boceto y los perforados
        List<float[][]> hue = new ArrayList<>();
        if (placa) {
            hue.addAll(p.agujeros);
            for (Pieza.Hueco h : p.huecos) hue.add(poligonoHueco(h));
        }
        for (float[][] pol : secs) {
            int n = pol.length;
            boolean ccw = area(pol) >= 0;
            float[][] a3 = new float[n][], b3 = new float[n][];
            for (int i = 0; i < n; i++) {
                float[] off = {s[0] * pol[i][0] + u[0] * pol[i][1], s[1] * pol[i][0] + u[1] * pol[i][1], s[2] * pol[i][0] + u[2] * pol[i][1]};
                float ki = off[0] * wi[0] + off[1] * wi[1] + off[2] * wi[2], kf = off[0] * wf[0] + off[1] * wf[1] + off[2] * wf[2];
                a3[i] = suma(suma(ini, off, 1), d, ti * ki);
                b3[i] = suma(suma(fin, off, 1), d, -tf * kf);
            }
            // costados
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float[] nrm;
                if (placa || n > 4) {
                    float es = pol[j][0] - pol[i][0], eu = pol[j][1] - pol[i][1];
                    float ns = ccw ? eu : -eu, nu = ccw ? -es : es;
                    nrm = unir(new float[]{s[0] * ns + u[0] * nu, s[1] * ns + u[1] * nu, s[2] * ns + u[2] * nu});
                } else {
                    float ms = (pol[i][0] + pol[j][0]) / 2, mu = (pol[i][1] + pol[j][1]) / 2;
                    nrm = unir(new float[]{s[0] * ms + u[0] * mu, s[1] * ms + u[1] * mu, s[2] * ms + u[2] * mu});
                }
                agregar(caras, new float[][]{a3[i], a3[j], b3[j], b3[i]}, nrm, base, n <= 4 || placa, p.id, 0);
            }
            // tapas (con los huecos de la placa)
            Cara kf = agregar(caras, b3, nFin, base, true, p.id, 5);
            float[][] inv = new float[n][];
            for (int i = 0; i < n; i++) inv[i] = a3[n - 1 - i];
            Cara ki = agregar(caras, inv, nIni, base, true, p.id, 6);
            if (placa && !hue.isEmpty()) {
                for (Cara k : new Cara[]{kf, ki}) {
                    if (k == null) continue;
                    float[] org = k == kf ? fin : ini;
                    k.hx = new float[hue.size()][];
                    k.hy = new float[hue.size()][];
                    for (int h = 0; h < hue.size(); h++) {
                        float[][] hp = hue.get(h);
                        k.hx[h] = new float[hp.length];
                        k.hy[h] = new float[hp.length];
                        for (int i = 0; i < hp.length; i++) {
                            float[] q = proyectar(org[0] + s[0] * hp[i][0] + u[0] * hp[i][1], org[1] + s[1] * hp[i][0] + u[1] * hp[i][1], org[2] + s[2] * hp[i][0] + u[2] * hp[i][1]);
                            k.hx[h][i] = q[0];
                            k.hy[h][i] = q[1];
                        }
                    }
                }
                // las paredes de adentro de cada hueco
                for (float[][] hp : hue) {
                    int m = hp.length;
                    boolean hc = area(hp) >= 0;
                    for (int i = 0; i < m; i++) {
                        int j = (i + 1) % m;
                        float es = hp[j][0] - hp[i][0], eu = hp[j][1] - hp[i][1];
                        float ns = hc ? -eu : eu, nu = hc ? es : -es;   // hacia el centro del hueco
                        float[] nrm = unir(new float[]{s[0] * ns + u[0] * nu, s[1] * ns + u[1] * nu, s[2] * ns + u[2] * nu});
                        float[] oi = {s[0] * hp[i][0] + u[0] * hp[i][1], s[1] * hp[i][0] + u[1] * hp[i][1], s[2] * hp[i][0] + u[2] * hp[i][1]};
                        float[] oj = {s[0] * hp[j][0] + u[0] * hp[j][1], s[1] * hp[j][0] + u[1] * hp[j][1], s[2] * hp[j][0] + u[2] * hp[j][1]};
                        Cara k = agregar(caras, new float[][]{suma(ini, oi, 1), suma(ini, oj, 1), suma(fin, oj, 1), suma(fin, oi, 1)}, nrm, 0xFF37474F, false, p.id, 9);
                        if (k != null) k.prof += 0.5f;
                    }
                }
            }
        }
        if (placa) return;
        // huecos de los tubos: un parche oscuro sobre la cara (y en la de enfrente si es pasante)
        for (Pieza.Hueco h : p.huecos) {
            int[] lados = h.pasante ? new int[]{h.cara, opuesta(h.cara)} : new int[]{h.cara};
            for (int cr : lados) {
                float[] nrm, lado1;
                float sobre;
                switch (cr) {
                    case 1: nrm = new float[]{-u[0], -u[1], -u[2]}; lado1 = s; break;
                    case 2: nrm = s; lado1 = u; break;
                    case 3: nrm = new float[]{-s[0], -s[1], -s[2]}; lado1 = u; break;
                    default: nrm = u; lado1 = s;
                }
                sobre = p.alcance(nrm);
                float[] cen = suma(suma(ini, d, h.pos), nrm, sobre + 0.6f);
                if (h.tipo == 3) {   // avellanado: un anillo más claro alrededor
                    Cara an = hacer(circulo(cen, d, lado1, h.d1 * 0.9f, 14), nrm, 0xFF607D8B);
                    if (an != null) { an.prof -= 0.8f; an.borde = false; caras.add(an); }
                }
                float largoH = h.d1, anchoH = h.tipo == 2 ? h.d2 : h.d1;
                float[][] pts;
                if (h.tipo == 0 || h.tipo == 3) pts = circulo(cen, d, lado1, h.d1 / 2, 12);
                else {
                    pts = new float[4][];
                    for (int i = 0; i < 4; i++) {
                        float ca = (i == 0 || i == 3 ? -1 : 1) * largoH / 2, cb = (i < 2 ? -1 : 1) * anchoH / 2;
                        pts[i] = suma(suma(cen, d, ca), lado1, cb);
                    }
                }
                Cara k = hacer(pts, nrm, 0xFF101010);
                if (k != null) { k.prof -= 1; k.borde = false; caras.add(k); }
            }
        }
    }

    private static int opuesta(int cara) { return cara == 0 ? 1 : cara == 1 ? 0 : cara == 2 ? 3 : 2; }

    private static float[][] circulo(float[] cen, float[] a, float[] b, float r, int n) {
        float[][] pts = new float[n][];
        for (int i = 0; i < n; i++) {
            double an = 2 * Math.PI * i / n;
            pts[i] = suma(suma(cen, a, (float) Math.cos(an) * r), b, (float) Math.sin(an) * r);
        }
        return pts;
    }

    static float area(float[][] pol) {
        float a = 0;
        for (int i = 0, j = pol.length - 1; i < pol.length; j = i++) a += pol[j][0] * pol[i][1] - pol[i][0] * pol[j][1];
        return a / 2;
    }

    /** Un hueco perforado en una placa, como polígono (s, u). */
    static float[][] poligonoHueco(Pieza.Hueco h) {
        if (h.tipo == 0 || h.tipo == 3) {
            float[][] r = new float[20][2];
            for (int i = 0; i < 20; i++) { double an = 2 * Math.PI * i / 20; r[i][0] = h.s + (float) Math.cos(an) * h.d1 / 2; r[i][1] = h.u + (float) Math.sin(an) * h.d1 / 2; }
            return r;
        }
        float a = h.d1 / 2, b = (h.tipo == 2 ? h.d2 : h.d1) / 2;
        return new float[][]{{h.s - a, h.u - b}, {h.s + a, h.u - b}, {h.s + a, h.u + b}, {h.s - a, h.u + b}};
    }

    private Cara agregar(List<Cara> caras, float[][] pts, float[] nrm, int base, boolean borde, int pieza, int tipo) {
        float f = deFrente(nrm);
        if (f > 0.02f) return null;   // no se ve: mira para el otro lado
        if (esResaltada(pieza, nrm, 0)) base = 0xFFFF6D00;
        else if (esResaltada(pieza, nrm, 1)) base = 0xFF2979FF;
        float luz = 0.45f + 0.55f * Math.min(1f, -f);
        int col = Color.rgb(Math.round(Color.red(base) * luz), Math.round(Color.green(base) * luz), Math.round(Color.blue(base) * luz));
        Cara k = hacer(pts, nrm, col);
        if (k != null) { k.borde = borde; k.pieza = pieza; k.tipo = tipo; k.nrm = nrm; k.p0 = pts[0]; caras.add(k); }
        return k;
    }

    private Cara hacer(float[][] pts, float[] nrm, int col) {
        if (deFrente(nrm) > 0.02f) return null;
        Cara k = new Cara();
        k.xs = new float[pts.length];
        k.ys = new float[pts.length];
        float pr = 0;
        for (int i = 0; i < pts.length; i++) {
            float[] q = proyectar(pts[i][0], pts[i][1], pts[i][2]);
            k.xs[i] = q[0];
            k.ys[i] = q[1];
            pr += q[2];
        }
        k.prof = pr / pts.length;
        k.color = col;
        return k;
    }

    /** Las flechitas X (rojo), Y (verde), Z (azul) en la esquina. */
    // versión 4.3: el ORBE — una esfera en la esquina; arrastrándola se gira la vista
    private float orbeX() { return getWidth() - dp(48); }
    private float orbeY() { return dp(48); }
    private float orbeR() { return dp(38); }
    private boolean enOrbe(float x, float y) { return Math.hypot(x - orbeX(), y - orbeY()) < orbeR() + dp(8); }
    private boolean girandoOrbe;

    private void dibujarEjes(Canvas c) {
        float ox = orbeX(), oy = orbeY(), R = orbeR(), L = R * 0.72f;
        Paint po = new Paint(Paint.ANTI_ALIAS_FLAG);
        po.setStyle(Paint.Style.FILL);
        po.setColor(girandoOrbe ? 0xCC37474F : 0x9926323A);
        c.drawCircle(ox, oy, R, po);
        po.setColor(0x22FFFFFF);
        c.drawCircle(ox - R * 0.3f, oy - R * 0.3f, R * 0.45f, po);
        po.setStyle(Paint.Style.STROKE);
        po.setStrokeWidth(dp(1.5f));
        po.setColor(girandoOrbe ? 0xFFFFB300 : 0xFF90A4AE);
        c.drawCircle(ox, oy, R, po);
        // el ecuador (el piso) como se ve ahora
        po.setStrokeWidth(dp(1));
        po.setColor(0x88B0BEC5);
        c.drawOval(new android.graphics.RectF(ox - R, oy - R * Math.abs(se), ox + R, oy + R * Math.abs(se)), po);
        float[][] ejes = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int[] col = {0xFFEF5350, 0xFF66BB6A, 0xFF42A5F5};
        String[] nom = {"X", "Y", "Z"};
        for (int i = 0; i < 3; i++) {
            float x1 = ejes[i][0] * cg - ejes[i][1] * sg;
            float y1 = ejes[i][0] * sg + ejes[i][1] * cg;
            float arriba = ejes[i][2] * ce + y1 * se;
            pEje.setColor(col[i]);
            c.drawLine(ox, oy, ox + x1 * L, oy - arriba * L, pEje);
            pTxt.setColor(col[i]);
            c.drawText(nom[i], ox + x1 * (L + dp(6)) - dp(4), oy - arriba * (L + dp(6)) + dp(4), pTxt);
        }
    }

    // ---------------- Dedos ----------------

    private float x0, y0, ax, ay, d0, z0, px0, py0, mx0, my0;
    private boolean dos, movio;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = ax = e.getX(); y0 = ay = e.getY();
                dos = false; movio = false;
                girandoOrbe = enOrbe(x0, y0);
                if (girandoOrbe) { lupa = false; invalidate(); return true; }
                acX = acY = acZ = 0;
                dedoX = x0; dedoY = y0;
                pxEf = panX; pyEf = panY;
                candidata = buscar(x0, y0);
                lupa = true;
                invalidate();
                if (modo == MOVER) {
                    // se arrastra la pieza que está bajo el dedo (o la escogida)
                    int id = buscar(x0, y0);
                    if (id >= 0 && id != escogida) { escogida = id; invalidate(); if (alEscoger != null) alEscoger.escogida(id); }
                }
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dos = true;
                    lupa = false;
                    d0 = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    z0 = zoom; px0 = panX; py0 = panY;
                    mx0 = (e.getX(0) + e.getX(1)) / 2; my0 = (e.getY(0) + e.getY(1)) / 2;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dos && e.getPointerCount() >= 2) {
                    float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    if (d0 > 0) zoom = Math.max(0.2f, Math.min(25f, z0 * d / d0));
                    panX = px0 + (e.getX(0) + e.getX(1)) / 2 - mx0;
                    panY = py0 + (e.getY(0) + e.getY(1)) / 2 - my0;
                    invalidate();
                    return true;
                }
                if (dos) return true;
                float dx = e.getX() - ax, dy = e.getY() - ay;
                if (girandoOrbe) {
                    if (Math.hypot(e.getX() - x0, e.getY() - y0) > dp(4)) movio = true;
                    giro -= dx * 0.45f;
                    elev = Math.max(-89, Math.min(89, elev + dy * 0.45f));
                    ax = e.getX(); ay = e.getY();
                    invalidate();
                    return true;
                }
                if (Math.hypot(e.getX() - x0, e.getY() - y0) > dp(8)) movio = true;
                dedoX = e.getX(); dedoY = e.getY();
                if (movio && !(modo == MOVER && escogida >= 0)) lupa = false;
                if (movio) {
                    if (modo == GIRAR) {
                        giro -= dx * 0.13f;   // versión 4.1: orbitar lento
                        elev = Math.max(-89, Math.min(89, elev + dy * 0.13f));
                    } else if (modo == MOVER && escogida >= 0 && alMover != null) {
                        // de pantalla a mm: derecha de la pantalla y arriba de la pantalla
                        prepararCamara();
                        float kx = dx / esc, ky = -dy / esc;
                        acX += cg * kx + sg * se * ky;
                        acY += -sg * kx + cg * se * ky;
                        acZ += ce * ky;
                        float px = Math.round(acX / 5) * 5f, py = Math.round(acY / 5) * 5f, pz = Math.round(acZ / 5) * 5f;
                        if (px != 0 || py != 0 || pz != 0) { alMover.mover(escogida, px, py, pz); acX -= px; acY -= py; acZ -= pz; }
                    } else {
                        panX += dx;
                        panY += dy;
                    }
                    invalidate();
                }
                ax = e.getX(); ay = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
                if (girandoOrbe) {
                    girandoOrbe = false;
                    if (!movio && dobleToque(e.getX(), e.getY())) enderezar();   // doble toque en el orbe: vista recta
                    invalidate();
                    return true;
                }
                lupa = false;
                candidata = -1;
                invalidate();
                if (!dos && !movio) tocar(e.getX(), e.getY());
                if (modo == MOVER && movio && alMover != null) alMover.soltar();
                return true;
        }
        return true;
    }

    /** Escoge la pieza más cercana al dedo. */
    // versión 4.3: doble toque en la pieza = pivote ahí (la vista gira alrededor de ese punto)
    private boolean pivote;
    private long ultToque;
    private float ultX, ultY;

    private boolean dobleToque(float x, float y) {
        long ahora = System.currentTimeMillis();
        boolean d = ahora - ultToque < 380 && Math.hypot(x - ultX, y - ultY) < dp(36);
        ultToque = d ? 0 : ahora; ultX = x; ultY = y;
        return d;
    }

    private boolean ponerPivote(float x, float y) {
        for (int i = vistas.size() - 1; i >= 0; i--) {
            Cara k = vistas.get(i);
            if (k.pieza < 0 || k.tipo == 9 || k.p0 == null || k.nrm == null || !dentro(k.xs, k.ys, x, y)) continue;
            boolean enHueco = false;
            if (k.hx != null) for (int h = 0; h < k.hx.length; h++) if (dentro(k.hx[h], k.hy[h], x, y)) enHueco = true;
            if (enHueco) continue;
            float[] q = desproyectar(x, y, k.p0, k.nrm);
            centro[0] = q[0]; centro[1] = q[1]; centro[2] = q[2];
            panX = x - getWidth() / 2f;
            panY = y - getHeight() / 2f;
            pivote = true;
            invalidate();
            return true;
        }
        return false;
    }

    /** Doble toque en el Orbe: la vista recta más cercana (cada 45° y piso, esquina o arriba). */
    private void enderezar() {
        giro = Math.round(giro / 45f) * 45f;
        float[] el = {0, 35, 89};
        float mejor = 0;
        for (float v : el) if (Math.abs(Math.abs(elev) - v) < Math.abs(Math.abs(elev) - mejor)) mejor = v;
        elev = Math.signum(elev == 0 ? 1 : elev) * mejor;
        invalidate();
    }

    private void tocar(float x, float y) {
        if (pideToque != null) { pideToque.tocado(x, y); return; }
        if (pideCara == null && dobleToque(x, y) && ponerPivote(x, y)) return;
        if (pideCara != null) { tocarCara(x, y); return; }
        int mejor = buscar(x, y);
        escogida = mejor;
        invalidate();
        if (alEscoger != null) alEscoger.escogida(mejor);
    }

    /** La pieza más cercana al dedo (-1 si ninguna). */
    private int buscar(float x, float y) {
        prepararCamara();
        pxEf = panX; pyEf = panY;
        // versión 4: primero la cara que está bajo el dedo
        for (int i = vistas.size() - 1; i >= 0; i--) {
            Cara k = vistas.get(i);
            if (k.pieza >= 0 && dentro(k.xs, k.ys, x, y)) return k.pieza;
        }
        Map<Integer, Pieza> mapa = mapa();
        int mejor = -1;
        float dist = dp(36);
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] a = proyectar(s[0], s[1], s[2]);
            float[] b = proyectar(s[0] + d[0] * p.largo, s[1] + d[1] * p.largo, s[2] + d[2] * p.largo);
            float vx = b[0] - a[0], vy = b[1] - a[1];
            float l2 = vx * vx + vy * vy;
            float tt = l2 < 1 ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * vx + (y - a[1]) * vy) / l2));
            float dd = (float) Math.hypot(x - (a[0] + vx * tt), y - (a[1] + vy * tt));
            if (dd < dist) { dist = dd; mejor = p.id; }
        }
        return mejor;
    }

    // ---------------- Versión 4.3: los bocetos en su plano ----------------

    private void dibujarHojas(Canvas c) {
        Paint pl = new Paint(Paint.ANTI_ALIAS_FLAG);
        pl.setStyle(Paint.Style.STROKE);
        Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
        pf.setStyle(Paint.Style.FILL);
        for (Hoja h : hojas) {
            if (!h.visible || h.b.vacio()) continue;
            boolean res = h.id == hojaResaltada;
            // las figuras cerradas, sombreadas
            try {
                List<double[][]> pols = new ArrayList<>();
                Editar2D.figuras(h.b, pols);
                Path pa = new Path();
                pa.setFillType(Path.FillType.EVEN_ODD);
                for (double[][] pol : pols) {
                    if (pol == null || pol.length < 3) continue;
                    for (int i = 0; i < pol.length; i++) {
                        float[] q = proyectar(h.mundo(pol[i][0], pol[i][1]));
                        if (i == 0) pa.moveTo(q[0], q[1]); else pa.lineTo(q[0], q[1]);
                    }
                    pa.close();
                }
                pf.setColor(res ? 0x55FFB300 : 0x33CFD8DC);
                c.drawPath(pa, pf);
            } catch (Exception ignored) { }
            pl.setColor(res ? 0xFFFFB300 : 0xFFECEFF1);
            pl.setStrokeWidth(dp(res ? 2.2f : 1.4f));
            for (Boceto.Ent e : h.b.ents) {
                Boceto.Punto a = h.b.puntos.get(e.a);
                if (a == null) continue;
                if (e.tipo == Boceto.LINEA) {
                    Boceto.Punto q = h.b.puntos.get(e.b);
                    if (q == null) continue;
                    float[] p1 = proyectar(h.mundo(a.x, a.y)), p2 = proyectar(h.mundo(q.x, q.y));
                    c.drawLine(p1[0], p1[1], p2[0], p2[1], pl);
                } else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
                    double a1 = 0, barrido = 2 * Math.PI;
                    if (e.tipo == Boceto.ARCO) {
                        Boceto.Punto p1 = h.b.puntos.get(e.b), p2 = h.b.puntos.get(e.c);
                        if (p1 == null || p2 == null) continue;
                        a1 = Math.atan2(p1.y - a.y, p1.x - a.x);
                        barrido = Math.atan2(p2.y - a.y, p2.x - a.x) - a1;
                        while (barrido <= 0) barrido += 2 * Math.PI;
                    }
                    int n = 40;
                    float[] ant = null;
                    for (int i = 0; i <= n; i++) {
                        double an = a1 + barrido * i / n;
                        float[] q = proyectar(h.mundo(a.x + e.r * Math.cos(an), a.y + e.r * Math.sin(an)));
                        if (ant != null) c.drawLine(ant[0], ant[1], q[0], q[1], pl);
                        ant = q;
                    }
                }
            }
            // el nombre del boceto
            float[] o = proyectar(h.mundo(0, 0));
            pTxt.setColor(res ? 0xFFFFB300 : 0xFFB0BEC5);
            c.drawText("✏ " + h.nombre, o[0] + dp(6), o[1] - dp(6), pTxt);
            pTxt.setColor(Color.WHITE);
        }
    }

    private float[] proyectar(float[] p) { return proyectar(p[0], p[1], p[2]); }
}
