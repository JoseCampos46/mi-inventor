package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Mi Inventor 4: amarrar tocando caras, perforar, cortar (inglete y tope), extruir el boceto a placas;
 * boceto 2D paramétrico (en mm) con lupa, imanes, herramientas de modificar, medir y DXF;
 * estructuras 3D en tubo, ángulo y platina (amarradas por cara),
 * y un mini Excel de medidas que manda en los dos. Lista de corte para comprar barras de 6 m.
 */
public class InventorActivity extends Activity {

    private static final String ULTIMO = "_ultimo";
    private static final float BARRA = 6000f, DISCO = 3f;   // barra de 6 m y lo que se come el disco al cortar
    private static final int ABRIR_ARCHIVO = 41, ABRIR_DXF = 42;
    private static final int FONDO = 0xFF151A26;

    private final List<Pieza> piezas = new ArrayList<>();
    private final Medidas medidas = new Medidas();
    private Vista3D vista;
    private VistaBoceto boceto;
    private LinearLayout lista, listaMedidas;
    private FrameLayout contenedor;
    private View panel2D, panel3D, panelMedidas;
    private final TextView[] pestanas = new TextView[3];
    private final List<TextView> botonesModo3D = new ArrayList<>();
    private int esquina3D = -1;
    private boolean ladoDer;
    private String nombreProyecto = "Sin nombre";
    private int escogida = -1;
    private int pestana = 0;
    // versión 4.3: varios bocetos, cada uno en su plano (como en Inventor)
    private final List<Hoja> hojas = new ArrayList<>();
    private Hoja hoja;
    private TextView cabeza2D;

    // deshacer / rehacer: copias livianas del proyecto
    private final List<String> atras = new ArrayList<>(), adelante = new ArrayList<>();

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(FONDO);
        getWindow().setNavigationBarColor(FONDO);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(FONDO);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));

        // pestañas de arriba
        LinearLayout tabs = new LinearLayout(this);
        String[] nt = {"✏ Boceto", "🧩 Montaje", "📊 Medidas"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            pestanas[i] = boton(nt[i], 0xFF37474F, () -> mostrar(k));
            pestanas[i].setTextSize(12);
            tabs.addView(pestanas[i], peso());
        }
        TextView tCorte = boton("📋 Corte", 0xFF43A047, this::listaCorte);
        tCorte.setTextSize(12);
        tabs.addView(tCorte, peso());
        TextView tArch = boton("📂 Archivo", 0xFF6D4C41, this::menuProyecto);
        tArch.setTextSize(12);
        tabs.addView(tArch, peso());
        // versión 4.3: ✕ para cerrar la aplicación (guarda antes)
        TextView tCerrar = boton("✕", 0xFFC62828, this::cerrarApp);
        tCerrar.setTextSize(18);
        LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(42), -1);
        xp.setMargins(dp(2), 0, 0, 0);
        tabs.addView(tCerrar, xp);
        raiz.addView(tabs, new LinearLayout.LayoutParams(-1, dp(44)));

        contenedor = new FrameLayout(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1f);
        cp.topMargin = dp(4);
        raiz.addView(contenedor, cp);
        panel2D = armar2D();
        panel3D = armar3D();
        panelMedidas = armarMedidas();
        contenedor.addView(panel2D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panel3D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panelMedidas, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);

        hojas.add(Hoja.nueva(1, 0));
        hoja = hojas.get(0);
        boceto.b = hoja.b;
        vista.hojas = hojas;
        abrir(ULTIMO, true);
        pestana = getPreferences(MODE_PRIVATE).getInt("pestana", 0);
        mostrar(pestana);
        recalcular();
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardar(ULTIMO, true);
        getPreferences(MODE_PRIVATE).edit().putInt("pestana", pestana).apply();
    }

    private void cerrarApp() {
        new AlertDialog.Builder(this).setMessage("¿Cerrar Mi Inventor? El trabajo queda guardado y al abrir sigue donde iba.")
                .setPositiveButton("✕ Cerrar", (d, w) -> {
                    guardar(ULTIMO, true);
                    getPreferences(MODE_PRIVATE).edit().putInt("pestana", pestana).apply();
                    finish();
                })
                .setNegativeButton("Seguir", null).show();
    }

    @Override
    public void onBackPressed() {
        if (vista.pideToque != null) { vista.pideToque = null; vista.hojaResaltada = -1; vista.invalidate(); aviso("Extruir cancelado"); return; }
        if (barra3D != null && barra3D.getVisibility() == View.VISIBLE) { cerrarPanel(); return; }
        if (pestana == 0 && boceto.modo != VistaBoceto.VER) { listo2D(); return; }
        if (pestana == 0 && (!boceto.sel.isEmpty() || !boceto.selPts.isEmpty())) { boceto.limpiarSeleccion(); return; }
        super.onBackPressed();
    }

    private void mostrar(int k) {
        pestana = k;
        panel2D.setVisibility(k == 0 ? View.VISIBLE : View.GONE);
        panel3D.setVisibility(k == 1 ? View.VISIBLE : View.GONE);
        panelMedidas.setVisibility(k == 2 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) colorear(pestanas[i], i == k ? 0xFF1E88E5 : 0xFF37474F);
        if (k == 2) pintarMedidas();
    }

    // ---------------- Ayudas ----------------

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        colorear(t, color);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private void colorear(TextView t, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
    }

    private LinearLayout fila(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, peso());
        return l;
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private Pieza porId(int id) {
        for (Pieza p : piezas) if (p.id == id) return p;
        return null;
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    private int nuevoId() {
        int m = 0;
        for (Pieza p : piezas) m = Math.max(m, p.id);
        return m + 1;
    }

    // ---------------- Deshacer ----------------

    /** Guarda una copia antes de cambiar algo. */
    private void antes() {
        try {
            atras.add(proyecto().toString());
            if (atras.size() > 60) atras.remove(0);
            adelante.clear();
        } catch (Exception ignored) {}
    }

    private void deshacer() {
        if (atras.isEmpty()) { aviso("No hay nada para deshacer"); return; }
        try {
            adelante.add(proyecto().toString());
            cargar(new JSONObject(atras.remove(atras.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo deshacer"); }
    }

    private void rehacer() {
        if (adelante.isEmpty()) { aviso("No hay nada para rehacer"); return; }
        try {
            atras.add(proyecto().toString());
            cargar(new JSONObject(adelante.remove(adelante.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo rehacer"); }
    }

    /** Volver a la copia que se acaba de guardar (cuando algo no cuadró). */
    private void revertir() {
        if (atras.isEmpty()) return;
        try { cargar(new JSONObject(atras.remove(atras.size() - 1))); } catch (Exception ignored) {}
    }

    // ---------------- Todo se recalcula desde la tablita ----------------

    private void fijos() {
        medidas.fijos.clear();
        float total = 0;
        for (Pieza p : piezas) { medidas.fijos.put("T" + p.id, (double) p.largo); total += p.largo; }
        medidas.fijos.put("total", (double) total);
        medidas.fijos.put("piezas", (double) piezas.size());
    }

    /** Tablita → piezas 3D → boceto 2D. Devuelve true si el boceto cuadró. */
    private boolean recalcular() {
        fijos();
        medidas.calcular();
        String err = null;
        for (Pieza p : piezas) { String e = p.aplicarFormulas(medidas); if (err == null) err = e; }
        fijos();
        medidas.calcular();
        for (Hoja h : hojas) if (h != hoja) h.b.resolver(medidas, -1);
        boolean ok = boceto.b.resolver(medidas, -1);
        boceto.revisar();
        pintarCabeza();
        actualizarPlacas();
        pintarOps();
        boceto.invalidate();
        vista.escogida = escogida;
        vista.invalidate();
        pintarLista();
        if (pestana == 2) pintarMedidas();
        if (err != null) aviso("⚠ " + err);
        return ok;
    }

    // =====================================================================
    //                              BOCETO 2D
    // =====================================================================

    // Versión 3: abajo van 4 grupos (Dibujar, Modificar, Amarrar, Medir); cada uno muestra sus herramientas.
    private static final int G_DIBUJAR = 0, G_MODIFICAR = 1, G_AMARRAR = 2, G_MEDIR = 3;
    private int grupo2D = G_DIBUJAR;
    private final TextView[] botonesGrupo = new TextView[4];
    private LinearLayout cajaHerr, casilla;
    private EditText casilla1, casilla2;
    private TextView casillaEt1, casillaEt2;
    private String herrActiva = "Ver";
    private final Map<String, TextView> botonesHerr = new HashMap<>();
    private double ultDesfase = 50, ultRadio = 20, ultChaflan = 20;

    private View armar2D() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        boceto = new VistaBoceto(this);
        boceto.medidas = medidas;
        boceto.orto = getPreferences(MODE_PRIVATE).getBoolean("orto", false);
        boceto.oyente = new VistaBoceto.Oyente() {
            @Override public void antes() { InventorActivity.this.antes(); }
            @Override public void cambio() { boceto.b.resolver(medidas, -1); boceto.revisar(); pintarCabeza(); boceto.invalidate(); }
            @Override public void pedirCota(Boceto.Restr nueva) { InventorActivity.this.pedirCota(nueva, null); }
            @Override public void pedirDistancia(int p1, int p2) { InventorActivity.this.pedirDistancia(p1, p2); }
            @Override public void editarCota(Boceto.Restr r) { InventorActivity.this.editarCota(r); }
            @Override public void pedirTexto(double x, double y) { InventorActivity.this.pedirTexto(x, y); }
            @Override public void seleccion() { }
            @Override public void aviso(String s) { InventorActivity.this.aviso(s); }
        };
        // versión 4.3: arriba dice qué boceto es, en qué plano y si ya está completo
        cabeza2D = new TextView(this);
        cabeza2D.setTextColor(Color.WHITE);
        cabeza2D.setTextSize(13);
        cabeza2D.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable gc = new GradientDrawable();
        gc.setColor(0xFF1A2F4A);
        gc.setCornerRadius(dp(8));
        cabeza2D.setBackground(gc);
        cabeza2D.setOnClickListener(v -> menuBocetos());
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-1, -2);
        chp.bottomMargin = dp(4);
        l.addView(cabeza2D, chp);
        l.addView(boceto, new LinearLayout.LayoutParams(-1, 0, 1f));

        // la casilla para escribir medidas (línea, rectángulo, círculo, polígono)
        casilla = new LinearLayout(this);
        casilla.setGravity(Gravity.CENTER_VERTICAL);
        casillaEt1 = etiquetaCasilla();
        casilla1 = campoCasilla();
        casillaEt2 = etiquetaCasilla();
        casilla2 = campoCasilla();
        casilla.addView(casillaEt1, new LinearLayout.LayoutParams(-2, -1));
        casilla.addView(casilla1, new LinearLayout.LayoutParams(0, -1, 1f));
        casilla.addView(casillaEt2, new LinearLayout.LayoutParams(-2, -1));
        casilla.addView(casilla2, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView ok = boton("OK", 0xFF2E7D32, this::okCasilla);
        LinearLayout.LayoutParams okp = new LinearLayout.LayoutParams(dp(56), -1);
        okp.leftMargin = dp(4);
        casilla.addView(ok, okp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(46));
        cp.topMargin = dp(4);
        l.addView(casilla, cp);
        casilla.setVisibility(View.GONE);

        // los 4 grupos
        LinearLayout grupos = new LinearLayout(this);
        String[] ng = {"✏ Dibujar", "🛠 Modificar", "🔗 Amarrar", "📐 Medir"};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            botonesGrupo[i] = boton(ng[i], 0xFF37474F, () -> grupo2D(k));
            botonesGrupo[i].setTextSize(13);
            grupos.addView(botonesGrupo[i], peso());
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(40));
        gp.topMargin = dp(4);
        l.addView(grupos, gp);

        cajaHerr = new LinearLayout(this);
        cajaHerr.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHerr, new LinearLayout.LayoutParams(-1, -2));

        // fila fija
        LinearLayout f = new LinearLayout(this);
        f.addView(boton("↶\nAtrás", 0xFF5E35B1, this::deshacer), peso());
        f.addView(boton("↷\nAdelante", 0xFF5E35B1, this::rehacer), peso());
        f.addView(boton("⛶\nVer todo", 0xFF455A64, boceto::encuadrar), peso());
        f.addView(boton("🗑\nBorrar", 0xFFC62828, this::borrar2D), peso());
        f.addView(boton("✓\nListo", 0xFF2E7D32, this::listo2D), peso());
        f.addView(boton("🏁\nTerminar", 0xFF1565C0, this::terminarBoceto), peso());
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(46));
        fp.topMargin = dp(4);
        l.addView(f, fp);
        // versión 4.2: la lista de operaciones (se abre y se cierra)
        l.addView(armarOps());
        svOps = new ScrollView(this);
        listaOps = new LinearLayout(this);
        listaOps.setOrientation(LinearLayout.VERTICAL);
        svOps.addView(listaOps);
        svOps.setVisibility(View.GONE);
        l.addView(svOps, new LinearLayout.LayoutParams(-1, 0, 0.55f));
        grupo2D(G_DIBUJAR);
        return l;
    }

    private TextView etiquetaCasilla() {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    private EditText campoCasilla() {
        EditText e = new EditText(this);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.BLACK);
        e.setHintTextColor(0xFF90A4AE);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(7));
        e.setBackground(g);
        return e;
    }

    /** Muestra el grupo de herramientas (Dibujar, Modificar, Amarrar o Medir). */
    private void grupo2D(int k) {
        grupo2D = k;
        for (int i = 0; i < 4; i++) colorear(botonesGrupo[i], i == k ? (i == G_AMARRAR ? 0xFF00897B : 0xFFFF8F00) : 0xFF37474F);
        cajaHerr.removeAllViews();
        botonesHerr.clear();
        List<Object[]> h = new ArrayList<>();   // {texto, color, acción}
        int gris = 0xFF455A64, verde = 0xFF00897B;
        switch (k) {
            case G_DIBUJAR:
                h.add(new Object[]{"✋\nVer", gris, (Runnable) () -> herr("Ver", VistaBoceto.VER)});
                h.add(new Object[]{"╱\nLínea", gris, (Runnable) () -> herr("Línea", VistaBoceto.LINEA)});
                h.add(new Object[]{"▭\nRectáng.", gris, (Runnable) () -> herr("Rectáng.", VistaBoceto.RECT)});
                h.add(new Object[]{"◯\nCírculo", gris, (Runnable) () -> herr("Círculo", VistaBoceto.CIRCULO)});
                h.add(new Object[]{"◠\nArco", gris, (Runnable) () -> herr("Arco", VistaBoceto.ARCO)});
                h.add(new Object[]{"⬡\nPolígono", gris, (Runnable) () -> herr("Polígono", VistaBoceto.POLIGONO)});
                h.add(new Object[]{"A\nTexto", gris, (Runnable) () -> herr("Texto", VistaBoceto.TEXTO)});
                h.add(new Object[]{"┼\nOrto", boceto.orto ? 0xFF1E88E5 : gris, (Runnable) this::orto});
                break;
            case G_MODIFICAR:
                h.add(new Object[]{"✥\nMover", gris, (Runnable) this::moverSel});
                h.add(new Object[]{"⧉\nCopiar", gris, (Runnable) this::copiarSel});
                h.add(new Object[]{"⟳\nRotar", gris, (Runnable) this::rotarSel});
                h.add(new Object[]{"⇋\nEspejo", gris, (Runnable) this::espejoSel});
                h.add(new Object[]{"⤢\nEscalar", gris, (Runnable) this::escalarSel});
                h.add(new Object[]{"⫽\nDesfase", gris, (Runnable) this::desfase});
                h.add(new Object[]{"✂\nRecortar", gris, (Runnable) this::recortar});
                h.add(new Object[]{"⟷\nExtender", gris, (Runnable) this::extender});
                h.add(new Object[]{"◜\nEmpalme", gris, (Runnable) () -> esquina(true)});
                h.add(new Object[]{"◸\nChaflán", gris, (Runnable) () -> esquina(false)});
                h.add(new Object[]{"⫶\nPartir", gris, (Runnable) this::partir});
                h.add(new Object[]{"▦\nMatriz", gris, (Runnable) this::matriz});
                break;
            case G_AMARRAR:
                h.add(new Object[]{"═\nHorizontal", verde, (Runnable) () -> amarrar(Boceto.HORIZ)});
                h.add(new Object[]{"║\nVertical", verde, (Runnable) () -> amarrar(Boceto.VERT)});
                h.add(new Object[]{"⊥\n90°", verde, (Runnable) () -> amarrar(Boceto.PERP)});
                h.add(new Object[]{"∥\nParalela", verde, (Runnable) () -> amarrar(Boceto.PARAL)});
                h.add(new Object[]{"=\nIgual", verde, (Runnable) () -> amarrar(Boceto.IGUAL)});
                h.add(new Object[]{"⊙\nUnir punto", verde, (Runnable) () -> amarrar(Boceto.COINC)});
                h.add(new Object[]{"◡\nTangente", verde, (Runnable) () -> amarrar(Boceto.TANG)});
                h.add(new Object[]{"📌\nFijo", verde, (Runnable) () -> amarrar(Boceto.FIJO)});
                h.add(new Object[]{"📏\nCota", 0xFF1565C0, (Runnable) () -> herr("Cota", VistaBoceto.COTA)});
                h.add(new Object[]{"∠\nÁngulo", 0xFF1565C0, (Runnable) this::cotaAngulo});
                h.add(new Object[]{"🗑\nQuitar", 0xFFC62828, (Runnable) this::amarrar2D});
                h.add(new Object[]{"👁\nMarcas", boceto.marcas ? 0xFF1E88E5 : gris, (Runnable) () -> { boceto.marcas = !boceto.marcas; boceto.invalidate(); grupo2D(G_AMARRAR); }});
                break;
            default:
                h.add(new Object[]{"✋\nEscoger", gris, (Runnable) () -> herr("Ver", VistaBoceto.VER)});
                h.add(new Object[]{"↔\nDistancia", gris, (Runnable) this::medirDistancia});
                h.add(new Object[]{"▨\nÁrea", gris, (Runnable) this::medirArea});
                h.add(new Object[]{"∠\nÁngulo", gris, (Runnable) this::medirAngulo});
        }
        LinearLayout fila = null;
        for (int i = 0; i < h.size(); i++) {
            if (i % 4 == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
                p.topMargin = dp(4);
                cajaHerr.addView(fila, p);
            }
            Object[] o = h.get(i);
            String txt = (String) o[0];
            TextView t = boton(txt, (Integer) o[1], (Runnable) o[2]);
            t.setTag(o[1]);
            botonesHerr.put(txt.substring(txt.indexOf('\n') + 1), t);
            fila.addView(t, peso());
        }
        if (k == G_AMARRAR || k == G_MEDIR || k == G_MODIFICAR) {
            if (boceto.modo != VistaBoceto.VER) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; }
        }
        boceto.medicion = null;
        boceto.lineaMedida = null;
        marcarHerr();
        mostrarCasilla();
    }

    /** Pone la herramienta de dibujo y la marca en naranja. */
    private void herr(String nombre, int modo) {
        herrActiva = nombre;
        boceto.ponerModo(modo);
        boceto.medicion = null;
        boceto.lineaMedida = null;
        marcarHerr();
        mostrarCasilla();
    }

    private void marcarHerr() {
        for (Map.Entry<String, TextView> e : botonesHerr.entrySet()) {
            TextView t = e.getValue();
            int base = t.getTag() instanceof Integer ? (Integer) t.getTag() : 0xFF455A64;
            colorear(t, e.getKey().equals(herrActiva) ? 0xFFFF8F00 : base);
        }
    }

    private void listo2D() {
        boceto.terminar();
        boceto.ponerModo(VistaBoceto.VER);
        herrActiva = "Ver";
        marcarHerr();
        mostrarCasilla();
        recalcular();
    }

    private void orto() {
        boceto.orto = !boceto.orto;
        getPreferences(MODE_PRIVATE).edit().putBoolean("orto", boceto.orto).apply();
        aviso(boceto.orto ? "Orto prendido: las líneas salen derechas o paradas" : "Orto apagado");
        grupo2D(G_DIBUJAR);
        boceto.invalidate();
    }

    // ---------------- La casilla de medidas ----------------

    private void mostrarCasilla() {
        int m = boceto.modo;
        boolean ver = m == VistaBoceto.LINEA || m == VistaBoceto.RECT || m == VistaBoceto.CIRCULO || m == VistaBoceto.POLIGONO;
        casilla.setVisibility(ver ? View.VISIBLE : View.GONE);
        if (!ver) return;
        casilla2.setVisibility(m == VistaBoceto.CIRCULO ? View.GONE : View.VISIBLE);
        casillaEt2.setVisibility(m == VistaBoceto.CIRCULO ? View.GONE : View.VISIBLE);
        if (m == VistaBoceto.LINEA) { casillaEt1.setText("Largo"); casillaEt2.setText("Ángulo"); casilla1.setHint("mm"); casilla2.setHint("0°"); }
        else if (m == VistaBoceto.RECT) { casillaEt1.setText("Ancho"); casillaEt2.setText("Alto"); casilla1.setHint("mm"); casilla2.setHint("mm"); }
        else if (m == VistaBoceto.CIRCULO) { casillaEt1.setText("Diámetro"); casilla1.setHint("mm o fórmula"); }
        else { casillaEt1.setText("Lados"); casillaEt2.setText("Radio"); casilla1.setText(String.valueOf(boceto.lados)); casilla2.setHint("mm"); }
    }

    /** Evalúa lo escrito: un número o una fórmula de la tablita. */
    private Double valorDe(String txt) {
        String t = txt == null ? "" : txt.trim();
        if (t.isEmpty()) return null;
        Double n = Formula.numero(t);
        if (n != null) return n;
        try { return medidas.evaluar(t); } catch (Exception e) { aviso("⚠ " + e.getMessage()); return null; }
    }

    private void okCasilla() {
        int m = boceto.modo;
        String t1 = casilla1.getText().toString().trim(), t2 = casilla2.getText().toString().trim();
        Double v1 = valorDe(t1);
        if (v1 == null) { if (t1.isEmpty()) aviso("Escriba la medida"); return; }
        String err;
        antes();
        if (m == VistaBoceto.LINEA) {
            Double ang = t2.isEmpty() ? Double.valueOf(0) : valorDe(t2);
            if (ang == null) { atras.remove(atras.size() - 1); return; }
            err = boceto.lineaPorMedida(t1, v1, ang);
        } else if (m == VistaBoceto.RECT) {
            Double v2 = valorDe(t2);
            if (v2 == null) { atras.remove(atras.size() - 1); aviso("Escriba el alto"); return; }
            err = boceto.rectPorMedida(t1, v1, t2, v2);
        } else if (m == VistaBoceto.CIRCULO) {
            err = boceto.circuloPorMedida(t1, v1);
        } else {
            int n = (int) Math.round(v1);
            if (n < 3 || n > 60) { atras.remove(atras.size() - 1); aviso("Los lados van de 3 a 60"); return; }
            boceto.lados = n;
            Double v2 = valorDe(t2);
            if (v2 == null) { atras.remove(atras.size() - 1); aviso("Lados: " + n + ". Ahora toque el centro y una punta, o escriba el radio"); return; }
            err = boceto.poligonoPorMedida(n, v2);
        }
        if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
        if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se puso: choca con otra medida o amarre"); return; }
        if (m == VistaBoceto.LINEA) { casilla1.setText(""); casilla2.setText(""); casilla1.requestFocus(); }
    }

    // ---------------- Modificar ----------------

    private List<Integer> escogidas() {
        List<Integer> l = new ArrayList<>();
        for (Integer id : boceto.sel) if (boceto.b.entPorId(id) != null) l.add(id);
        return l;
    }

    /** Si no hay nada escogido: avisa y deja la hoja en «escoger». */
    private boolean faltaEscoger(String que) {
        if (!escogidas().isEmpty()) return false;
        boceto.ponerModo(VistaBoceto.VER);
        herrActiva = "Ver";
        marcarHerr();
        aviso("Primero toque lo que quiere " + que + " (queda en naranja) y vuelva a tocar el botón");
        return true;
    }

    private VistaBoceto.Pedido pedido(String nombre, VistaBoceto.AlTerminar fin, String... ayudas) {
        herrActiva = nombre;
        marcarHerr();
        VistaBoceto.Pedido p = new VistaBoceto.Pedido(fin, ayudas);
        return p;
    }

    private void moverSel() {
        if (escogidas().isEmpty()) {
            herr("Mover", VistaBoceto.MOVER);
            aviso("Arrastre un punto. Para mover piezas enteras: escójalas primero y toque ✥ Mover");
            return;
        }
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Mover", t -> {
            antes();
            Editar2D.transformar(boceto.b, s, Editar2D.traslado(t.get(1).x - t.get(0).x, t.get(1).y - t.get(0).y), true, 1, false);
            despuesDeModificar("Movido");
        }, "Mover: toque el punto de agarre (por ejemplo una esquina)", "Ahora toque a dónde va ese punto");
        p.fantasma = 1;
        boceto.pedir(p);
    }

    private void copiarSel() {
        if (faltaEscoger("copiar")) return;
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Copiar", t -> {
            antes();
            List<Integer> nuevas = Editar2D.copiar(boceto.b, s, Editar2D.traslado(t.get(1).x - t.get(0).x, t.get(1).y - t.get(0).y), true, 1, false);
            boceto.sel.clear();
            boceto.sel.addAll(nuevas);
            despuesDeModificar("Copiado (la copia quedó escogida)");
        }, "Copiar: toque el punto de agarre", "Ahora toque dónde va la copia");
        p.fantasma = 1;
        boceto.pedir(p);
    }

    private void rotarSel() {
        if (faltaEscoger("rotar")) return;
        List<Integer> s = escogidas();
        boceto.pedir(pedido("Rotar", t -> {
            VistaBoceto.Toque c = t.get(0);
            EditText e = campoTexto("90", "grados");
            e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            dialogo("⟳ Rotar (grados contra el reloj; negativo = con el reloj)", e, "Rotar", () -> {
                Double g = valorDe(e.getText().toString());
                if (g == null) return;
                antes();
                int d = Editar2D.giroDerecho(g);
                Editar2D.transformar(boceto.b, s, Editar2D.giro(c.x, c.y, g), d >= 0, 1, d == 1);
                despuesDeModificar("Rotado " + Formula.n(g) + "°");
            });
        }, "Rotar: toque el punto alrededor del cual gira"));
    }

    private void espejoSel() {
        if (faltaEscoger("voltear en espejo")) return;
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Espejo", t -> {
            double ax = t.get(0).x, ay = t.get(0).y, bx = t.get(1).x, by = t.get(1).y;
            if (Math.hypot(bx - ax, by - ay) < 0.5) { aviso("Los dos puntos del espejo deben ser distintos"); return; }
            boolean derecho = Math.abs(bx - ax) < 1e-6 || Math.abs(by - ay) < 1e-6;
            new AlertDialog.Builder(this).setTitle("⇋ Espejo")
                    .setItems(new String[]{"Dejar el original y la copia", "Quitar el original"}, (d, w) -> {
                        antes();
                        List<Integer> nuevas = Editar2D.copiar(boceto.b, s, Editar2D.espejo(ax, ay, bx, by), derecho, 1, false);
                        if (w == 1) for (Integer id : s) { Boceto.Ent e = boceto.b.entPorId(id); if (e != null) boceto.b.borrar(e); }
                        boceto.sel.clear();
                        boceto.sel.addAll(nuevas);
                        despuesDeModificar("Espejo hecho");
                    }).setNegativeButton("Cancelar", null).show();
        }, "Espejo: toque el primer punto de la línea del espejo", "Ahora toque el segundo punto de la línea del espejo");
        p.fantasma = 2;
        boceto.pedir(p);
    }

    private void escalarSel() {
        if (faltaEscoger("agrandar o achicar")) return;
        List<Integer> s = escogidas();
        boceto.pedir(pedido("Escalar", t -> {
            VistaBoceto.Toque c = t.get(0);
            EditText e = campoTexto("2", "");
            dialogo("⤢ Escalar: cuántas veces (2 = el doble, 0.5 = la mitad)", e, "Escalar", () -> {
                Double f = valorDe(e.getText().toString());
                if (f == null || f <= 0) { aviso("Escriba un número mayor que cero"); return; }
                antes();
                Editar2D.transformar(boceto.b, s, Editar2D.escala(c.x, c.y, f), true, f, false);
                despuesDeModificar("Escalado ×" + Formula.n(f));
            });
        }, "Escalar: toque el punto que se queda quieto"));
    }

    private void desfase() {
        EditText e = campoTexto(Formula.n(ultDesfase), "mm");
        dialogo("⫽ Desfase: a cuántos mm (o fórmula, ej. tubo)", e, "Seguir", () -> {
            Double d = valorDe(e.getText().toString());
            if (d == null || d <= 0) { aviso("Escriba una distancia mayor que cero"); return; }
            ultDesfase = d;
            VistaBoceto.Pedido p = pedido("Desfase", t -> {
                antes();
                String err = Editar2D.desfase(boceto.b, t.get(0).ent, d, t.get(1).x, t.get(1).y);
                if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
                despuesDeModificar(null);
            }, "Desfase " + Formula.n(d) + " mm: toque la línea, el círculo o el arco (una línea de un rectángulo desfasa todo el rectángulo)",
                    "Ahora toque hacia qué lado (adentro o afuera)");
            p.quiereEnt[0] = true;
            p.repetir = true;
            p.linea = false;
            boceto.pedir(p);
        });
    }

    private void recortar() {
        VistaBoceto.Pedido p = pedido("Recortar", t -> {
            antes();
            String err = Editar2D.recortar(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Recortar: toque el pedazo que sobra (se corta hasta donde cruza con otra cosa). Siga tocando; termine con ✓ Listo");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void extender() {
        VistaBoceto.Pedido p = pedido("Extender", t -> {
            antes();
            String err = Editar2D.extender(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Extender: toque la línea cerca de la punta que quiere alargar (llega hasta lo primero que encuentre)");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void partir() {
        VistaBoceto.Pedido p = pedido("Partir", t -> {
            antes();
            String err = Editar2D.partir(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Partir: toque la línea donde la quiere partir (sirve el imán de la mitad)");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void esquina(boolean redondo) {
        EditText e = campoTexto(Formula.n(redondo ? ultRadio : ultChaflan), "mm");
        dialogo(redondo ? "◜ Empalme: radio (mm o fórmula)" : "◸ Chaflán: cuánto se corta en cada lado (mm)", e, "Seguir", () -> {
            Double v = valorDe(e.getText().toString());
            if (v == null || v <= 0) { aviso("Escriba una medida mayor que cero"); return; }
            if (redondo) ultRadio = v; else ultChaflan = v;
            VistaBoceto.Pedido p = pedido(redondo ? "Empalme" : "Chaflán", t -> {
                antes();
                String err = Editar2D.esquina(boceto.b, t.get(0).punto, v, redondo);
                if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
                despuesDeModificar(null);
            }, (redondo ? "Empalme R" : "Chaflán ") + Formula.n(v) + ": toque la esquina (el punto donde se juntan dos líneas)");
            p.quierePunto[0] = true;
            p.repetir = true;
            p.linea = false;
            boceto.pedir(p);
        });
    }

    private void matriz() {
        if (faltaEscoger("repetir")) return;
        List<Integer> s = escogidas();
        new AlertDialog.Builder(this).setTitle("▦ Matriz: repetir lo escogido")
                .setItems(new String[]{"▦ En filas y columnas", "◎ En círculo"}, (d, w) -> {
                    if (w == 0) matrizFilas(s); else matrizCirculo(s);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void matrizFilas(List<Integer> s) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Columnas (cuántas a lo ancho, contando la original)"));
        EditText col = campoTexto("4", ""); l.addView(col);
        l.addView(etiqueta("Distancia entre columnas (mm, negativo = a la izquierda)"));
        EditText dx = campoTexto("100", ""); l.addView(dx);
        l.addView(etiqueta("Filas (cuántas hacia arriba, contando la original)"));
        EditText fil = campoTexto("1", ""); l.addView(fil);
        l.addView(etiqueta("Distancia entre filas (mm, negativo = hacia abajo)"));
        EditText dy = campoTexto("100", ""); l.addView(dy);
        new AlertDialog.Builder(this).setTitle("▦ Matriz en filas y columnas").setView(l)
                .setPositiveButton("Hacer", (d, w) -> {
                    Double c = valorDe(col.getText().toString()), f = valorDe(fil.getText().toString());
                    Double x = valorDe(dx.getText().toString()), y = valorDe(dy.getText().toString());
                    if (c == null || f == null || x == null || y == null) return;
                    int nc = (int) Math.round(c), nf = (int) Math.round(f);
                    if (nc < 1 || nf < 1 || nc * nf > 400) { aviso("Entre 1 y 400 copias en total"); return; }
                    antes();
                    for (int i = 0; i < nc; i++) for (int j = 0; j < nf; j++) {
                        if (i == 0 && j == 0) continue;
                        Editar2D.copiar(boceto.b, s, Editar2D.traslado(i * x, j * y), true, 1, false);
                    }
                    despuesDeModificar((nc * nf - 1) + " copias");
                }).setNegativeButton("Cancelar", null).show();
    }

    private void matrizCirculo(List<Integer> s) {
        boceto.pedir(pedido("Matriz", t -> {
            VistaBoceto.Toque c = t.get(0);
            LinearLayout l = new LinearLayout(this);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setPadding(dp(18), dp(4), dp(18), 0);
            l.addView(etiqueta("Cuántas en total (contando la original)"));
            EditText n = campoTexto("6", ""); l.addView(n);
            l.addView(etiqueta("Ángulo que ocupan (360 = la vuelta completa)"));
            EditText g = campoTexto("360", ""); l.addView(g);
            new AlertDialog.Builder(this).setTitle("◎ Matriz en círculo").setView(l)
                    .setPositiveButton("Hacer", (d, w) -> {
                        Double nn = valorDe(n.getText().toString()), gg = valorDe(g.getText().toString());
                        if (nn == null || gg == null) return;
                        int k = (int) Math.round(nn);
                        if (k < 2 || k > 360) { aviso("Entre 2 y 360"); return; }
                        double paso = Math.abs(gg - 360) < 1e-6 ? 360.0 / k : gg / (k - 1);
                        antes();
                        for (int i = 1; i < k; i++) {
                            int dd = Editar2D.giroDerecho(paso * i);
                            Editar2D.copiar(boceto.b, s, Editar2D.giro(c.x, c.y, paso * i), dd >= 0, 1, dd == 1);
                        }
                        despuesDeModificar((k - 1) + " copias en círculo");
                    }).setNegativeButton("Cancelar", null).show();
        }, "Matriz en círculo: toque el centro"));
    }

    /** Después de modificar: se resuelve; si algo no cuadró se avisa (se puede deshacer). */
    private void despuesDeModificar(String ok) {
        boolean bien = recalcular();
        if (!bien) aviso("⚠ Quedó algo que no cuadra con las medidas o amarres. Toque ↶ Atrás si no le gusta");
        else if (ok != null) aviso("✔ " + ok);
        if (boceto.pedido == null) { herrActiva = "Ver"; marcarHerr(); }
    }

    private void dialogo(String titulo, View v, String si, Runnable r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(v);
        new AlertDialog.Builder(this).setTitle(titulo).setView(l)
                .setPositiveButton(si, (d, w) -> r.run())
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Amarrar (botones directos) ----------------

    private void amarrar(int tipo) {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null) s.add(e); }
        List<Integer> pts = new ArrayList<>();
        for (Integer id : boceto.selPts) if (bb.puntos.containsKey(id)) pts.add(id);
        if (boceto.modo != VistaBoceto.VER) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; marcarHerr(); mostrarCasilla(); }
        String falta = null;
        switch (tipo) {
            case Boceto.HORIZ: case Boceto.VERT: {
                List<Boceto.Ent> ls = new ArrayList<>();
                for (Boceto.Ent e : s) if (e.tipo == Boceto.LINEA) ls.add(e);
                if (ls.isEmpty()) { falta = "Toque una o varias líneas"; break; }
                antes();
                for (Boceto.Ent e : ls) {
                    bb.restr.removeIf(r -> (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == e.id);
                    bb.restriccion(tipo, e.id, -1, -1, -1, null);
                }
                terminarAmarre();
                return;
            }
            case Boceto.PERP: case Boceto.PARAL:
                if (s.size() != 2 || s.get(0).tipo != Boceto.LINEA || s.get(1).tipo != Boceto.LINEA) { falta = "Toque exactamente dos líneas"; break; }
                poner(tipo, s.get(0).id, s.get(1).id, -1, -1);
                boceto.limpiarSeleccion();
                return;
            case Boceto.IGUAL:
                if (s.size() < 2) { falta = "Toque dos o más líneas (o círculos)"; break; }
                {
                    boolean lineas = s.get(0).tipo == Boceto.LINEA;
                    for (Boceto.Ent e : s) if ((e.tipo == Boceto.LINEA) != lineas || e.tipo == Boceto.TEXTO) { falta = "Todas deben ser líneas, o todas círculos y arcos"; break; }
                    if (falta != null) break;
                    antes();
                    for (int i = 1; i < s.size(); i++) bb.restriccion(Boceto.IGUAL, s.get(0).id, s.get(i).id, -1, -1, null);
                    terminarAmarre();
                    return;
                }
            case Boceto.COINC:
                if (pts.size() == 2) { poner(Boceto.COINC, -1, -1, pts.get(0), pts.get(1)); boceto.limpiarSeleccion(); return; }
                if (pts.size() == 1 && s.size() == 1 && s.get(0).tipo != Boceto.TEXTO) { poner(Boceto.SOBRE, s.get(0).id, -1, pts.get(0), -1); boceto.limpiarSeleccion(); return; }
                falta = "Toque dos puntos (quedan unidos), o un punto y una línea (el punto queda sobre la línea)";
                break;
            case Boceto.TANG: {
                Boceto.Ent ln = null, ci = null;
                for (Boceto.Ent e : s) { if (e.tipo == Boceto.LINEA) ln = e; else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) ci = e; }
                if (s.size() != 2 || ln == null || ci == null) { falta = "Toque una línea y un círculo (o arco)"; break; }
                poner(Boceto.TANG, ln.id, ci.id, -1, -1);
                boceto.limpiarSeleccion();
                return;
            }
            case Boceto.FIJO:
                if (pts.isEmpty()) { falta = "Toque uno o dos puntos para dejarlos fijos (o sueltos si ya estaban fijos)"; break; }
                antes();
                for (Integer p : pts) {
                    boolean ya = false;
                    for (Boceto.Restr r : bb.restr) if (r.tipo == Boceto.FIJO && r.p1 == p) ya = true;
                    if (ya) bb.restr.removeIf(r -> r.tipo == Boceto.FIJO && r.p1 == p);
                    else bb.restriccion(Boceto.FIJO, -1, -1, p, -1, null);
                }
                terminarAmarre();
                return;
        }
        if (falta != null) aviso(falta);
    }

    private void terminarAmarre() {
        if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)"); return; }
        boceto.limpiarSeleccion();
    }

    private void cotaAngulo() {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) s.add(e); }
        if (s.size() != 2) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; marcarHerr(); aviso("Toque dos líneas y luego ∠ Ángulo"); return; }
        Boceto.Restr r = new Boceto.Restr();
        r.tipo = Boceto.C_ANG; r.e1 = s.get(0).id; r.e2 = s.get(1).id;
        pedirCota(r, null);
        boceto.limpiarSeleccion();
    }

    // ---------------- Medir ----------------

    private void mostrarMedida(String txt, double[] linea) {
        boceto.medicion = txt;
        boceto.lineaMedida = linea;
        boceto.invalidate();
    }

    private void medirDistancia() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Distancia", t -> {
            double ax = t.get(0).x, ay = t.get(0).y, bx = t.get(1).x, by = t.get(1).y;
            double d = Math.hypot(bx - ax, by - ay), g = Math.toDegrees(Math.atan2(by - ay, bx - ax));
            mostrarMedida("Distancia " + Formula.n(Math.round(d * 10) / 10.0) + " mm · ↔ " + Formula.n(Math.round(Math.abs(bx - ax) * 10) / 10.0)
                    + " · ↕ " + Formula.n(Math.round(Math.abs(by - ay) * 10) / 10.0) + " · " + Formula.n(Math.round(g * 10) / 10.0) + "°", new double[]{ax, ay, bx, by});
        }, "Distancia: toque el primer punto", "Ahora toque el segundo punto");
        p.repetir = true;
        boceto.pedir(p);
    }

    private void medirArea() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Área", t -> {
            double[] a = Editar2D.area(boceto.b, t.get(0).x, t.get(0).y);
            if (a == null) { mostrarMedida(null, null); aviso("Toque adentro de una figura cerrada (rectángulo, polígono o círculo)"); return; }
            mostrarMedida("Área " + String.format(Locale.US, "%.3f", a[0] / 1e6) + " m² (" + Formula.n(Math.round(a[0])) + " mm²) · Perímetro "
                    + Formula.n(Math.round(a[1] * 10) / 10.0) + " mm", null);
        }, "Área: toque adentro de una figura cerrada");
        p.repetir = true;
        p.linea = false;
        p.crudo = true;
        boceto.pedir(p);
    }

    private void medirAngulo() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Ángulo", t -> {
            Boceto.Ent e = boceto.b.entPorId(t.get(0).ent), f = boceto.b.entPorId(t.get(1).ent);
            if (e == null || f == null || e.tipo != Boceto.LINEA || f.tipo != Boceto.LINEA) { aviso("Toque dos líneas"); return; }
            double g = Editar2D.anguloEntre(boceto.b, e, f);
            mostrarMedida("Ángulo " + Formula.n(Math.round(g * 10) / 10.0) + "° (el otro lado " + Formula.n(Math.round((180 - g) * 10) / 10.0) + "°)", null);
        }, "Ángulo: toque la primera línea", "Ahora toque la segunda línea");
        p.quiereEnt[0] = true;
        p.quiereEnt[1] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private EditText campoTexto(String valor, String pista) {
        EditText e = new EditText(this);
        e.setText(valor);
        e.setHint(pista);
        e.setTextSize(18);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setSelection(e.getText().length());
        return e;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(0xFF90A4AE);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    /** Escribir el valor de una cota nueva: un número (mm) o una fórmula de la tablita; y si quiere, ponerle nombre. */
    private void pedirCota(Boceto.Restr nueva, String sugerido) {
        Boceto bb = boceto.b;
        double actual = bb.medir(nueva);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Medida en mm, o fórmula (ej. ancho - 2*tubo)"));
        EditText val = campoTexto(sugerido != null ? sugerido : Formula.n(actual), "");
        l.addView(val);
        l.addView(etiqueta("Nombre para la tablita (opcional, ej. ancho)"));
        EditText nom = campoTexto("", "sin nombre");
        l.addView(nom);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[nueva.tipo]).setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String v = val.getText().toString().trim();
                    if (v.isEmpty()) return;
                    String n = nom.getText().toString().trim();
                    antes();
                    if (!n.isEmpty()) {
                        String ok = Medidas.nombreValido(n);
                        if (ok == null) { aviso("Ese nombre no sirve: use letras y números, sin espacios"); atras.remove(atras.size() - 1); return; }
                        Medidas.Fila f = medidas.buscar(ok);
                        if (f == null) { f = new Medidas.Fila(ok, v); medidas.filas.add(f); } else f.formula = v;
                        nueva.formula = ok;
                    } else nueva.formula = v;
                    bb.restr.add(nueva);
                    if (!recalcular() || nueva.error != null) {
                        String por = nueva.error != null ? nueva.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se puso: " + por);
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirDistancia(int p1, int p2) {
        new AlertDialog.Builder(this).setTitle("📏 Distancia entre los dos puntos")
                .setItems(new String[]{"↔ Horizontal", "↕ Vertical", "⤢ Alineada (en línea recta)"}, (d, w) -> {
                    Boceto.Restr r = new Boceto.Restr();
                    r.tipo = w == 0 ? Boceto.C_HORIZ : w == 1 ? Boceto.C_VERT : Boceto.C_DIST;
                    r.p1 = p1; r.p2 = p2;
                    pedirCota(r, null);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void editarCota(Boceto.Restr r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Hoy mide " + boceto.textoCota(r) + (r.error != null ? "\n⚠ " + r.error : "")));
        l.addView(etiqueta("Nuevo valor (mm) o fórmula"));
        EditText val = campoTexto(r.formula, "");
        l.addView(val);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[r.tipo]).setView(l)
                .setPositiveButton("Cambiar", (d, w) -> {
                    String v = val.getText().toString().trim();
                    if (v.isEmpty() || v.equals(r.formula)) return;
                    antes();
                    int i = boceto.b.restr.indexOf(r);
                    // si la cota es solo el nombre de una fila, se cambia la fila (así se mueve todo lo que la usa)
                    Medidas.Fila f = medidas.buscar(r.formula);
                    if (f != null && Formula.numero(v) != null) f.formula = v; else r.formula = v;
                    boolean ok = recalcular();
                    Boceto.Restr rr = i >= 0 && i < boceto.b.restr.size() ? boceto.b.restr.get(i) : r;
                    if (!ok || rr.error != null) {
                        String por = rr.error != null ? rr.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se cambió: " + por);
                    }
                })
                .setNeutralButton("🗑 Quitar cota", (d, w) -> { antes(); boceto.b.restr.remove(r); recalcular(); })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirTexto(double x, double y) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        EditText t = campoTexto("", "Ej. COCINA");
        l.addView(t);
        l.addView(etiqueta("Alto de la letra (mm)"));
        EditText al = campoTexto("150", "");
        al.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(al);
        new AlertDialog.Builder(this).setTitle("A Texto").setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String s = t.getText().toString().trim();
                    if (s.isEmpty()) return;
                    antes();
                    Boceto.Punto p = boceto.b.punto(x, y);
                    Boceto.Ent e = boceto.b.ent(Boceto.TEXTO);
                    e.a = p.id;
                    e.texto = s;
                    Double h = Formula.numero(al.getText().toString());
                    e.r = h == null || h <= 0 ? 150 : h;
                    boceto.invalidate();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🗑 Quitar: los amarres y cotas de lo escogido, para quitar el que sobre. */
    private void amarrar2D() {
        Boceto bb = boceto.b;
        Set<Integer> s = new HashSet<>(boceto.sel), pts = new HashSet<>(boceto.selPts);
        List<Boceto.Restr> suyas = new ArrayList<>();
        for (Boceto.Restr r : bb.restr) {
            boolean es = s.contains(r.e1) || s.contains(r.e2) || pts.contains(r.p1) || pts.contains(r.p2);
            if (s.isEmpty() && pts.isEmpty()) es = true;
            if (es) suyas.add(r);
        }
        if (suyas.isEmpty()) {
            aviso(s.isEmpty() && pts.isEmpty() ? "No hay amarres ni cotas" : "Eso que escogió no tiene amarres ni cotas");
            return;
        }
        String[] nom = new String[suyas.size()];
        for (int i = 0; i < nom.length; i++) {
            Boceto.Restr r = suyas.get(i);
            nom[i] = "🗑 " + Boceto.NOMBRES[r.tipo] + (r.esCota() ? " (" + boceto.textoCota(r) + ")" : "");
        }
        new AlertDialog.Builder(this).setTitle(s.isEmpty() && pts.isEmpty() ? "🗑 Quitar (todos los amarres)" : "🗑 Quitar amarre de lo escogido")
                .setItems(nom, (d, w) -> { antes(); bb.restr.remove(suyas.get(w)); recalcular(); })
                .setNegativeButton("Cerrar", null).show();
    }

    private void poner(int tipo, int e1, int e2, int p1, int p2) {
        antes();
        boceto.b.restriccion(tipo, e1, e2, p1, p2, null);
        if (!recalcular()) {
            revertir();
            recalcular();
            aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)");
        }
    }

    private void borrar2D() {
        Boceto bb = boceto.b;
        if (boceto.sel.isEmpty() && boceto.selPts.isEmpty()) { aviso("Con ✋ Ver toque lo que quiere borrar"); return; }
        antes();
        for (Integer id : new ArrayList<>(boceto.sel)) { Boceto.Ent e = bb.entPorId(id); if (e != null) bb.borrar(e); }
        for (Integer p : new ArrayList<>(boceto.selPts)) {
            for (Boceto.Ent e : new ArrayList<>(bb.ents)) if (e.a == p || e.b == p || e.c == p) bb.borrar(e);
            bb.puntos.remove(p);
            bb.limpiarPuntos();
        }
        boceto.limpiarSeleccion();
        recalcular();
    }

    /** El boceto en PDF tamaño carta, todo en negro nítido, con su escala. */
    private void pdf2D() {
        if (boceto.b.vacio()) { aviso("El boceto está vacío"); return; }
        try {
            PdfDocument doc = new PdfDocument();
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create());
            Canvas c = pg.getCanvas();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTextSize(13);
            p.setFakeBoldText(true);
            c.drawText("MI INVENTOR · " + nombreProyecto, 40, 45, p);
            p.setFakeBoldText(false);
            p.setTextSize(9.5f);
            boceto.imprimir(c, 36, 60, 540, 640);
            double esc = boceto.escalaImpresa;   // puntos de papel por mm
            long e = Math.max(1, Math.round(1 / (esc / 72.0 * 25.4)));
            c.drawText("Medidas en milímetros · Escala aprox. 1:" + e + " · " + new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "CO")).format(new Date()), 40, 735, p);
            // las medidas con nombre de la tablita, abajo
            StringBuilder sb = new StringBuilder();
            for (Medidas.Fila f : medidas.filas) {
                Double v = medidas.valorDe(f.nombre);
                if (sb.length() > 0) sb.append("   ");
                sb.append(f.nombre).append(" = ").append(v == null ? "⚠" : Formula.n(v));
            }
            if (sb.length() > 0) c.drawText(sb.length() > 110 ? sb.substring(0, 110) + "…" : sb.toString(), 40, 752, p);
            Paint marco = new Paint();
            marco.setStyle(Paint.Style.STROKE);
            marco.setColor(Color.BLACK);
            marco.setStrokeWidth(1);
            c.drawRect(30, 55, 582, 720, marco);
            doc.finishPage(pg);
            guardarPdf(doc, "MiInventor_Plano_");
        } catch (Exception ex) {
            aviso("No se pudo hacer el PDF");
        }
    }

    private void guardarPdf(PdfDocument doc, String prefijo) throws Exception {
        ContentValues cv = new ContentValues();
        String nom = prefijo + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".pdf";
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        try (OutputStream o = getContentResolver().openOutputStream(u)) { doc.writeTo(o); }
        doc.close();
        aviso("✔ PDF guardado en Descargas/MiBarra/MiInventor");
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception ignored) {}
    }

    // =====================================================================
    //                              MEDIDAS (mini Excel)
    // =====================================================================

    private View armarMedidas() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView ay = new TextView(this);
        ay.setText("Cada medida tiene nombre y fórmula. Las cotas del 2D y las piezas del 3D pueden usar estos nombres: "
                + "cambia un número y se rehace todo. Funciones: redondear( ), arriba( ), abajo( ), min( ; ), max( ; ), si(cond; sí; no).");
        ay.setTextColor(0xFFB0BEC5);
        ay.setTextSize(13);
        ay.setPadding(dp(6), dp(4), dp(6), dp(6));
        l.addView(ay);
        ScrollView sv = new ScrollView(this);
        listaMedidas = new LinearLayout(this);
        listaMedidas.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listaMedidas);
        l.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout acc = fila(
                boton("➕ Agregar medida", 0xFF00897B, () -> editarFila(null)),
                boton("💬 WhatsApp", 0xFF25A244, () -> compartirTexto(textoMedidas())),
                boton("↶ Atrás", 0xFF5E35B1, this::deshacer));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(46));
        ap.topMargin = dp(4);
        l.addView(acc, ap);
        return l;
    }

    private void pintarMedidas() {
        listaMedidas.removeAllViews();
        if (medidas.filas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay medidas. Toque ➕ Agregar medida, o en el 2D ponga una cota y escríbale un nombre.\n\n"
                    + "Ejemplo:\n  ancho = 4000\n  tubo = 40\n  travesano = ancho - 2*tubo\n  tubos_6m = arriba(total / 6000)");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            listaMedidas.addView(t);
        }
        int n = 1;
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            String err = medidas.errorDe(f.nombre);
            boolean soloNumero = Formula.numero(f.formula) != null;
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(err != null ? 0xFF4A1C1C : 0xFF1E2A3A);
            g.setCornerRadius(dp(8));
            r.setBackground(g);
            TextView num = new TextView(this);
            num.setText(String.valueOf(n++));
            num.setTextColor(0xFF78909C);
            num.setTextSize(12);
            r.addView(num, new LinearLayout.LayoutParams(dp(22), -2));
            TextView t = new TextView(this);
            t.setText(f.nombre + (soloNumero ? "" : "\n= " + f.formula));
            t.setTextColor(Color.WHITE);
            t.setTextSize(15);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView val = new TextView(this);
            val.setText(err != null ? "⚠ " + err : Formula.n(v == null ? 0 : v));
            val.setTextColor(err != null ? 0xFFFF8A80 : 0xFFFFD54A);
            val.setTextSize(err != null ? 12 : 17);
            val.setTypeface(Typeface.DEFAULT_BOLD);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(err != null ? dp(150) : -2, -2));
            r.setOnClickListener(x -> editarFila(f));
            r.setOnLongClickListener(x -> {
                new AlertDialog.Builder(this).setMessage("¿Borrar la medida «" + f.nombre + "»? Lo que la use quedará con error.")
                        .setPositiveButton("Borrar", (d, w) -> { antes(); medidas.filas.remove(f); recalcular(); })
                        .setNegativeButton("Cancelar", null).show();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            listaMedidas.addView(r, lp);
        }
        // los valores que pone la app
        TextView sub = new TextView(this);
        StringBuilder s = new StringBuilder("Valores de la app (solo leer):\n");
        for (Map.Entry<String, Double> e : medidas.fijos.entrySet()) s.append(e.getKey()).append(" = ").append(Formula.n(e.getValue())).append("   ");
        sub.setText(s.toString().trim());
        sub.setTextColor(0xFF90A4AE);
        sub.setTextSize(13);
        sub.setPadding(dp(8), dp(12), dp(8), dp(8));
        listaMedidas.addView(sub);
    }

    private void editarFila(Medidas.Fila f) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Nombre (sin espacios, ej. ancho)"));
        EditText nom = campoTexto(f == null ? "" : f.nombre, "ancho");
        l.addView(nom);
        l.addView(etiqueta("Valor o fórmula (ej. 4000  ·  ancho - 2*tubo)"));
        EditText fo = campoTexto(f == null ? "" : f.formula, "4000");
        l.addView(fo);
        new AlertDialog.Builder(this).setTitle(f == null ? "➕ Medida nueva" : "✏ " + f.nombre).setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = Medidas.nombreValido(nom.getText().toString());
                    String v = fo.getText().toString().trim();
                    if (n == null) { aviso("El nombre debe empezar con letra, sin espacios ni signos (y no puede ser T1, total…)"); return; }
                    if (v.isEmpty()) { aviso("Escriba el valor o la fórmula"); return; }
                    Medidas.Fila otra = medidas.buscar(n);
                    if (otra != null && otra != f) { aviso("Ya hay una medida «" + n + "»"); return; }
                    antes();
                    String viejo = f == null ? null : f.nombre;
                    Medidas.Fila x = f == null ? new Medidas.Fila() : f;
                    x.nombre = n;
                    x.formula = v;
                    if (f == null) medidas.filas.add(x);
                    // si cambió el nombre, se cambia también donde se usaba
                    if (viejo != null && !Formula.plano(viejo).equals(Formula.plano(n))) renombrar(viejo, n);
                    if (!recalcular()) {
                        revertir();
                        recalcular();
                        aviso("⚠ Con ese valor el dibujo no cuadra: no se cambió");
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Cambia un nombre dentro de todas las fórmulas. */
    private void renombrar(String viejo, String nuevo) {
        String re = "(?i)(?<![\\p{L}\\p{N}_])" + java.util.regex.Pattern.quote(viejo) + "(?![\\p{L}\\p{N}_])";
        for (Medidas.Fila f : medidas.filas) f.formula = f.formula.replaceAll(re, nuevo);
        for (Boceto.Restr r : boceto.b.restr) r.formula = r.formula.replaceAll(re, nuevo);
        for (Pieza p : piezas) for (Map.Entry<String, String> e : p.f.entrySet()) e.setValue(e.getValue().replaceAll(re, nuevo));
    }

    private String textoMedidas() {
        StringBuilder s = new StringBuilder("MI INVENTOR · MEDIDAS · ").append(nombreProyecto).append("\n\n");
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            s.append(f.nombre).append(" = ");
            if (Formula.numero(f.formula) == null) s.append(f.formula).append(" = ");
            s.append(v == null ? "⚠ error" : Formula.n(v)).append(" mm\n");
        }
        return s.toString();
    }

    // =====================================================================
    //                              3D
    // =====================================================================

    private boolean movioPieza;

    private View armar3D() {
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        vista = new Vista3D(this);
        vista.piezas = piezas;
        vista.alEscoger = id -> { escogida = id; pintarLista(); };
        vista.alMover = new Vista3D.AlMover() {
            @Override public void mover(int id, float dx, float dy, float dz) {
                Pieza p = porId(id);
                if (p == null) return;
                if (!movioPieza) { antes(); movioPieza = true; }
                p.cx += dx; p.cy += dy; p.cz += dz;
                p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                vista.invalidate();
            }
            @Override public void soltar() { movioPieza = false; pintarLista(); }
        };
        raiz.addView(vista, new LinearLayout.LayoutParams(-1, 0, 1.15f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(4);
        raiz.addView(armarPanel3D(), pp);

        LinearLayout vistas = new LinearLayout(this);
        TextView b3d = boton("🧊 3D 1/4", 0xFF37474F, null);
        b3d.setOnClickListener(x -> {
            // versión 4.2: cada toque mira desde otra esquina
            esquina3D = (esquina3D + 1) % 4;
            vista.vista(-35 + 90 * esquina3D, 25);
            b3d.setText("🧊 3D " + (esquina3D + 1) + "/4");
        });
        vistas.addView(b3d, peso());
        vistas.addView(boton("Frente", 0xFF37474F, () -> vista.vista(0, 0)), peso());
        TextView bLado = boton("Lado ⇄", 0xFF37474F, null);
        bLado.setOnClickListener(x -> { ladoDer = !ladoDer; vista.vista(ladoDer ? -90 : 90, 0); aviso(ladoDer ? "Visto por la derecha" : "Visto por la izquierda"); });
        vistas.addView(bLado, peso());
        vistas.addView(boton("Arriba", 0xFF37474F, () -> vista.vista(0, 89)), peso());
        vistas.addView(boton("⛶ Todo", 0xFF37474F, () -> vista.encuadrar()), peso());
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(36));
        vp.topMargin = dp(4);
        raiz.addView(vistas, vp);

        // Versión 2: qué hace un dedo
        LinearLayout modos = new LinearLayout(this);
        String[][] md = {{"✋ Correr vista (gire con el Orbe)", "" + Vista3D.CORRER}, {"✥ Mover pieza", "" + Vista3D.MOVER}};
        for (String[] m : md) {
            final int k = Integer.parseInt(m[1]);
            TextView t = boton(m[0], 0xFF37474F, () -> modo3D(k));
            t.setTag(k);
            botonesModo3D.add(t);
            modos.addView(t, peso());
        }
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(36));
        mp.topMargin = dp(4);
        raiz.addView(modos, mp);

        LinearLayout acciones = new LinearLayout(this);
        acciones.addView(boton("✏\nBoceto", 0xFF1565C0, this::nuevoBoceto), peso());
        acciones.addView(boton("⬆\nExtruir", 0xFF1565C0, this::extruir3D), peso());
        acciones.addView(boton("➕\nTubo", 0xFF00897B, () -> editar(null)), peso());
        acciones.addView(boton("✏\nEditar", 0xFF1E88E5, () -> { Pieza p = porId(escogida); if (p == null) aviso("Toque primero una pieza"); else editar(p); }), peso());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(46));
        ap.topMargin = dp(4);
        raiz.addView(acciones, ap);
        LinearLayout acciones2 = new LinearLayout(this);
        acciones2.addView(boton("⧉\nCopiar", 0xFF5E35B1, this::copiarEscogida), peso());
        acciones2.addView(boton("⟳\nRotar", 0xFF6A1B9A, this::rotar), peso());
        acciones2.addView(boton("🔗\nAmarrar", 0xFF00897B, this::amarrar3D), peso());
        acciones2.addView(boton("🔩\nPerforar", 0xFF6D4C41, this::perforar), peso());
        LinearLayout.LayoutParams ap2 = new LinearLayout.LayoutParams(-1, dp(46));
        ap2.topMargin = dp(4);
        raiz.addView(acciones2, ap2);
        LinearLayout acciones3 = new LinearLayout(this);
        acciones3.addView(boton("✂\nCortar", 0xFFC62828, this::cortar3D), peso());
        acciones3.addView(boton("🗑\nBorrar", 0xFFB71C1C, this::borrar3D), peso());
        acciones3.addView(boton("↶\nAtrás", 0xFF455A64, this::deshacer), peso());
        acciones3.addView(boton("↷\nAdelante", 0xFF455A64, this::rehacer), peso());
        LinearLayout.LayoutParams ap3 = new LinearLayout.LayoutParams(-1, dp(46));
        ap3.topMargin = dp(4);
        raiz.addView(acciones3, ap3);

        ScrollView sv = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        sv.addView(lista);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 0.7f);
        lp.topMargin = dp(4);
        raiz.addView(sv, lp);
        modo3D(Vista3D.CORRER);
        return raiz;
    }

    private void modo3D(int m) {
        if (vista.modo == m && m != Vista3D.CORRER) m = Vista3D.CORRER;   // versión 4.2: tocar otra vez lo apaga
        vista.modo = m;
        for (TextView t : botonesModo3D) colorear(t, ((Integer) t.getTag()) == m ? 0xFFFF8F00 : 0xFF37474F);
        if (m == Vista3D.MOVER) aviso("Arrastre la pieza con el dedo (se mueve de 5 en 5 mm)");
    }

    private String resumen(Pieza p) {
        StringBuilder s = new StringBuilder();
        s.append(p.nombre()).append(" · ").append(p.referencia()).append("\n")
                .append(Pieza.n(p.largo)).append(" mm");
        if (p.f.containsKey("largo")) s.append(" (= ").append(p.f.get("largo")).append(")");
        s.append(" · ").append(Pieza.DIRS[p.dir].substring(0, 1));
        if (Math.abs(p.incl) > 0.01f) s.append(" inclinado ").append(Pieza.n(p.incl)).append("°");
        Pieza pp = porId(p.padre);
        if (pp != null) {
            s.append(" · unido a ").append(pp.nombre()).append(p.punto == 0 ? " (inicio" : p.punto == 1 ? " (final" : " (a " + Pieza.n(p.aMm) + " mm");
            s.append(p.cara > 0 ? ", " + Pieza.CARAS_UNION[p.cara].toLowerCase() : "").append(")");
            String cor = p.textoUnion();
            int k = cor.indexOf(" · corrido");
            if (k >= 0) s.append(cor.substring(k));
            if (Math.abs(p.sep) > 0.01f) s.append(" · separ. ").append(Pieza.n(p.sep)).append(" mm");
        }
        if (!p.huecos.isEmpty()) s.append(" · ").append(p.huecos.size()).append(p.huecos.size() == 1 ? " hueco" : " huecos");
        return s.toString();
    }

    private void pintarLista() {
        if (lista == null) return;
        lista.removeAllViews();
        boolean hayBoceto = false;
        for (Hoja h : hojas) if (!h.b.vacio() || hojas.size() > 1) hayBoceto = true;
        if (hayBoceto) {
            tituloArbol("🌳 Árbol del montaje · ✏ Bocetos");
            for (Hoja h : hojas) filaArbol("✏ " + h.nombre + " · " + h.plano + usadoEn(h), 0xFF1A2F4A, false, h.visible,
                    () -> { vista.hojaResaltada = vista.hojaResaltada == h.id ? -1 : h.id; vista.invalidate(); },
                    () -> { h.visible = !h.visible; vista.invalidate(); pintarLista(); },
                    () -> abrirHoja(h), () -> borrarHoja(h));
            if (!piezas.isEmpty()) tituloArbol("🧩 Piezas");
        }
        if (!piezas.isEmpty()) {
            for (Pieza p : piezas) filaArbol((p.tipo == Pieza.PLACA ? "⬆ " : "") + resumen(p), p.tipo == Pieza.PLACA ? 0xFF123044 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34,
                    p.id == escogida, !p.oculta,
                    () -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); },
                    () -> { p.oculta = !p.oculta; if (p.oculta && escogida == p.id) escogida = -1; vista.escogida = escogida; vista.invalidate(); pintarLista(); },
                    () -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); editar(p); },
                    () -> eliminar(p));
            return;
        }
        if (hayBoceto) return;
        if (piezas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Toque ✏ Boceto para dibujar una figura y luego ⬆ Extruir, o ➕ Tubo para poner un tubo.\n\nCada pieza arranca en el punto 0 o pegada a otra pieza (al inicio, al final o a una medida), "
                    + "y puede quedar separada los milímetros que usted diga.\n\nUn dedo corre la vista (o gira con 🔄, o arrastra la pieza con ✥), dos dedos acercan. "
                    + "En el largo puede escribir una fórmula de la tablita, por ejemplo: ancho - 2*tubo.");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            lista.addView(t);
            return;
        }
        for (Pieza p : piezas) {
            TextView t = new TextView(this);
            t.setText(resumen(p));
            t.setTextColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            t.setTextSize(14);
            t.setPadding(dp(10), dp(7), dp(8), dp(7));
            GradientDrawable g = new GradientDrawable();
            g.setColor(p.id == escogida ? 0xFFFFB300 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34);
            g.setCornerRadius(dp(8));
            t.setBackground(g);
            t.setOnClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); });
            t.setOnLongClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); opcionesPieza(p); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            lista.addView(t, lp);
        }
    }

    private void opcionesPieza(Pieza p) {
        new AlertDialog.Builder(this).setTitle(p.nombre())
                .setItems(new String[]{"✏ Editar", "⧉ Copiar (queda pegada al final de esta)", "⟳ Rotar", "🔗 Amarrar a otra pieza", "🗑 Eliminar"}, (d, w) -> {
                    if (w == 0) editar(p);
                    else if (w == 1) copiarEscogida();
                    else if (w == 2) rotar();
                    else if (w == 3) amarrar3D();
                    else eliminar(p);
                }).show();
    }

    private void copiarEscogida() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        antes();
        Pieza c = p.copia(nuevoId());
        if (c == null) return;
        if (c.titulo != null && !c.titulo.isEmpty()) c.titulo = c.titulo + " copia";
        c.padre = p.id;
        c.punto = 1;
        c.sep = 0;
        c.cx = c.cy = c.cz = 0;
        c.f.remove("sep"); c.f.remove("cx"); c.f.remove("cy"); c.f.remove("cz"); c.f.remove("aMm");
        piezas.add(c);
        escogida = c.id;
        vista.encuadrar();
        recalcular();
        aviso("Copia " + c.nombre() + " pegada al final de " + p.nombre());
    }

    /** Las piezas que cuelgan de esta (para no amarrar en círculo y para rotar todo junto). */
    private Set<Integer> descendientes(int id) {
        Set<Integer> r = new HashSet<>();
        boolean cambio = true;
        r.add(id);
        while (cambio) {
            cambio = false;
            for (Pieza p : piezas) if (!r.contains(p.id) && r.contains(p.padre)) { r.add(p.id); cambio = true; }
        }
        return r;
    }

    /** Al eliminar o soltar, lo que estaba unido se queda en su puesto. */
    private void soltarEnSuPuesto(Pieza h) {
        Map<Integer, Pieza> m = mapa();
        float[] ini = h.inicio(m, 0), dir = h.direccion();
        h.padre = -1;
        h.cara = 0;
        h.cx = ini[0] - dir[0] * h.sep;
        h.cy = ini[1] - dir[1] * h.sep;
        h.cz = ini[2] - dir[2] * h.sep;
        h.f.remove("cx"); h.f.remove("cy"); h.f.remove("cz");
    }

    private void eliminar(Pieza p) {
        new AlertDialog.Builder(this).setMessage("¿Eliminar " + p.nombre() + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    antes();
                    for (Pieza h : piezas) if (h.padre == p.id) soltarEnSuPuesto(h);
                    piezas.remove(p);
                    escogida = -1;
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** ⟳ Rotar 90°: la pieza y todo lo que tiene pegado giran juntos. */
    private void rotar() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        new AlertDialog.Builder(this).setTitle("⟳ Rotar " + p.nombre() + " (y lo que tiene pegado)")
                .setItems(new String[]{"↻ 90° en el piso (alrededor de Z)", "↻ 90° parándola (alrededor de X)", "↻ 90° de lado (alrededor de Y)",
                        "↕ Cambiar la inclinación…", "🔁 Girar la sección 90° (ángulo o platina)"}, (d, w) -> {
                    if (w == 3) { inclinacion(p); return; }
                    antes();
                    if (w == 4) { p.giro = (p.giro + 1) & 3; recalcular(); return; }
                    for (Integer id : descendientes(p.id)) {
                        Pieza x = porId(id);
                        if (x == null) continue;
                        x.dir = Pieza.girarDir(x.dir, w);
                        if (x != p) {
                            float[] v = Pieza.girarVec(new float[]{x.cx, x.cy, x.cz}, w);
                            x.cx = v[0]; x.cy = v[1]; x.cz = v[2];
                        }
                    }
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cerrar", null).show();
    }

    private void inclinacion(Pieza p) {
        EditText e = campoTexto(Pieza.n(p.incl), "grados");
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        new AlertDialog.Builder(this).setTitle("Inclinación de " + p.nombre() + " (0 = derecho)").setView(e)
                .setPositiveButton("Listo", (d, w) -> {
                    Double v = Formula.numero(e.getText().toString());
                    if (v == null) return;
                    antes();
                    p.incl = v.floatValue();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🔗 Amarrar la pieza escogida a otra (o soltarla dejándola en su puesto). */

    // ---------------- Versión 4.2: lista de operaciones del boceto 2D y tabla de propiedades ----------------

    private LinearLayout listaOps;
    private ScrollView svOps;
    private TextView tiraOps;
    private boolean opsAbiertas;

    private View armarOps() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        tiraOps = boton("📋 Operaciones del boceto ▼", 0xFF263238, null);
        tiraOps.setTextSize(13);
        tiraOps.setOnClickListener(v -> {
            opsAbiertas = !opsAbiertas;
            svOps.setVisibility(opsAbiertas ? View.VISIBLE : View.GONE);
            pintarOps();
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(34));
        tp.topMargin = dp(4);
        c.addView(tiraOps, tp);
        return c;
    }

    private String nombreEnt(Map<Integer, String> nom, int id) {
        String n = nom.get(id);
        return n == null ? "?" : n;
    }

    /** Nombres cortos: L1, L2… líneas · C1… círculos · A1… arcos · X1… textos. */
    private Map<Integer, String> nombres2D() {
        Map<Integer, String> m = new HashMap<>();
        int l = 0, c = 0, a = 0, x = 0;
        for (Boceto.Ent e : boceto.b.ents) {
            String n = e.tipo == Boceto.LINEA ? "L" + (++l) : e.tipo == Boceto.CIRCULO ? "C" + (++c) : e.tipo == Boceto.ARCO ? "A" + (++a) : "X" + (++x);
            m.put(e.id, n);
        }
        return m;
    }

    private void filaOp(String txt, int fondo, boolean escogida, View.OnClickListener al) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(escogida ? Color.BLACK : Color.WHITE);
        t.setTextSize(14);
        t.setPadding(dp(10), dp(6), dp(8), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(escogida ? 0xFFFFB300 : fondo);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setOnClickListener(al);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(3);
        listaOps.addView(t, p);
    }

    private void pintarOps() {
        if (tiraOps == null) return;
        Boceto bb = boceto.b;
        int total = bb.ents.size() + bb.restr.size() + placasDe(hoja).size();
        tiraOps.setText("📋 Operaciones del boceto (" + total + ") " + (opsAbiertas ? "▲" : "▼"));
        if (!opsAbiertas) return;
        listaOps.removeAllViews();
        if (total == 0) { filaOp("Todavía no hay nada dibujado", 0xFF263238, false, v -> { }); return; }
        Map<Integer, String> nom = nombres2D();
        for (Boceto.Ent e : bb.ents) {
            Boceto.Punto a = bb.puntos.get(e.a);
            if (a == null) continue;
            String txt;
            if (e.tipo == Boceto.LINEA) {
                Boceto.Punto q = bb.puntos.get(e.b);
                if (q == null) continue;
                double ang = Math.toDegrees(Math.atan2(q.y - a.y, q.x - a.x));
                txt = nom.get(e.id) + " · Línea · " + Formula.n(Math.round(bb.largo(e) * 10) / 10.0) + " mm · " + Formula.n(Math.round(ang * 10) / 10.0) + "°";
                for (Boceto.Restr r : bb.restr) {
                    if (r.e1 != e.id) continue;
                    if (r.tipo == Boceto.HORIZ) txt += " · ═";
                    if (r.tipo == Boceto.VERT) txt += " · ║";
                }
            } else if (e.tipo == Boceto.CIRCULO) txt = nom.get(e.id) + " · Círculo · Ø " + Formula.n(Math.round(e.r * 20) / 10.0) + " · centro " + Formula.n(Math.round(a.x)) + ", " + Formula.n(Math.round(a.y));
            else if (e.tipo == Boceto.ARCO) txt = nom.get(e.id) + " · Arco · R " + Formula.n(Math.round(e.r * 10) / 10.0) + " · centro " + Formula.n(Math.round(a.x)) + ", " + Formula.n(Math.round(a.y));
            else txt = nom.get(e.id) + " · Texto · «" + e.texto + "»";
            final Boceto.Ent ent = e;
            filaOp(txt, 0xFF1E3A34, boceto.sel.contains(e.id), v -> {
                boceto.sel.clear(); boceto.selPts.clear(); boceto.sel.add(ent.id); boceto.invalidate(); pintarOps();
                tablaEnt(ent);
            });
        }
        for (Boceto.Restr r : bb.restr) {
            final Boceto.Restr rr = r;
            String quien = (r.e1 >= 0 ? nombreEnt(nom, r.e1) : "") + (r.e2 >= 0 ? " y " + nombreEnt(nom, r.e2) : "")
                    + (r.p1 >= 0 ? (r.e1 >= 0 ? ", " : "") + "punto" : "");
            if (r.esCota())
                filaOp("📏 Cota · " + Boceto.NOMBRES[r.tipo] + " = " + boceto.textoCota(r) + " (" + quien + ")", 0xFF1A2F4A, false, v -> editarCota(rr));
            else
                filaOp("🔗 Amarre · " + Boceto.NOMBRES[r.tipo] + " (" + quien + ")", 0xFF2A2F36, false, v ->
                        new AlertDialog.Builder(this).setTitle("🔗 " + Boceto.NOMBRES[rr.tipo])
                                .setMessage("¿Quitar este amarre?")
                                .setPositiveButton("🗑 Quitar", (d, w) -> { antes(); bb.restr.remove(rr); recalcular(); })
                                .setNegativeButton("Dejarlo", null).show());
        }
        for (Pieza p : placasDe(hoja))
            filaOp("⬆ Extrusión · " + p.nombre() + " · " + Pieza.n(p.largo) + " mm" + (p.agujeros.isEmpty() ? "" : " · " + p.agujeros.size() + " huecos"), 0xFF123044, false, v -> editarPlaca(p));
    }

    /** La tabla de propiedades de una línea, círculo, arco o texto del boceto. */
    private void tablaEnt(Boceto.Ent e) {
        Boceto bb = boceto.b;
        Boceto.Punto a = bb.puntos.get(e.a);
        if (a == null) return;
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        String nombre = nombres2D().get(e.id);
        Boceto.Restr cota = null;
        for (Boceto.Restr r : bb.restr)
            if (r.e1 == e.id && (r.tipo == Boceto.C_LARGO || r.tipo == Boceto.C_DIAM || r.tipo == Boceto.C_RADIO)) cota = r;
        final Boceto.Restr cotaF = cota;
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto q = bb.puntos.get(e.b);
            EditText x1 = celda(l, "Inicio X", Formula.n(r2(a.x))), y1 = celda(l, "Inicio Y", Formula.n(r2(a.y)));
            EditText x2 = celda(l, "Final X", Formula.n(r2(q.x))), y2 = celda(l, "Final Y", Formula.n(r2(q.y)));
            String lg = cota != null ? cota.formula : Formula.n(r2(bb.largo(e)));
            EditText lar = celda(l, cota != null ? "Largo (cota)" : "Largo", lg);
            double ang0 = Math.toDegrees(Math.atan2(q.y - a.y, q.x - a.x));
            EditText ang = celda(l, "Ángulo (grados)", Formula.n(r2(ang0)));
            tablaDialogo("📋 " + nombre + " · Línea", l, e, () -> {
                Double vx1 = valorDe(x1.getText().toString()), vy1 = valorDe(y1.getText().toString()), vx2 = valorDe(x2.getText().toString()), vy2 = valorDe(y2.getText().toString());
                Double va = valorDe(ang.getText().toString());
                if (vx1 == null || vy1 == null || vx2 == null || vy2 == null || va == null) { aviso("Revise los números"); return false; }
                a.x = vx1; a.y = vy1; q.x = vx2; q.y = vy2;
                String tl = lar.getText().toString().trim();
                Double vl = valorDe(tl);
                if (Math.abs(va - ang0) > 0.01 || (vl != null && Math.abs(vl - Math.hypot(q.x - a.x, q.y - a.y)) > 0.01)) {
                    double L = vl != null ? vl : Math.hypot(q.x - a.x, q.y - a.y), an = Math.toRadians(va);
                    q.x = a.x + L * Math.cos(an); q.y = a.y + L * Math.sin(an);
                    if (Math.abs(va - ang0) > 0.01) bb.restr.removeIf(r -> (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == e.id);
                }
                if (!tl.equals(lg) && vl != null) {
                    if (cotaF != null) cotaF.formula = tl;
                    else bb.restriccion(Boceto.C_LARGO, e.id, -1, -1, -1, tl);
                }
                return true;
            });
        } else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
            boolean circ = e.tipo == Boceto.CIRCULO;
            EditText cx = celda(l, "Centro X", Formula.n(r2(a.x))), cy = celda(l, "Centro Y", Formula.n(r2(a.y)));
            String md = cota != null ? cota.formula : Formula.n(r2(circ ? e.r * 2 : e.r));
            EditText med = celda(l, circ ? "Diámetro" : "Radio", md);
            tablaDialogo("📋 " + nombre + (circ ? " · Círculo" : " · Arco"), l, e, () -> {
                Double vx = valorDe(cx.getText().toString()), vy = valorDe(cy.getText().toString());
                String tm = med.getText().toString().trim();
                Double vm = valorDe(tm);
                if (vx == null || vy == null || vm == null || vm <= 0) { aviso("Revise los números"); return false; }
                double dx = vx - a.x, dy = vy - a.y;
                a.x = vx; a.y = vy;
                if (!circ) for (int k : new int[]{e.b, e.c}) { Boceto.Punto p = bb.puntos.get(k); if (p != null) { p.x += dx; p.y += dy; } }
                if (!tm.equals(md)) {
                    if (cotaF != null) cotaF.formula = tm;
                    else if (circ) bb.restriccion(Boceto.C_DIAM, e.id, -1, -1, -1, tm);
                    else bb.restriccion(Boceto.C_RADIO, e.id, -1, -1, -1, tm);
                }
                return true;
            });
        } else {
            EditText tx = celda(l, "Texto", e.texto);
            tx.setInputType(InputType.TYPE_CLASS_TEXT);
            EditText alto = celda(l, "Alto de letra (mm)", Formula.n(r2(e.r)));
            EditText px = celda(l, "X", Formula.n(r2(a.x))), py = celda(l, "Y", Formula.n(r2(a.y)));
            tablaDialogo("📋 " + nombre + " · Texto", l, e, () -> {
                Double va = valorDe(alto.getText().toString()), vx = valorDe(px.getText().toString()), vy = valorDe(py.getText().toString());
                if (va == null || vx == null || vy == null) { aviso("Revise los números"); return false; }
                e.texto = tx.getText().toString();
                e.r = va; a.x = vx; a.y = vy;
                return true;
            });
        }
    }

    private static double r2(double v) { return Math.round(v * 100) / 100.0; }

    /** Una fila de la tabla: el nombre a la izquierda y la casilla a la derecha (se corrige con el cursor). */
    private EditText celda(LinearLayout l, String etiqueta, String valor) {
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextSize(14);
        t.setTextColor(Color.WHITE);
        f.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        EditText e = campoCasilla();
        e.setText(valor);
        f.addView(e, new LinearLayout.LayoutParams(0, dp(42), 1.2f));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(4);
        l.addView(f, p);
        return e;
    }

    private interface Guardar { boolean hacer(); }

    private void tablaDialogo(String titulo, LinearLayout l, Boceto.Ent e, Guardar g) {
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle(titulo).setView(sv)
                .setPositiveButton("✓ Guardar", (d, w) -> {
                    antes();
                    if (!g.hacer()) { atras.remove(atras.size() - 1); return; }
                    if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se pudo: choca con otra medida o amarre"); }
                })
                .setNeutralButton("🗑 Borrar", (d, w) -> { antes(); boceto.b.borrar(e); boceto.limpiarSeleccion(); recalcular(); })
                .setNegativeButton("Cancelar", null).show();
    }

    // =====================================================================
    //          VERSIÓN 4: amarrar tocando caras, perforar, cortar, extruir
    // =====================================================================

    private LinearLayout barra3D;
    private TextView panelTitulo;
    private LinearLayout panelCaja;

    private View armarPanel3D() {
        barra3D = new LinearLayout(this);
        barra3D.setOrientation(LinearLayout.VERTICAL);
        barra3D.setPadding(dp(6), dp(4), dp(6), dp(4));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        barra3D.setBackground(g);
        panelTitulo = new TextView(this);
        panelTitulo.setTextColor(Color.WHITE);
        panelTitulo.setTextSize(14);
        panelTitulo.setTypeface(Typeface.DEFAULT_BOLD);
        barra3D.addView(panelTitulo);
        panelCaja = new LinearLayout(this);
        panelCaja.setOrientation(LinearLayout.VERTICAL);
        barra3D.addView(panelCaja);
        barra3D.setVisibility(View.GONE);
        return barra3D;
    }

    private void panel(String titulo) {
        panelTitulo.setText(titulo);
        panelCaja.removeAllViews();
        barra3D.setVisibility(View.VISIBLE);
    }

    private void cerrarPanel() {
        barra3D.setVisibility(View.GONE);
        vista.pideCara = null;
        vista.resA = vista.resB = -1;
        vista.invalidate();
    }

    private LinearLayout filaPanel() {
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(42));
        p.topMargin = dp(4);
        panelCaja.addView(f, p);
        return f;
    }

    private EditText campoPanel(LinearLayout fila, String etiqueta, String valor) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setPadding(dp(4), 0, dp(4), 0);
        fila.addView(t, new LinearLayout.LayoutParams(-2, -1));
        t.setGravity(Gravity.CENTER_VERTICAL);
        EditText e = campoCasilla();
        e.setText(valor);
        fila.addView(e, new LinearLayout.LayoutParams(0, -1, 1f));
        return e;
    }

    private static float punto3(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    private static float[] menos(float[] a, float[] b) { return new float[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }

    private static float r5(float v) { return Math.round(v / 5f) * 5f; }

    private static float r1(float v) { return Math.round(v * 10f) / 10f; }

    private Map<Integer, Pieza> mapaPiezas() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    /** La dirección (0..5) que más se parece al vector. */
    private static int dirMasCercana(float[] v) {
        float[][] base = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {-1, 0, 0}, {0, -1, 0}, {0, 0, -1}};
        int m = 0;
        float mejor = -9;
        for (int i = 0; i < 6; i++) { float k = punto3(base[i], v); if (k > mejor) { mejor = k; m = i; } }
        return m;
    }

    /** ¿b está pegada (directa o indirectamente) a a? */
    private boolean dependeDe(Pieza b, Pieza a) {
        Pieza x = b;
        for (int i = 0; i < 80 && x != null; i++) {
            if (x.id == a.id) return true;
            x = x.padre >= 0 ? porId(x.padre) : null;
        }
        return false;
    }

    // ---------------- 🔗 Amarrar tocando caras ----------------

    private int amA = -1, amTipoA;
    private float[] amNrmA;

    private void amarrar3D() {
        mostrar(1);
        amA = -1;
        panel("🔗 Amarrar · paso 1 de 2: toque la cara de la pieza que va a mover");
        LinearLayout f = filaPanel();
        Pieza esc = porId(escogida);
        if (esc != null && esc.padre >= 0)
            f.addView(boton("🔓 Soltar " + esc.nombre(), 0xFF6D4C41, () -> { antes(); soltarEnSuPuesto(esc); cerrarPanel(); recalcular(); aviso("✔ " + esc.nombre() + " quedó suelta en su sitio"); }), peso());
        f.addView(boton("✋ Mover la vista", 0xFF37474F, () -> aviso("Con dos dedos puede correr y acercar la vista mientras amarra")), peso());
        f.addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        vista.resA = vista.resB = -1;
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (amA < 0) {
                if (tipo == 9) return;
                amA = pieza; amTipoA = tipo; amNrmA = nrm;
                vista.resA = pieza; vista.resNrmA = nrm;
                vista.invalidate();
                panelTitulo.setText("🔗 Amarrar · paso 2 de 2: toque la cara donde se pega " + porId(pieza).nombre());
                return;
            }
            if (pieza == amA) { aviso("Toque una cara de OTRA pieza"); return; }
            Pieza a = porId(amA), b = porId(pieza);
            if (a == null || b == null) return;
            if (dependeDe(b, a)) { aviso("No se puede: " + b.nombre() + " está pegada a " + a.nombre() + ". Amarre al revés."); return; }
            antes();
            aplicarAmarre(a, amTipoA, b, tipo, nrm, q);
            vista.pideCara = null;
            vista.resB = pieza; vista.resNrmB = nrm;
            escogida = a.id;
            recalcular();
            panelAmarre(a, b);
        };
        vista.invalidate();
    }

    private void aplicarAmarre(Pieza a, int tipoA, Pieza b, int tipoB, float[] nB, float[] pB) {
        Map<Integer, Pieza> m = mapaPiezas();
        float[] dA = a.direccion();
        boolean punta = tipoA == 5 || tipoA == 6 || Math.abs(punto3(dA, nB)) > 0.7f;
        if (punta && a.tipo != Pieza.PLACA) { a.dir = dirMasCercana(nB); a.incl = 0; }
        a.padre = b.id;
        a.sep = 0; a.luz = 0; a.en1 = 0; a.en2 = 0;
        a.cx = a.cy = a.cz = 0;
        for (String k : new String[]{"cx", "cy", "cz", "sep", "aMm"}) a.f.remove(k);
        float[] sB = b.inicio(m, 0), dB = b.direccion();
        float[][] eB = Vista3D.ejes(b);
        if (tipoB == 5 || tipoB == 6) {
            a.cara = 5;
            a.punto = tipoB == 5 ? 1 : 0;
            float[] org = a.punto == 1 ? new float[]{sB[0] + dB[0] * b.largo, sB[1] + dB[1] * b.largo, sB[2] + dB[2] * b.largo} : sB;
            float e1 = punto3(menos(pB, org), eB[1]), e2 = punto3(menos(pB, org), eB[2]);
            if (b.tipo == Pieza.PLACA) { a.en1 = r5(e1); a.en2 = r5(e2); }
        } else {
            float ks = punto3(nB, eB[1]), ku = punto3(nB, eB[2]);
            a.cara = Math.abs(ku) >= Math.abs(ks) ? (ku > 0 ? 1 : 2) : (ks > 0 ? 4 : 3);
            float t = punto3(menos(pB, sB), dB);
            float borde = Math.max(30, b.largo * 0.05f);
            if (t < borde) a.punto = 0;
            else if (t > b.largo - borde) a.punto = 1;
            else { a.punto = 2; a.aMm = r5(t); }
            if (b.tipo == Pieza.PLACA) {
                float[] t1 = Pieza.ejeT1(b, a.cara);
                float[] eje = {sB[0] + dB[0] * t, sB[1] + dB[1] * t, sB[2] + dB[2] * t};
                a.en1 = r5(punto3(menos(pB, eje), t1));
            }
        }
    }

    /** La barrita después de amarrar: separación, a lo largo, al ras, alineación, voltear. Los números se aplican al escribirlos. */
    private void panelAmarre(Pieza a, Pieza b) {
        panel("🔗 " + a.nombre() + " pegada a " + b.nombre() + " (" + Pieza.CARAS_UNION[a.cara].toLowerCase() + ")");
        LinearLayout f1 = filaPanel();
        EditText luz = campoPanel(f1, "Separación", Pieza.n(a.luz));
        EditText largo = campoPanel(f1, "A lo largo", Pieza.n(a.punto == 0 ? 0 : a.punto == 1 ? b.largo : a.aMm));
        final boolean[] quieto = {false};
        Runnable leer = () -> {
            if (quieto[0]) return;
            Double v = valorDe(luz.getText().toString());
            if (v != null) a.luz = v.floatValue();
            if (a.cara != 5) {
                Double w = valorDe(largo.getText().toString());
                if (w != null) { a.punto = 2; a.aMm = w.floatValue(); a.f.remove("aMm"); }
            }
            recalcular();
        };
        android.text.TextWatcher tw = new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence c, int x, int y, int z) { }
            @Override public void afterTextChanged(android.text.Editable e) { leer.run(); }
        };
        luz.addTextChangedListener(tw);
        largo.addTextChangedListener(tw);
        // poner un número sin disparar el aplicar dos veces
        java.util.function.Consumer<Float> ponerLargo = v -> { quieto[0] = true; largo.setText(Pieza.n(v)); quieto[0] = false; };
        LinearLayout f2 = filaPanel();
        f2.addView(boton("⟵ Al inicio", 0xFF455A64, () -> { a.punto = 2; a.aMm = 0; ponerLargo.accept(0f); leer.run(); }), peso());
        f2.addView(boton("Al final ⟶", 0xFF455A64, () -> {
            // que las dos puntas queden parejas al final
            float k = punto3(a.direccion(), b.direccion());
            float v = k > 0.9f ? b.largo - a.largo : k < -0.9f ? b.largo : b.largo;
            a.punto = 2; a.aMm = Math.max(0, v);
            ponerLargo.accept(a.aMm);
            leer.run();
        }), peso());
        f2.addView(boton("Centrada", 0xFF455A64, () -> { alinear(a, b, 0); leer.run(); }), peso());
        f2.addView(boton("⇄ Voltear", 0xFF5E35B1, () -> { if (a.tipo != Pieza.PLACA) a.dir = (a.dir + 3) % 6; leer.run(); }), peso());
        LinearLayout f3 = filaPanel();
        f3.addView(boton("Borde 1", 0xFF455A64, () -> { alinear(a, b, 1); leer.run(); }), peso());
        f3.addView(boton("Borde 2", 0xFF455A64, () -> { alinear(a, b, 2); leer.run(); }), peso());
        f3.addView(boton("Cancelar", 0xFF455A64, () -> { revertir(); cerrarPanel(); recalcular(); }), peso());
        f3.addView(boton("✓ Listo", 0xFF2E7D32, () -> { leer.run(); cerrarPanel(); recalcular(); aviso("✔ " + a.nombre() + " amarrada a " + b.nombre()); }), peso());
    }

    private void alinear(Pieza a, Pieza b, int k) {
        float[] t1 = Pieza.ejeT1(b, a.cara);
        if (k == 0) { a.en1 = 0; if (a.cara == 5 && b.tipo != Pieza.PLACA) a.en2 = 0; return; }
        float[] nt = {-t1[0], -t1[1], -t1[2]};
        if (k == 1) a.en1 = -(b.alcance(nt) - a.alcance(nt));
        else a.en1 = b.alcance(t1) - a.alcance(t1);
    }

    // ---------------- 🔩 Perforar tocando la cara ----------------

    private void perforar() {
        mostrar(1);
        panel("🔩 Perforar: toque la cara donde va el hueco");
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            Pieza p = porId(pieza);
            if (p == null || tipo == 9) return;
            boolean placa = p.tipo == Pieza.PLACA;
            if (placa && tipo != 5 && tipo != 6) { aviso("En una placa, toque la cara de encima o la de abajo"); return; }
            if (!placa && (tipo == 5 || tipo == 6)) { aviso("Toque una cara a lo largo del tubo, no la punta"); return; }
            Map<Integer, Pieza> m = mapaPiezas();
            float[] s0 = p.inicio(m, 0), d = p.direccion();
            float[][] e = Vista3D.ejes(p);
            vista.pideCara = null;
            vista.resA = pieza; vista.resNrmA = nrm;
            vista.invalidate();
            if (placa) {
                float[] org = tipo == 5 ? new float[]{s0[0] + d[0] * p.largo, s0[1] + d[1] * p.largo, s0[2] + d[2] * p.largo} : s0;
                panelPerforar(p, -1, 0, r5(punto3(menos(q, org), e[1])), r5(punto3(menos(q, org), e[2])));
            } else {
                float ks = punto3(nrm, e[1]), ku = punto3(nrm, e[2]);
                int cara = Math.abs(ku) >= Math.abs(ks) ? (ku > 0 ? 0 : 1) : (ks > 0 ? 2 : 3);
                panelPerforar(p, cara, Math.max(0, Math.min(p.largo, r5(punto3(menos(q, s0), d)))), 0, 0);
            }
        };
    }

    private void panelPerforar(Pieza p, int cara, float pos, float s, float u) {
        boolean placa = cara < 0;
        panel("🔩 Perforar " + p.nombre() + (placa ? "" : " · cara " + Pieza.CARAS[cara].toLowerCase()));
        final int[] tipo = {0};
        final boolean[] pasante = {true};
        LinearLayout f0 = filaPanel();
        List<TextView> bt = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            final int k = i;
            TextView t = boton(Pieza.HUECOS[i], i == 0 ? 0xFFFF8F00 : 0xFF455A64, null);
            t.setTextSize(12);
            t.setOnClickListener(x -> { tipo[0] = k; for (int j = 0; j < bt.size(); j++) colorear(bt.get(j), j == k ? 0xFFFF8F00 : 0xFF455A64); });
            bt.add(t);
            f0.addView(t, peso());
        }
        LinearLayout f1 = filaPanel();
        EditText d1 = campoPanel(f1, "Ø / largo", "10");
        EditText d2 = campoPanel(f1, "Ancho ranura", "8");
        LinearLayout f2 = filaPanel();
        EditText ps = placa ? campoPanel(f2, "X", Pieza.n(s)) : campoPanel(f2, "Desde la punta", Pieza.n(pos));
        EditText pu = placa ? campoPanel(f2, "Y", Pieza.n(u)) : null;
        LinearLayout f3 = filaPanel();
        EditText cuantos = campoPanel(f3, "Cuántos", "1");
        EditText cada = campoPanel(f3, "Cada (mm)", "80");
        LinearLayout f4 = filaPanel();
        if (!placa) {
            TextView tp = boton("Pasante ✓", 0xFF00897B, null);
            tp.setOnClickListener(x -> { pasante[0] = !pasante[0]; tp.setText(pasante[0] ? "Pasante ✓" : "Solo esta cara"); colorear(tp, pasante[0] ? 0xFF00897B : 0xFF455A64); });
            f4.addView(tp, peso());
        }
        f4.addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        f4.addView(boton("✓ Perforar", 0xFF2E7D32, () -> {
            Double v1 = valorDe(d1.getText().toString()), v2 = valorDe(d2.getText().toString());
            Double vp = valorDe(ps.getText().toString()), vu = pu == null ? Double.valueOf(0) : valorDe(pu.getText().toString());
            Double vn = valorDe(cuantos.getText().toString()), vc = valorDe(cada.getText().toString());
            if (v1 == null || v1 <= 0 || vp == null || vu == null || vn == null || vc == null) { aviso("Revise las medidas"); return; }
            int n = Math.max(1, Math.min(200, (int) Math.round(vn)));
            antes();
            for (int i = 0; i < n; i++) {
                Pieza.Hueco h = new Pieza.Hueco();
                h.tipo = tipo[0];
                h.d1 = v1.floatValue();
                h.d2 = v2 == null ? 8 : v2.floatValue();
                if (placa) { h.s = (float) (vp + i * vc); h.u = vu.floatValue(); }
                else { h.cara = cara; h.pos = (float) (vp + i * vc); h.pasante = pasante[0]; }
                p.huecos.add(h);
            }
            cerrarPanel();
            recalcular();
            aviso("✔ " + n + (n == 1 ? " hueco" : " huecos") + " en " + p.nombre());
        }), peso());
    }

    // ---------------- ✂ Cortar ----------------

    private void cortar3D() {
        mostrar(1);
        new AlertDialog.Builder(this).setTitle("✂ Cortar")
                .setItems(new String[]{"◸ Inglete entre dos tubos (esquina)", "▮ Tope: un tubo llega recto a la cara de otro",
                        "∠ Punta a un ángulo (la pieza escogida)", "📏 Cambiar el largo (la pieza escogida)", "↺ Quitar los cortes inclinados (la escogida)"}, (d, w) -> {
                    if (w == 0) inglete();
                    else if (w == 1) tope();
                    else {
                        Pieza p = porId(escogida);
                        if (p == null) { aviso("Toque primero una pieza"); return; }
                        if (w == 2) cortarAngulo(p);
                        else if (w == 3) {
                            EditText e = campoTexto(p.f.containsKey("largo") ? p.f.get("largo") : Pieza.n(p.largo), "mm o fórmula");
                            dialogo("📏 Largo de " + p.nombre() + " (por el eje)", e, "Cambiar", () -> { antes(); leerCampo(p, "largo", e.getText().toString()); recalcular(); });
                        } else { antes(); p.corteIni = p.corteFin = 0; recalcular(); }
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Mueve el inicio de la pieza delta mm hacia adentro (el final queda quieto). */
    private void moverInicio(Pieza a, float delta) {
        if (a.padre >= 0) { a.sep += delta; a.f.remove("sep"); }
        else {
            float[] d = a.direccion();
            a.cx += d[0] * delta; a.cy += d[1] * delta; a.cz += d[2] * delta;
            for (String k : new String[]{"cx", "cy", "cz"}) a.f.remove(k);
        }
        a.largo -= delta;
        a.f.remove("largo");
    }

    private void inglete() {
        panel("◸ Inglete: toque el primer tubo de la esquina");
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        final int[] primero = {-1};
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (primero[0] < 0) {
                primero[0] = pieza;
                vista.resA = pieza; vista.resNrmA = nrm;
                vista.invalidate();
                panelTitulo.setText("◸ Inglete: ahora toque el otro tubo de la esquina");
                return;
            }
            if (pieza == primero[0]) return;
            Pieza a = porId(primero[0]), b = porId(pieza);
            if (a == null || b == null) return;
            String err = hacerInglete(a, b);
            cerrarPanel();
            if (err != null) aviso(err); else { recalcular(); aviso("✔ Inglete hecho en " + a.nombre() + " y " + b.nombre()); }
        };
    }

    private String hacerInglete(Pieza a, Pieza b) {
        Map<Integer, Pieza> m = mapaPiezas();
        float[] sa = a.inicio(m, 0), da = a.direccion(), sb = b.inicio(m, 0), db = b.direccion();
        // puntos más cercanos de los dos ejes
        float[] w0 = menos(sa, sb);
        float aa = punto3(da, da), bb = punto3(da, db), cc = punto3(db, db), dd = punto3(da, w0), ee = punto3(db, w0);
        float den = aa * cc - bb * bb;
        if (Math.abs(den) < 1e-4f) return "Esos dos tubos van paralelos: no hacen esquina";
        float ta = (bb * ee - cc * dd) / den, tb = (aa * ee - bb * dd) / den;
        float[] ca = {sa[0] + da[0] * ta, sa[1] + da[1] * ta, sa[2] + da[2] * ta}, cb = {sb[0] + db[0] * tb, sb[1] + db[1] * tb, sb[2] + db[2] * tb};
        float sepEjes = (float) Math.sqrt(punto3(menos(ca, cb), menos(ca, cb)));
        if (sepEjes > Math.max(Math.max(a.a, a.b), Math.max(b.a, b.b))) return "Esos tubos no se juntan en una esquina (están separados " + Pieza.n(sepEjes) + " mm)";
        antes();
        boolean finA = ta > a.largo / 2, finB = tb > b.largo / 2;
        // hacia dónde sigue cada tubo desde la esquina
        float[] va = finA ? new float[]{-da[0], -da[1], -da[2]} : da, vb = finB ? new float[]{-db[0], -db[1], -db[2]} : db;
        float th = (float) Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, punto3(va, vb)))));
        float phi = (180 - th) / 2;
        if (b.padre == a.id && b.cara == 5) { b.cara = 0; b.en1 = b.en2 = 0; }
        if (a.padre == b.id && a.cara == 5) { a.cara = 0; a.en1 = a.en2 = 0; }
        ponerInglete(a, finA, ta, vb, phi);
        ponerInglete(b, finB, tb, va, phi);
        return null;
    }

    private void ponerInglete(Pieza p, boolean fin, float t, float[] otro, float phi) {
        float[][] e = Vista3D.ejes(p);
        float ds = punto3(otro, e[1]), du = punto3(otro, e[2]);
        float l = (float) Math.hypot(ds, du);
        if (l < 1e-4f) { ds = 1; du = 0; } else { ds /= l; du /= l; }
        if (fin) { p.largo = t; p.f.remove("largo"); p.corteFin = phi; p.cfS = ds; p.cfU = du; }
        else { moverInicio(p, t); p.corteIni = phi; p.ciS = ds; p.ciU = du; }
    }

    private void tope() {
        panel("▮ Tope: toque el tubo que se va a cortar");
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        final int[] primero = {-1};
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (primero[0] < 0) {
                primero[0] = pieza;
                vista.resA = pieza; vista.resNrmA = nrm;
                vista.invalidate();
                panelTitulo.setText("▮ Tope: ahora toque la cara contra la que llega");
                return;
            }
            if (pieza == primero[0]) return;
            Pieza a = porId(primero[0]);
            if (a == null) return;
            Map<Integer, Pieza> m = mapaPiezas();
            float[] sa = a.inicio(m, 0), da = a.direccion();
            float k = punto3(da, nrm);
            cerrarPanel();
            if (Math.abs(k) < 0.1f) { aviso("Ese tubo no llega de frente a esa cara"); return; }
            float t = punto3(menos(q, sa), nrm) / k;
            antes();
            if (t > a.largo / 2) { if (t <= 1) { revertir(); return; } a.largo = t; a.f.remove("largo"); a.corteFin = 0; }
            else { if (a.largo - t <= 1) { revertir(); return; } moverInicio(a, t); a.corteIni = 0; }
            recalcular();
            aviso("✔ " + a.nombre() + " llega recto a la cara · largo " + Pieza.n(a.largo) + " mm");
        };
    }

    private void cortarAngulo(Pieza p) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] punta = {1}, hacia = {0};
        l.addView(etiqueta("Qué punta"));
        grupoBotones(l, new String[]{"Inicio", "Final"}, punta, 2, null);
        l.addView(etiqueta("El corte se inclina hacia"));
        grupoBotones(l, new String[]{"Lo ancho", "Lo alto"}, hacia, 2, null);
        l.addView(etiqueta("Grados (0 = recto; negativo = al otro lado)"));
        EditText g = campoTexto(Pieza.n(punta[0] == 1 ? p.corteFin : p.corteIni), "");
        l.addView(g);
        new AlertDialog.Builder(this).setTitle("∠ Cortar la punta de " + p.nombre()).setView(l)
                .setPositiveButton("Cortar", (d, w) -> {
                    Double v = valorDe(g.getText().toString());
                    if (v == null || Math.abs(v) > 75) { aviso("Entre −75° y 75°"); return; }
                    antes();
                    float ds = hacia[0] == 0 ? 1 : 0, du = hacia[0] == 0 ? 0 : 1;
                    if (punta[0] == 1) { p.corteFin = v.floatValue(); p.cfS = ds; p.cfU = du; }
                    else { p.corteIni = v.floatValue(); p.ciS = ds; p.ciU = du; }
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- ⬆ Extruir el boceto ----------------

    private void extruir() {
        if (boceto.b.vacio()) { aviso("Primero dibuje una figura cerrada (rectángulo, polígono, círculo…)"); return; }
        VistaBoceto.Pedido p = pedido("Extruir", t -> {
            Editar2D.Figura f = Editar2D.figuraEn(boceto.b, t.get(0).x, t.get(0).y);
            if (f == null) { aviso("Toque adentro de una figura cerrada"); return; }
            dialogoExtruir(hoja, f);
        }, "Extruir: toque adentro de la figura cerrada (lo que tenga adentro queda como hueco)");
        p.linea = false;
        p.crudo = true;
        boceto.pedir(p);
    }

    private static float[][] aPlaca(double[][] pol) {
        // en la placa acostada: s va hacia −X y u hacia Y (así queda igual que en el boceto)
        float[][] r = new float[pol.length][2];
        for (int i = 0; i < pol.length; i++) { r[i][0] = (float) -pol[i][0]; r[i][1] = (float) pol[i][1]; }
        return r;
    }

    private List<Pieza> placas() {
        List<Pieza> l = new ArrayList<>();
        for (Pieza x : piezas) if (x.tipo == Pieza.PLACA) l.add(x);
        return l;
    }

    private void dialogoExtruir(Hoja h, Editar2D.Figura f) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        l.addView(etiqueta("Nombre de la pieza"));
        EditText nom = campoTexto("Pieza " + (placas().size() + 1), "");
        l.addView(nom);
        l.addView(etiqueta("Grueso (mm o fórmula)"));
        EditText g = campoTexto("6", "");
        l.addView(g);
        final int[] modo = {0}, lado = {0};
        List<Pieza> ps = placasDe(h);
        l.addView(etiqueta("Qué hacer"));
        grupoBotones(l, ps.isEmpty() ? new String[]{"➕ Pieza nueva"} : new String[]{"➕ Pieza nueva", "➖ Cortar en una pieza"}, modo, 2, null);
        l.addView(etiqueta("Hacia dónde sale del plano"));
        grupoBotones(l, new String[]{"⬆ Para un lado", "⬇ Para el otro"}, lado, 2, null);
        l.addView(etiqueta("Figura con " + f.huecos.size() + (f.huecos.size() == 1 ? " hueco" : " huecos") + " adentro · " + h.nombre + " · " + h.plano));
        new AlertDialog.Builder(this).setTitle("⬆ Extruir").setView(l)
                .setPositiveButton("Extruir", (d, w) -> {
                    vista.hojaResaltada = -1;
                    if (modo[0] == 1) { cortarEnPlaca(f, ps); return; }
                    antes();
                    Pieza p = new Pieza();
                    p.id = nuevoId();
                    p.tipo = Pieza.PLACA;
                    p.titulo = nom.getText().toString().trim();
                    p.medida = "";
                    p.calibre = "";
                    p.dir = 2;
                    p.hoja = h.id;
                    float[] n = h.normal();
                    p.marco = new float[]{h.o[0], h.o[1], h.o[2], h.ex[0], h.ex[1], h.ex[2], h.ey[0], h.ey[1], h.ey[2], n[0], n[1], n[2]};
                    p.contorno = aF(f.pol);
                    p.entsContorno = new ArrayList<>(f.borde);
                    for (int i = 0; i < f.huecos.size(); i++) { p.agujeros.add(aF(f.polHuecos.get(i))); p.entsAgujeros.add(new ArrayList<>(f.huecos.get(i))); }
                    p.largo = 6;
                    leerCampo(p, "largo", g.getText().toString());
                    if (p.largo <= 0) p.largo = 6;
                    p.alReves = lado[0] == 1;
                    piezas.add(p);
                    escogida = p.id;
                    boceto.ponerModo(VistaBoceto.VER);
                    herrActiva = "Ver";
                    mostrar(1);
                    vista.encuadrar();
                    recalcular();
                    aviso("✔ " + p.nombre() + ": " + Pieza.n(p.largo) + " mm. Si cambia las cotas de " + h.nombre + ", la pieza cambia también");
                }).setNegativeButton("Cancelar", (d, w) -> { vista.hojaResaltada = -1; vista.invalidate(); }).show();
    }

    private static float[][] aF(double[][] pol) {
        float[][] r = new float[pol.length][2];
        for (int i = 0; i < pol.length; i++) { r[i][0] = (float) pol[i][0]; r[i][1] = (float) pol[i][1]; }
        return r;
    }

    /** La forma tal como se guarda en esa placa (las viejas, acostadas, van al revés en X). */
    private static float[][] enPlaca(Pieza p, double[][] pol) { return p.marco != null ? aF(pol) : aPlaca(pol); }

    private void cortarEnPlaca(Editar2D.Figura f, List<Pieza> ps) {
        String[] nom = new String[ps.size()];
        for (int i = 0; i < nom.length; i++) nom[i] = ps.get(i).nombre() + " · " + ps.get(i).referencia();
        new AlertDialog.Builder(this).setTitle("➖ Cortar en qué pieza")
                .setItems(nom, (d, w) -> {
                    antes();
                    Pieza p = ps.get(w);
                    p.agujeros.add(enPlaca(p, f.pol));
                    p.entsAgujeros.add(new ArrayList<>(f.borde));
                    mostrar(1);
                    recalcular();
                    aviso("✔ Se cortó esa figura en " + p.nombre());
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Las piezas siguen a su boceto: si cambian las cotas, cambia su forma. */
    private void actualizarPlacas() {
        for (Pieza p : piezas) {
            if (p.tipo != Pieza.PLACA || p.entsContorno.isEmpty()) continue;
            Hoja h = porHoja(p.hoja);
            if (h == null) continue;
            double[][] pol = Editar2D.poligono(h.b, p.entsContorno);
            if (pol == null || pol.length < 3) continue;
            p.contorno = enPlaca(p, pol);
            p.agujeros.clear();
            for (List<Integer> hu : p.entsAgujeros) {
                double[][] ph = Editar2D.poligono(h.b, hu);
                if (ph != null && ph.length >= 3) p.agujeros.add(enPlaca(p, ph));
            }
        }
    }

    // ---------------- Versión 4.3: bocetos, montaje y árbol ----------------

    private Hoja porHoja(int id) {
        for (Hoja h : hojas) if (h.id == id) return h;
        return null;
    }

    private List<Pieza> placasDe(Hoja h) {
        List<Pieza> l = new ArrayList<>();
        if (h != null) for (Pieza x : piezas) if (x.tipo == Pieza.PLACA && x.hoja == h.id) l.add(x);
        return l;
    }

    private String usadoEn(Hoja h) {
        StringBuilder sb = new StringBuilder();
        for (Pieza p : placasDe(h)) sb.append(sb.length() == 0 ? "" : ", ").append(p.nombre());
        return sb.length() == 0 ? "" : " · usado en " + sb;
    }

    private int figurasDe(Hoja h) {
        try { return Editar2D.figuras(h.b, new ArrayList<>()).size(); } catch (Exception e) { return 0; }
    }

    private void pintarCabeza() {
        if (cabeza2D == null || hoja == null) return;
        String estado;
        int nf = figurasDe(hoja);
        if (hoja.b.vacio()) estado = "Dibuje una figura cerrada";
        else if (boceto.libres == null) estado = nf + (nf == 1 ? " figura cerrada" : " figuras cerradas");
        else if (hoja.b.gradosLibres == 0) estado = "✔ Completo (todo negro) · " + nf + (nf == 1 ? " figura cerrada" : " figuras cerradas");
        else estado = "🔵 Faltan " + hoja.b.gradosLibres + " medidas o amarres (lo azul) · " + nf + (nf == 1 ? " figura cerrada" : " figuras cerradas");
        cabeza2D.setText("✏ " + hoja.nombre + " · " + hoja.plano + usadoEn(hoja) + "  ▼\n" + estado);
    }

    private void menuBocetos() {
        List<String> op = new ArrayList<>();
        for (Hoja h : hojas) op.add((h == hoja ? "▶ " : "✏ ") + h.nombre + " · " + h.plano + usadoEn(h));
        op.add("➕ Boceto nuevo");
        op.add("✎ Cambiar el nombre de " + hoja.nombre);
        new AlertDialog.Builder(this).setTitle("Bocetos").setItems(op.toArray(new String[0]), (d, w) -> {
            if (w < hojas.size()) abrirHoja(hojas.get(w));
            else if (w == hojas.size()) nuevoBoceto();
            else {
                EditText t = campoTexto(hoja.nombre, "");
                new AlertDialog.Builder(this).setTitle("Nombre del boceto").setView(t)
                        .setPositiveButton("Guardar", (d2, w2) -> { antes(); hoja.nombre = t.getText().toString().trim().isEmpty() ? hoja.nombre : t.getText().toString().trim(); recalcular(); })
                        .setNegativeButton("Cancelar", null).show();
            }
        }).show();
    }

    /** Abrir un boceto: se pasa al 2D con ese boceto. */
    private void abrirHoja(Hoja h) {
        if (h == null) return;
        if (boceto.modo != VistaBoceto.VER) listo2D();
        hoja = h;
        h.visible = true;
        boceto.b = h.b;
        boceto.limpiarSeleccion();
        mostrar(0);
        boceto.post(boceto::encuadrar);
        recalcular();
    }

    private int nuevoIdHoja() {
        int m = 0;
        for (Hoja h : hojas) m = Math.max(m, h.id);
        return m + 1;
    }

    /** ✏ Boceto nuevo: en el piso, el frente, el lado o sobre la cara de una pieza. */
    private void nuevoBoceto() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] plano = {0};
        l.addView(etiqueta("En qué plano"));
        grupoBotones(l, new String[]{"Piso (XY)", "Frente (XZ)", "Lado (YZ)", "🧱 Cara de una pieza"}, plano, 2, null);
        l.addView(etiqueta("Corrido desde el punto 0 (mm), hacia afuera del plano"));
        EditText cor = campoTexto("0", "");
        l.addView(cor);
        new AlertDialog.Builder(this).setTitle("✏ Boceto nuevo").setView(l)
                .setPositiveButton("Crear", (d, w) -> {
                    if (plano[0] == 3) {
                        mostrar(1);
                        aviso("Toque la cara de la pieza donde va el boceto");
                        vista.pideCara = (pieza, tipo, nrm, q) -> {
                            vista.pideCara = null;
                            Pieza pz = porId(pieza);
                            Hoja h = new Hoja();
                            h.id = nuevoIdHoja();
                            h.nombre = "Boceto " + h.id;
                            h.plano = "Cara de " + (pz == null ? "pieza" : pz.nombre());
                            float[] n = {nrm[0], nrm[1], nrm[2]};
                            float[] ey = Math.abs(n[2]) < 0.9f ? new float[]{-n[0] * n[2], -n[1] * n[2], 1 - n[2] * n[2]} : new float[]{0, 1, 0};
                            float ly = (float) Math.sqrt(ey[0] * ey[0] + ey[1] * ey[1] + ey[2] * ey[2]);
                            ey = new float[]{ey[0] / ly, ey[1] / ly, ey[2] / ly};
                            h.ey = ey;
                            h.ex = new float[]{ey[1] * n[2] - ey[2] * n[1], ey[2] * n[0] - ey[0] * n[2], ey[0] * n[1] - ey[1] * n[0]};
                            h.o = new float[]{Math.round(q[0]), Math.round(q[1]), Math.round(q[2])};
                            antes();
                            hojas.add(h);
                            abrirHoja(h);
                            aviso("✏ " + h.nombre + " sobre " + h.plano + ". El 0,0 quedó donde tocó");
                        };
                        return;
                    }
                    antes();
                    Hoja h = Hoja.nueva(nuevoIdHoja(), plano[0]);
                    Double c = valorDe(cor.getText().toString());
                    if (c != null && c != 0) {
                        float[] n = h.normal();
                        h.o = new float[]{(float) (n[0] * c), (float) (n[1] * c), (float) (n[2] * c)};
                        h.plano += " a " + Formula.n(c) + " mm";
                    }
                    hojas.add(h);
                    abrirHoja(h);
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🏁 Terminar boceto: se pasa al montaje para extruir. */
    private void terminarBoceto() {
        if (boceto.modo != VistaBoceto.VER) listo2D();
        int nf = figurasDe(hoja);
        vista.hojaResaltada = nf > 0 ? hoja.id : -1;
        mostrar(1);
        vista.encuadrar();
        recalcular();
        if (nf == 0) aviso("🏁 " + hoja.nombre + " terminado, pero no tiene figuras cerradas para extruir");
        else if (!placasDe(hoja).isEmpty()) aviso("🏁 " + hoja.nombre + " terminado: " + usadoEn(hoja).replace(" · usado en ", "") + " ya se actualizó");
        else aviso("🏁 " + hoja.nombre + " terminado. Toque ⬆ Extruir para hacer la pieza");
    }

    /** ⬆ Extruir en el montaje: se escoge el boceto y se toca la figura sombreada. */
    private void extruir3D() {
        List<Hoja> c = new ArrayList<>();
        if (hoja != null && figurasDe(hoja) > 0) c.add(hoja);
        for (Hoja h : hojas) if (h != hoja && figurasDe(h) > 0) c.add(h);
        if (c.isEmpty()) { aviso("Primero haga un boceto con una figura cerrada (✏ Boceto)"); return; }
        if (c.size() == 1) { extruirDe(c.get(0)); return; }
        String[] nom = new String[c.size()];
        for (int i = 0; i < nom.length; i++) nom[i] = c.get(i).nombre + " · " + c.get(i).plano + usadoEn(c.get(i));
        new AlertDialog.Builder(this).setTitle("⬆ Extruir: ¿de qué boceto?").setItems(nom, (d, w) -> extruirDe(c.get(w))).show();
    }

    private void extruirDe(Hoja h) {
        List<double[][]> pols = new ArrayList<>();
        List<List<Integer>> ls = Editar2D.figuras(h.b, pols);
        h.visible = true;
        if (ls.size() == 1 && pols.get(0) != null) {
            Editar2D.Figura f = new Editar2D.Figura();
            f.borde = ls.get(0);
            f.pol = pols.get(0);
            dialogoExtruir(h, f);
            return;
        }
        mostrar(1);
        vista.hojaResaltada = h.id;
        vista.invalidate();
        aviso("Toque adentro de la figura sombreada que quiere extruir (atrás = cancelar)");
        vista.pideToque = (x, y) -> {
            float[] w = vista.enPlano(x, y, h.o, h.normal());
            double[] q = h.local(w);
            Editar2D.Figura f = Editar2D.figuraEn(h.b, q[0], q[1]);
            if (f == null) { aviso("Ahí no hay figura cerrada de " + h.nombre + ". Toque adentro de lo sombreado"); return; }
            vista.pideToque = null;
            dialogoExtruir(h, f);
        };
    }

    private void borrar3D() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere borrar (o use 🗑 en el árbol de abajo)"); return; }
        eliminar(p);
    }

    private void borrarHoja(Hoja h) {
        List<Pieza> us = placasDe(h);
        String msg = "¿Borrar " + h.nombre + "?" + (us.isEmpty() ? "" : "\n\nLas piezas " + usadoEn(h).replace(" · usado en ", "") + " se quedan con la forma que tienen, pero ya no se pueden cambiar desde el boceto.");
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("🗑 Borrar", (d, w) -> {
            antes();
            for (Pieza p : us) { p.entsContorno.clear(); p.entsAgujeros.clear(); p.hoja = -1; }
            hojas.remove(h);
            if (hojas.isEmpty()) hojas.add(Hoja.nueva(1, 0));
            if (hoja == h) { hoja = hojas.get(hojas.size() - 1); boceto.b = hoja.b; boceto.limpiarSeleccion(); }
            recalcular();
        }).setNegativeButton("Cancelar", null).show();
    }

    /** Una fila del árbol: el nombre y los botones 👁 ✏ 🗑. */
    private void filaArbol(String txt, int fondo, boolean escogido, boolean visible, Runnable tocar, Runnable ojo, Runnable lapiz, Runnable basura) {
        LinearLayout f = new LinearLayout(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(escogido ? Color.BLACK : visible ? Color.WHITE : 0xFF90A4AE);
        t.setTextSize(14);
        t.setPadding(dp(10), dp(7), dp(8), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(escogido ? 0xFFFFB300 : fondo);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(v -> tocar.run());
        f.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView[] bs = {boton(visible ? "👁" : "◌", 0xFF37474F, ojo), boton("✏", 0xFF1E88E5, lapiz), boton("🗑", 0xFFC62828, basura)};
        for (TextView b : bs) {
            b.setTextSize(15);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(42), -1);
            bp.leftMargin = dp(3);
            f.addView(b, bp);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        lista.addView(f, lp);
    }

    private void tituloArbol(String txt) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(0xFFB0BEC5);
        t.setTextSize(13);
        t.setPadding(dp(6), dp(8), dp(6), dp(2));
        lista.addView(t);
    }

    /** Editar una placa: grueso, sitio, borrar. */
    private void editarPlaca(Pieza p) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        l.addView(etiqueta("Nombre de la pieza"));
        EditText tn = campoTexto(p.nombre(), "");
        l.addView(tn);
        l.addView(etiqueta("Grueso (mm o fórmula)"));
        EditText g = campoTexto(p.f.containsKey("largo") ? p.f.get("largo") : Pieza.n(p.largo), "");
        l.addView(g);
        final int[] lado = {p.alReves ? 1 : 0};
        if (p.marco != null) {
            l.addView(etiqueta("Hacia dónde sale del plano"));
            grupoBotones(l, new String[]{"⬆ Para un lado", "⬇ Para el otro"}, lado, 2, null);
        }
        l.addView(etiqueta("Corrida en X, Y, Z (mm)"));
        EditText x = campoTexto(Pieza.n(p.cx), ""), y = campoTexto(Pieza.n(p.cy), ""), z = campoTexto(Pieza.n(p.cz), "");
        l.addView(x); l.addView(y); l.addView(z);
        l.addView(etiqueta(p.huecos.size() + " huecos perforados · " + p.agujeros.size() + " huecos del boceto"));
        new AlertDialog.Builder(this).setTitle("✏ " + p.nombre() + " (placa)").setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    antes();
                    String tt = tn.getText().toString().trim();
                    if (!tt.equals(p.nombre())) p.titulo = tt;
                    p.alReves = lado[0] == 1;
                    leerCampo(p, "largo", g.getText().toString());
                    leerCampo(p, "cx", x.getText().toString());
                    leerCampo(p, "cy", y.getText().toString());
                    leerCampo(p, "cz", z.getText().toString());
                    recalcular();
                })
                .setNeutralButton(porHoja(p.hoja) != null ? "✏ Su boceto" : "🗑 Eliminar", (d, w) -> { Hoja h = porHoja(p.hoja); if (h != null) abrirHoja(h); else eliminar(p); })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Versión 3: en una sola ventana: el punto, la cara donde se pega y la separación, con un dibujito de muestra. */
    private void dialogoAmarre(Pieza p, Pieza padre) {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), dp(4));
        sv.addView(l);
        final int[] punto = {p.padre == padre.id ? p.punto : 1};
        final int[] cara = {p.padre == padre.id ? p.cara : 0};
        View[] muestra = new View[1];
        l.addView(etiqueta("1. En qué punto de " + padre.nombre()));
        grupoBotones(l, new String[]{"Inicio", "Final", "A medida"}, punto, 3, () -> muestra[0].invalidate());
        EditText am = campoTexto(p.padre == padre.id ? (p.f.containsKey("aMm") ? p.f.get("aMm") : Pieza.n(p.aMm)) : "0", "");
        l.addView(etiqueta("Medida desde el inicio (mm o fórmula), si escogió «A medida»"));
        l.addView(am);
        l.addView(etiqueta("2. En qué cara de " + padre.nombre() + " se pega"));
        grupoBotones(l, new String[]{"Arriba", "Abajo", "Punta", "Izquierda", "Derecha", "Centrado"}, cara, 3, () -> muestra[0].invalidate());
        l.addView(etiqueta("3. Separación (luz libre, mm o fórmula)"));
        EditText se = campoTexto(p.padre == padre.id ? (p.f.containsKey("sep") ? p.f.get("sep") : Pieza.n(p.sep)) : "0", "");
        l.addView(se);
        muestra[0] = new View(this) {
            private final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight();
                c.drawColor(0xFF0D1117);
                float y0 = h * 0.55f, alto = h * 0.2f, x0 = w * 0.08f, x1 = w * 0.92f;
                pp.setColor(0xFF26A69A);
                c.drawRect(x0, y0, x1, y0 + alto, pp);
                pp.setTextSize(dp(12));
                pp.setColor(Color.WHITE);
                c.drawText(padre.nombre(), (x0 + x1) / 2 - dp(8), y0 + alto / 2 + dp(4), pp);
                int k = cara[0];
                float cw = alto * 0.9f, ch = h * 0.34f;
                float px = punto[0] == 0 ? x0 : punto[0] == 1 ? x1 : (x0 + x1) / 2;
                float cx = px - cw / 2, cy;
                String nota = "";
                switch (k) {
                    case 1: cy = y0 - ch; break;
                    case 2: cy = y0 + alto; break;
                    case 3: cy = y0 + alto / 2 - ch / 2; nota = " (al lado izquierdo)"; break;
                    case 4: cy = y0 + alto / 2 - ch / 2; nota = " (al lado derecho)"; break;
                    case 5: cy = y0 + alto / 2 - ch / 2; cx = punto[0] == 0 ? x0 - cw : x1; break;
                    default: cy = y0 + alto / 2 - ch / 2; nota = " (en el eje)";
                }
                pp.setColor(k == 3 || k == 4 ? 0x99FFB300 : 0xFFFFB300);
                c.drawRect(cx, cy, cx + cw, cy + ch, pp);
                pp.setColor(Color.WHITE);
                c.drawText(p.nombre() + " " + Pieza.CARAS_UNION[k].toLowerCase() + nota, dp(6), dp(16), pp);
            }
        };
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(110));
        mp.topMargin = dp(8);
        l.addView(muestra[0], mp);
        new AlertDialog.Builder(this).setTitle("🔗 Amarrar " + p.nombre() + " a " + padre.nombre()).setView(sv)
                .setPositiveButton("Amarrar", (d2, w2) -> {
                    antes();
                    p.padre = padre.id;
                    p.punto = punto[0];
                    p.cara = cara[0];
                    p.cx = p.cy = p.cz = 0;
                    p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                    leerCampo(p, "aMm", am.getText().toString());
                    leerCampo(p, "sep", se.getText().toString());
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Botones para escoger una opción (la escogida queda en naranja). Las opciones van en el orden de los valores: "Arriba" = 1… */
    private void grupoBotones(LinearLayout l, String[] ops, int[] valor, int columnas, Runnable alCambiar) {
        // la cara: los textos están en orden de pantalla; el valor real sale de CARAS_UNION
        List<TextView> bs = new ArrayList<>();
        LinearLayout fila = null;
        for (int i = 0; i < ops.length; i++) {
            if (i % columnas == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(42));
                fp.topMargin = dp(4);
                l.addView(fila, fp);
            }
            int v = Arrays.asList(Pieza.CARAS_UNION).indexOf(ops[i]);
            if (v < 0) v = i;
            final int val = v;
            TextView t = boton(ops[i], 0xFF455A64, null);
            t.setTag(val);
            t.setOnClickListener(x -> {
                valor[0] = val;
                for (TextView o : bs) colorear(o, ((Integer) o.getTag()) == valor[0] ? 0xFFFF8F00 : 0xFF455A64);
                if (alCambiar != null) alCambiar.run();
            });
            bs.add(t);
            fila.addView(t, peso());
        }
        for (TextView o : bs) colorear(o, ((Integer) o.getTag()) == valor[0] ? 0xFFFF8F00 : 0xFF455A64);
    }

    /** Un campo de la pieza: número fijo o fórmula de la tablita. */
    private void leerCampo(Pieza p, String k, String texto) {
        String t = texto == null ? "" : texto.trim();
        if (t.isEmpty()) return;
        Double n = Formula.numero(t);
        if (n != null) { p.ponerCampo(k, n.floatValue()); p.f.remove(k); return; }
        fijos();
        medidas.calcular();
        try {
            double v = medidas.evaluar(t);
            p.ponerCampo(k, (float) v);
            p.f.put(k, t);
        } catch (Exception e) {
            aviso("⚠ " + p.nombre() + ": la fórmula «" + t + "» no sirve: " + e.getMessage());
        }
    }

    // ---------------- Formulario de una pieza ----------------

    private EditText numero(LinearLayout l, String etiqueta, float valor, boolean signo) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        e.setText(Pieza.n(valor));
        e.setTextSize(17);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | (signo ? InputType.TYPE_NUMBER_FLAG_SIGNED : 0));
        l.addView(e);
        return e;
    }

    /** Casilla que acepta número o fórmula (el teclado normal, para poder escribir nombres). */
    private EditText numeroOFormula(LinearLayout l, String etiqueta, Pieza p, String k) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        String f = p.f.get(k);
        e.setText(f != null ? f : Pieza.n(p.campo(k)));
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        l.addView(e);
        return e;
    }

    private EditText[] filaNumeros(LinearLayout l, String[] etiquetas, float[] valores, boolean signo) {
        LinearLayout fila = new LinearLayout(this);
        EditText[] r = new EditText[etiquetas.length];
        for (int i = 0; i < etiquetas.length; i++) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            r[i] = numero(c, etiquetas[i], valores[i], signo);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.setMargins(0, 0, dp(6), 0);
            fila.addView(c, p);
        }
        l.addView(fila);
        return r;
    }

    private Spinner lista(LinearLayout l, String etiqueta, String[] items, int sel) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(Math.max(0, Math.min(items.length - 1, sel)));
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
        return s;
    }

    private static float leer(EditText e, float porDefecto) {
        try { return Float.parseFloat(e.getText().toString().trim().replace(',', '.')); } catch (Exception x) { return porDefecto; }
    }

    private static String[] nombresMedidas(int tipo) {
        Object[][] m = Pieza.MEDIDAS[tipo];
        String[] r = new String[m.length + 1];
        for (int i = 0; i < m.length; i++) r[i] = (String) m[i][0];
        r[m.length] = "Otra medida (escríbala abajo)";
        return r;
    }

    private void titulo(LinearLayout l, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(2));
        l.addView(t);
    }

    private void editar(Pieza original) {
        if (original != null && original.tipo == Pieza.PLACA) { editarPlaca(original); return; }
        final boolean nueva = original == null;
        final Pieza p;
        if (nueva) {
            p = new Pieza();
            p.id = nuevoId();
            Pieza ult = piezas.isEmpty() ? null : piezas.get(piezas.size() - 1);
            if (ult != null) {   // por comodidad: la nueva sale igual a la anterior y pegada a su final
                p.tipo = ult.tipo; p.medida = ult.medida; p.a = ult.a; p.b = ult.b; p.t = ult.t; p.calibre = ult.calibre;
                p.padre = ult.id; p.punto = 1;
            }
        } else p = original;

        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), dp(10));
        sv.addView(l);
        if (!nueva) {
            // versión 4.2: dónde queda la pieza (se calcula sola)
            float[] ini = p.inicio(mapaPiezas(), 0), d = p.direccion();
            TextView co = etiqueta("Inicio X, Y, Z: " + Pieza.n(r1(ini[0])) + ", " + Pieza.n(r1(ini[1])) + ", " + Pieza.n(r1(ini[2]))
                    + "\nFinal X, Y, Z: " + Pieza.n(r1(ini[0] + d[0] * p.largo)) + ", " + Pieza.n(r1(ini[1] + d[1] * p.largo)) + ", " + Pieza.n(r1(ini[2] + d[2] * p.largo))
                    + "\nLargo de corte (punta larga): " + Pieza.n(r1(p.largoCorte())) + " mm");
            co.setTextColor(0xFF90A4AE);
            l.addView(co);
        }

        titulo(l, "1. El perfil");
        Spinner sTipo = lista(l, "Perfil", Pieza.TIPOS, p.tipo);
        int iMed = Arrays.asList(nombresMedidas(p.tipo)).indexOf(p.medida);
        Spinner sMed = lista(l, "Medida", nombresMedidas(p.tipo), iMed < 0 ? Pieza.MEDIDAS[p.tipo].length : iMed);
        EditText[] dims = filaNumeros(l, new String[]{"Ancho mm", "Alto mm", "Espesor mm"}, new float[]{p.a, p.b, p.t}, false);
        TextView tc = new TextView(this);
        tc.setText("Calibre (para pedirlo en la ferretería)");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setPadding(0, dp(8), 0, 0);
        l.addView(tc);
        EditText eCal = new EditText(this);
        eCal.setText(p.calibre);
        l.addView(eCal);
        final int[] tipoAntes = {p.tipo};
        sTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                if (pos == tipoAntes[0]) return;
                tipoAntes[0] = pos;
                sMed.setAdapter(new ArrayAdapter<>(InventorActivity.this, android.R.layout.simple_spinner_dropdown_item, nombresMedidas(pos)));
                sMed.setSelection(Math.min(2, Pieza.MEDIDAS[pos].length - 1));
                eCal.setText(pos <= 2 ? "Cal 18" : "");
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });
        sMed.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                Object[][] m = Pieza.MEDIDAS[sTipo.getSelectedItemPosition()];
                if (pos >= m.length) return;
                dims[0].setText(Pieza.n((Float) m[pos][1]));
                dims[1].setText(Pieza.n((Float) m[pos][2]));
                dims[2].setText(Pieza.n((Float) m[pos][3]));
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });

        titulo(l, "2. Largo y hacia dónde va");
        EditText eLargo = numeroOFormula(l, "Largo de corte (mm o fórmula, ej. ancho - 2*tubo)", p, "largo");
        Spinner sDir = lista(l, "Dirección", Pieza.DIRS, p.dir);
        EditText eIncl = numero(l, "Inclinación (grados, 0 = derecho)", p.incl, true);
        Spinner sGiro = lista(l, "Girar la sección (para ángulo o platina)", new String[]{"0°", "90°", "180°", "270°"}, p.giro);

        titulo(l, "3. Dónde se une");
        Set<Integer> no = nueva ? new HashSet<>() : descendientes(p.id);
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (x != p && !no.contains(x.id)) posibles.add(x);
        String[] nomPadres = new String[posibles.size() + 1];
        nomPadres[0] = "En el punto 0 (suelta)";
        int selPadre = 0;
        for (int i = 0; i < posibles.size(); i++) {
            nomPadres[i + 1] = posibles.get(i).nombre() + " · " + posibles.get(i).referencia();
            if (posibles.get(i).id == p.padre) selPadre = i + 1;
        }
        Spinner sPadre = lista(l, "Va pegada a", nomPadres, selPadre);
        Spinner sPunto = lista(l, "En qué punto de esa pieza", new String[]{"Al inicio", "Al final", "A una medida del inicio"}, p.punto);
        Spinner sCara = lista(l, "En qué cara de esa pieza se pega", Pieza.CARAS_UNION, p.cara);
        EditText eAmm = numeroOFormula(l, "Medida desde el inicio (mm o fórmula), si escogió «a una medida»", p, "aMm");
        EditText eSep = numeroOFormula(l, "Separación (mm o fórmula) — luz entre las dos piezas", p, "sep");
        EditText eCx = numeroOFormula(l, "Correr X (mm o fórmula)", p, "cx");
        EditText eCy = numeroOFormula(l, "Correr Y (mm o fórmula)", p, "cy");
        EditText eCz = numeroOFormula(l, "Correr Z (mm o fórmula)", p, "cz");

        titulo(l, "4. Cortes de las puntas");
        EditText[] cortes = filaNumeros(l, new String[]{"Inicio (°)", "Final (°)"}, new float[]{p.corteIni, p.corteFin}, true);

        titulo(l, "5. Huecos y ranuras");
        LinearLayout cajaHuecos = new LinearLayout(this);
        cajaHuecos.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHuecos);
        List<Object[]> filasHueco = new ArrayList<>();
        for (Pieza.Hueco h : p.huecos) agregarFilaHueco(cajaHuecos, filasHueco, h);
        TextView masH = boton("➕ Agregar hueco", 0xFF37474F, () -> agregarFilaHueco(cajaHuecos, filasHueco, new Pieza.Hueco()));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(44));
        mp.topMargin = dp(6);
        l.addView(masH, mp);

        new AlertDialog.Builder(this).setTitle(nueva ? "➕ Pieza nueva " + p.nombre() : "✏ " + p.nombre()).setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    antes();
                    p.tipo = sTipo.getSelectedItemPosition();
                    int im = sMed.getSelectedItemPosition();
                    p.a = Math.max(1, leer(dims[0], p.a));
                    p.b = Math.max(1, leer(dims[1], p.b));
                    p.t = Math.max(0.3f, leer(dims[2], p.t));
                    p.medida = im < Pieza.MEDIDAS[p.tipo].length ? (String) Pieza.MEDIDAS[p.tipo][im][0]
                            : Pieza.n(p.a) + "x" + Pieza.n(p.b) + " mm";
                    p.calibre = eCal.getText().toString();
                    leerCampo(p, "largo", eLargo.getText().toString());
                    if (p.largo <= 0) p.largo = 1000;
                    p.dir = sDir.getSelectedItemPosition();
                    p.incl = leer(eIncl, 0);
                    p.giro = sGiro.getSelectedItemPosition();
                    int ip = sPadre.getSelectedItemPosition();
                    p.padre = ip == 0 ? -1 : posibles.get(ip - 1).id;
                    p.punto = sPunto.getSelectedItemPosition();
                    p.cara = p.padre < 0 ? 0 : sCara.getSelectedItemPosition();
                    leerCampo(p, "aMm", eAmm.getText().toString());
                    leerCampo(p, "sep", eSep.getText().toString());
                    leerCampo(p, "cx", eCx.getText().toString());
                    leerCampo(p, "cy", eCy.getText().toString());
                    leerCampo(p, "cz", eCz.getText().toString());
                    p.corteIni = leer(cortes[0], 0); p.corteFin = leer(cortes[1], 0);
                    p.huecos.clear();
                    for (Object[] f : filasHueco) {
                        Pieza.Hueco h = new Pieza.Hueco();
                        h.tipo = ((Spinner) f[0]).getSelectedItemPosition();
                        h.d1 = Math.max(1, leer((EditText) f[1], 10));
                        h.d2 = Math.max(1, leer((EditText) f[2], 8));
                        h.pos = leer((EditText) f[3], 50);
                        h.cara = ((Spinner) f[4]).getSelectedItemPosition();
                        p.huecos.add(h);
                    }
                    if (nueva) piezas.add(p);
                    escogida = p.id;
                    vista.encuadrar();
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Una fila de hueco: tipo, medidas, posición y cara. */
    private void agregarFilaHueco(LinearLayout caja, List<Object[]> filas, Pieza.Hueco h) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(8), dp(4), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        f.setBackground(g);
        Spinner sT = lista(f, "Hueco " + (filas.size() + 1), Pieza.HUECOS, h.tipo);
        EditText[] m = filaNumeros(f, new String[]{"Ø / lado / largo", "Ancho ranura", "A mm del inicio"}, new float[]{h.d1, h.d2, h.pos}, false);
        Spinner sC = lista(f, "En qué cara", Pieza.CARAS, h.cara);
        Object[] reg = {sT, m[0], m[1], m[2], sC, f};
        TextView quitar = boton("✕ Quitar este hueco", 0xFFC62828, () -> { caja.removeView(f); filas.remove(reg); });
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, dp(38));
        qp.topMargin = dp(6);
        f.addView(quitar, qp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        caja.addView(f, lp);
        filas.add(reg);
    }

    // ---------------- Lista de corte ----------------

    private String textoCorte() {
        Map<String, List<Pieza>> grupos = new LinkedHashMap<>();
        for (Pieza p : piezas) {
            if (p.tipo == Pieza.PLACA) continue;
            List<Pieza> g = grupos.get(p.referencia());
            if (g == null) { g = new ArrayList<>(); grupos.put(p.referencia(), g); }
            g.add(p);
        }
        StringBuilder s = new StringBuilder();
        s.append("MI INVENTOR - LISTA DE CORTE\n");
        s.append("Proyecto: ").append(nombreProyecto).append("\n");
        s.append(new SimpleDateFormat("dd/MM/yyyy h:mm a", new Locale("es", "CO")).format(new Date())).append("\n");
        s.append("Barras de 6 m · se descuentan 3 mm por cada corte\n");
        int totalBarras = 0;
        for (Map.Entry<String, List<Pieza>> en : grupos.entrySet()) {
            s.append("\n========================================\n");
            s.append(en.getKey().toUpperCase(new Locale("es", "CO"))).append("\n");
            s.append("========================================\n");
            float metros = 0;
            List<Float> largos = new ArrayList<>();
            List<String> largas = new ArrayList<>();
            int extra = 0;
            for (Pieza p : en.getValue()) {
                float lc = p.largoCorte();
                metros += lc;
                s.append(String.format(Locale.US, "%-4s %6s mm", p.nombre(), Pieza.n(lc)));
                if (Math.abs(p.corteIni) > 0.01f || Math.abs(p.corteFin) > 0.01f)
                    s.append("  (punta larga) cortes ").append(Pieza.n(Math.abs(p.corteIni))).append("° / ").append(Pieza.n(Math.abs(p.corteFin))).append("°")
                            .append(" · eje ").append(Pieza.n(p.largo));
                else s.append("  cortes rectos (90°)");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(h.texto()).append("\n");
                if (lc > BARRA) { largas.add(p.nombre() + " (" + Pieza.n(lc) + " mm)"); extra += (int) Math.ceil(lc / BARRA); }
                else largos.add(lc);
            }
            // acomodar los cortes en barras: primero los más largos
            largos.sort((x, y) -> Float.compare(y, x));
            List<List<Float>> barras = new ArrayList<>();
            List<Float> libre = new ArrayList<>();
            for (float L : largos) {
                int k = -1;
                for (int i = 0; i < barras.size(); i++) if (libre.get(i) >= L + (barras.get(i).isEmpty() ? 0 : DISCO)) { k = i; break; }
                if (k < 0) { barras.add(new ArrayList<>()); libre.add(BARRA); k = barras.size() - 1; }
                libre.set(k, libre.get(k) - L - (barras.get(k).isEmpty() ? 0 : DISCO));
                barras.get(k).add(L);
            }
            s.append("\nMetros lineales: ").append(String.format(Locale.US, "%.2f", metros / 1000f)).append(" m\n");
            for (int i = 0; i < barras.size(); i++) {
                s.append("Barra ").append(i + 1).append(": ");
                List<Float> b = barras.get(i);
                for (int j = 0; j < b.size(); j++) s.append(j == 0 ? "" : " + ").append(Pieza.n(b.get(j)));
                s.append("  (sobran ").append(Pieza.n(Math.max(0, libre.get(i)))).append(" mm)\n");
            }
            if (!largas.isEmpty()) s.append("Más largas que 6 m (van empatadas): ").append(String.join(", ", largas)).append("\n");
            int comprar = barras.size() + extra;
            totalBarras += comprar;
            s.append(">> COMPRAR: ").append(comprar).append(comprar == 1 ? " barra de 6 m\n" : " barras de 6 m\n");
        }
        // versión 4: las placas sacadas del boceto
        List<Pieza> pl = placas();
        if (!pl.isEmpty()) {
            s.append("\n========================================\nPLACAS (del boceto)\n========================================\n");
            for (Pieza p : pl) {
                float s0 = Float.MAX_VALUE, s1 = -Float.MAX_VALUE, u0 = Float.MAX_VALUE, u1 = -Float.MAX_VALUE;
                if (p.contorno != null) for (float[] q : p.contorno) { s0 = Math.min(s0, q[0]); s1 = Math.max(s1, q[0]); u0 = Math.min(u0, q[1]); u1 = Math.max(u1, q[1]); }
                float ar = p.contorno == null ? 0 : Math.abs(Vista3D.area(p.contorno));
                for (float[][] h : p.agujeros) ar -= Math.abs(Vista3D.area(h));
                s.append(p.nombre()).append("  ").append(Pieza.n(s1 - s0)).append(" x ").append(Pieza.n(u1 - u0)).append(" mm · grueso ")
                        .append(Pieza.n(p.largo)).append(" mm · área ").append(String.format(Locale.US, "%.3f", ar / 1e6f)).append(" m²");
                int nh = p.agujeros.size() + p.huecos.size();
                if (nh > 0) s.append(" · ").append(nh).append(nh == 1 ? " hueco" : " huecos");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(Pieza.HUECOS[h.tipo].toLowerCase()).append(" Ø").append(Pieza.n(h.d1))
                        .append(" en X ").append(Pieza.n(-h.s)).append(" Y ").append(Pieza.n(h.u)).append("\n");
            }
        }
        s.append("\n----------------------------------------\n");
        s.append("TOTAL: ").append(totalBarras).append(" barras de 6 m\n");
        return s.toString();
    }

    private void listaCorte() {
        if (piezas.isEmpty()) { aviso("Todavía no hay piezas en el 3D"); return; }
        String txt = textoCorte();
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(Color.WHITE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("📋 Lista de corte").setView(sv)
                .setPositiveButton("📄 PDF carta", (d, w) -> pdf(txt))
                .setNeutralButton("📲 WhatsApp", (d, w) -> compartirTexto(txt))
                .setNegativeButton("Cerrar", null).show();
    }

    private void compartirTexto(String txt) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) { try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {} }
    }

    /** La lista en PDF tamaño carta, letras negras nítidas. */
    private void pdf(String txt) {
        try {
            PdfDocument doc = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(10.5f);
            String[] lineas = txt.split("\n");
            float alto = 14, arriba = 50, abajo = 792 - 45;
            int num = 1, i = 0;
            while (i < lineas.length) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                float y = arriba;
                while (i < lineas.length && y < abajo) {
                    String ln = lineas[i++];
                    p.setFakeBoldText(ln.startsWith(">>") || ln.startsWith("TOTAL") || ln.startsWith("MI INVENTOR") || (i > 1 && ln.equals(ln.toUpperCase()) && !ln.startsWith("=")));
                    c.drawText(ln, 45, y, p);
                    y += alto;
                }
                p.setFakeBoldText(false);
                c.drawText("Página " + num, 520, 775, p);
                doc.finishPage(pg);
                num++;
            }
            guardarPdf(doc, "MiInventor_Corte_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Proyectos (archivos livianos) ----------------

    private File carpeta() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private JSONObject proyecto() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 4);
        o.put("nombre", nombreProyecto);
        JSONArray a = new JSONArray();
        for (Pieza p : piezas) a.put(p.json());
        o.put("piezas", a);
        o.put("medidas", medidas.json());
        JSONArray hs = new JSONArray();
        for (Hoja h : hojas) hs.put(h.json());
        o.put("bocetos", hs);
        o.put("hojaAct", hoja == null ? 1 : hoja.id);
        return o;
    }

    private void cargar(JSONObject o) throws Exception {
        JSONArray a = o.optJSONArray("piezas");
        piezas.clear();
        if (a != null) for (int i = 0; i < a.length(); i++) piezas.add(Pieza.deJson(a.getJSONObject(i)));
        medidas.deJson(o.optJSONArray("medidas"));
        hojas.clear();
        JSONArray hs = o.optJSONArray("bocetos");
        if (hs != null) for (int i = 0; i < hs.length(); i++) hojas.add(Hoja.deJson(hs.getJSONObject(i)));
        else {
            // proyectos viejos: un solo boceto, en el piso
            Hoja h = Hoja.nueva(1, 0);
            h.b = Boceto.deJson(o.optJSONObject("boceto"));
            hojas.add(h);
            for (Pieza p : piezas) if (p.tipo == Pieza.PLACA && p.hoja < 0) p.hoja = 1;
        }
        if (hojas.isEmpty()) hojas.add(Hoja.nueva(1, 0));
        hoja = porHoja(o.optInt("hojaAct", hojas.get(0).id));
        if (hoja == null) hoja = hojas.get(0);
        boceto.b = hoja.b;
        boceto.limpiarSeleccion();
        nombreProyecto = o.optString("nombre", nombreProyecto);
        if (porId(escogida) == null) escogida = -1;
    }

    private void menuProyecto() {
        new AlertDialog.Builder(this).setTitle("📂 Archivo · " + nombreProyecto)
                .setItems(new String[]{"💾 Guardar con nombre", "📂 Abrir uno guardado", "📤 Enviar el proyecto (archivo liviano)",
                        "📥 Abrir un proyecto recibido", "📄 Empezar uno nuevo (vacío)",
                        "📄 PDF carta del plano 2D", "📐 Abrir un plano DXF (de AutoCAD)", "💾 Guardar el plano 2D en DXF", "🧹 Hoja 2D nueva (borra solo el 2D)"}, (d, w) -> {
                    if (w == 0) pedirNombre();
                    else if (w == 1) listaProyectos();
                    else if (w == 2) enviarProyecto();
                    else if (w == 3) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_ARCHIVO); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else if (w == 4) new AlertDialog.Builder(this).setMessage("¿Empezar vacío? Lo que no haya guardado con nombre se pierde (se puede deshacer con ↶).")
                                .setPositiveButton("Empezar", (d2, w2) -> {
                                    antes();
                                    piezas.clear(); medidas.filas.clear();
                                    hojas.clear(); hojas.add(Hoja.nueva(1, 0)); hoja = hojas.get(0); boceto.b = hoja.b;
                                    escogida = -1; nombreProyecto = "Sin nombre";
                                    vista.encuadrar(); boceto.encuadrar(); recalcular();
                                })
                                .setNegativeButton("Cancelar", null).show();
                    else if (w == 5) pdf2D();
                    else if (w == 6) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_DXF); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else if (w == 7) exportarDxf();
                    else new AlertDialog.Builder(this).setMessage("¿Borrar todo el boceto 2D? (se puede deshacer con ↶)")
                                .setPositiveButton("Borrar", (d2, w2) -> { antes(); hoja.b = new Boceto(); boceto.b = hoja.b; boceto.limpiarSeleccion(); recalcular(); })
                                .setNegativeButton("Cancelar", null).show();
                }).show();
    }

    /** Versión 3: el plano 2D en DXF (se abre en AutoCAD y en cualquier programa de dibujo). */
    private void exportarDxf() {
        if (boceto.b.vacio()) { aviso("El boceto 2D está vacío"); return; }
        try {
            byte[] datos = Dxf.exportar(boceto.b, boceto).getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                    + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".dxf";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/dxf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            new AlertDialog.Builder(this).setTitle("✔ DXF guardado")
                    .setMessage(nom + "\n\nQuedó en Descargas/MiBarra/MiInventor (" + Math.max(1, datos.length / 1024) + " KB).\nMedidas en milímetros.")
                    .setPositiveButton("📤 Enviar", (d, w) -> {
                        Intent i = new Intent(Intent.ACTION_SEND).setType("application/dxf").putExtra(Intent.EXTRA_STREAM, u)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { startActivity(Intent.createChooser(i, "Enviar el DXF")); } catch (Exception ignored) {}
                    })
                    .setNegativeButton("Listo", null).show();
        } catch (Exception e) {
            aviso("No se pudo guardar el DXF");
        }
    }

    /** Lee el DXF escogido y pregunta si reemplaza el boceto o se agrega. */
    private void abrirDxf(Uri u) {
        String texto;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) {
                bo.write(b, 0, n);
                if (bo.size() > 40 * 1024 * 1024) { aviso("Ese plano es muy grande (más de 40 MB)"); return; }
            }
            byte[] datos = bo.toByteArray();
            String inicio = new String(datos, 0, Math.min(datos.length, 32), StandardCharsets.ISO_8859_1);
            if (inicio.startsWith("AC10") || inicio.startsWith("AC1.")) {
                new AlertDialog.Builder(this).setTitle("Ese archivo es DWG")
                        .setMessage("Mi Inventor abre DXF. Pídale el plano en DXF a quien se lo mandó (en AutoCAD: Guardar como → DXF), "
                                + "o conviértalo gratis con ODA File Converter en un computador.")
                        .setPositiveButton("Entendido", null).show();
                return;
            }
            if (inicio.startsWith("AutoCAD Binary DXF")) { aviso("Ese DXF está en binario: guárdelo como DXF de texto (ASCII)"); return; }
            texto = new String(datos, StandardCharsets.UTF_8);
            if (!texto.contains("SECTION")) { aviso("Ese archivo no es un plano DXF"); return; }
        } catch (Exception e) {
            aviso("No se pudo leer el archivo");
            return;
        }
        final String t = texto;
        new AlertDialog.Builder(this).setTitle("📐 Abrir DXF")
                .setItems(new String[]{"Reemplazar el boceto 2D", "Agregarlo al boceto 2D que hay"}, (d, w) -> {
                    antes();
                    if (w == 0) { hoja.b = new Boceto(); boceto.b = hoja.b; }
                    Dxf.Resultado r = Dxf.importar(t, boceto.b);
                    if (r.total() == 0) { revertir(); aviso("No se encontraron líneas, círculos, arcos ni textos"); return; }
                    boceto.limpiarSeleccion();
                    mostrar(0);
                    boceto.encuadrar();
                    recalcular();
                    String m = "✔ " + r.lineas + " líneas, " + r.circulos + " círculos, " + r.arcos + " arcos, " + r.textos + " textos";
                    if (!r.unidades.equals("mm")) m += " (venía en " + r.unidades + ", pasado a mm)";
                    if (r.omitidos > 0) m += ". " + r.omitidos + " cosas no se pudieron traer (bloques, sombreados o cotas)";
                    new AlertDialog.Builder(this).setTitle("Plano abierto").setMessage(m).setPositiveButton("Listo", null).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** El proyecto es solo números y fórmulas: unos pocos KB. Se guarda en Descargas/MiBarra/MiInventor y se manda. */
    private void enviarProyecto() {
        try {
            byte[] datos = proyecto().toString().getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + ".miv.json";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            aviso("✔ Archivo de " + Math.max(1, datos.length / 1024) + " KB en Descargas/MiBarra/MiInventor");
            Intent i = new Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_STREAM, u)
                    .putExtra(Intent.EXTRA_TEXT, "Proyecto de Mi Inventor: " + nombreProyecto).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Enviar el proyecto"));
        } catch (Exception e) {
            aviso("No se pudo preparar el archivo");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == ABRIR_DXF) { abrirDxf(data.getData()); return; }
        if (req != ABRIR_ARCHIVO) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            byte[] b = new byte[8192];
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONObject o = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            antes();
            cargar(o);
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            aviso("Ese archivo no es un proyecto de Mi Inventor");
        }
    }

    private void pedirNombre() {
        EditText e = new EditText(this);
        e.setText("Sin nombre".equals(nombreProyecto) ? "" : nombreProyecto);
        e.setHint("Por ejemplo: escalera 55-21");
        new AlertDialog.Builder(this).setTitle("Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty() || n.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    nombreProyecto = n;
                    guardar(n, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void guardar(String nombre, boolean callado) {
        try {
            try (FileWriter w = new FileWriter(new File(carpeta(), nombre + ".json"))) { w.write(proyecto().toString()); }
            if (!callado) aviso("✔ Guardado «" + nombre + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo guardar");
        }
    }

    private void abrir(String nombre, boolean callado) {
        try {
            File f = new File(carpeta(), nombre + ".json");
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            cargar(o);
            escogida = -1;
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            if (!callado) aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo abrir");
        }
    }

    private void listaProyectos() {
        File[] fs = carpeta().listFiles(x -> x.getName().endsWith(".json") && !x.getName().startsWith("_"));
        if (fs == null || fs.length == 0) { aviso("Todavía no hay proyectos guardados con nombre"); return; }
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] nom = new String[fs.length];
        for (int i = 0; i < fs.length; i++) nom[i] = fs[i].getName().replace(".json", "") + "  (" + Math.max(1, fs[i].length() / 1024) + " KB)";
        new AlertDialog.Builder(this).setTitle("📂 Proyectos").setItems(nom, (d, w) -> {
            String n = fs[w].getName().replace(".json", "");
            new AlertDialog.Builder(this).setTitle(n).setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                if (w2 == 0) { antes(); abrir(n, false); }
                else new AlertDialog.Builder(this).setMessage("¿Borrar «" + n + "» para siempre?")
                        .setPositiveButton("Borrar", (d3, w3) -> { fs[w].delete(); aviso("Borrado"); })
                        .setNegativeButton("Cancelar", null).show();
            }).show();
        }).show();
    }
}
