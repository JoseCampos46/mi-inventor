package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

/** Versión 5: referencias que no son sólidos (como en Inventor): planos, ejes y puntos de trabajo. */
public class Ref {
    public static final int PLANO = 0, EJE = 1, PUNTO = 2;
    public static final String[] TIPOS = {"Plano", "Eje", "Punto"};

    public int id, tipo;
    public String nombre = "";
    /** Plano: un punto del plano · Eje: un punto del eje · Punto: el punto. */
    public float[] o = {0, 0, 0};
    /** Plano: la normal · Eje: la dirección. */
    public float[] v = {0, 0, 1};
    /** Plano: el eje X del dibujo del plano (para el cuadro que se ve). */
    public float[] ex = {1, 0, 0};
    /** Tamaño del dibujo: lado del plano o largo del eje (mm). */
    public float tam = 1000;
    public boolean visible = true;

    /** El eje Y del plano (ex y ey quedan con la normal v hacia afuera). */
    public float[] ey() { return Geo.unit(Geo.cross(v, ex)); }

    public static Ref plano(int id, String nombre, float[] o, float[] n) {
        Ref r = new Ref();
        r.id = id; r.tipo = PLANO; r.nombre = nombre;
        r.o = o.clone(); r.v = Geo.unit(n);
        float[] a = Math.abs(r.v[2]) < 0.9f ? new float[]{0, 0, 1} : new float[]{0, 1, 0};
        // eje X del cuadro: horizontal cuando se puede
        r.ex = Geo.unit(Geo.cross(a, r.v));
        return r;
    }

    public static Ref eje(int id, String nombre, float[] o, float[] d, float largo) {
        Ref r = new Ref();
        r.id = id; r.tipo = EJE; r.nombre = nombre;
        r.o = o.clone(); r.v = Geo.unit(d); r.tam = Math.max(100, largo);
        return r;
    }

    public static Ref punto(int id, String nombre, float[] o) {
        Ref r = new Ref();
        r.id = id; r.tipo = PUNTO; r.nombre = nombre;
        r.o = o.clone();
        return r;
    }

    public String texto() {
        String s = (tipo == PLANO ? "▱ " : tipo == EJE ? "╱ " : "• ") + nombre;
        if (tipo == PUNTO) s += " · " + Pieza.n(o[0]) + ", " + Pieza.n(o[1]) + ", " + Pieza.n(o[2]);
        return s;
    }

    public JSONObject json() throws Exception {
        JSONObject j = new JSONObject();
        j.put("id", id); j.put("t", tipo); j.put("n", nombre); j.put("vis", visible); j.put("tam", (double) tam);
        j.put("o", arr(o)); j.put("v", arr(v)); j.put("ex", arr(ex));
        return j;
    }

    public static Ref deJson(JSONObject j) {
        Ref r = new Ref();
        r.id = j.optInt("id"); r.tipo = j.optInt("t"); r.nombre = j.optString("n", "Ref");
        r.visible = j.optBoolean("vis", true); r.tam = (float) j.optDouble("tam", 1000);
        r.o = vec(j.optJSONArray("o"), r.o); r.v = vec(j.optJSONArray("v"), r.v); r.ex = vec(j.optJSONArray("ex"), r.ex);
        return r;
    }

    private static JSONArray arr(float[] v) throws Exception {
        JSONArray a = new JSONArray();
        for (float x : v) a.put(Math.round(x * 1000) / 1000.0);
        return a;
    }

    private static float[] vec(JSONArray a, float[] d) {
        if (a == null || a.length() < 3) return d;
        return new float[]{(float) a.optDouble(0, 0), (float) a.optDouble(1, 0), (float) a.optDouble(2, 0)};
    }
}
