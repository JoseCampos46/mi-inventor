package co.jose.miinventor;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * v6.9 · El manual de cada sección: imagen arriba y la explicación debajo.
 * Las imágenes salen de assets/tutorial/<seccion>_<n>.png (pantallazos reales); si falta una, sale un cuadro con su ícono.
 * Se va acomodando con cada versión.
 */
final class Tutorial {
    private Tutorial() { }

    static final int GENERAL = 0, PIEZA = 1, LAMINA = 2, ALUCOBOND = 3, CASA = 4, MONTAJE = 5, GABINETES = 6, CORTE = 7;
    static final String[] CLAVES = {"general", "pieza", "lamina", "alucobond", "casa", "montaje", "gabinetes", "corte"};
    static final String[] TITULOS = {"📖 Tutorial general", "🟩 Chepe Pieza", "📐 Chepe Lámina", "▦ Chepe Alucobond", "🏠 Chepe Casa", "🧩 Chepe Montaje", "🗄 Chepe Gabinetes", "✂ Chepe Corte"};

    /** Cada paso: {ícono, explicación}. */
    static final String[][][] PASOS = {
            {   // general
                    {"☰", "El menú de las tres rayitas (izquierda): escoja en qué va a trabajar. Siempre arranca en una pantalla nueva y limpia."},
                    {"⋮", "El menú de la derecha: guardar, librería, PDF, DXF, WhatsApp, tutorial de la sección y cerrar."},
                    {"⬛⬜", "En ☰ escoja la pantalla negra o blanca. En negra las líneas salen blancas; en blanca, negras."},
                    {"🔢", "El mini teclado de ChpCad: números, + − × ÷, paréntesis. «/» es pulgadas: 1/4 = 6.35 mm. ◀ ▶ corren el cursor. ABC abre las letras."},
                    {"📏", "Cada cota nace con nombre (L1, L2… ángulos A1…). Úselos en fórmulas: L1 + 20, (L1 − 30) ÷ 2."},
                    {"⊕", "Amarre al 0,0: toque un lado del rectángulo, una esquina o un círculo y luego ⊕ Al 0,0. El 0,0 solo se ve un momento (no sale en pantallazos)."},
                    {"🌳", "El cajetín de abajo: la lista de operaciones. Boceto = el dibujo; Pieza = el sólido. ✏ modificar, 👁 apagar, 🗑 borrar (pregunta antes)."},
                    {"🎥📷", "REC graba la pantalla (sin sonido, se va derecho a Claude). FOTO guarda el pantallazo en Descargas/MiBarra/MiInventor/Fotos."},
                    {"💾", "Al cambiar de sección pregunta «¿Guardar cambios?». Cada 2 minutos se guarda una copia de recuperación aparte (las 3 últimas)."}},
            {   // pieza
                    {"✏", "☰ → Chepe Pieza. Escoja el plano (XY piso, XZ frente, YZ lado) y dibuje el perfil con medidas."},
                    {"⊕", "Amarre la figura al 0,0 (centro, esquina o mitad de un lado). Así llega al montaje."},
                    {"⬆", "✓ Listo → Extruir: escriba el largo (mm, fórmula o pulgadas)."},
                    {"👆", "Toque una cara de la pieza: boceto en esa cara (perforación o saliente) o color."},
                    {"🌳", "El árbol de abajo es como el de Inventor: debajo de la pieza va su boceto, su extrusión y cada perforación o saliente con su propio boceto. Toque un renglón y se abre."},
                    {"🔁", "¿Hizo un saliente y era perforación (o al revés)? Toque la operación en el árbol → 🔁 Cambiar. Usa el mismo boceto."},
                    {"🔒", "Toque una cota → 🔒 Ponerle candado: queda fija y no se cambia ni se borra hasta quitarle el candado."}},
            {   // lámina
                    {"✏", "☰ → Chepe Lámina. Dibuje la cara principal (rectángulo con ancho y alto) y toque ✓ Listo."},
                    {"📐", "Escoja el calibre. La lámina sale en 3D."},
                    {"↪", "Doblez: toque la arista, escriba el ángulo (90°, 45°…) y el largo de la pestaña."},
                    {"📄", "Desarrollo: el plano para cortar con los dobleces en punteado. PDF, DXF, WhatsApp o ✂ Enviar a Corte Láminas."}},
            {   // alucobond
                    {"▦", "☰ → Chepe Alucobond. Dibuje la base (ej. 1000 × 1000) y toque ✓ Listo."},
                    {"4/6", "Escoja el grueso del panel: 4 o 6 mm (aluminio de 0,6 mm a lado y lado)."},
                    {"↪", "Ruteo: toque la arista y escriba el ángulo (90°, 135°…) y el alto de la pestaña (ej. 25)."},
                    {"📄", "Desarrollo: no suma ni resta (1000 + 25 + 25 = 1050). Los ruteos en V van en punteado."},
                    {"✂", "✂ Enviar a Corte Láminas: la pieza pasa sola a Alucobond 1500 × 5500."}},
            {   // casa
                    {"🏠", "☰ → Chepe Casa: rectángulo de la casa y cuartos que comparten muro."},
                    {"🚪🪟", "Puertas y ventanas: se ubican con sus cotas a lado y lado."},
                    {"🧱", "Muro suelto: para muros adicionales; toque la cota para cambiarla."},
                    {"🧊", "La vista 3D gira con las barras de abajo y de la derecha."}},
            {   // montaje
                    {"📥", "Insertar: traiga piezas de la librería."},
                    {"🔗", "Amarrar: toque una cara y luego la otra; queda en 0 o a una distancia."},
                    {"⟳", "Rotar, copiar, espejo y arreglo para repetir piezas."}},
            {   // gabinetes
                    {"🗄", "☰ → Chepe Gabinetes: escoja INFERIOR (entre muro y muro) o SUPERIOR (ancho y compartimientos)."},
                    {"🧊", "Arriba, 🧊 3D muestra el gabinete en 3D: un dedo lo gira y dos dedos acercan. ▭ Frente vuelve a la vista con cotas."},
                    {"↔", "Inferior: escriba la luz entre muros y acomode los módulos (2 puertas, 1 puerta, cajonero, fregadero). El mesón va encima."},
                    {"⚠", "Abajo le dice si faltan o se pasan milímetros. ↔ Ajustar el último lo cuadra con la luz."},
                    {"📋", "Despiece: tableros de 15 o 9 mm con su canto (F A I D) y los metros de canto."},
                    {"✂", "✂ A Corte: el despiece pasa solo a Chepe Corte Láminas (madera 1220 × 2440)."}},
            {   // corte
                    {"📏", "Chepe Corte Lineal: arriba los perfiles (referencia como ALH-175 o 38x38 y el largo de la barra). Abajo cada pedazo con su referencia, medida, cantidad y nombre. La app agrupa por referencia y dice cuántas barras de cada una."},
                    {"🪟", "Chepe Corte Láminas: primero escoja el material (lámina, vidrio, madera o Alucobond). Arriba el largo y ancho de la lámina; abajo las piezas, cada una con «Rotar» Sí o No."},
                    {"⋮", "En ⋮ (arriba a la derecha): calibre de la lámina, grueso del disco, rotar todas y los retales del taller. Lámina metálica: corte 0 y rotar SÍ. Madera y Alucobond: disco 4 y rotar NO. Perfiles: disco 3."},
                    {"♻", "✂ Calcular dice cuántas comprar. En el plano, lo que sobra de cada lámina sale en punteado con su medida (Sobra 2440 x 300)."},
                    {"🗑", "Cada fila tiene 🗑 para borrarla."}}
    };

    static void mostrar(Activity act, int seccion) {
        float d = act.getResources().getDisplayMetrics().density;
        boolean negro = Tema.negro;
        int fondo = negro ? 0xFF0D1018 : Color.WHITE, texto = negro ? Color.WHITE : Color.BLACK;
        android.app.Dialog dlg = new android.app.Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout raiz = new LinearLayout(act);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(fondo);
        raiz.setPadding((int) (10 * d), (int) (10 * d), (int) (10 * d), (int) (10 * d));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        TextView cerrar = new TextView(act);
        cerrar.setText("⬅");
        cerrar.setTextSize(22);
        cerrar.setTextColor(Color.WHITE);
        cerrar.setGravity(Gravity.CENTER);
        GradientDrawable gc = new GradientDrawable();
        gc.setColor(0xFF37474F);
        gc.setCornerRadius(9 * d);
        cerrar.setBackground(gc);
        cerrar.setOnClickListener(v -> dlg.dismiss());
        arriba.addView(cerrar, new LinearLayout.LayoutParams((int) (52 * d), (int) (46 * d)));
        TextView t = new TextView(act);
        t.setText(TITULOS[seccion] + " · Tutorial\n" + InventorActivity.VERSION);
        t.setTextColor(0xFFFFB300);
        t.setTextSize(17);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding((int) (10 * d), 0, 0, 0);
        arriba.addView(t);
        raiz.addView(arriba);
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(act);
        sv.addView(l);
        raiz.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        String[][] pasos = PASOS[seccion];
        for (int i = 0; i < pasos.length; i++) {
            LinearLayout tarjeta = new LinearLayout(act);
            tarjeta.setOrientation(LinearLayout.VERTICAL);
            tarjeta.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), (int) (12 * d));
            GradientDrawable gt = new GradientDrawable();
            gt.setColor(fondo);
            gt.setStroke((int) (2 * d), texto);
            gt.setCornerRadius(12 * d);
            tarjeta.setBackground(gt);
            // imagen arriba: el pantallazo real si ya existe; si no, el ícono del paso
            android.graphics.Bitmap bm = null;
            try (java.io.InputStream in = act.getAssets().open("tutorial/" + CLAVES[seccion] + "_" + (i + 1) + ".png")) { bm = android.graphics.BitmapFactory.decodeStream(in); }
            catch (Exception ignored) { }
            if (bm != null) {
                ImageView iv = new ImageView(act);
                iv.setImageBitmap(bm);
                iv.setAdjustViewBounds(true);
                tarjeta.addView(iv, new LinearLayout.LayoutParams(-1, -2));
            } else {
                TextView ic = new TextView(act);
                ic.setText(pasos[i][0]);
                ic.setTextSize(40);
                ic.setGravity(Gravity.CENTER);
                GradientDrawable gi = new GradientDrawable();
                gi.setColor(negro ? 0xFF1C2430 : 0xFFF3E5D8);
                gi.setCornerRadius(10 * d);
                ic.setBackground(gi);
                tarjeta.addView(ic, new LinearLayout.LayoutParams(-1, (int) (110 * d)));
            }
            TextView ex = new TextView(act);
            ex.setText("Paso " + (i + 1) + ". " + pasos[i][1]);
            ex.setTextColor(texto);
            ex.setTextSize(16);
            ex.setPadding(0, (int) (8 * d), 0, 0);
            tarjeta.addView(ex);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
            tp.topMargin = (int) (12 * d);
            l.addView(tarjeta, tp);
        }
        dlg.setContentView(raiz);
        dlg.show();
    }
}
