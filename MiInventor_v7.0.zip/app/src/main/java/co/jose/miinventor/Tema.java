package co.jose.miinventor;

import android.content.Context;
import android.content.SharedPreferences;

/** v6.9: el color de la pantalla de trabajo lo escoge Jose (negra o blanca). Líneas: blancas en negro, negras en blanco. */
final class Tema {
    private Tema() { }
    static boolean negro = true;
    /** v6.9: el 0,0 solo se ve mientras se está amarrando al 0,0 (nunca en pantallazos). */
    static boolean verCero = false;

    static void cargar(Context c) {
        negro = prefs(c).getBoolean("fondoNegro", true);
    }

    static void poner(Context c, boolean n) {
        negro = n;
        prefs(c).edit().putBoolean("fondoNegro", n).apply();
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("chpcad", Context.MODE_PRIVATE); }

    static int fondo() { return negro ? 0xFF0D1018 : 0xFFFFFFFF; }
    static int linea() { return negro ? 0xFFFFFFFF : 0xFF000000; }
    static int texto() { return negro ? 0xFFECEFF1 : 0xFF263238; }
    static int cota() { return negro ? 0xFF90CAF9 : 0xFF0D47A1; }
}
