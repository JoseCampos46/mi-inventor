package co.jose.miinventor;

import java.util.ArrayList;
import java.util.List;

/**
 * v6.4 ChpCad: la casa levantada en 3D. Los muros salen de la planta (celdas de muro), los huecos de puertas y
 * ventanas se restan como cajas, y se ponen el vidrio, las hojas de las puertas, los muebles y el sobrepiso.
 */
final class Casa3D {

    static final int MURO = 0xFFE6DCC8, VIDRIO = 0xFF90CAF9, PUERTA = 0xFF8D6E63, PISO = 0xFFBDBDBD;

    /** alturaCorte = 0: sin corte; si no, los muros se cortan a esa altura para ver adentro. */
    static List<Pieza> piezas(CasaPlano p, float alturaCorte) {
        List<Pieza> r = new ArrayList<>();
        int[] id = {1};
        float H = alturaCorte > 0 ? Math.min(p.alto, alturaCorte) : p.alto;
        // muros como cajas
        List<float[]> cajas = new ArrayList<>();
        for (float[] c : p.celdasMuro(null)) cajas.add(new float[]{c[0], c[1], 0, c[2], c[3], H});
        // los huecos se restan
        for (CasaPlano.Abertura a : p.aberturas) {
            float[] h = p.huella(a);
            float z0 = a.tipo == 1 ? a.ante : 0, z1 = Math.min(z0 + a.alto, p.alto + 1);
            float[] hueco = {h[0], h[1], z0, h[2], h[3], z1};
            List<float[]> n = new ArrayList<>();
            for (float[] b : cajas) n.addAll(restar(b, hueco));
            cajas = n;
        }
        for (float[] b : cajas) r.add(caja(id, b, MURO, "Muro"));
        // vidrios y hojas de puertas (solo si quedan por debajo del corte)
        for (CasaPlano.Abertura a : p.aberturas) {
            float[] h = p.huella(a);
            boolean enX = h[4] > 0.5f;
            float cx = (h[0] + h[2]) / 2, cy = (h[1] + h[3]) / 2;
            if (a.tipo == 1) {
                float z0 = a.ante, z1 = Math.min(H, a.ante + a.alto);
                if (z1 > z0) r.add(caja(id, enX ? new float[]{h[0], cy - 5, z0, h[2], cy + 5, z1} : new float[]{cx - 5, h[1], z0, cx + 5, h[3], z1}, VIDRIO, "Ventana"));
            } else if (a.tipo == 0 || a.tipo == 3 || a.tipo == 4) {
                float z1 = Math.min(H, a.alto);
                r.add(caja(id, enX ? new float[]{h[0], cy - 20, 0, h[2], cy + 20, z1} : new float[]{cx - 20, h[1], 0, cx + 20, h[3], z1}, PUERTA, CasaPlano.TIPOS[a.tipo]));
            }
        }
        // muebles
        for (CasaPlano.Mueble m : p.muebles) {
            float[] b = p.cajaMueble(m);
            Libreria.Item it = Libreria.item(m.clave);
            r.add(caja(id, new float[]{b[0], b[1], 0, b[2], b[3], Math.min(m.z, alturaCorte > 0 ? H : 99999)}, it == null ? 0xFFB0BEC5 : it.color, m.nombre));
        }
        // sobrepiso
        if (p.verSobrepiso) {
            float x0 = -150, y0 = -150, x1 = p.ancho + 150, y1 = p.fondo + 150;
            for (CasaPlano.Cuarto c : p.cuartos) {
                x0 = Math.min(x0, c.x - p.gInt - 150); y0 = Math.min(y0, c.y - p.gInt - 150);
                x1 = Math.max(x1, c.x + c.w + p.gInt + 150); y1 = Math.max(y1, c.y + c.h + p.gInt + 150);
            }
            r.add(caja(id, new float[]{x0, y0, -100, x1, y1, 0}, PISO, "Sobrepiso"));
        }
        return r;
    }

    private static Pieza caja(int[] id, float[] b, int color, String nombre) {
        Pieza p = new Pieza();
        p.id = id[0]++;
        p.tipo = Pieza.PLACA;
        p.titulo = nombre;
        p.medida = "";
        p.calibre = "";
        p.dir = 2;
        float w = b[3] - b[0], h = b[4] - b[1];
        p.marco = new float[]{b[0], b[1], b[2], 1, 0, 0, 0, 1, 0, 0, 0, 1};
        p.contorno = new float[][]{{0, 0}, {w, 0}, {w, h}, {0, h}};
        p.largo = Math.max(1, b[5] - b[2]);
        p.tinte = color;
        p.fija = true;
        return p;
    }

    /** Caja A menos caja B: hasta 6 cajas. */
    static List<float[]> restar(float[] a, float[] b) {
        List<float[]> r = new ArrayList<>();
        if (b[0] >= a[3] || b[3] <= a[0] || b[1] >= a[4] || b[4] <= a[1] || b[2] >= a[5] || b[5] <= a[2]) { r.add(a); return r; }
        float x0 = a[0], x1 = a[3], y0 = a[1], y1 = a[4], z0 = a[2], z1 = a[5];
        if (b[0] > x0) { r.add(new float[]{x0, y0, z0, b[0], y1, z1}); x0 = b[0]; }
        if (b[3] < x1) { r.add(new float[]{b[3], y0, z0, x1, y1, z1}); x1 = b[3]; }
        if (b[1] > y0) { r.add(new float[]{x0, y0, z0, x1, b[1], z1}); y0 = b[1]; }
        if (b[4] < y1) { r.add(new float[]{x0, b[4], z0, x1, y1, z1}); y1 = b[4]; }
        if (b[2] > z0) r.add(new float[]{x0, y0, z0, x1, y1, b[2]});
        if (b[5] < z1) r.add(new float[]{x0, y0, b[5], x1, y1, z1});
        return r;
    }
}
