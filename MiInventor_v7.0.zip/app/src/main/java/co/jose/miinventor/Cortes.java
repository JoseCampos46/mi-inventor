package co.jose.miinventor;

import android.app.AlertDialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * v6.3: ✂ Cortes. Listado de corte de barras (perfiles P1 a P50) y de láminas (vidrio, tableros, alucobond),
 * con sierra, retales y existencias (todo arranca en 0). Dice cuánto comprar y dibuja cada corte.
 */
final class Cortes {

    // =====================================================================
    //                    El cálculo (sin pantalla, se puede probar)
    // =====================================================================

    /** Una referencia de perfil: P1, P2… */
    static final class Ref {
        String nombre = "P1";
        double barra = 6000;
        int tengo = 0;
        String retales = "";   // ej: 1200x2; 850
        String piezas = "";    // ej: 300x4; 500x2
    }

    /** Una barra (o retal) ya cortada. */
    static final class Barra {
        String origen;          // "Retal", "En existencia", "Nueva"
        double largo;
        final List<Double> piezas = new ArrayList<>();
        final List<String> nombres = new ArrayList<>();   // v6.7: el nombre de cada pedazo
        double usado;           // despuntes + piezas + sierra
        double desperdicio;     // v6.7: despuntes + lo que se come la sierra
        double sobra() { return largo - usado; }
        double enPiezas() { double t = 0; for (double p : piezas) t += p; return t; }
        String clave() { return origen + "|" + largo + "|" + piezas + "|" + nombres; }
    }

    static final class ResBarras {
        String ref;
        final List<Barra> barras = new ArrayList<>();
        final List<Barra> grupos = new ArrayList<>();     // v6.7: barras iguales juntas («2 barras»)
        final List<Integer> cuantas = new ArrayList<>();
        int retalesUsados, existUsadas, nuevas;
        double piezasMm, compradoMm;
        String error;

        void agrupar() {
            grupos.clear(); cuantas.clear();
            for (Barra b : barras) {
                int k = -1;
                for (int i = 0; i < grupos.size(); i++) if (grupos.get(i).clave().equals(b.clave())) { k = i; break; }
                if (k < 0) { grupos.add(b); cuantas.add(1); } else cuantas.set(k, cuantas.get(k) + 1);
            }
        }
    }

    /** "300x4; 500x2, 750" → lista de medidas (cada una repetida). */
    static List<Double> leerLista(String t) {
        List<Double> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').replace(',', ';').split(";")) {
            String p = parte.trim().toLowerCase(Locale.US).replace('*', 'x').replace('×', 'x');
            if (p.isEmpty()) continue;
            String[] w = p.split("x");
            try {
                double m = Double.parseDouble(w[0].trim().replace(" ", ""));
                int n = w.length > 1 ? (int) Math.round(Double.parseDouble(w[1].trim())) : 1;
                for (int i = 0; i < n && i < 2000; i++) r.add(m);
            } catch (Exception ignored) { }
        }
        return r;
    }

    private static final java.util.regex.Pattern MEDIDA = java.util.regex.Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*(?:[xX*×]\\s*([0-9]+))?");

    /** v6.7: "300x4 verticales; 500x2 travesaño" → {medida, nombre} repetidos. */
    static List<Object[]> leerPedazos(String t) {
        List<Object[]> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').split(";")) {
            String p = parte.trim();
            if (p.isEmpty()) continue;
            java.util.regex.Matcher m = MEDIDA.matcher(p);
            if (!m.find()) continue;
            try {
                double med = Double.parseDouble(m.group(1).replace(',', '.'));
                int n = m.group(2) != null ? Integer.parseInt(m.group(2)) : 1;
                String nom = (p.substring(0, m.start()) + " " + p.substring(m.end())).trim().replaceAll("\\s+", " ");
                for (int i = 0; i < n && i < 2000; i++) r.add(new Object[]{med, nom});
            } catch (Exception ignored) { }
        }
        return r;
    }

    static ResBarras cortarBarras(Ref ref, double sierra) { return cortarBarras(ref, sierra, 0, 0); }

    static ResBarras cortarBarras(Ref ref, double sierra, double despIzq, double despDer) {
        ResBarras res = new ResBarras();
        res.ref = ref.nombre;
        List<Object[]> ps = leerPedazos(ref.piezas);
        ps.sort((a, b) -> Double.compare((Double) b[0], (Double) a[0]));
        List<Double> ret = leerLista(ref.retales);
        Collections.sort(ret);   // primero los retales más pequeños que sirvan
        boolean[] retUsado = new boolean[ret.size()];
        int exist = ref.tengo;
        double desp = Math.max(0, despIzq) + Math.max(0, despDer);
        for (Object[] o : ps) {
            double p = (Double) o[0];
            res.piezasMm += p;
            if (p + desp > ref.barra) { res.error = "Hay un pedazo de " + Pieza.n((float) p) + " mm más largo que la barra (con despuntes)"; continue; }
            // 1) en la barra ya abierta donde quede más justo
            Barra mejor = null;
            for (Barra b : res.barras) {
                double nec = p + (b.piezas.isEmpty() ? 0 : sierra);
                if (b.sobra() >= nec - 1e-6 && (mejor == null || b.sobra() < mejor.sobra())) mejor = b;
            }
            if (mejor == null) {
                // 2) un retal que alcance (el más pequeño), 3) una barra en existencia, 4) una barra nueva
                Barra b = new Barra();
                int k = -1;
                for (int i = 0; i < ret.size(); i++) if (!retUsado[i] && ret.get(i) >= p) { k = i; break; }
                if (k >= 0) { retUsado[k] = true; b.origen = "Retal"; b.largo = ret.get(k); res.retalesUsados++; }
                else if (exist > 0) { exist--; b.origen = "En existencia"; b.largo = ref.barra; res.existUsadas++; b.usado = desp; b.desperdicio = desp; }
                else { b.origen = "Nueva"; b.largo = ref.barra; res.nuevas++; res.compradoMm += ref.barra; b.usado = desp; b.desperdicio = desp; }
                res.barras.add(b);
                mejor = b;
            }
            double k = mejor.piezas.isEmpty() ? 0 : sierra;
            mejor.usado += p + k;
            mejor.desperdicio += k;
            mejor.piezas.add(p);
            mejor.nombres.add((String) o[1]);
        }
        res.agrupar();
        return res;
    }

    /** Material en láminas: vidrio, tablero, alucobond. */
    static final class Mat {
        int tipo = 2;          // v6.9: 0 lámina metálica · 1 vidrio · 2 madera · 3 Alucobond
        double sierra = 4;     // v6.9: cada material con su propio corte
        String nombre = "Vidrio";
        double ancho = 2440, alto = 1220;
        int tengo = 0;
        boolean girar = true;
        String retales = "";   // ej: 600x400x2
        String piezas = "";    // una por renglón: 600x300x4 canto F I gira|fija
        String calibre = "";   // v7: lámina metálica (Cal 18…), para el pedido
    }

    static final class Pz {
        String nombre;
        double w, h;          // como se escribió
        boolean f, a, i, d;   // canto: frente y atrás (lados de w), izquierdo y derecho (lados de h)
        boolean girar = true; // v7: cada pieza dice si se puede rotar
        double canto() { return (f ? w : 0) + (a ? w : 0) + (i ? h : 0) + (d ? h : 0); }
    }

    static final class Puesta {
        Pz pz;
        double x, y, w, h;
        boolean girada;
    }

    static final class Hoja2 {
        String origen;
        double ancho, alto;
        final List<Puesta> puestas = new ArrayList<>();
        final List<double[]> libres = new ArrayList<>();   // x, y, w, h (MaxRects)
        double usado() { double s = 0; for (Puesta p : puestas) s += p.w * p.h; return s; }
    }

    static final class ResLam {
        final List<Hoja2> hojas = new ArrayList<>();
        int retalesUsados, existUsadas, nuevas;
        double cantoMm, piezasArea;
        String error;
    }

    /** "600x300x4 canto F I" o "Lateral 600x300x2 F". */
    static List<Pz> leerPiezas(String t) { return leerPiezas(t, true); }

    static List<Pz> leerPiezas(String t, boolean girarDef) {
        List<Pz> r = new ArrayList<>();
        if (t == null) return r;
        for (String reng : t.split("[\\n;]")) {
            String s = reng.trim();
            if (s.isEmpty()) continue;
            String[] w = s.replace('*', 'x').replace('×', 'x').split("\\s+");
            Pz base = null;
            int n = 1;
            StringBuilder nom = new StringBuilder();
            boolean f = false, a = false, iz = false, de = false, gi = girarDef;
            for (String tok : w) {
                String k = tok.toLowerCase(Locale.US);
                if (base == null && k.matches("[0-9.]+x[0-9.]+(x[0-9]+)?")) {
                    String[] m = k.split("x");
                    base = new Pz();
                    base.w = Double.parseDouble(m[0]); base.h = Double.parseDouble(m[1]);
                    if (m.length > 2) n = Integer.parseInt(m[2]);
                } else if (base != null && k.matches("x?[0-9]+")) n = Integer.parseInt(k.replace("x", ""));
                else if (k.equals("f")) f = true;
                else if (k.equals("a")) a = true;
                else if (k.equals("i")) iz = true;
                else if (k.equals("d")) de = true;
                else if (k.equals("todo") || k.equals("t")) { f = a = iz = de = true; }
                else if (k.equals("gira")) gi = true;
                else if (k.equals("fija")) gi = false;
                else if (!k.equals("canto") && base == null) nom.append(nom.length() > 0 ? " " : "").append(tok);
            }
            if (base == null || base.w <= 0 || base.h <= 0) continue;
            for (int i = 0; i < n && i < 2000; i++) {
                Pz p = new Pz();
                p.nombre = nom.length() > 0 ? nom.toString() : Pieza.n((float) base.w) + "x" + Pieza.n((float) base.h);
                p.w = base.w; p.h = base.h; p.f = f; p.a = a; p.i = iz; p.d = de; p.girar = gi;
                r.add(p);
            }
        }
        return r;
    }

    static List<double[]> leerRetales2(String t) {
        List<double[]> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').replace(',', ';').split(";")) {
            String p = parte.trim().toLowerCase(Locale.US).replace('*', 'x').replace('×', 'x').replace(" ", "");
            if (p.isEmpty()) continue;
            String[] m = p.split("x");
            try {
                double w = Double.parseDouble(m[0]), h = Double.parseDouble(m[1]);
                int n = m.length > 2 ? Integer.parseInt(m[2]) : 1;
                for (int i = 0; i < n && i < 500; i++) r.add(new double[]{w, h});
            } catch (Exception ignored) { }
        }
        return r;
    }

    static ResLam cortarLaminas(Mat m, double sierra) {
        ResLam res = new ResLam();
        List<Pz> ps = leerPiezas(m.piezas, m.girar);
        ps.sort((p, q) -> Double.compare(Math.max(q.w, q.h) * 1e6 + q.w * q.h, Math.max(p.w, p.h) * 1e6 + p.w * p.h));
        List<double[]> ret = leerRetales2(m.retales);
        ret.sort((p, q) -> Double.compare(p[0] * p[1], q[0] * q[1]));
        boolean[] retUsado = new boolean[ret.size()];
        int exist = m.tengo;
        for (Pz p : ps) {
            res.cantoMm += p.canto();
            res.piezasArea += p.w * p.h;
            if (!cabe(p, m.ancho, m.alto, p.girar)) { res.error = "La pieza " + p.nombre + " no cabe en la lámina de " + Pieza.n((float) m.ancho) + " x " + Pieza.n((float) m.alto); continue; }
            boolean puesta = false;
            for (Hoja2 h : res.hojas) if (poner(h, p, sierra, p.girar)) { puesta = true; break; }
            while (!puesta) {
                Hoja2 h = new Hoja2();
                int k = -1;
                for (int i = 0; i < ret.size(); i++) if (!retUsado[i] && cabe(p, ret.get(i)[0], ret.get(i)[1], p.girar)) { k = i; break; }
                if (k >= 0) { retUsado[k] = true; h.origen = "Retal"; h.ancho = ret.get(k)[0]; h.alto = ret.get(k)[1]; res.retalesUsados++; }
                else if (exist > 0) { exist--; h.origen = "En existencia"; h.ancho = m.ancho; h.alto = m.alto; res.existUsadas++; }
                else { h.origen = "Nueva"; h.ancho = m.ancho; h.alto = m.alto; res.nuevas++; }
                h.libres.add(new double[]{0, 0, h.ancho + sierra, h.alto + sierra});
                res.hojas.add(h);
                puesta = poner(h, p, sierra, p.girar);
                if (!puesta && k < 0) break;   // no debería pasar
            }
        }
        return res;
    }

    /** v7: el sobrante (retal) de cada lámina: la franja de la derecha y la de abajo, ya descontado el corte. */
    static List<double[]> sobrantes(Hoja2 h, double sierra) {
        List<double[]> r = new ArrayList<>();
        double mx = 0, my = 0;
        for (Puesta p : h.puestas) { mx = Math.max(mx, p.x + p.w); my = Math.max(my, p.y + p.h); }
        if (h.puestas.isEmpty()) return r;
        double x1 = Math.min(h.ancho, mx + sierra), y1 = Math.min(h.alto, my + sierra);
        if (h.ancho - x1 >= 1) r.add(new double[]{x1, 0, h.ancho - x1, h.alto});
        if (h.alto - y1 >= 1) r.add(new double[]{0, y1, Math.min(h.ancho, mx), h.alto - y1});
        return r;
    }

    private static boolean cabe(Pz p, double w, double h, boolean girar) {
        return p.w <= w + 1e-6 && p.h <= h + 1e-6 || girar && p.h <= w + 1e-6 && p.w <= h + 1e-6;
    }

    /** MaxRects, mejor lado corto: la pieza se agranda con la sierra y se busca el hueco más justo. */
    private static boolean poner(Hoja2 hj, Pz p, double k, boolean girar) {
        double bw = p.w + k, bh = p.h + k;
        double mejor = Double.MAX_VALUE, mejor2 = Double.MAX_VALUE;
        double[] sel = null;
        boolean gir = false;
        for (double[] r : hj.libres) {
            for (int o = 0; o < (girar ? 2 : 1); o++) {
                double w = o == 0 ? bw : bh, h = o == 0 ? bh : bw;
                if (w <= r[2] + 1e-6 && h <= r[3] + 1e-6) {
                    double c = Math.min(r[2] - w, r[3] - h), l = Math.max(r[2] - w, r[3] - h);
                    if (c < mejor || c == mejor && l < mejor2) { mejor = c; mejor2 = l; sel = new double[]{r[0], r[1], w, h}; gir = o == 1; }
                }
            }
        }
        if (sel == null) return false;
        Puesta pu = new Puesta();
        pu.pz = p; pu.x = sel[0]; pu.y = sel[1]; pu.w = gir ? p.h : p.w; pu.h = gir ? p.w : p.h; pu.girada = gir;
        hj.puestas.add(pu);
        // partir los huecos libres que toca
        List<double[]> nuevos = new ArrayList<>();
        for (double[] r : hj.libres) {
            if (sel[0] >= r[0] + r[2] || sel[0] + sel[2] <= r[0] || sel[1] >= r[1] + r[3] || sel[1] + sel[3] <= r[1]) { nuevos.add(r); continue; }
            if (sel[0] > r[0]) nuevos.add(new double[]{r[0], r[1], sel[0] - r[0], r[3]});
            if (sel[0] + sel[2] < r[0] + r[2]) nuevos.add(new double[]{sel[0] + sel[2], r[1], r[0] + r[2] - sel[0] - sel[2], r[3]});
            if (sel[1] > r[1]) nuevos.add(new double[]{r[0], r[1], r[2], sel[1] - r[1]});
            if (sel[1] + sel[3] < r[1] + r[3]) nuevos.add(new double[]{r[0], sel[1] + sel[3], r[2], r[1] + r[3] - sel[1] - sel[3]});
        }
        // quitar los que quedan dentro de otro
        List<double[]> lim = new ArrayList<>();
        for (int i = 0; i < nuevos.size(); i++) {
            double[] a = nuevos.get(i);
            boolean dentro = false;
            for (int j = 0; j < nuevos.size() && !dentro; j++) {
                if (i == j) continue;
                double[] b = nuevos.get(j);
                if (a[0] >= b[0] && a[1] >= b[1] && a[0] + a[2] <= b[0] + b[2] && a[1] + a[3] <= b[1] + b[3] && (j < i || a[0] != b[0] || a[1] != b[1] || a[2] != b[2] || a[3] != b[3])) dentro = true;
            }
            if (!dentro) lim.add(a);
        }
        hj.libres.clear();
        hj.libres.addAll(lim);
        return true;
    }

    // =====================================================================
    //                              La pantalla
    // =====================================================================

    private final InventorActivity act;
    private final File carpeta;
    private final List<Ref> refs = new ArrayList<>();
    private final List<Mat> mats = new ArrayList<>();
    private double sierraB = 3, sierraL = 4;
    // v6.7: despuntes de la barra, retal mínimo que vale la pena guardar y el nombre del trabajo
    private double despIzq = 0, despDer = 0, retalMin = 300;
    private String trabajo = "";
    private android.app.Dialog abierta;

    Cortes(InventorActivity act, File carpeta) {
        this.act = act;
        this.carpeta = carpeta;
        cargar();
    }

    private int dp(float v) { return Math.round(v * act.getResources().getDisplayMetrics().density); }

    private void aviso(String s) { Toast.makeText(act, s, Toast.LENGTH_LONG).show(); }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(act);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    /** v6.7: letreros blancos y en negrilla (nada de gris claro). */
    private TextView etiqueta(String s) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextSize(15);
        t.setTextColor(Color.WHITE);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    /** v7: una línea con lo que está escogido en ⋮ (calibre, disco, retales), en blanco. */
    private TextView datos(String s) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextSize(14);
        t.setTextColor(Color.WHITE);
        t.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        return t;
    }

    private EditText campo(String v, String pista, boolean numero, boolean varias) {
        EditText e = new EditText(act);
        e.setTextSize(18);
        e.setTextColor(Color.BLACK);
        e.setHintTextColor(0xFF616161);
        e.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(7));
        e.setBackground(g);
        if (varias) { e.setSingleLine(false); e.setMinLines(3); e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS); }
        else { e.setSingleLine(true); e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS); }
        if (numero) {
            // v6.7: el número se VE (sierra 4, barra 6000…); al tocarlo sale el teclado de ChpCad
            Teclado.numero(act, e, "Escriba el número", v);
            e.setText(v);
        } else { e.setText(v); e.setHint(pista); Teclado.letras(act, e); }
        return e;
    }

    private static double num(android.widget.TextView e, double def) {
        try { return Double.parseDouble(Teclado.tx(e).trim().replace(',', '.')); } catch (Exception x) { return def; }
    }

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    /** v6.7: Chepe Corte es una sección propia: pantalla completa, con su título y sus botones abajo.
     *  v7: arriba a la derecha el menú ⋮ con lo que se configura (calibre, disco, retales…). */
    private android.app.Dialog pantalla(String titulo, View contenido, Object[][] botones, Runnable menu) {
        android.app.Dialog d = new android.app.Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout raiz = new LinearLayout(act);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF151A26);
        raiz.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        TextView atras = boton("⬅", 0xFF37474F, d::dismiss);
        arriba.addView(atras, new LinearLayout.LayoutParams(dp(52), dp(46)));
        TextView t = new TextView(act);
        t.setText(titulo + "\n" + InventorActivity.VERSION + (trabajo.isEmpty() ? "" : " · trabajo «" + trabajo + "»"));
        t.setTextColor(0xFFFFB300);
        t.setTextSize(16);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(dp(10), 0, 0, 0);
        arriba.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        if (menu != null) arriba.addView(boton("⋮", 0xFF37474F, menu), new LinearLayout.LayoutParams(dp(52), dp(46)));
        raiz.addView(arriba);
        ScrollView sv = new ScrollView(act);
        sv.addView(contenido);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = dp(6);
        raiz.addView(sv, sp);
        LinearLayout abajo = new LinearLayout(act);
        for (Object[] bo : botones) {
            Runnable r = (Runnable) bo[2];
            abajo.addView(boton((String) bo[0], (Integer) bo[1], r), peso());
        }
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(6);
        raiz.addView(abajo, ap);
        d.setContentView(raiz);
        d.show();
        return d;
    }

    private android.app.Dialog pantalla(String titulo, View contenido, Object[][] botones) { return pantalla(titulo, contenido, botones, null); }

    /** Cierra la pantalla abierta y la vuelve a pintar (después de cambiar algo en ⋮). */
    private void repintar(Runnable abrir) {
        if (abierta != null) try { abierta.dismiss(); } catch (Exception ignored) { }
        abrir.run();
    }

    /** v7: una ventanita con una tablita (para los retales del taller, desde ⋮). */
    private void ventanaTabla(String titulo, String[] titulos, float[] pesos, int[] tipos, List<String[]> datos, String[] nueva, String textoMas, java.util.function.Consumer<List<String[]>> listo) {
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8), dp(4), dp(8), dp(4));
        l.setBackgroundColor(0xFF151A26);
        Lector lec = tabla(l, titulos, pesos, tipos, datos, nueva, textoMas);
        ScrollView sv = new ScrollView(act);
        sv.addView(l);
        new AlertDialog.Builder(act).setTitle(titulo).setView(sv)
                .setPositiveButton("✔ Listo", (d, w) -> listo.accept(lec.leer()))
                .setNegativeButton("Cancelar", null).show();
    }

    void abrir() {
        new AlertDialog.Builder(act).setTitle("✂ Chepe Corte · " + InventorActivity.VERSION)
                .setItems(new String[]{"📏 Corte Lineal · barras de 6 m", "🪟 Corte Láminas · lámina, vidrio, madera, Alucobond"}, (d, w) -> {
                    if (w == 0) pantallaBarras(); else pantallaLaminas();
                }).show();
    }

    // ---------------- v6.7: trabajos guardados (con nombre y fecha) ----------------

    private File carpetaTrabajos() {
        File f = new File(carpeta, "_cortes");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    /** Primero se escoge el trabajo (como en la app de corte): los guardados, con su fecha, o uno nuevo. */
    private void escogerTrabajo(Runnable seguir) {
        File[] fs = carpetaTrabajos().listFiles(x -> x.getName().endsWith(".json"));
        List<File> l = new ArrayList<>();
        if (fs != null) Collections.addAll(l, fs);
        l.sort((x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        java.text.SimpleDateFormat sf = new java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US);
        String[] it = new String[l.size() + 1];
        it[0] = "➕ Trabajo nuevo";
        for (int i = 0; i < l.size(); i++) {
            String n = l.get(i).getName();
            it[i + 1] = "📁 " + n.substring(0, n.length() - 5) + "   ·  " + sf.format(new java.util.Date(l.get(i).lastModified()));
        }
        new AlertDialog.Builder(act).setTitle("✂ Chepe Corte · trabajos guardados").setItems(it, (d, w) -> {
            if (w == 0) {
                EditText e = new EditText(act);
                e.setHint("Ej. estructura antejardín");
                e.setTextSize(18);
                Teclado.letras(act, e);
                new AlertDialog.Builder(act).setTitle("Nombre del trabajo").setView(e)
                        .setPositiveButton("Crear", (d2, w2) -> {
                            String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                            if (n.isEmpty()) n = "Trabajo " + (l.size() + 1);
                            trabajo = n;
                            refs.clear(); mats.clear();
                            seguir.run();
                        }).setNegativeButton("Cancelar", null).show();
            } else {
                File f = l.get(w - 1);
                trabajo = f.getName().substring(0, f.getName().length() - 5);
                refs.clear(); mats.clear();
                leer(f);
                seguir.run();
            }
        }).setNegativeButton("Cerrar", null).show();
    }

    // ---------------- Corte Lineal (barras) ----------------

    void pantallaBarras() { escogerTrabajo(this::formBarras); }

    /** v7: arriba la lista de perfiles (referencia y largo de la barra); abajo los pedazos, cada uno con su referencia.
     *  La app agrupa por referencia y dice cuántas barras de cada una. Disco, despuntes y retales van en ⋮. */
    private void formBarras() {
        if (refs.isEmpty()) refs.add(new Ref());
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(4), 0, dp(4), dp(8));
        int nRet = 0;
        for (Ref r : refs) nRet += leerLista(r.retales).size();
        l.addView(datos("Disco " + Pieza.n((float) sierraB) + " mm · despuntes " + Pieza.n((float) despIzq) + " / " + Pieza.n((float) despDer)
                + " mm · retales del taller: " + nRet));
        l.addView(etiqueta("Perfiles (barras que se compran)"));
        List<String[]> perf = new ArrayList<>();
        for (Ref r : refs) perf.add(new String[]{r.nombre, Pieza.n((float) r.barra)});
        Lector lpf = tabla(l, new String[]{"Referencia", "Largo barra"}, new float[]{1.4f, 1}, new int[]{0, 1}, perf,
                new String[]{"", "6000"}, "➕ Otro perfil");
        l.addView(etiqueta("Pedazos a cortar"));
        List<String[]> pzs = new ArrayList<>();
        for (Ref r : refs) for (String[] f : filasPedazos(r.piezas)) pzs.add(new String[]{r.nombre, f[0], f[1], f[2]});
        Lector lpz = tabla(l, new String[]{"Referencia", "Medida", "Cant.", "Nombre"}, new float[]{1.2f, 1, 0.7f, 1.2f}, new int[]{0, 1, 1, 0}, pzs,
                new String[]{refs.get(0).nombre, "", "1", ""}, "➕ Otro pedazo");
        Runnable leerTodo = () -> leerBarras(lpf.leer(), lpz.leer());
        Runnable menu = () -> {
            leerTodo.run();
            String[] op = {"Grueso del disco: " + Pieza.n((float) sierraB) + " mm", "Despunte izquierdo: " + Pieza.n((float) despIzq) + " mm",
                    "Despunte derecho: " + Pieza.n((float) despDer) + " mm", "Guardar retal desde: " + Pieza.n((float) retalMin) + " mm", "♻ Retales del taller"};
            new AlertDialog.Builder(act).setTitle("⋮ Corte Lineal").setItems(op, (d, w) -> {
                if (w == 0) Teclado.pedir(act, "Grueso del disco (mm)", sierraB, v -> { sierraB = Math.max(0, v); guardar(); repintar(this::formBarras); });
                else if (w == 1) Teclado.pedir(act, "Despunte izquierdo (mm)", despIzq, v -> { despIzq = Math.max(0, v); guardar(); repintar(this::formBarras); });
                else if (w == 2) Teclado.pedir(act, "Despunte derecho (mm)", despDer, v -> { despDer = Math.max(0, v); guardar(); repintar(this::formBarras); });
                else if (w == 3) Teclado.pedir(act, "Guardar como retal desde (mm)", retalMin, v -> { retalMin = Math.max(0, v); guardar(); repintar(this::formBarras); });
                else {
                    List<String[]> rt = new ArrayList<>();
                    for (Ref r : refs) for (String[] f : filasPedazos(r.retales)) rt.add(new String[]{r.nombre, f[0], f[1]});
                    ventanaTabla("♻ Retales del taller", new String[]{"Referencia", "Medida", "Cant."}, new float[]{1.3f, 1, 0.7f}, new int[]{0, 1, 1}, rt,
                            new String[]{refs.get(0).nombre, "", "1"}, "➕ Otro retal", filas -> {
                                for (Ref r : refs) r.retales = "";
                                List<String[]> sin = new ArrayList<>();
                                for (String[] f : filas) {
                                    Ref r = refPorNombre(f[0]);
                                    if (r == null) continue;
                                    r.retales = (r.retales.isEmpty() ? "" : r.retales + "; ") + textoPedazos(java.util.Collections.singletonList(new String[]{f[1], f[2], ""}));
                                }
                                guardar();
                                repintar(this::formBarras);
                            });
                }
            }).show();
        };
        abierta = pantalla("📏 Chepe Corte Lineal", l, new Object[][]{
                {"💾 Guardar", 0xFF2E7D32, (Runnable) () -> { leerTodo.run(); guardar(); aviso("✔ Guardado «" + trabajo + "»"); }},
                {"✂ Calcular", 0xFFC62828, (Runnable) () -> { leerTodo.run(); guardar(); resultadoBarras(); }}}, menu);
    }

    /** La referencia con ese nombre (sin importar mayúsculas); si no existe, se crea con barra de 6000. */
    private Ref refPorNombre(String n) {
        String k = n == null ? "" : n.trim();
        if (k.isEmpty()) return refs.isEmpty() ? null : refs.get(0);
        for (Ref r : refs) if (r.nombre.trim().equalsIgnoreCase(k)) return r;
        if (refs.size() >= 50) return null;
        Ref r = new Ref();
        r.nombre = k;
        refs.add(r);
        return r;
    }

    private void leerBarras(List<String[]> perfiles, List<String[]> pedazos) {
        java.util.Map<String, String> retalesAntes = new java.util.HashMap<>();
        for (Ref r : refs) retalesAntes.put(r.nombre.trim().toLowerCase(Locale.ROOT), r.retales);
        refs.clear();
        for (String[] f : perfiles) {
            String n = f[0] == null ? "" : f[0].trim();
            if (n.isEmpty()) n = "P" + (refs.size() + 1);
            Ref r = refPorNombre(n);
            if (r == null) continue;
            try { r.barra = Math.max(1, Double.parseDouble(f[1].replace(',', '.'))); } catch (Exception e) { r.barra = 6000; }
            String ra = retalesAntes.get(r.nombre.trim().toLowerCase(Locale.ROOT));
            r.retales = ra == null ? "" : ra;
        }
        if (refs.isEmpty()) refs.add(new Ref());
        for (Ref r : refs) r.piezas = "";
        for (String[] f : pedazos) {
            Ref r = refPorNombre(f[0]);
            if (r == null || f[1] == null || f[1].isEmpty()) continue;
            String t = textoPedazos(java.util.Collections.singletonList(new String[]{f[1], f[2], f[3]}));
            r.piezas = r.piezas.isEmpty() ? t : r.piezas + "; " + t;
        }
    }

    private void resultadoBarras() {
        List<ResBarras> rs = new ArrayList<>();
        for (Ref r : refs) { ResBarras x = cortarBarras(r, sierraB, despIzq, despDer); if (!x.barras.isEmpty() || x.error != null) rs.add(x); }
        if (rs.isEmpty()) { aviso("Escriba los pedazos a cortar"); return; }
        StringBuilder sb = new StringBuilder();
        for (ResBarras x : rs) {
            sb.append(x.ref).append(": usa ").append(x.barras.size()).append(x.barras.size() == 1 ? " barra" : " barras");
            if (x.retalesUsados > 0) sb.append(" · ").append(x.retalesUsados).append(" retal").append(x.retalesUsados == 1 ? "" : "es");
            sb.append(" → COMPRAR ").append(x.nuevas).append('\n');
            // v6.7: los retales que quedan (desde el tamaño mínimo) para guardarlos
            List<String> quedan = new ArrayList<>();
            for (Barra b : x.barras) if (b.sobra() >= retalMin) quedan.add(Pieza.n((float) Math.floor(b.sobra())));
            if (!quedan.isEmpty()) sb.append("   ♻ Retales que quedan: ").append(String.join("; ", quedan)).append('\n');
            if (x.error != null) sb.append("   ⚠ ").append(x.error).append('\n');
        }
        dibujo("📏 Listado de corte · barras", sb.toString(), new DibujoBarras(rs), () -> pdfBarras(rs));
    }

    // ---------------- Corte Láminas ----------------

    void pantallaLaminas() { escogerTrabajo(this::escogerMaterial); }

    static final String[] MATERIALES = {"🔩 Lámina metálica", "🪟 Vidrio", "🪵 Madera (tableros)", "▦ Alucobond"};
    static final String[] CALIBRES = {"Cal 10", "Cal 12", "Cal 14", "Cal 16", "Cal 18", "Cal 20", "Cal 22", "Cal 24", "Cal 26"};

    /** v6.9: cada material con su propia pantalla y sus criterios. */
    private void escogerMaterial() {
        new AlertDialog.Builder(act).setTitle("✂ ¿Qué material va a cortar?").setItems(MATERIALES, (d, w) -> {
            Mat m = null;
            for (Mat x : mats) if (x.tipo == w) m = x;
            if (m == null) { m = nuevoMat(w); mats.add(m); }
            formLaminas(m);
        }).show();
    }

    /** v7: valores por defecto de cada material (se cambian en ⋮). */
    static Mat nuevoMat(int tipo) {
        Mat m = new Mat();
        m.tipo = tipo;
        switch (tipo) {
            case 0: m.calibre = "Cal 18"; m.nombre = "Lámina Cal 18"; m.ancho = 2440; m.alto = 1220; m.sierra = 0; m.girar = true; break;
            case 1: m.nombre = "Vidrio 4 mm"; m.ancho = 3300; m.alto = 2140; m.sierra = 0; m.girar = true; break;
            case 3: m.nombre = "Alucobond 4 mm"; m.ancho = 5500; m.alto = 1500; m.sierra = 4; m.girar = false; break;
            default: m.nombre = "Madera 15 mm"; m.ancho = 2440; m.alto = 1220; m.sierra = 4; m.girar = false;
        }
        return m;
    }

    /** v6.9: abre Corte Láminas con estas piezas (de Chepe Gabinetes o Chepe Alucobond). */
    void abrirConPiezas(int tipo, String nombreTrabajo, String piezas) {
        trabajo = nombreTrabajo;
        refs.clear(); mats.clear();
        Mat m = nuevoMat(tipo);
        m.piezas = piezas;
        mats.add(m);
        guardar();
        formLaminas(m);
    }

    private void formLaminas(Mat m) {
        final int tipo = m.tipo;
        boolean conCanto = tipo == 2, conDisco = tipo != 1;
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(4), 0, dp(4), dp(8));
        int nRet = leerRetales2(m.retales).size();
        StringBuilder dt = new StringBuilder(MATERIALES[tipo].substring(2).trim());
        if (tipo == 0 && !m.calibre.isEmpty()) dt.append(" · ").append(m.calibre);
        if (conDisco) dt.append(tipo == 0 ? " · corte " : " · disco ").append(Pieza.n((float) m.sierra)).append(" mm");
        dt.append(" · rotar: ").append(m.girar ? "SÍ" : "NO").append(" · retales del taller: ").append(nRet);
        l.addView(datos(dt.toString()));
        l.addView(etiqueta("Material"));
        EditText nom = campo(m.nombre, "Nombre del material", false, false);
        l.addView(nom);
        l.addView(etiqueta("Lámina entera (la que se compra)"));
        List<String[]> lam = new ArrayList<>();
        lam.add(new String[]{Pieza.n((float) m.ancho), Pieza.n((float) m.alto)});
        Lector llam = tabla(l, new String[]{"Largo", "Ancho"}, new float[]{1, 1}, new int[]{1, 1}, lam, null, null);
        l.addView(etiqueta("Piezas a cortar"));
        String rot = m.girar ? "Sí" : "No";
        Lector lpz = conCanto
                ? tabla(l, new String[]{"Nombre", "Largo", "Ancho", "Cant.", "Canto", "Rotar"}, new float[]{1.3f, 1, 1, 0.7f, 0.8f, 0.8f}, new int[]{0, 1, 1, 1, 0, 2},
                    filasPiezas(m.piezas, true, m.girar), new String[]{"", "", "", "1", "", rot}, "➕ Otra pieza")
                : tabla(l, new String[]{"Nombre", "Largo", "Ancho", "Cant.", "Rotar"}, new float[]{1.3f, 1, 1, 0.7f, 0.8f}, new int[]{0, 1, 1, 1, 2},
                    filasPiezas(m.piezas, false, m.girar), new String[]{"", "", "", "1", rot}, "➕ Otra pieza");
        Runnable leer = () -> {
            m.nombre = nom.getText().toString().trim().isEmpty() ? MATERIALES[tipo].substring(2).trim() : nom.getText().toString().trim();
            List<String[]> la = llam.leer();
            if (!la.isEmpty()) {
                try { m.ancho = Math.max(1, Double.parseDouble(la.get(0)[0].replace(',', '.'))); } catch (Exception ignored) { }
                try { m.alto = Math.max(1, Double.parseDouble(la.get(0)[1].replace(',', '.'))); } catch (Exception ignored) { }
            }
            m.tengo = 0;   // v7: la app dice cuántas comprar
            m.piezas = textoPiezas(lpz.leer(), conCanto);
            sierraL = m.sierra;
        };
        Runnable otraVez = () -> formLaminas(m);
        Runnable menu = () -> {
            leer.run();
            List<String> op = new ArrayList<>();
            List<Runnable> ac = new ArrayList<>();
            if (tipo == 0) {
                op.add("Calibre: " + (m.calibre.isEmpty() ? "—" : m.calibre));
                ac.add(() -> new AlertDialog.Builder(act).setTitle("Calibre de la lámina").setItems(CALIBRES, (d, w) -> {
                    String antes = m.calibre;
                    m.calibre = CALIBRES[w];
                    if (m.nombre.startsWith("Lámina")) m.nombre = "Lámina " + m.calibre;
                    else if (!antes.isEmpty() && m.nombre.contains(antes)) m.nombre = m.nombre.replace(antes, m.calibre);
                    guardar(); repintar(otraVez);
                }).show());
            }
            if (conDisco) {
                op.add((tipo == 0 ? "Corte (mm, 0 = cizalla): " : "Grueso del disco: ") + Pieza.n((float) m.sierra) + " mm");
                ac.add(() -> Teclado.pedir(act, tipo == 0 ? "Lo que se come cada corte (mm)" : "Grueso del disco (mm)", m.sierra, v -> { m.sierra = Math.max(0, v); sierraL = m.sierra; guardar(); repintar(otraVez); }));
            }
            op.add("↻ Rotar piezas: " + (m.girar ? "SÍ" : "NO") + " (cambiar en todas)");
            ac.add(() -> new AlertDialog.Builder(act).setTitle("¿Las piezas se pueden rotar?")
                    .setItems(new String[]{"↻ SÍ, todas se pueden rotar", tipo == 2 ? "⇅ NO, cuidar la veta" : "⇅ NO, cuidar el sentido"}, (d, w) -> {
                        m.girar = w == 0;
                        StringBuilder sb = new StringBuilder();
                        for (String reng : m.piezas.split("\n")) {
                            String s = reng.replaceAll("\\s+(gira|fija)\\b", "").trim();
                            if (s.isEmpty()) continue;
                            sb.append(s).append(m.girar ? " gira" : " fija").append('\n');
                        }
                        m.piezas = sb.toString();
                        guardar(); repintar(otraVez);
                    }).show());
            op.add("♻ Retales del taller (" + leerRetales2(m.retales).size() + ")");
            ac.add(() -> ventanaTabla("♻ Retales del taller", new String[]{"Largo", "Ancho", "Cant."}, new float[]{1, 1, 0.7f}, new int[]{1, 1, 1},
                    filasRetales(m.retales), new String[]{"", "", "1"}, "➕ Otro retal", filas -> { m.retales = textoRetales(filas); guardar(); repintar(otraVez); }));
            new AlertDialog.Builder(act).setTitle("⋮ " + MATERIALES[tipo]).setItems(op.toArray(new String[0]), (d, w) -> ac.get(w).run()).show();
        };
        abierta = pantalla(MATERIALES[tipo] + " · Chepe Corte Láminas", l, new Object[][]{
                {"💾 Guardar", 0xFF2E7D32, (Runnable) () -> { leer.run(); guardar(); aviso("✔ Guardado «" + trabajo + "»"); }},
                {"✂ Calcular", 0xFFC62828, (Runnable) () -> { leer.run(); guardar(); resultadoLaminas(m); }}}, menu);
    }

    // ---------------- v6.9: una fila por pedazo ----------------

    interface Lector { List<String[]> leer(); }

    /** Una casilla Sí/No que se cambia con un toque (v7: «se puede rotar»). */
    private TextView siNo(String v) {
        boolean si = !"No".equalsIgnoreCase(v == null ? "" : v.trim());
        TextView t = boton(si ? "Sí" : "No", si ? 0xFF00897B : 0xFF6D4C41, null);
        t.setPadding(dp(2), dp(10), dp(2), dp(10));
        t.setOnClickListener(x -> {
            boolean ahora = !"Sí".equals(t.getText().toString());
            t.setText(ahora ? "Sí" : "No");
            GradientDrawable g = new GradientDrawable();
            g.setColor(ahora ? 0xFF00897B : 0xFF6D4C41);
            g.setCornerRadius(dp(9));
            t.setBackground(g);
        });
        return t;
    }

    /** Una tablita de casillas: una fila por pedazo, con 🗑 para borrar la fila y ➕ para agregar otra.
     *  tipos: 0 letras · 1 número · 2 Sí/No. Los títulos van en una sola línea para que las casillas queden alineadas.
     *  Si textoMas es null, es una sola fila fija (sin ➕ ni 🗑). */
    private Lector tabla(LinearLayout padre, String[] titulos, float[] pesos, int[] tipos, List<String[]> datos, String[] nueva, String textoMas) {
        boolean fija = textoMas == null;
        LinearLayout caja = new LinearLayout(act);
        caja.setOrientation(LinearLayout.VERTICAL);
        padre.addView(caja);
        LinearLayout cab = new LinearLayout(act);
        for (int i = 0; i < titulos.length; i++) {
            TextView t = new TextView(act);
            t.setText(titulos[i]);
            t.setTextColor(0xFFFFB300);
            t.setTextSize(13);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, pesos[i]);
            p.setMargins(dp(3), 0, dp(3), 0);
            cab.addView(t, p);
        }
        if (!fija) cab.addView(new View(act), new LinearLayout.LayoutParams(dp(42), 1));
        caja.addView(cab);
        LinearLayout lista = new LinearLayout(act);
        lista.setOrientation(LinearLayout.VERTICAL);
        caja.addView(lista);
        List<TextView[]> filas = new ArrayList<>();
        List<String[]> mios = new ArrayList<>(datos);
        Runnable[] pintar = new Runnable[1];
        java.util.function.Supplier<List<String[]>> todo = () -> {
            List<String[]> r = new ArrayList<>();
            for (TextView[] f : filas) {
                String[] v = new String[f.length];
                for (int i = 0; i < f.length; i++) v[i] = Teclado.tx(f[i]).trim();
                r.add(v);
            }
            return r;
        };
        Lector lector = () -> {
            List<String[]> r = new ArrayList<>();
            for (String[] v : todo.get()) {
                boolean vacia = true;
                for (int i = 0; i < v.length; i++) if (!v[i].isEmpty() && tipos[i] == 1) vacia = false;
                if (!vacia) r.add(v);
            }
            return r;
        };
        pintar[0] = () -> {
            lista.removeAllViews();
            filas.clear();
            for (int fi = 0; fi < mios.size(); fi++) {
                String[] d = mios.get(fi);
                LinearLayout f = new LinearLayout(act);
                f.setGravity(Gravity.CENTER_VERTICAL);
                TextView[] cs = new TextView[titulos.length];
                for (int i = 0; i < titulos.length; i++) {
                    String v = i < d.length && d[i] != null ? d[i] : "";
                    TextView e;
                    if (tipos[i] == 2) e = siNo(v);
                    else {
                        e = campo(v, "", tipos[i] == 1 && (v.isEmpty() || Teclado.esNumero(v)), false);
                        e.setTextSize(16);
                    }
                    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, pesos[i]);
                    p.setMargins(dp(2), dp(3), dp(2), dp(3));
                    f.addView(e, p);
                    cs[i] = e;
                }
                if (!fija) {
                    final int k = fi;
                    TextView bo = boton("🗑", 0xFFC62828, () -> {
                        // lo escrito se conserva; solo se quita esta fila
                        List<String[]> nuevas = todo.get();
                        if (k < nuevas.size()) nuevas.remove(k);
                        mios.clear(); mios.addAll(nuevas);
                        pintar[0].run();
                    });
                    f.addView(bo, new LinearLayout.LayoutParams(dp(42), dp(44)));
                }
                lista.addView(f);
                filas.add(cs);
            }
        };
        pintar[0].run();
        if (!fija) {
            TextView mas = boton(textoMas, 0xFF1565C0, () -> {
                List<String[]> nuevas = todo.get();
                String[] n = new String[titulos.length];
                for (int i = 0; i < n.length; i++) n[i] = nueva != null && i < nueva.length && nueva[i] != null ? nueva[i] : "";
                // la referencia de un pedazo nuevo: la misma de la fila de arriba
                if (!nuevas.isEmpty() && tipos[0] == 0 && "Referencia".equals(titulos[0])) n[0] = nuevas.get(nuevas.size() - 1)[0];
                nuevas.add(n);
                mios.clear(); mios.addAll(nuevas);
                pintar[0].run();
            });
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.topMargin = dp(4);
            caja.addView(mas, mp);
        }
        return lector;
    }

    /** "545x4 descanso; 2996x2" → filas {medida, cant, nombre}. */
    static List<String[]> filasPedazos(String t) {
        List<String[]> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').replace(',', ';').split(";")) {
            String p = parte.trim();
            if (p.isEmpty()) continue;
            java.util.regex.Matcher m = MEDIDA.matcher(p);
            if (!m.find()) continue;
            String nom = (p.substring(0, m.start()) + " " + p.substring(m.end())).trim().replaceAll("\\s+", " ");
            r.add(new String[]{m.group(1).replace(',', '.'), m.group(2) != null ? m.group(2) : "1", nom});
        }
        return r;
    }

    static String textoPedazos(List<String[]> filas) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : filas) {
            if (f[0] == null || f[0].isEmpty()) continue;
            String n = f.length > 1 && f[1] != null && !f[1].isEmpty() ? f[1] : "1";
            if (sb.length() > 0) sb.append("; ");
            sb.append(f[0]).append('x').append(n);
            if (f.length > 2 && f[2] != null && !f[2].isEmpty()) sb.append(' ').append(f[2].replace(";", " "));
        }
        return sb.toString();
    }

    /** "Lateral 600x300x2 F A fija" → {nombre, largo, ancho, cant, [canto], rotar}. */
    static List<String[]> filasPiezas(String t, boolean canto, boolean girarDef) {
        List<String[]> r = new ArrayList<>();
        if (t == null) return r;
        for (String reng : t.split("[\\n;]")) {
            String s = reng.trim();
            if (s.isEmpty()) continue;
            StringBuilder nom = new StringBuilder(), ca = new StringBuilder();
            String w = "", h = "", n = "1";
            boolean gi = girarDef;
            for (String tok : s.replace('*', 'x').replace('×', 'x').split("\\s+")) {
                String k = tok.toLowerCase(Locale.US);
                if (w.isEmpty() && k.matches("[0-9.]+x[0-9.]+(x[0-9]+)?")) {
                    String[] m = k.split("x");
                    w = m[0]; h = m[1];
                    if (m.length > 2) n = m[2];
                } else if (k.equals("gira")) gi = true;
                else if (k.equals("fija")) gi = false;
                else if (!w.isEmpty() && k.matches("[faid]|todo")) ca.append(ca.length() > 0 ? " " : "").append(tok.toUpperCase(Locale.US));
                else if (!k.equals("canto") && w.isEmpty()) nom.append(nom.length() > 0 ? " " : "").append(tok);
            }
            if (w.isEmpty()) continue;
            String g = gi ? "Sí" : "No";
            r.add(canto ? new String[]{nom.toString(), w, h, n, ca.toString(), g} : new String[]{nom.toString(), w, h, n, g});
        }
        return r;
    }

    static String textoPiezas(List<String[]> filas, boolean canto) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : filas) {
            if (f[1] == null || f[1].isEmpty() || f[2] == null || f[2].isEmpty()) continue;
            String nom = f[0] == null || f[0].isEmpty() ? "Pieza" : f[0].replaceAll("[0-9.]+x[0-9.]+", "").trim();
            if (nom.matches("(?i)[faid]|gira|fija")) nom = "Pieza " + nom;
            String n = f[3] == null || f[3].isEmpty() ? "1" : f[3];
            sb.append(nom.isEmpty() ? "Pieza" : nom).append(' ').append(f[1]).append('x').append(f[2]).append('x').append(n);
            if (canto && f.length > 4 && f[4] != null) {
                for (String c : f[4].toUpperCase(Locale.US).split("[\\s,]+")) if (c.matches("[FAID]|TODO")) sb.append(' ').append(c);
            }
            String g = f[f.length - 1];
            sb.append("No".equalsIgnoreCase(g) ? " fija" : " gira");
            sb.append('\n');
        }
        return sb.toString();
    }

    static List<String[]> filasRetales(String t) {
        List<String[]> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').replace(',', ';').split(";")) {
            String p = parte.trim().toLowerCase(Locale.US).replace('*', 'x').replace('×', 'x').replace(" ", "");
            if (p.isEmpty()) continue;
            String[] m = p.split("x");
            if (m.length < 2) continue;
            r.add(new String[]{m[0], m[1], m.length > 2 ? m[2] : "1"});
        }
        return r;
    }

    static String textoRetales(List<String[]> filas) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : filas) {
            if (f[0] == null || f[0].isEmpty() || f[1] == null || f[1].isEmpty()) continue;
            if (sb.length() > 0) sb.append("; ");
            sb.append(f[0]).append('x').append(f[1]).append('x').append(f[2] == null || f[2].isEmpty() ? "1" : f[2]);
        }
        return sb.toString();
    }

    private void resultadoLaminas(Mat m) {
        ResLam r = cortarLaminas(m, m.sierra);
        if (r.hojas.isEmpty()) { aviso(r.error != null ? r.error : "Escriba las piezas"); return; }
        double area = 0;
        for (Hoja2 h : r.hojas) area += h.ancho * h.alto;
        StringBuilder sb = new StringBuilder();
        sb.append(m.nombre).append(": ").append(r.hojas.size()).append(r.hojas.size() == 1 ? " lámina" : " láminas");
        if (r.retalesUsados > 0) sb.append(" (").append(r.retalesUsados).append(" retal").append(r.retalesUsados == 1 ? "" : "es").append(" del taller)");
        sb.append("\nCOMPRAR ").append(r.nuevas).append(r.nuevas == 1 ? " lámina" : " láminas").append(" de ").append(Pieza.n((float) m.ancho)).append(" x ").append(Pieza.n((float) m.alto));
        if (m.tipo == 0 && !m.calibre.isEmpty()) sb.append(" · ").append(m.calibre);
        sb.append("\nAprovechamiento: ").append(Math.round(100 * r.piezasArea / Math.max(1, area))).append(" %");
        if (r.cantoMm > 0) sb.append("\nCanto: ").append(String.format(Locale.US, "%.2f", r.cantoMm / 1000)).append(" metros lineales");
        // v7: lo que sobra de cada lámina (retal), acotado
        StringBuilder so = new StringBuilder();
        for (int i = 0; i < r.hojas.size(); i++)
            for (double[] s : sobrantes(r.hojas.get(i), m.sierra))
                so.append(so.length() > 0 ? "; " : "").append("#").append(i + 1).append(" ").append(Pieza.n((float) Math.floor(s[2]))).append("x").append(Pieza.n((float) Math.floor(s[3])));
        if (so.length() > 0) sb.append("\n♻ Sobra: ").append(so);
        if (r.error != null) sb.append("\n⚠ ").append(r.error);
        dibujo("🪟 Listado de corte · láminas", sb.toString(), new DibujoLaminas(r, m.sierra), () -> pdfLaminas(m, r));
    }

    // ---------------- Mostrar e imprimir ----------------

    private void dibujo(String titulo, String resumen, View v, Runnable pdf) {
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(4), dp(6), dp(4), dp(6));
        TextView t = new TextView(act);
        t.setText(resumen);
        t.setTextSize(15);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.WHITE);
        l.addView(t);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = dp(8);
        l.addView(v, vp);
        pantalla(titulo, l, new Object[][]{{"🖨 PDF carta", 0xFF1565C0, pdf}});
    }

    /** Las barras, una debajo de otra (las iguales juntas: «2 barras»). */
    private final class DibujoBarras extends View {
        final List<ResBarras> rs;

        DibujoBarras(List<ResBarras> rs) {
            super(act);
            this.rs = rs;
            int n = 0;
            for (ResBarras x : rs) n += x.grupos.size() + 1;
            setMinimumHeight(dp(58) * n + dp(10));
        }

        @Override
        protected void onDraw(Canvas c) {
            pintarBarras(c, rs, 0, Integer.MAX_VALUE, getWidth(), dp(58), dp(11.5f), false);
        }
    }

    private static final int[] COLORES = {0xFF4FC3F7, 0xFFAED581, 0xFFFFD54F, 0xFFCE93D8, 0xFFFF8A65, 0xFF80CBC4, 0xFFF48FB1, 0xFFB0BEC5};

    /** v6.7: como la app de corte: cuántas barras así, «6000 mm (usado: … + desperdicio: …)», y cada pedazo con medida y nombre.
     *  Dibuja desde la fila "desde" hasta "hasta"; devuelve cuántas filas usó. */
    private int pintarBarras(Canvas c, List<ResBarras> rs, int desde, int hasta, float ancho, float alto, float letra, boolean papel) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int fila = 0, pintadas = 0;
        float y = 0;
        for (ResBarras x : rs) {
            java.util.Map<String, Integer> color = new java.util.HashMap<>();
            for (int i = -1; i < x.grupos.size(); i++) {
                if (fila < desde) { fila++; continue; }
                if (pintadas >= hasta) return pintadas;
                p.setStyle(Paint.Style.FILL);
                p.setTextSize(letra);
                p.setFakeBoldText(true);
                p.setColor(papel ? Color.BLACK : Color.WHITE);
                if (i < 0) {
                    p.setTextSize(letra * 1.15f);
                    c.drawText("Referencia " + x.ref + " · " + x.barras.size() + (x.barras.size() == 1 ? " barra" : " barras") + " · comprar " + x.nuevas, 4, y + alto * 0.6f, p);
                } else {
                    Barra b = x.grupos.get(i);
                    int n = x.cuantas.get(i);
                    float x0 = 4, w = ancho - 8, top = y + letra * 2.5f, h = letra * 1.6f;
                    float k = (float) (w / Math.max(b.largo, 1));
                    c.drawText(n + (n == 1 ? " barra" : " barras") + " · " + b.origen + " · " + Pieza.n((float) b.largo) + " mm (usado: " + Pieza.n((float) Math.round(b.usado))
                            + " mm + desperdicio: " + Pieza.n((float) Math.round(b.desperdicio)) + " mm · sobra " + Pieza.n((float) Math.floor(b.sobra())) + ")", x0, y + letra * 1.1f, p);
                    p.setFakeBoldText(false);
                    float cx = x0 + (float) despIzq * k;
                    float ty = top + h + letra * 1.15f;
                    float tx = x0;
                    for (int j = 0; j < b.piezas.size(); j++) {
                        double pz = b.piezas.get(j);
                        String nom = b.nombres.get(j);
                        String clave = Pieza.n((float) pz) + "|" + nom;
                        if (!color.containsKey(clave)) color.put(clave, COLORES[color.size() % COLORES.length]);
                        float pw = (float) pz * k;
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(papel ? 0xFFE6E6E6 : color.get(clave));
                        c.drawRect(cx, top, cx + pw, top + h, p);
                        p.setStyle(Paint.Style.STROKE);
                        p.setColor(Color.BLACK);
                        p.setStrokeWidth(papel ? 0.8f : dp(1));
                        c.drawRect(cx, top, cx + pw, top + h, p);
                        cx += pw + (float) sierraB * k;
                    }
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(papel ? Color.BLACK : 0xFFECEFF1);
                    c.drawRect(x0, top, x0 + w, top + h, p);
                    // debajo: «2× 545 mm [descanso]», un letrero por cada medida distinta
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(papel ? Color.BLACK : Color.WHITE);
                    p.setTextSize(letra * 0.95f);
                    java.util.LinkedHashMap<String, Integer> cuenta = new java.util.LinkedHashMap<>();
                    for (int j = 0; j < b.piezas.size(); j++) {
                        String cl = Pieza.n((float) (double) b.piezas.get(j)) + " mm" + (b.nombres.get(j).isEmpty() ? "" : " [" + b.nombres.get(j) + "]");
                        cuenta.put(cl, cuenta.getOrDefault(cl, 0) + 1);
                    }
                    for (java.util.Map.Entry<String, Integer> en : cuenta.entrySet()) {
                        String t = en.getValue() + "× " + en.getKey() + "   ";
                        float tw = p.measureText(t);
                        if (tx + tw > x0 + w && tx > x0) break;   // lo que no cabe se ve en el PDF
                        c.drawText(t, tx, ty, p);
                        tx += tw;
                    }
                }
                y += alto;
                fila++;
                pintadas++;
            }
        }
        return pintadas;
    }

    private void pdfBarras(List<ResBarras> rs) {
        try {
            PdfDocument doc = new PdfDocument();
            int total = 0;
            for (ResBarras x : rs) total += x.grupos.size() + 1;
            int porHoja = 16, hecho = 0, num = 1;
            while (hecho < total) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.BLACK);
                p.setTextSize(13);
                p.setFakeBoldText(true);
                c.drawText("ChpCad · CORTE LINEAL" + (trabajo.isEmpty() ? "" : " · " + trabajo) + " · disco " + Pieza.n((float) sierraB) + " mm · hoja " + num, 36, 40, p);
                c.save();
                c.translate(36, 56);
                hecho += pintarBarras(c, rs, hecho, porHoja, 540, 43, 9, true);
                c.restore();
                doc.finishPage(pg);
                num++;
            }
            act.guardarPdf(doc, "MiInventor_CorteBarras_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    private final class DibujoLaminas extends View {
        final ResLam r;
        final double sierra;

        DibujoLaminas(ResLam r, double sierra) {
            super(act);
            this.r = r;
            this.sierra = sierra;
            float w = act.getResources().getDisplayMetrics().widthPixels - dp(60);
            float h = 0;
            for (Hoja2 hj : r.hojas) h += w * hj.alto / hj.ancho + dp(26);
            setMinimumHeight((int) h + dp(10));
        }

        @Override
        protected void onDraw(Canvas c) {
            float y = 0;
            for (int i = 0; i < r.hojas.size(); i++) {
                Hoja2 hj = r.hojas.get(i);
                float w = getWidth() - 8;
                y += pintarHoja(c, hj, i + 1, 4, y, w, dp(11), false, sierra);
            }
        }
    }

    /** Dibuja una lámina con sus piezas; devuelve el alto que usó. */
    private float pintarHoja(Canvas c, Hoja2 hj, int n, float x0, float y0, float w, float letra, boolean papel, double sierra) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float k = (float) (w / hj.ancho);
        float top = y0 + letra * 1.6f;
        p.setTextSize(letra);
        p.setFakeBoldText(true);
        p.setColor(papel ? Color.BLACK : Color.WHITE);
        c.drawText("#" + n + " " + hj.origen + " " + Pieza.n((float) hj.ancho) + " x " + Pieza.n((float) hj.alto)
                + " · aprovecha " + Math.round(100 * hj.usado() / (hj.ancho * hj.alto)) + " %", x0, y0 + letra * 1.1f, p);
        p.setFakeBoldText(false);
        p.setStyle(Paint.Style.FILL);
        p.setColor(papel ? 0xFFFFFFFF : 0xFF37474F);
        c.drawRect(x0, top, x0 + w, top + (float) hj.alto * k, p);
        for (Puesta pu : hj.puestas) {
            float a = x0 + (float) pu.x * k, b = top + (float) pu.y * k, wa = (float) pu.w * k, hb = (float) pu.h * k;
            p.setStyle(Paint.Style.FILL);
            p.setColor(papel ? 0xFFE6E6E6 : 0xFF4FC3F7);
            c.drawRect(a, b, a + wa, b + hb, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(papel ? 0.7f : dp(1));
            p.setColor(Color.BLACK);
            c.drawRect(a, b, a + wa, b + hb, p);
            // canto: una raya gruesa al lado del borde que lo lleva
            p.setStrokeWidth(papel ? 2f : dp(3));
            float g = papel ? 2f : dp(3);
            boolean f = pu.girada ? pu.pz.i : pu.pz.f, at = pu.girada ? pu.pz.d : pu.pz.a, iz = pu.girada ? pu.pz.f : pu.pz.i, de = pu.girada ? pu.pz.a : pu.pz.d;
            if (f) c.drawLine(a + g, b + hb - g, a + wa - g, b + hb - g, p);
            if (at) c.drawLine(a + g, b + g, a + wa - g, b + g, p);
            if (iz) c.drawLine(a + g, b + g, a + g, b + hb - g, p);
            if (de) c.drawLine(a + wa - g, b + g, a + wa - g, b + hb - g, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            String t1 = pu.pz.nombre, t2 = Pieza.n((float) pu.pz.w) + "x" + Pieza.n((float) pu.pz.h) + (pu.girada ? " ↻" : "");
            float ts = Math.min(letra, Math.max(5, hb / 3));
            p.setTextSize(ts);
            if (p.measureText(t2) < wa - 2 && hb > ts * 1.2f) c.drawText(t2, a + (wa - p.measureText(t2)) / 2, b + hb / 2 + ts * (hb > ts * 2.6f ? 1.0f : 0.35f), p);
            if (!t1.equals(t2) && p.measureText(t1) < wa - 2 && hb > ts * 2.6f) c.drawText(t1, a + (wa - p.measureText(t1)) / 2, b + hb / 2 - ts * 0.2f, p);
        }
        // v7: el sobrante (retal) de la lámina, con raya punteada y su medida
        for (double[] so : sobrantes(hj, sierra)) {
            float a = x0 + (float) so[0] * k, b = top + (float) so[1] * k, wa = (float) so[2] * k, hb = (float) so[3] * k;
            p.setStyle(Paint.Style.FILL);
            p.setColor(papel ? 0xFFF5F5F5 : 0xFF455A64);
            c.drawRect(a, b, a + wa, b + hb, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(papel ? 0.7f : dp(1));
            p.setColor(papel ? Color.BLACK : 0xFFFFFFFF);
            p.setPathEffect(new android.graphics.DashPathEffect(new float[]{papel ? 3 : dp(4), papel ? 2 : dp(3)}, 0));
            c.drawRect(a, b, a + wa, b + hb, p);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            p.setFakeBoldText(true);
            String t = "Sobra " + Pieza.n((float) Math.floor(so[2])) + " x " + Pieza.n((float) Math.floor(so[3]));
            float ts = letra;
            p.setTextSize(ts);
            float tw = p.measureText(t);
            if (tw < wa - 2 && hb > ts * 1.2f) c.drawText(t, a + (wa - tw) / 2, b + hb / 2 + ts * 0.35f, p);
            else if (tw < hb - 2 && wa > ts * 1.2f) {   // franja angosta: el letrero de lado
                c.save();
                c.rotate(-90, a + wa / 2, b + hb / 2);
                c.drawText(t, a + wa / 2 - tw / 2, b + hb / 2 + ts * 0.35f, p);
                c.restore();
            } else {
                ts = Math.max(5, Math.min(ts, Math.max(wa, hb) / Math.max(1, t.length()) * 1.6f));
                p.setTextSize(ts);
                tw = p.measureText(t);
                if (wa >= hb) c.drawText(t, a + Math.max(1, (wa - tw) / 2), b + hb / 2 + ts * 0.35f, p);
                else { c.save(); c.rotate(-90, a + wa / 2, b + hb / 2); c.drawText(t, a + wa / 2 - tw / 2, b + hb / 2 + ts * 0.35f, p); c.restore(); }
            }
            p.setFakeBoldText(false);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(papel ? 1 : dp(1.5f));
        p.setColor(papel ? Color.BLACK : 0xFFB0BEC5);
        c.drawRect(x0, top, x0 + w, top + (float) hj.alto * k, p);
        return (float) hj.alto * k + letra * 1.6f + (papel ? 14 : dp(12));
    }

    private void pdfLaminas(Mat m, ResLam r) {
        try {
            PdfDocument doc = new PdfDocument();
            int num = 1, i = 0;
            while (i < r.hojas.size()) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.BLACK);
                p.setTextSize(13);
                p.setFakeBoldText(true);
                c.drawText("ChpCad · CORTE DE " + m.nombre.toUpperCase(Locale.ROOT) + (trabajo.isEmpty() ? "" : " · " + trabajo) + (m.tipo == 1 ? "" : " · corte " + Pieza.n((float) m.sierra) + " mm") + " · hoja " + num, 36, 40, p);
                p.setFakeBoldText(false);
                p.setTextSize(9);
                c.drawText((r.cantoMm > 0 ? "Raya gruesa = lleva canto · " : "") + "↻ = pieza girada · punteado = lo que sobra (retal)"
                        + (r.cantoMm > 0 ? " · canto total " + String.format(Locale.US, "%.2f", r.cantoMm / 1000) + " m" : ""), 36, 54, p);
                float y = 66;
                boolean alguna = false;
                while (i < r.hojas.size()) {
                    Hoja2 hj = r.hojas.get(i);
                    float h = (float) (540 * hj.alto / hj.ancho) + 30;
                    if (alguna && y + h > 760) break;
                    y += pintarHoja(c, hj, i + 1, 36, y, 540, 9, true, m.sierra);
                    alguna = true;
                    i++;
                }
                doc.finishPage(pg);
                num++;
            }
            act.guardarPdf(doc, "MiInventor_CorteLaminas_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Guardar ----------------

    private File archivo() { return new File(carpeta, "_cortes.json"); }

    private void guardar() {
        try {
            JSONObject o = new JSONObject();
            o.put("sierraB", sierraB); o.put("sierraL", sierraL);
            o.put("despIzq", despIzq); o.put("despDer", despDer); o.put("retalMin", retalMin);
            JSONArray a = new JSONArray();
            for (Ref r : refs) {
                JSONObject x = new JSONObject();
                x.put("n", r.nombre); x.put("b", r.barra); x.put("t", r.tengo); x.put("r", r.retales); x.put("p", r.piezas);
                a.put(x);
            }
            o.put("refs", a);
            JSONArray b = new JSONArray();
            for (Mat m : mats) {
                JSONObject x = new JSONObject();
                x.put("k", m.tipo); x.put("s", m.sierra); x.put("n", m.nombre); x.put("an", m.ancho); x.put("al", m.alto); x.put("t", m.tengo); x.put("g", m.girar); x.put("r", m.retales); x.put("p", m.piezas); x.put("c", m.calibre);
                b.put(x);
            }
            o.put("mats", b);
            try (FileWriter w = new FileWriter(archivo())) { w.write(o.toString()); }
            // v6.7: cada trabajo en su propio archivo (con nombre y fecha)
            if (!trabajo.isEmpty()) try (FileWriter w = new FileWriter(new File(carpetaTrabajos(), trabajo + ".json"))) { w.write(o.toString()); }
        } catch (Exception ignored) { }
    }

    private void cargar() { leer(archivo()); }

    private void leer(File f) {
        try {
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            sierraB = o.optDouble("sierraB", 3); sierraL = o.optDouble("sierraL", 4);
            despIzq = o.optDouble("despIzq", 0); despDer = o.optDouble("despDer", 0); retalMin = o.optDouble("retalMin", 300);
            refs.clear(); mats.clear();
            JSONArray a = o.optJSONArray("refs");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.getJSONObject(i);
                Ref r = new Ref();
                r.nombre = x.optString("n", "P" + (i + 1)); r.barra = x.optDouble("b", 6000); r.tengo = x.optInt("t", 0);
                r.retales = x.optString("r", ""); r.piezas = x.optString("p", "");
                refs.add(r);
            }
            JSONArray b = o.optJSONArray("mats");
            if (b != null) for (int i = 0; i < b.length(); i++) {
                JSONObject x = b.getJSONObject(i);
                Mat m = new Mat();
                m.nombre = x.optString("n", "Vidrio"); m.ancho = x.optDouble("an", 2440); m.alto = x.optDouble("al", 1220); m.tengo = x.optInt("t", 0);
                m.girar = x.optBoolean("g", true); m.retales = x.optString("r", ""); m.piezas = x.optString("p", "");
                m.tipo = x.optInt("k", 2); m.sierra = x.optDouble("s", o.optDouble("sierraL", 4));
                m.calibre = x.optString("c", m.tipo == 0 ? "Cal 18" : ""); m.tengo = 0;
                mats.add(m);
            }
        } catch (Exception ignored) { }
    }
}
