package co.jose.miinventor;

import java.util.ArrayList;
import java.util.List;

/**
 * v6.3: sólidos con cortes (resta de sólidos), como el "Extruir → Cortar" de Inventor.
 * Es el método de árboles BSP (el mismo de csg.js), pasado a Java y en milímetros.
 * Se usa para los cortes en las caras de lado y en las puntas de las placas y perfiles.
 */
final class Csg {
    private static final double EPS = 1e-3;

    static final class Pol {
        final List<double[]> v;
        double[] n;
        double w;

        Pol(List<double[]> v) {
            this.v = v;
            plano();
        }

        private void plano() {
            // normal por el método de Newell (aguanta polígonos con puntos casi en línea)
            double nx = 0, ny = 0, nz = 0;
            for (int i = 0; i < v.size(); i++) {
                double[] a = v.get(i), b = v.get((i + 1) % v.size());
                nx += (a[1] - b[1]) * (a[2] + b[2]);
                ny += (a[2] - b[2]) * (a[0] + b[0]);
                nz += (a[0] - b[0]) * (a[1] + b[1]);
            }
            double l = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (l < 1e-12) { n = new double[]{0, 0, 1}; w = 0; return; }
            n = new double[]{nx / l, ny / l, nz / l};
            w = n[0] * v.get(0)[0] + n[1] * v.get(0)[1] + n[2] * v.get(0)[2];
        }

        Pol copia() {
            List<double[]> c = new ArrayList<>();
            for (double[] p : v) c.add(p.clone());
            Pol q = new Pol(c);
            q.n = n.clone(); q.w = w;
            return q;
        }

        void voltear() {
            java.util.Collections.reverse(v);
            n = new double[]{-n[0], -n[1], -n[2]};
            w = -w;
        }

        boolean sirve() {
            return v.size() >= 3;
        }
    }

    private static final class Plano {
        double[] n;
        double w;

        Plano(double[] n, double w) { this.n = n.clone(); this.w = w; }

        void voltear() { n = new double[]{-n[0], -n[1], -n[2]}; w = -w; }

        void partir(Pol p, List<Pol> cf, List<Pol> cb, List<Pol> f, List<Pol> b) {
            int tipoPol = 0;
            int m = p.v.size();
            int[] tipos = new int[m];
            for (int i = 0; i < m; i++) {
                double[] q = p.v.get(i);
                double t = n[0] * q[0] + n[1] * q[1] + n[2] * q[2] - w;
                int tp = t < -EPS ? 2 : t > EPS ? 1 : 0;
                tipoPol |= tp;
                tipos[i] = tp;
            }
            switch (tipoPol) {
                case 0:
                    if (n[0] * p.n[0] + n[1] * p.n[1] + n[2] * p.n[2] > 0) cf.add(p); else cb.add(p);
                    break;
                case 1: f.add(p); break;
                case 2: b.add(p); break;
                default: {
                    List<double[]> fv = new ArrayList<>(), bv = new ArrayList<>();
                    for (int i = 0; i < m; i++) {
                        int j = (i + 1) % m;
                        int ti = tipos[i], tj = tipos[j];
                        double[] vi = p.v.get(i), vj = p.v.get(j);
                        if (ti != 2) fv.add(vi);
                        if (ti != 1) bv.add(ti != 2 ? vi.clone() : vi);
                        if ((ti | tj) == 3) {
                            double den = n[0] * (vj[0] - vi[0]) + n[1] * (vj[1] - vi[1]) + n[2] * (vj[2] - vi[2]);
                            double t = (w - (n[0] * vi[0] + n[1] * vi[1] + n[2] * vi[2])) / den;
                            double[] c = {vi[0] + (vj[0] - vi[0]) * t, vi[1] + (vj[1] - vi[1]) * t, vi[2] + (vj[2] - vi[2]) * t};
                            fv.add(c);
                            bv.add(c.clone());
                        }
                    }
                    if (fv.size() >= 3) { Pol q = new Pol(fv); q.n = p.n.clone(); q.w = p.w; f.add(q); }
                    if (bv.size() >= 3) { Pol q = new Pol(bv); q.n = p.n.clone(); q.w = p.w; b.add(q); }
                }
            }
        }
    }

    private static final class Nodo {
        Plano plano;
        Nodo frente, atras;
        List<Pol> pols = new ArrayList<>();

        Nodo(List<Pol> l) { if (l != null) armar(l); }

        void invertir() {
            for (Pol p : pols) p.voltear();
            if (plano != null) plano.voltear();
            if (frente != null) frente.invertir();
            if (atras != null) atras.invertir();
            Nodo t = frente; frente = atras; atras = t;
        }

        List<Pol> recortar(List<Pol> l) {
            if (plano == null) return new ArrayList<>(l);
            List<Pol> f = new ArrayList<>(), b = new ArrayList<>();
            for (Pol p : l) plano.partir(p, f, b, f, b);
            if (frente != null) f = frente.recortar(f);
            if (atras != null) b = atras.recortar(b); else b = new ArrayList<>();
            f.addAll(b);
            return f;
        }

        void recortarCon(Nodo bsp) {
            pols = bsp.recortar(pols);
            if (frente != null) frente.recortarCon(bsp);
            if (atras != null) atras.recortarCon(bsp);
        }

        List<Pol> todos() {
            List<Pol> l = new ArrayList<>(pols);
            if (frente != null) l.addAll(frente.todos());
            if (atras != null) l.addAll(atras.todos());
            return l;
        }

        void armar(List<Pol> l) {
            if (l.isEmpty()) return;
            if (plano == null) plano = new Plano(l.get(0).n, l.get(0).w);
            List<Pol> f = new ArrayList<>(), b = new ArrayList<>();
            for (Pol p : l) plano.partir(p, pols, pols, f, b);
            if (!f.isEmpty()) { if (frente == null) frente = new Nodo(null); frente.armar(f); }
            if (!b.isEmpty()) { if (atras == null) atras = new Nodo(null); atras.armar(b); }
        }
    }

    private static List<Pol> copiar(List<Pol> l) {
        List<Pol> r = new ArrayList<>();
        for (Pol p : l) r.add(p.copia());
        return r;
    }

    // ---------------- v6.6: orden exacto de pintado (de atrás para adelante) ----------------

    /** El árbol BSP del sólido: sirve para pintar sin que lo de atrás quede encima. */
    static Object arbol(List<Pol> l) { return new Nodo(copiar(l)); }

    static List<Pol> todosDe(Object a) { return ((Nodo) a).todos(); }

    /** Los polígonos de atrás para adelante, mirando en la dirección v (cámara ortográfica). */
    static void orden(Object a, double[] v, List<Pol> out) {
        Nodo n = (Nodo) a;
        if (n == null) return;
        if (n.plano == null) { out.addAll(n.pols); return; }
        double d = n.plano.n[0] * v[0] + n.plano.n[1] * v[1] + n.plano.n[2] * v[2];
        Nodo lejos = d < 0 ? n.atras : n.frente, cerca = d < 0 ? n.frente : n.atras;
        if (lejos != null) orden(lejos, v, out);
        out.addAll(n.pols);
        if (cerca != null) orden(cerca, v, out);
    }

    /** A menos B. */
    static List<Pol> restar(List<Pol> A, List<Pol> B) {
        Nodo a = new Nodo(copiar(A)), b = new Nodo(copiar(B));
        a.invertir();
        a.recortarCon(b);
        b.recortarCon(a);
        b.invertir();
        b.recortarCon(a);
        b.invertir();
        a.armar(b.todos());
        a.invertir();
        return a.todos();
    }

    // ---------------- Armar sólidos ----------------

    /**
     * Prisma: el polígono (x, y) puesto en el plano org + ax·x + ay·y, empujado por el vector dir.
     * Las tapas se parten en triángulos (orejas) para que la resta funcione con figuras en L, U, etc.
     */
    static List<Pol> prisma(double[][] pol, double[] org, double[] ax, double[] ay, double[] dir) {
        List<Pol> r = new ArrayList<>();
        int n = pol.length;
        if (n < 3) return r;
        double[][] p = pol;
        if (area(p) < 0) { p = new double[n][]; for (int i = 0; i < n; i++) p[i] = pol[n - 1 - i]; }
        double[][] a = new double[n][], b = new double[n][];
        for (int i = 0; i < n; i++) {
            a[i] = new double[]{org[0] + ax[0] * p[i][0] + ay[0] * p[i][1], org[1] + ax[1] * p[i][0] + ay[1] * p[i][1], org[2] + ax[2] * p[i][0] + ay[2] * p[i][1]};
            b[i] = new double[]{a[i][0] + dir[0], a[i][1] + dir[1], a[i][2] + dir[2]};
        }
        for (int[] t : orejas(p)) {
            List<double[]> abajo = new ArrayList<>();
            abajo.add(a[t[2]].clone()); abajo.add(a[t[1]].clone()); abajo.add(a[t[0]].clone());
            r.add(new Pol(abajo));
            List<double[]> arriba = new ArrayList<>();
            arriba.add(b[t[0]].clone()); arriba.add(b[t[1]].clone()); arriba.add(b[t[2]].clone());
            r.add(new Pol(arriba));
        }
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            List<double[]> q = new ArrayList<>();
            q.add(a[i].clone()); q.add(a[j].clone()); q.add(b[j].clone()); q.add(b[i].clone());
            r.add(new Pol(q));
        }
        // si dir va para el lado contrario de ax × ay, el sólido quedó al revés: se voltea todo
        double[] z = {ax[1] * ay[2] - ax[2] * ay[1], ax[2] * ay[0] - ax[0] * ay[2], ax[0] * ay[1] - ax[1] * ay[0]};
        if (z[0] * dir[0] + z[1] * dir[1] + z[2] * dir[2] < 0) for (Pol q : r) q.voltear();
        return r;
    }

    static double area(double[][] p) {
        double s = 0;
        for (int i = 0, j = p.length - 1; i < p.length; j = i++) s += p[j][0] * p[i][1] - p[i][0] * p[j][1];
        return s / 2;
    }

    /** Partir un polígono sencillo (contra reloj) en triángulos, cortando orejas. */
    static List<int[]> orejas(double[][] p) {
        List<int[]> r = new ArrayList<>();
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < p.length; i++) idx.add(i);
        int guarda = 0;
        while (idx.size() > 3 && guarda++ < 10000) {
            boolean corto = false;
            for (int k = 0; k < idx.size(); k++) {
                int i0 = idx.get((k + idx.size() - 1) % idx.size()), i1 = idx.get(k), i2 = idx.get((k + 1) % idx.size());
                double[] a = p[i0], b = p[i1], c = p[i2];
                double cr = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
                if (cr <= 1e-9) continue;   // punta para adentro
                boolean adentro = false;
                for (int o : idx) {
                    if (o == i0 || o == i1 || o == i2) continue;
                    if (enTriangulo(p[o], a, b, c)) { adentro = true; break; }
                }
                if (adentro) continue;
                r.add(new int[]{i0, i1, i2});
                idx.remove(k);
                corto = true;
                break;
            }
            if (!corto) break;   // figura rara: lo que queda va en abanico
        }
        for (int k = 1; k + 1 < idx.size(); k++) r.add(new int[]{idx.get(0), idx.get(k), idx.get(k + 1)});
        return r;
    }

    private static boolean enTriangulo(double[] q, double[] a, double[] b, double[] c) {
        double d1 = (q[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (q[1] - b[1]);
        double d2 = (q[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (q[1] - c[1]);
        double d3 = (q[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (q[1] - a[1]);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }

    /**
     * Las aristas que se dibujan: los bordes que no comparte otro pedazo de la misma cara
     * (así no se ven las rayas de los triángulos).
     */
    static List<List<double[][]>> aristas(List<Pol> l) {
        List<List<double[][]>> todo = new ArrayList<>();
        for (int i = 0; i < l.size(); i++) {
            List<double[][]> r = new ArrayList<>();
            todo.add(r);
            Pol p = l.get(i);
            int m = p.v.size();
            for (int k = 0; k < m; k++) {
                double[] a = p.v.get(k), b = p.v.get((k + 1) % m);
                if (dist(a, b) < 0.05) continue;
                boolean adentro = false;
                for (int j = 0; j < l.size() && !adentro; j++) {
                    if (j == i) continue;
                    Pol q = l.get(j);
                    if (q.n[0] * p.n[0] + q.n[1] * p.n[1] + q.n[2] * p.n[2] < 0.9999 || Math.abs(q.w - p.w) > 0.05) continue;
                    int mq = q.v.size();
                    for (int t = 0; t < mq && !adentro; t++) {
                        double[] c = q.v.get(t), d = q.v.get((t + 1) % mq);
                        if (solapa(a, b, c, d)) adentro = true;
                    }
                }
                if (!adentro) r.add(new double[][]{a, b});
            }
        }
        return todo;
    }

    private static double dist(double[] a, double[] b) {
        return Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]));
    }

    /** El segmento a-b queda sobre el segmento c-d (en línea y montados). */
    private static boolean solapa(double[] a, double[] b, double[] c, double[] d) {
        double[] u = {d[0] - c[0], d[1] - c[1], d[2] - c[2]};
        double l = Math.sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
        if (l < 1e-9) return false;
        u[0] /= l; u[1] /= l; u[2] /= l;
        double ta = (a[0] - c[0]) * u[0] + (a[1] - c[1]) * u[1] + (a[2] - c[2]) * u[2];
        double tb = (b[0] - c[0]) * u[0] + (b[1] - c[1]) * u[1] + (b[2] - c[2]) * u[2];
        double[] pa = {c[0] + u[0] * ta, c[1] + u[1] * ta, c[2] + u[2] * ta}, pb = {c[0] + u[0] * tb, c[1] + u[1] * tb, c[2] + u[2] * tb};
        if (dist(pa, a) > 0.05 || dist(pb, b) > 0.05) return false;
        double lo = Math.min(ta, tb), hi = Math.max(ta, tb);
        return hi - lo > 0.05 && Math.min(hi, l) - Math.max(lo, 0) > (hi - lo) * 0.5;
    }
}
