package co.jose.miinventor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * La hoja del boceto 2D. Dos dedos siempre acercan y corren la hoja.
 * Con «Ver» un dedo corre la hoja y tocar escoge; con las herramientas de dibujo el dedo pone los puntos
 * (se ve la línea mientras corre el dedo y el punto queda donde lo suelta).
 * Versión 3: lupa, imanes (extremo, mitad, centro, cruce, 90°, tangente), orto, polígono,
 * «Siguiente» cuando hay cosas montadas y pedidos de puntos para las herramientas de Modificar y Medir.
 */
public class VistaBoceto extends View {

    public static final int VER = 0, LINEA = 1, RECT = 2, CIRCULO = 3, ARCO = 4, TEXTO = 5, COTA = 6, MOVER = 7, POLIGONO = 8, PEDIDO = 9, CUADRO = 10;
    public static final String[] AYUDA = {
            "Un dedo corre la hoja, dos dedos acercan. Toque para escoger (si hay varias cosas juntas, toque «Siguiente»).",
            "Línea: suelte el dedo en cada punto, o escriba largo y ángulo abajo. Para terminar toque ✓ Listo.",
            "Rectángulo: suelte en una esquina y luego en la contraria, o escriba ancho y alto abajo.",
            "Círculo: suelte en el centro y luego en el borde, o escriba el diámetro abajo.",
            "Arco: suelte en el centro, luego en el inicio y luego en el final (contra el reloj).",
            "Texto: suelte el dedo donde va el texto.",
            "Cota: toque una línea o un círculo; dos puntos; o un borde punteado y lo que va amarrado a él.",
            "Mover: arrastre un punto; el dibujo se acomoda respetando medidas y amarres.",
            "Polígono: suelte en el centro y luego en una punta, o escriba lados y radio abajo.",
            "",
            "Cuadro: arrastre → (de izquierda a derecha) escoge lo que queda todo adentro · arrastre ← (de derecha a izquierda) escoge todo lo que el cuadro toque."};

    public interface Oyente {
        void antes();                                        // guardar para deshacer
        void cambio();                                       // ya cambió algo
        void pedirCota(Boceto.Restr nueva);                  // escribir el valor de una cota nueva
        void pedirDistancia(int p1, int p2);                 // escoger horizontal, vertical o alineada
        void editarCota(Boceto.Restr r);
        void pedirTexto(double x, double y);
        void seleccion();
        void aviso(String s);
    }

    // ---------------- Pedidos (Modificar y Medir piden tocar puntos o piezas) ----------------

    /** Lo que se tocó: el sitio (mm), el punto que había ahí (o -1) y la pieza tocada (o -1). */
    public static class Toque {
        public double x, y;
        public int punto = -1, ent = -1;
    }

    public interface AlTerminar { void listo(List<Toque> t); }

    public static class Pedido {
        public String[] ayudas;          // una por cada toque
        public boolean[] quiereEnt;      // ese toque debe caer sobre una pieza
        public boolean[] quierePunto;    // ese toque debe caer sobre un punto que ya existe
        public boolean repetir;          // se queda pidiendo (recortar, partir…)
        public int fantasma;             // 0 nada · 1 mover lo escogido · 2 espejo de lo escogido
        public boolean linea = true;     // dibujar la línea desde el primer toque
        public boolean crudo;            // versión 4.2: usar el sitio del dedo, sin imán (extruir, área)
        public AlTerminar fin;

        public Pedido(AlTerminar fin, String... ayudas) {
            this.fin = fin;
            this.ayudas = ayudas;
            quiereEnt = new boolean[ayudas.length];
            quierePunto = new boolean[ayudas.length];
        }
    }

    public Pedido pedido;
    private final List<Toque> toques = new ArrayList<>();

    public void pedir(Pedido p) {
        ponerModo(PEDIDO);
        pedido = p;
        toques.clear();
        invalidate();
    }

    // ---------------- Estado ----------------

    public Boceto b = new Boceto();
    public Medidas medidas;
    public Oyente oyente;
    public int modo = VER;
    public final List<Integer> sel = new ArrayList<>();      // piezas escogidas (todas las que quiera)
    public final List<Integer> selPts = new ArrayList<>();   // puntos escogidos (hasta 2)
    public boolean orto = true;                              // v6.5: las líneas nacen derechas o paradas (paralelas o perpendiculares)
    public boolean marcas = true;                            // ver las marcas de los amarres
    public java.util.List<Integer> sueltas;                  // versión 4.4: puntas abiertas que encontró el doctor
    public int lados = 6;                                    // polígono
    public String medicion;                                  // resultado de Medir (se ve arriba)
    public double[] lineaMedida;                             // la línea que se midió (mm)

    private double esc = 0.1;          // píxeles por mm
    private float offX, offY;          // dónde queda el (0,0) en la pantalla
    private boolean listo;

    // lo que se va dibujando
    private final List<Integer> clic = new ArrayList<>();    // puntos ya puestos con la herramienta
    private double fx = Double.NaN, fy;                      // dónde está el imán (mm)
    private int cotaP1 = -1;
    private int cotaBorde = -1;   // v6.6: borde punteado escogido para amarrar algo a él
    private Iman primero;                                    // primer toque del rectángulo y del polígono

    // lupa y «Siguiente»
    private boolean lupa, enLupa;
    private float dedoX = -1, dedoY = -1;
    private final List<int[]> candidatos = new ArrayList<>();  // {0 punto | 1 pieza, id}
    private int candIdx;
    private final RectF rSiguiente = new RectF();

    private final Paint pLin = new Paint(Paint.ANTI_ALIAS_FLAG), pPto = new Paint(Paint.ANTI_ALIAS_FLAG),
            pCota = new Paint(Paint.ANTI_ALIAS_FLAG), pTxt = new Paint(Paint.ANTI_ALIAS_FLAG), pRej = new Paint(),
            pGlifo = new Paint(Paint.ANTI_ALIAS_FLAG), pFondo = new Paint(Paint.ANTI_ALIAS_FLAG), pIman = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Object[]> zonasCota = new ArrayList<>();   // {RectF, Restr} para tocar el número de una cota

    public VistaBoceto(Context c) {
        super(c);
        pLin.setStyle(Paint.Style.STROKE);
        pLin.setStrokeCap(Paint.Cap.ROUND);
        pCota.setStyle(Paint.Style.STROKE);
        pRej.setStrokeWidth(1);
        pGlifo.setFakeBoldText(true);
        pIman.setStyle(Paint.Style.STROKE);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    // ---------------- Pantalla ↔ mm ----------------

    private float sx(double x) { return (float) (offX + x * esc); }
    private float sy(double y) { return (float) (offY - y * esc); }
    private double mx(float x) { return (x - offX) / esc; }
    private double my(float y) { return (offY - y) / esc; }

    public void encuadrar() {
        if (getWidth() == 0) return;
        double[] c = b.caja();
        if (hayCalco()) {
            double[] k = calco.caja();
            if (b.vacio()) c = k;
            else c = new double[]{Math.min(c[0], k[0]), Math.min(c[1], k[1]), Math.max(c[2], k[2]), Math.max(c[3], k[3])};
        }
        double w = Math.max(500, c[2] - c[0]), h = Math.max(500, c[3] - c[1]);
        esc = Math.min(getWidth() * 0.86 / w, getHeight() * 0.76 / h);
        offX = (float) (getWidth() / 2.0 - (c[0] + c[2]) / 2 * esc);
        offY = (float) (getHeight() / 2.0 + dp(10) + (c[1] + c[3]) / 2 * esc);
        listo = true;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!listo || ow == 0) encuadrar();
    }

    public void ponerModo(int m) {
        cerrarPolilinea();
        polilinea = false;
        modo = m;
        if (m != PEDIDO) pedido = null;
        toques.clear();
        clic.clear();
        cotaP1 = -1;
        cotaBorde = -1;
        primero = null;
        fx = Double.NaN;
        candidatos.clear();
        if (m != VER && m != PEDIDO && m != CUADRO) { sel.clear(); selPts.clear(); }
        invalidate();
    }

    /** Termina la línea o el pedido que se venía haciendo. */
    /** v6.6: Polilínea = líneas seguidas; al terminar se cierra sola contra la primera punta. */
    public boolean polilinea;

    private void cerrarPolilinea() {
        if (modo == LINEA && polilinea && clic.size() >= 3) {
            int ini = clic.get(0), fin = clic.get(clic.size() - 1);
            if (ini != fin) lineaNueva(fin, ini);
        }
    }

    public void terminar() {
        cerrarPolilinea();
        clic.clear();
        toques.clear();
        cotaP1 = -1;
        cotaBorde = -1;
        primero = null;
        fx = Double.NaN;
        invalidate();
    }

    public void limpiarSeleccion() {
        sel.clear();
        selPts.clear();
        candidatos.clear();
        invalidate();
    }

    /** Si hay un primer punto puesto (para escribir la medida abajo). */
    public boolean hayInicio() {
        if (modo == LINEA) return !clic.isEmpty();
        if (modo == RECT || modo == POLIGONO) return primero != null;
        if (modo == CIRCULO) return !clic.isEmpty();
        return false;
    }

    // ---------------- Buscar cerca del dedo ----------------

    private int puntoCerca(float x, float y, float radio, int excluir) {
        int mejor = -1;
        float d = radio;
        for (Boceto.Punto p : b.puntos.values()) {
            if (p.id == excluir) continue;
            float dd = (float) Math.hypot(sx(p.x) - x, sy(p.y) - y);
            if (dd < d) { d = dd; mejor = p.id; }
        }
        return mejor;
    }

    private int puntoCerca(float x, float y, float radio) { return puntoCerca(x, y, radio, -1); }

    /** Distancia en pantalla del dedo a una entidad. */
    private float distA(Boceto.Ent e, float x, float y) {
        Boceto.Punto a = b.puntos.get(e.a);
        if (a == null) return Float.MAX_VALUE;
        switch (e.tipo) {
            case Boceto.LINEA: {
                Boceto.Punto q = b.puntos.get(e.b);
                if (q == null) return Float.MAX_VALUE;
                float ax = sx(a.x), ay = sy(a.y), bx = sx(q.x), by = sy(q.y);
                float vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy;
                float t = l2 < 1 ? 0 : Math.max(0, Math.min(1, ((x - ax) * vx + (y - ay) * vy) / l2));
                return (float) Math.hypot(x - (ax + vx * t), y - (ay + vy * t));
            }
            case Boceto.CIRCULO:
                return (float) Math.abs(Math.hypot(x - sx(a.x), y - sy(a.y)) - e.r * esc);
            case Boceto.ARCO: {
                float d = (float) Math.abs(Math.hypot(x - sx(a.x), y - sy(a.y)) - e.r * esc);
                if (!Editar2D.enArcoEnt(b, e, mx(x), my(y))) d += dp(30);
                return d;
            }
            case Boceto.TEXTO:
                return (float) Math.hypot(x - sx(a.x), y - sy(a.y));
        }
        return Float.MAX_VALUE;
    }

    private Boceto.Ent entCerca(float x, float y) {
        Boceto.Ent mejor = null;
        float d = dp(26);
        for (Boceto.Ent e : b.ents) {
            float dd = distA(e, x, y);
            if (dd < d) { d = dd; mejor = e; }
        }
        return mejor;
    }

    // ---------------- Imanes ----------------

    public static final int I_REJILLA = 0, I_EXTREMO = 1, I_MEDIO = 2, I_CENTRO = 3, I_CRUCE = 4, I_PERP = 5, I_TANG = 6, I_CERCA = 7, I_ORIGEN = 8, I_CALCO = 9;
    private static final String[] NOM_IMAN = {"", "Extremo", "Mitad", "Centro", "Cruce", "90°", "Tangente", "Sobre la línea", "Origen 0,0", "Punto del calco DXF"};

    /** Versión 5: el plano DXF de referencia (calco), en gris; sus puntas y mitades son imanes. */
    public Boceto calco;
    public boolean verCalco = true;

    private boolean hayCalco() { return calco != null && verCalco && !calco.vacio(); }

    /** Imán en el calco: una punta, un centro o la mitad de una línea. */
    private Iman imanCalco(float x, float y) {
        if (!hayCalco()) return null;
        Iman im = null;
        float lim = dp(22);
        for (Boceto.Punto p : calco.puntos.values()) {
            float d = (float) Math.hypot(sx(p.x) - x, sy(p.y) - y);
            if (d < lim) { lim = d; im = new Iman(); im.x = p.x; im.y = p.y; im.tipo = I_CALCO; }
        }
        if (im != null) return im;
        lim = dp(18);
        for (Boceto.Ent e : calco.ents) {
            if (e.tipo != Boceto.LINEA) continue;
            Boceto.Punto a = calco.puntos.get(e.a), q = calco.puntos.get(e.b);
            if (a == null || q == null) continue;
            double mx0 = (a.x + q.x) / 2, my0 = (a.y + q.y) / 2;
            float d = (float) Math.hypot(sx(mx0) - x, sy(my0) - y);
            if (d < lim) { lim = d; im = new Iman(); im.x = mx0; im.y = my0; im.tipo = I_CALCO; }
        }
        return im;
    }

    private void dibujarCalco(Canvas c) {
        if (!hayCalco()) return;
        Paint pc = new Paint(Paint.ANTI_ALIAS_FLAG);
        pc.setStyle(Paint.Style.STROKE);
        pc.setStrokeWidth(dp(1.2f));
        pc.setColor(0xFF78909C);
        pc.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(6), dp(4)}, 0));
        for (Boceto.Ent e : calco.ents) {
            Boceto.Punto a = calco.puntos.get(e.a);
            if (a == null) continue;
            if (e.tipo == Boceto.LINEA) {
                Boceto.Punto q = calco.puntos.get(e.b);
                if (q != null) c.drawLine(sx(a.x), sy(a.y), sx(q.x), sy(q.y), pc);
            } else if (e.tipo == Boceto.CIRCULO) {
                c.drawCircle(sx(a.x), sy(a.y), (float) (e.r * esc), pc);
            } else if (e.tipo == Boceto.ARCO) {
                Boceto.Punto p1 = calco.puntos.get(e.b), p2 = calco.puntos.get(e.c);
                if (p1 == null || p2 == null) continue;
                double a1 = Math.atan2(p1.y - a.y, p1.x - a.x), a2 = Math.atan2(p2.y - a.y, p2.x - a.x), barrido = a2 - a1;
                while (barrido <= 0) barrido += 2 * Math.PI;
                float r = (float) (e.r * esc);
                RectF ov = new RectF(sx(a.x) - r, sy(a.y) - r, sx(a.x) + r, sy(a.y) + r);
                c.drawArc(ov, (float) -Math.toDegrees(a1), (float) -Math.toDegrees(barrido), false, pc);
            }
        }
    }

    private static class Iman {
        double x, y;
        int tipo, punto = -1, e1 = -1, e2 = -1;
    }

    private Iman iman;

    /** Paso de la rejilla para redondear (mm), según qué tan cerca se ve. */
    private double pasoRedondeo() {
        if (esc > 3) return 1;
        if (esc > 0.6) return 5;
        return 10;
    }

    /** El punto de donde sale la línea que se está dibujando (para 90°, tangente y orto). */
    private double[] previo() {
        if ((modo == LINEA) && !clic.isEmpty()) {
            Boceto.Punto p = b.puntos.get(clic.get(clic.size() - 1));
            if (p != null) return new double[]{p.x, p.y};
        }
        if (modo == PEDIDO && pedido != null && pedido.linea && !toques.isEmpty()) return new double[]{toques.get(0).x, toques.get(0).y};
        if ((modo == RECT || modo == POLIGONO) && primero != null) return new double[]{primero.x, primero.y};
        return null;
    }

    private Iman buscarIman(float x, float y, int excluir) {
        Iman im = new Iman();
        double[] pre = previo();
        // 1. un punto que ya existe (extremo o centro)
        int k = puntoCerca(x, y, dp(22), excluir);
        if (k >= 0) {
            Boceto.Punto p = b.puntos.get(k);
            im.x = p.x; im.y = p.y; im.punto = k; im.tipo = I_EXTREMO;
            for (Boceto.Ent e : b.ents) if ((e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) && e.a == k) im.tipo = I_CENTRO;
            return im;
        }
        // versión 4.2: el punto 0,0 (origen) también es imán
        if (Math.hypot(sx(0) - x, sy(0) - y) < dp(20)) {
            im.x = 0; im.y = 0; im.tipo = I_ORIGEN;
            return im;
        }
        // versión 5: las puntas y mitades del calco DXF
        Iman ic = imanCalco(x, y);
        if (ic != null) return ic;
        // las piezas cerca del dedo
        List<Boceto.Ent> cerca = new ArrayList<>();
        for (Boceto.Ent e : b.ents) {
            if (e.tipo == Boceto.TEXTO) continue;
            if (excluir >= 0 && Editar2D.puntosDe(e).contains(excluir)) continue;
            if (distA(e, x, y) < dp(44)) cerca.add(e);
        }
        float lim = dp(20);
        // 2. la mitad de una línea
        for (Boceto.Ent e : cerca) {
            if (e.tipo != Boceto.LINEA) continue;
            Boceto.Punto a = b.puntos.get(e.a), q = b.puntos.get(e.b);
            double mx0 = (a.x + q.x) / 2, my0 = (a.y + q.y) / 2;
            float d = (float) Math.hypot(sx(mx0) - x, sy(my0) - y);
            if (d < lim) { lim = d; im.x = mx0; im.y = my0; im.tipo = I_MEDIO; im.e1 = e.id; }
        }
        if (im.tipo != I_REJILLA) return im;
        // 3. donde se cruzan dos piezas
        lim = dp(20);
        for (int i = 0; i < cerca.size(); i++) for (int j = i + 1; j < cerca.size(); j++) {
            for (double[] c : Editar2D.cruces(b, cerca.get(i), cerca.get(j))) {
                float d = (float) Math.hypot(sx(c[0]) - x, sy(c[1]) - y);
                if (d < lim) { lim = d; im.x = c[0]; im.y = c[1]; im.tipo = I_CRUCE; im.e1 = cerca.get(i).id; im.e2 = cerca.get(j).id; }
            }
        }
        if (im.tipo != I_REJILLA) return im;
        // 4. a 90° o tangente desde el punto anterior
        if (pre != null) {
            lim = dp(20);
            for (Boceto.Ent e : cerca) {
                Boceto.Punto a = b.puntos.get(e.a);
                if (e.tipo == Boceto.LINEA) {
                    Boceto.Punto q = b.puntos.get(e.b);
                    double dx = q.x - a.x, dy = q.y - a.y, l2 = dx * dx + dy * dy;
                    if (l2 < 1e-9) continue;
                    double t = ((pre[0] - a.x) * dx + (pre[1] - a.y) * dy) / l2;
                    if (t < 0 || t > 1) continue;
                    double px = a.x + dx * t, py = a.y + dy * t;
                    if (Math.hypot(px - pre[0], py - pre[1]) < 1) continue;
                    float d = (float) Math.hypot(sx(px) - x, sy(py) - y);
                    if (d < lim) { lim = d; im.x = px; im.y = py; im.tipo = I_PERP; im.e1 = e.id; }
                } else {
                    double dx = pre[0] - a.x, dy = pre[1] - a.y, dd = Math.hypot(dx, dy);
                    if (dd <= e.r + 1e-6) continue;
                    double th = Math.atan2(dy, dx), al = Math.acos(e.r / dd);
                    for (double s : new double[]{th + al, th - al}) {
                        double px = a.x + e.r * Math.cos(s), py = a.y + e.r * Math.sin(s);
                        if (e.tipo == Boceto.ARCO && !Editar2D.enArcoEnt(b, e, px, py)) continue;
                        float d = (float) Math.hypot(sx(px) - x, sy(py) - y);
                        if (d < lim) { lim = d; im.x = px; im.y = py; im.tipo = I_TANG; im.e1 = e.id; }
                    }
                }
            }
            if (im.tipo != I_REJILLA) return im;
        }
        // 5. sobre una pieza
        lim = dp(12);
        for (Boceto.Ent e : cerca) {
            float d = distA(e, x, y);
            if (d >= lim) continue;
            Boceto.Punto a = b.puntos.get(e.a);
            double fx0 = mx(x), fy0 = my(y);
            if (e.tipo == Boceto.LINEA) {
                Boceto.Punto q = b.puntos.get(e.b);
                double dx = q.x - a.x, dy = q.y - a.y, l2 = dx * dx + dy * dy;
                if (l2 < 1e-9) continue;
                double t = Math.max(0, Math.min(1, ((fx0 - a.x) * dx + (fy0 - a.y) * dy) / l2));
                im.x = a.x + dx * t; im.y = a.y + dy * t;
            } else {
                double an = Math.atan2(fy0 - a.y, fx0 - a.x);
                im.x = a.x + e.r * Math.cos(an); im.y = a.y + e.r * Math.sin(an);
            }
            lim = d; im.tipo = I_CERCA; im.e1 = e.id;
        }
        if (im.tipo != I_REJILLA) return im;
        // 6. la rejilla (y orto: derecho o parado)
        double g = pasoRedondeo();
        im.x = Math.round(mx(x) / g) * g;
        im.y = Math.round(my(y) / g) * g;
        if (orto && pre != null) {
            if (Math.abs(im.x - pre[0]) >= Math.abs(im.y - pre[1])) im.y = pre[1]; else im.x = pre[0];
        }
        return im;
    }

    /** Pone el punto donde está el imán: si ya hay uno, usa ese; si cae en la mitad o sobre una pieza, queda amarrado ahí. */
    private int ponerPunto(Iman im) {
        if (im.punto >= 0 && b.puntos.containsKey(im.punto)) return im.punto;
        Boceto.Punto p = b.punto(im.x, im.y);
        switch (im.tipo) {
            case I_MEDIO: b.restriccion(Boceto.MEDIO, im.e1, -1, p.id, -1, null); break;
            case I_CRUCE:
                if (b.entPorId(im.e1).tipo != Boceto.TEXTO) b.restriccion(Boceto.SOBRE, im.e1, -1, p.id, -1, null);
                if (b.entPorId(im.e2).tipo != Boceto.TEXTO) b.restriccion(Boceto.SOBRE, im.e2, -1, p.id, -1, null);
                break;
            case I_PERP: case I_TANG: case I_CERCA: b.restriccion(Boceto.SOBRE, im.e1, -1, p.id, -1, null); break;
            case I_ORIGEN: b.restriccion(Boceto.FIJO, -1, -1, p.id, -1, null); break;   // pegado al 0,0: no se mueve
        }
        return p.id;
    }

    /** Línea nueva: si quedó casi horizontal o casi vertical, se amarra así (como Inventor). */
    private Boceto.Ent lineaNueva(int a, int c) {
        if (a == c) return null;
        Boceto.Punto p = b.puntos.get(a), q = b.puntos.get(c);
        Boceto.Ent e = b.linea(p, q);
        double ang = Math.toDegrees(Math.atan2(q.y - p.y, q.x - p.x));
        double m = Math.abs(((ang % 180) + 180) % 180);
        if (m < 2 || m > 178) { q.y = p.y; b.restriccion(Boceto.HORIZ, e.id, -1, -1, -1, null); }
        else if (Math.abs(m - 90) < 2) { q.x = p.x; b.restriccion(Boceto.VERT, e.id, -1, -1, -1, null); }
        return e;
    }

    // ---------------- Dedos ----------------

    private float x0, y0, ax, ay, d0, mx0, my0, ox0, oy0;
    private double esc0;
    private boolean dos, movio;
    private int arrastre = -1;

    private boolean usaIman() { return dibujando() || modo == PEDIDO || (modo == MOVER && arrastre >= 0); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = ax = e.getX(); y0 = ay = e.getY();
                dedoX = x0; dedoY = y0;
                dos = false; movio = false;
                arrastre = -1;
                lupa = !rSiguiente.contains(x0, y0) || candidatos.size() < 2;
                if (modo == MOVER) {
                    arrastre = puntoCerca(x0, y0, dp(30));
                    if (arrastre >= 0 && oyente != null) oyente.antes();
                }
                if (usaIman()) { iman = buscarIman(x0, y0, arrastre); fx = iman.x; fy = iman.y; }
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dos = true;
                    lupa = false;
                    fx = Double.NaN;
                    d0 = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    esc0 = esc; ox0 = offX; oy0 = offY;
                    mx0 = (e.getX(0) + e.getX(1)) / 2; my0 = (e.getY(0) + e.getY(1)) / 2;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dos && e.getPointerCount() >= 2) {
                    float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    float cx = (e.getX(0) + e.getX(1)) / 2, cy = (e.getY(0) + e.getY(1)) / 2;
                    double f = d0 > 0 ? d / d0 : 1;
                    double nuevo = Math.max(0.002, Math.min(50, esc0 * f));
                    f = nuevo / esc0;
                    esc = nuevo;
                    // el punto que estaba entre los dedos sigue entre los dedos
                    offX = (float) (cx - (mx0 - ox0) * f);
                    offY = (float) (cy - (my0 - oy0) * f);
                    invalidate();
                    return true;
                }
                if (dos) return true;
                dedoX = e.getX(); dedoY = e.getY();
                if (Math.hypot(e.getX() - x0, e.getY() - y0) > dp(8)) movio = true;
                if (modo == MOVER && arrastre >= 0) {
                    Boceto.Punto p = b.puntos.get(arrastre);
                    if (p != null) {
                        iman = buscarIman(e.getX(), e.getY(), arrastre);
                        p.x = iman.x;
                        p.y = iman.y;
                        fx = iman.x; fy = iman.y;
                        b.resolver(medidas, arrastre);
                    }
                } else if (usaIman()) {
                    iman = buscarIman(e.getX(), e.getY(), -1);
                    fx = iman.x; fy = iman.y;
                } else if (modo == CUADRO) {
                    lupa = false;   // versión 6.1: el cuadro se dibuja en onDraw
                } else if (movio) {
                    lupa = false;
                    offX += e.getX() - ax;
                    offY += e.getY() - ay;
                }
                invalidate();
                ax = e.getX(); ay = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                lupa = false;
                dedoX = -1;
                if (dos || e.getActionMasked() == MotionEvent.ACTION_CANCEL) { invalidate(); return true; }
                if (modo == MOVER && arrastre >= 0) {
                    if (iman != null && iman.punto >= 0 && iman.punto != arrastre) b.unirPuntos(iman.punto, arrastre);
                    b.resolver(medidas, -1);
                    arrastre = -1;
                    fx = Double.NaN;
                    if (oyente != null) oyente.cambio();
                    invalidate();
                    return true;
                }
                if (modo == PEDIDO && pedido != null && iman != null) { tocarPedido(iman, e.getX(), e.getY()); return true; }
                if (dibujando() && iman != null) { soltar(iman, e.getX(), e.getY()); return true; }
                if (modo == CUADRO && movio) { escogerCuadro(x0, y0, e.getX(), e.getY()); invalidate(); return true; }
                if (!movio) tocar(e.getX(), e.getY());
                invalidate();
                return true;
        }
        return true;
    }

    private boolean dibujando() { return (modo >= LINEA && modo <= COTA) || modo == POLIGONO; }

    /** El dedo se soltó con una herramienta de dibujo. */
    private void soltar(Iman im, float x, float y) {
        fx = Double.NaN;
        switch (modo) {
            case LINEA: {
                if (oyente != null) oyente.antes();
                boolean eraVacioL = b.vacio() && clic.isEmpty();
                int k = ponerPunto(im);
                anclar(k, eraVacioL);
                if (!clic.isEmpty()) {
                    int ult = clic.get(clic.size() - 1);
                    if (k == ult) { invalidate(); return; }
                    Boceto.Ent ln = lineaNueva(ult, k);
                    if (ln != null && im.tipo == I_PERP) b.restriccion(Boceto.PERP, ln.id, im.e1, -1, -1, null);
                    if (ln != null && im.tipo == I_TANG) b.restriccion(Boceto.TANG, ln.id, im.e1, -1, -1, null);
                    if (k == clic.get(0)) { clic.clear(); listoCambio(); return; }   // cerró la figura
                }
                clic.add(k);
                listoCambio();
                return;
            }
            case RECT: {
                if (primero == null) { primero = im; invalidate(); return; }
                if (oyente != null) oyente.antes();
                Iman a = primero;
                primero = null;
                if (Math.abs(im.x - a.x) < 1 || Math.abs(im.y - a.y) < 1) { invalidate(); return; }
                hacerRect(a, im, null, null);
                listoCambio();
                return;
            }
            case CIRCULO: {
                if (clic.isEmpty()) { if (oyente != null) oyente.antes(); clic.add(ponerPunto(im)); invalidate(); return; }
                Boceto.Punto c = b.puntos.get(clic.get(0));
                clic.clear();
                double r = Math.hypot(im.x - c.x, im.y - c.y);
                if (im.tipo == I_REJILLA) r = Math.max(pasoRedondeo(), Math.round(r / pasoRedondeo()) * pasoRedondeo());
                if (r < 0.5) { b.limpiarPuntos(); invalidate(); return; }
                boolean eraVacioC = b.vacio();
                Boceto.Ent e = b.ent(Boceto.CIRCULO);
                e.a = c.id; e.r = r;
                anclar(c.id, eraVacioC);
                if (im.tipo == I_TANG || im.tipo == I_CERCA || im.tipo == I_EXTREMO) {
                    // el borde pasa por ese punto
                    int p = ponerPunto(im);
                    b.restriccion(Boceto.SOBRE, e.id, -1, p, -1, null);
                }
                listoCambio();
                return;
            }
            case ARCO: {
                if (clic.isEmpty()) { if (oyente != null) oyente.antes(); clic.add(ponerPunto(im)); invalidate(); return; }
                if (clic.size() == 1) { clic.add(ponerPunto(im)); invalidate(); return; }
                Boceto.Punto c = b.puntos.get(clic.get(0)), p1 = b.puntos.get(clic.get(1));
                double r = Math.hypot(p1.x - c.x, p1.y - c.y);
                double an = Math.atan2(im.y - c.y, im.x - c.x);
                Boceto.Punto p2 = im.punto >= 0 ? b.puntos.get(im.punto) : b.punto(c.x + r * Math.cos(an), c.y + r * Math.sin(an));
                clic.clear();
                if (r < 0.5 || p2.id == p1.id) { b.limpiarPuntos(); invalidate(); return; }
                Boceto.Ent e = b.ent(Boceto.ARCO);
                e.a = c.id; e.b = p1.id; e.c = p2.id; e.r = r;
                b.resolver(medidas, -1);
                listoCambio();
                return;
            }
            case POLIGONO: {
                if (primero == null) { primero = im; invalidate(); return; }
                if (oyente != null) oyente.antes();
                Iman c = primero;
                primero = null;
                double r = Math.hypot(im.x - c.x, im.y - c.y);
                if (r < 1) { invalidate(); return; }
                hacerPoligono(c, r, Math.atan2(im.y - c.y, im.x - c.x));
                listoCambio();
                return;
            }
            case TEXTO:
                if (oyente != null) oyente.pedirTexto(im.x, im.y);
                return;
            case COTA: {
                int k = im.punto;
                // v6.6: si antes tocó un borde de la cara (punteado), lo que toque ahora queda acotado a ese borde
                if (cotaBorde >= 0) {
                    Boceto.Ent bo = b.entPorId(cotaBorde);
                    cotaBorde = -1;
                    Boceto.Ent e2 = k >= 0 ? null : entCerca(x, y);
                    int pt = k;
                    if (pt < 0 && e2 != null && (e2.tipo == Boceto.CIRCULO || e2.tipo == Boceto.ARCO)) pt = e2.a;
                    if (bo != null && (pt >= 0 || e2 != null && e2.tipo == Boceto.LINEA && e2 != bo)) {
                        Boceto.Restr r = new Boceto.Restr();
                        r.tipo = Boceto.C_PL;
                        if (pt >= 0) { r.e1 = bo.id; r.p1 = pt; }
                        else {   // línea con línea: la distancia entre las dos, del borde quieto a la que se mueve
                            r.e1 = e2.id; r.p1 = bo.a;
                            boolean hv = false;
                            for (Boceto.Restr q : b.restr) if ((q.tipo == Boceto.HORIZ || q.tipo == Boceto.VERT || q.tipo == Boceto.PARAL) && (q.e1 == e2.id || q.e2 == e2.id)) hv = true;
                            if (!hv) b.restriccion(Boceto.PARAL, e2.id, bo.id, -1, -1, null);
                        }
                        invalidate();
                        if (oyente != null) oyente.pedirCota(r);
                        return;
                    }
                    invalidate();
                    if (oyente != null) oyente.aviso("Toque el borde punteado y después la línea, el punto o el círculo que va amarrado a él");
                    return;
                }
                if (k < 0) {
                    Boceto.Ent e0 = entCerca(x, y);
                    if (e0 != null && e0.tipo == Boceto.LINEA && e0.punteada) {
                        cotaBorde = e0.id;
                        cotaP1 = -1;
                        invalidate();
                        if (oyente != null) oyente.aviso("Borde escogido. Ahora toque la línea, el punto o el círculo que va amarrado a este borde");
                        return;
                    }
                }
                if (k >= 0) {
                    if (cotaP1 < 0) { cotaP1 = k; invalidate(); if (oyente != null) oyente.aviso("Ahora toque el otro punto"); return; }
                    if (k != cotaP1) { int p1 = cotaP1; cotaP1 = -1; invalidate(); if (oyente != null) oyente.pedirDistancia(p1, k); return; }
                }
                cotaP1 = -1;
                Boceto.Ent e = entCerca(x, y);
                if (e == null) { invalidate(); return; }
                Boceto.Restr r = new Boceto.Restr();
                r.e1 = e.id;
                if (e.tipo == Boceto.LINEA) r.tipo = Boceto.C_LARGO;
                else if (e.tipo == Boceto.CIRCULO) r.tipo = Boceto.C_DIAM;
                else if (e.tipo == Boceto.ARCO) r.tipo = Boceto.C_RADIO;
                else { invalidate(); return; }
                invalidate();
                if (oyente != null) oyente.pedirCota(r);
                return;
            }
        }
    }

    /** Rectángulo de la esquina a hasta la esquina c. Si vienen fórmulas, pone las cotas de ancho y alto. */
    /** Versión 6.2: la primera figura del boceto queda amarrada (📌) para que no salga "faltan 2 medidas". */
    public boolean anclarAuto = true;

    private void anclar(int pid, boolean eraVacio) {
        if (true) return;   // v6.3: ya no se clava solo; la figura se lleva al 0,0 con ⊕ Al 0,0
        if (!anclarAuto || !eraVacio || pid < 0) return;
        for (Boceto.Restr r : b.restr) if (r.tipo == Boceto.FIJO) return;
        for (Boceto.Punto q : b.puntos.values()) if (q.fijo) return;
        b.restriccion(Boceto.FIJO, -1, -1, pid, -1, null);
    }

    private void hacerRect(Iman a, Iman c, String fAncho, String fAlto) {
        boolean eraVacio = b.vacio();
        int ia = ponerPunto(a);
        anclar(ia, eraVacio);
        Boceto.Punto pa = b.puntos.get(ia);
        Boceto.Punto q = b.punto(c.x, pa.y);
        int ic = ponerPunto(c);
        Boceto.Punto pc = b.puntos.get(ic);
        Boceto.Punto d = b.punto(pa.x, pc.y);
        Boceto.Ent ab = b.linea(pa, q), bc = b.linea(q, pc), cd = b.linea(pc, d), da = b.linea(d, pa);
        b.restriccion(Boceto.HORIZ, ab.id, -1, -1, -1, null);
        b.restriccion(Boceto.HORIZ, cd.id, -1, -1, -1, null);
        b.restriccion(Boceto.VERT, bc.id, -1, -1, -1, null);
        b.restriccion(Boceto.VERT, da.id, -1, -1, -1, null);
        if (fAncho != null) b.restriccion(Boceto.C_LARGO, ab.id, -1, -1, -1, fAncho);
        if (fAlto != null) b.restriccion(Boceto.C_LARGO, da.id, -1, -1, -1, fAlto);
    }

    private void hacerPoligono(Iman c, double r, double ang0) {
        int n = Math.max(3, Math.min(60, lados));
        int[] ids = new int[n];
        for (int i = 0; i < n; i++) {
            double a = ang0 + 2 * Math.PI * i / n;
            ids[i] = b.punto(c.x + r * Math.cos(a), c.y + r * Math.sin(a)).id;
        }
        Boceto.Ent primera = null;
        for (int i = 0; i < n; i++) {
            Boceto.Ent e = b.linea(b.puntos.get(ids[i]), b.puntos.get(ids[(i + 1) % n]));
            if (primera == null) primera = e;
            else b.restriccion(Boceto.IGUAL, primera.id, e.id, -1, -1, null);
        }
    }

    // ---------------- Medidas escritas en la casilla de abajo ----------------

    /** Línea desde el último punto con el largo (fórmula y valor) y el ángulo (grados, 0 = a la derecha). */
    public String lineaPorMedida(String fLargo, double largo, double ang) {
        if (modo != LINEA || clic.isEmpty()) return "Primero toque dónde empieza la línea";
        if (largo <= 0) return "El largo debe ser mayor que cero";
        int ult = clic.get(clic.size() - 1);
        Boceto.Punto p = b.puntos.get(ult);
        double a = Math.toRadians(ang);
        Boceto.Punto q = b.punto(p.x + largo * Math.cos(a), p.y + largo * Math.sin(a));
        Boceto.Ent e = lineaNueva(ult, q.id);
        if (e != null) b.restriccion(Boceto.C_LARGO, e.id, -1, -1, -1, fLargo);
        clic.add(q.id);
        invalidate();
        return null;
    }

    /** v6.3: dónde arranca una figura escrita con medidas sin tocar la hoja: en el 0,0 si la hoja está vacía, si no en el centro de la pantalla. */
    private Iman puntoInicial() {
        Iman im = new Iman();
        if (b.vacio()) { im.x = 0; im.y = 0; im.tipo = I_ORIGEN; }
        else {
            im.x = Math.round((getWidth() / 2f - offX) / esc);
            im.y = Math.round((offY - getHeight() / 2f) / esc);
            im.tipo = I_REJILLA;
        }
        return im;
    }

    /** Rectángulo desde la primera esquina: ancho hacia la derecha y alto hacia arriba. */
    public String rectPorMedida(String fAncho, double ancho, String fAlto, double alto) {
        if (modo != RECT) return "Escoja ▭ Rectáng.";
        if (ancho <= 0 || alto <= 0) return "El ancho y el alto deben ser mayores que cero";
        boolean centrado = primero == null;
        if (centrado) {   // v6.5: con OK sale en el centro de lo que se está viendo (no en el 0,0)
            primero = new Iman();
            primero.x = Math.round((getWidth() / 2f - offX) / esc - ancho / 2);
            primero.y = Math.round((offY - getHeight() / 2f) / esc - alto / 2);
            primero.tipo = I_REJILLA;
        }
        Iman c = new Iman();
        c.x = primero.x + ancho; c.y = primero.y + alto;
        Iman a = primero;
        primero = null;
        hacerRect(a, c, fAncho, fAlto);
        // si no cabe en la pantalla, la pantalla se aleja sola
        if (centrado && (ancho * esc > getWidth() * 0.9 || alto * esc > getHeight() * 0.85)) encuadrar();
        invalidate();
        return null;
    }

    public String circuloPorMedida(String fDiam, double diam) {
        if (modo != CIRCULO) return "Escoja ◯ Círculo";
        if (diam <= 0) return "El diámetro debe ser mayor que cero";
        if (clic.isEmpty()) {   // v6.5: con OK sale en el centro de la pantalla
            Iman m = new Iman();
            m.x = Math.round((getWidth() / 2f - offX) / esc); m.y = Math.round((offY - getHeight() / 2f) / esc); m.tipo = I_REJILLA;
            clic.add(ponerPunto(m));
        }
        boolean eraVacioC = b.vacio();
        Boceto.Ent e = b.ent(Boceto.CIRCULO);
        e.a = clic.get(0); e.r = diam / 2;
        anclar(e.a, eraVacioC);
        clic.clear();
        b.restriccion(Boceto.C_DIAM, e.id, -1, -1, -1, fDiam);
        invalidate();
        return null;
    }

    public String poligonoPorMedida(int n, double radio) {
        if (modo != POLIGONO || primero == null) return "Primero toque dónde va el centro";
        if (radio <= 0) return "El radio debe ser mayor que cero";
        lados = n;
        Iman c = primero;
        primero = null;
        hacerPoligono(c, radio, Math.PI / 2);
        invalidate();
        return null;
    }

    // ---------------- Pedidos ----------------

    private void tocarPedido(Iman im, float x, float y) {
        Pedido p = pedido;
        int paso = toques.size();
        if (paso >= p.ayudas.length) return;
        Toque t = new Toque();
        t.x = im.x; t.y = im.y; t.punto = im.punto;
        if (p.crudo) { t.x = mx(x); t.y = my(y); t.punto = -1; }
        if (p.quiereEnt[paso]) {
            Boceto.Ent e = entCerca(x, y);
            if (e == null) { if (oyente != null) oyente.aviso("Toque encima de una línea, círculo o arco"); invalidate(); return; }
            t.ent = e.id;
            if (im.tipo == I_REJILLA) { t.x = mx(x); t.y = my(y); }
        }
        if (p.quierePunto[paso] && t.punto < 0) { if (oyente != null) oyente.aviso("Toque un punto (una esquina)"); invalidate(); return; }
        toques.add(t);
        fx = Double.NaN;
        if (toques.size() < p.ayudas.length) { invalidate(); return; }
        List<Toque> listos = new ArrayList<>(toques);
        toques.clear();
        if (!p.repetir) { pedido = null; modo = VER; }
        p.fin.listo(listos);
        invalidate();
    }

    // ---------------- Escoger ----------------

    /** Tocar con «Ver»: el número de una cota se edita; un punto o una pieza se escoge. */
    private void tocar(float x, float y) {
        if (candidatos.size() > 1 && rSiguiente.contains(x, y)) { siguiente(); return; }
        for (Object[] z : zonasCota) {
            RectF r = (RectF) z[0];
            if (r.contains(x, y) || (Math.abs(r.centerX() - x) < r.width() / 2 + dp(10) && Math.abs(r.centerY() - y) < r.height() / 2 + dp(10))) {
                if (oyente != null) oyente.editarCota((Boceto.Restr) z[1]);
                return;
            }
        }
        if (modo != VER) return;
        candidatos.clear();
        List<float[]> l = new ArrayList<>();   // {distancia, tipo, id}
        for (Boceto.Punto p : b.puntos.values()) {
            float d = (float) Math.hypot(sx(p.x) - x, sy(p.y) - y);
            if (d < dp(16)) l.add(new float[]{d - dp(6), 0, p.id});
        }
        for (Boceto.Ent e : b.ents) {
            float d = distA(e, x, y);
            if (d < dp(26)) l.add(new float[]{d, 1, e.id});
        }
        l.sort((m, n) -> Float.compare(m[0], n[0]));
        for (float[] k : l) candidatos.add(new int[]{(int) k[1], (int) k[2]});
        candIdx = 0;
        if (candidatos.isEmpty()) { sel.clear(); selPts.clear(); }
        else alternar(candidatos.get(0));
        invalidate();
        if (oyente != null) oyente.seleccion();
    }

    private void alternar(int[] c) {
        if (c[0] == 0) {
            Integer id = c[1];
            if (selPts.contains(id)) selPts.remove(id);
            else { selPts.add(id); if (selPts.size() > 2) selPts.remove(0); }
        } else {
            Integer id = c[1];
            if (sel.contains(id)) sel.remove(id); else sel.add(id);
        }
    }

    /** «Siguiente»: quita lo que se escogió y escoge lo que estaba debajo. */
    private void siguiente() {
        alternar(candidatos.get(candIdx));
        candIdx = (candIdx + 1) % candidatos.size();
        alternar(candidatos.get(candIdx));
        invalidate();
        if (oyente != null) oyente.seleccion();
    }

    // ---------------- Dibujo ----------------

    private void listoCambio() {
        invalidate();
        if (oyente != null) oyente.cambio();
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(Tema.fondo());
        zonasCota.clear();
        contenido(c);
        // la ayuda de la herramienta
        pTxt.setTextSize(dp(12.5f));
        pTxt.setColor(Tema.negro ? 0xFFB0BEC5 : 0xFF37474F);
        pTxt.setFakeBoldText(false);
        String ayuda = modo == PEDIDO && pedido != null ? pedido.ayudas[Math.min(toques.size(), pedido.ayudas.length - 1)] : AYUDA[modo];
        if (orto && (modo == LINEA || modo == PEDIDO)) ayuda += "  (Orto: solo derecho o parado)";
        float yAyuda = dibujarTextoLargo(c, ayuda, dp(8), dp(16), getWidth() - dp(16));
        // lo que se midió
        if (medicion != null) {
            pTxt.setTextSize(dp(14));
            pTxt.setFakeBoldText(true);
            float w = Math.min(getWidth() - dp(16), pTxt.measureText(medicion) + dp(16));
            pFondo.setColor(0xF2FFF3E0);
            c.drawRoundRect(dp(8), yAyuda + dp(6), dp(8) + w, yAyuda + dp(32), dp(6), dp(6), pFondo);
            pTxt.setColor(Color.BLACK);
            dibujarTextoLargo(c, medicion, dp(16), yAyuda + dp(24), w - dp(12));
        }
        // «Siguiente» cuando hay varias cosas juntas
        if (candidatos.size() > 1 && modo == VER) {
            String s = "▶ Siguiente (" + (candIdx + 1) + " de " + candidatos.size() + ")";
            pTxt.setTextSize(dp(15));
            pTxt.setFakeBoldText(true);
            float w = pTxt.measureText(s) + dp(28);
            rSiguiente.left = getWidth() / 2f - w / 2; rSiguiente.right = getWidth() / 2f + w / 2;
            rSiguiente.top = getHeight() - dp(52); rSiguiente.bottom = getHeight() - dp(10);
            pFondo.setColor(0xFF5E35B1);
            c.drawRoundRect(rSiguiente, dp(10), dp(10), pFondo);
            pTxt.setColor(Color.WHITE);
            c.drawText(s, rSiguiente.left + dp(14), rSiguiente.bottom - dp(14), pTxt);
        } else { rSiguiente.left = rSiguiente.right = rSiguiente.top = rSiguiente.bottom = 0; }
        // v6.5: sin lupa (estorbaba). El ícono UCS fijo abajo a la izquierda, como en AutoCAD
        {
            float ux = dp(18), uy = getHeight() - dp(18), L = dp(34);
            Paint u = new Paint(Paint.ANTI_ALIAS_FLAG);
            u.setStrokeWidth(dp(2.5f));
            u.setColor(0xFFE53935);
            c.drawLine(ux, uy, ux + L, uy, u);
            c.drawLine(ux + L, uy, ux + L - dp(7), uy - dp(4), u);
            c.drawLine(ux + L, uy, ux + L - dp(7), uy + dp(4), u);
            u.setColor(0xFF43A047);
            c.drawLine(ux, uy, ux, uy - L, u);
            c.drawLine(ux, uy - L, ux - dp(4), uy - L + dp(7), u);
            c.drawLine(ux, uy - L, ux + dp(4), uy - L + dp(7), u);
            u.setStrokeWidth(0);
            u.setTextSize(dp(12));
            u.setFakeBoldText(true);
            u.setColor(0xFFE53935);
            c.drawText("X", ux + L + dp(3), uy + dp(4), u);
            u.setColor(0xFF43A047);
            c.drawText("Y", ux - dp(4), uy - L - dp(4), u);
            u.setColor(0xFF263238);
            u.setTextSize(dp(9));
            c.drawText("UCS", ux + dp(5), uy - dp(5), u);
        }
        // versión 6.1: el cuadro de selección (azul = ventana, verde punteado = captura)
        if (modo == CUADRO && movio && dedoX >= 0 && !dos) {
            boolean ventana = dedoX >= x0;
            Paint pc = new Paint(Paint.ANTI_ALIAS_FLAG);
            pc.setStyle(Paint.Style.FILL);
            pc.setColor(ventana ? 0x222196F3 : 0x2243A047);
            float l = Math.min(x0, dedoX), r = Math.max(x0, dedoX), t = Math.min(y0, dedoY), bo = Math.max(y0, dedoY);
            c.drawRect(l, t, r, bo, pc);
            pc.setStyle(Paint.Style.STROKE);
            pc.setStrokeWidth(dp(2));
            pc.setColor(ventana ? 0xFF1565C0 : 0xFF2E7D32);
            if (!ventana) pc.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(8), dp(5)}, 0));
            c.drawRect(l, t, r, bo, pc);
        }
    }

    /** Puntos de muestra de una pieza del dibujo (para saber si queda adentro del cuadro o lo toca). */
    private List<double[]> muestras(Boceto.Ent e) {
        List<double[]> r = new ArrayList<>();
        Boceto.Punto a = b.puntos.get(e.a);
        if (a == null) return r;
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto q = b.puntos.get(e.b);
            if (q == null) return r;
            for (int i = 0; i <= 16; i++) r.add(new double[]{a.x + (q.x - a.x) * i / 16.0, a.y + (q.y - a.y) * i / 16.0});
        } else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
            for (int i = 0; i < 32; i++) {
                double an = 2 * Math.PI * i / 32, x = a.x + e.r * Math.cos(an), y = a.y + e.r * Math.sin(an);
                if (e.tipo == Boceto.ARCO && !Editar2D.enArcoEnt(b, e, x, y)) continue;
                r.add(new double[]{x, y});
            }
        } else r.add(new double[]{a.x, a.y});
        return r;
    }

    /** Ventana (→): lo que queda todo adentro · Captura (←): todo lo que el cuadro toque. */
    private void escogerCuadro(float xa, float ya, float xb, float yb) {
        boolean ventana = xb >= xa;
        double x1 = Math.min(mx(xa), mx(xb)), x2 = Math.max(mx(xa), mx(xb)), y1 = Math.min(my(ya), my(yb)), y2 = Math.max(my(ya), my(yb));
        int n = 0;
        for (Boceto.Ent e : b.ents) {
            List<double[]> ms = muestras(e);
            if (ms.isEmpty()) continue;
            int dentro = 0;
            for (double[] q : ms) if (q[0] >= x1 && q[0] <= x2 && q[1] >= y1 && q[1] <= y2) dentro++;
            boolean entra = ventana ? dentro == ms.size() : dentro > 0;
            if (entra && !sel.contains(e.id)) { sel.add(e.id); n++; }
        }
        if (oyente != null) {
            oyente.aviso((ventana ? "▭ Ventana: " : "⬚ Captura: ") + n + (n == 1 ? " cosa escogida" : " cosas escogidas") + " (" + sel.size() + " en total). Ahora use Modificar o 🗑 Borrar");
            oyente.seleccion();
        }
    }

    /** Todo lo de la hoja: rejilla, dibujo, lo que se está haciendo y la marca del imán. */
    private void contenido(Canvas c) {
        rejilla(c);
        // versión 4.2: el punto 0,0 de referencia (rojo = eje X, verde = eje Y)
        // v6.9: solo se ve mientras se amarra al 0,0 (no sale en pantallazos)
        if (Tema.verCero) {
        float ox = sx(0), oy = sy(0), lr = dp(26);
        pIman.setStrokeWidth(dp(2));
        pIman.setColor(0xFFD32F2F);
        c.drawLine(ox, oy, ox + lr, oy, pIman);
        pIman.setColor(0xFF2E7D32);
        c.drawLine(ox, oy, ox, oy - lr, pIman);
        pPto.setColor(Tema.linea());
        c.drawCircle(ox, oy, dp(3.5f), pPto);
        pTxt.setTextSize(dp(11));
        pTxt.setFakeBoldText(true);
        pTxt.setColor(Tema.linea());
        c.drawText("0,0", ox + dp(4), oy + dp(14), pTxt);
        }
        dibujarCalco(c);
        pintar(c, false);
        // lo escogido para mover o copiar, corrido (fantasma)
        if (modo == PEDIDO && pedido != null && pedido.fantasma > 0 && !toques.isEmpty() && !Double.isNaN(fx)) {
            Toque t = toques.get(0);
            Editar2D.Mover m = pedido.fantasma == 1 ? Editar2D.traslado(fx - t.x, fy - t.y) : Editar2D.espejo(t.x, t.y, fx, fy);
            if (Math.hypot(fx - t.x, fy - t.y) > 0.5) dibujarFantasma(c, m);
        }
        pLin.setColor(0xFFFF6F00);
        pLin.setStrokeWidth(dp(2));
        pLin.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(6), dp(4)}, 0));
        if (!Double.isNaN(fx)) {
            if (modo == LINEA && !clic.isEmpty()) {
                Boceto.Punto p = b.puntos.get(clic.get(clic.size() - 1));
                if (p != null) {
                    c.drawLine(sx(p.x), sy(p.y), sx(fx), sy(fy), pLin);
                    double an = Math.toDegrees(Math.atan2(fy - p.y, fx - p.x));
                    if (!enLupa) letrero(c, Formula.n(Math.hypot(fx - p.x, fy - p.y)) + " mm · " + Formula.n(Math.round(an * 10) / 10.0) + "°", sx(fx) + dp(12), sy(fy) - dp(30));
                }
            } else if (modo == RECT && primero != null) {
                c.drawRect(Math.min(sx(primero.x), sx(fx)), Math.min(sy(primero.y), sy(fy)), Math.max(sx(primero.x), sx(fx)), Math.max(sy(primero.y), sy(fy)), pLin);
                if (!enLupa) letrero(c, Formula.n(Math.abs(fx - primero.x)) + " × " + Formula.n(Math.abs(fy - primero.y)), sx(fx) + dp(12), sy(fy) - dp(30));
            } else if (modo == POLIGONO && primero != null) {
                double r = Math.hypot(fx - primero.x, fy - primero.y), a0 = Math.atan2(fy - primero.y, fx - primero.x);
                int n = Math.max(3, lados);
                for (int i = 0; i < n; i++) {
                    double a1 = a0 + 2 * Math.PI * i / n, a2 = a0 + 2 * Math.PI * (i + 1) / n;
                    c.drawLine(sx(primero.x + r * Math.cos(a1)), sy(primero.y + r * Math.sin(a1)), sx(primero.x + r * Math.cos(a2)), sy(primero.y + r * Math.sin(a2)), pLin);
                }
                if (!enLupa) letrero(c, n + " lados · R " + Formula.n(r), sx(fx) + dp(12), sy(fy) - dp(30));
            } else if ((modo == CIRCULO || modo == ARCO) && !clic.isEmpty()) {
                Boceto.Punto p = b.puntos.get(clic.get(0));
                if (p != null) {
                    float r = (float) (Math.hypot(fx - p.x, fy - p.y) * esc);
                    if (modo == CIRCULO || clic.size() == 1) c.drawCircle(sx(p.x), sy(p.y), r, pLin);
                    c.drawLine(sx(p.x), sy(p.y), sx(fx), sy(fy), pLin);
                    if (!enLupa && modo == CIRCULO) letrero(c, "Ø " + Formula.n(2 * Math.hypot(fx - p.x, fy - p.y)), sx(fx) + dp(12), sy(fy) - dp(30));
                }
            } else if (modo == PEDIDO && pedido != null && pedido.linea && !toques.isEmpty()) {
                Toque t = toques.get(0);
                c.drawLine(sx(t.x), sy(t.y), sx(fx), sy(fy), pLin);
                if (!enLupa) letrero(c, Formula.n(Math.hypot(fx - t.x, fy - t.y)) + " mm", sx(fx) + dp(12), sy(fy) - dp(30));
            }
            marcaIman(c);
        }
        pLin.setPathEffect(null);
        // la línea que se midió
        if (lineaMedida != null) {
            pLin.setColor(0xFFE65100);
            pLin.setStrokeWidth(dp(2));
            c.drawLine(sx(lineaMedida[0]), sy(lineaMedida[1]), sx(lineaMedida[2]), sy(lineaMedida[3]), pLin);
        }
        if (cotaP1 >= 0) {
            Boceto.Punto p = b.puntos.get(cotaP1);
            if (p != null) { pPto.setColor(0xFFFF6F00); c.drawCircle(sx(p.x), sy(p.y), dp(8), pPto); }
        }
        for (Integer k : clic) {
            Boceto.Punto p = k == null || k < 0 ? null : b.puntos.get(k);
            if (p != null) { pPto.setColor(0xFFFF6F00); c.drawCircle(sx(p.x), sy(p.y), dp(5), pPto); }
        }
        for (Toque t : toques) { pPto.setColor(0xFFFF6F00); c.drawCircle(sx(t.x), sy(t.y), dp(5), pPto); }
        if (primero != null) { pPto.setColor(0xFFFF6F00); c.drawCircle(sx(primero.x), sy(primero.y), dp(5), pPto); }
    }

    /** La marca del imán: cuadrito extremo, triángulo mitad, círculo centro, X cruce, ⊥ 90°, tangente. */
    private void marcaIman(Canvas c) {
        float x = sx(fx), y = sy(fy), r = dp(7);
        pIman.setColor(0xFFE65100);
        pIman.setStrokeWidth(dp(2));
        int t = iman == null ? I_REJILLA : iman.tipo;
        switch (t) {
            case I_EXTREMO: c.drawRect(x - r, y - r, x + r, y + r, pIman); break;
            case I_MEDIO: {
                Path p = new Path();
                p.moveTo(x, y - r); p.lineTo(x + r, y + r * 0.8f); p.lineTo(x - r, y + r * 0.8f); p.close();
                c.drawPath(p, pIman);
                break;
            }
            case I_CENTRO: c.drawCircle(x, y, r, pIman); break;
            case I_CRUCE: c.drawLine(x - r, y - r, x + r, y + r, pIman); c.drawLine(x - r, y + r, x + r, y - r, pIman); break;
            case I_PERP: c.drawLine(x - r, y + r, x + r, y + r, pIman); c.drawLine(x, y + r, x, y - r, pIman); break;
            case I_TANG: c.drawCircle(x, y + r / 2, r / 2, pIman); c.drawLine(x - r, y - r / 2, x + r, y - r / 2, pIman); break;
            case I_ORIGEN: c.drawCircle(x, y, r, pIman); c.drawLine(x - r * 1.6f, y, x + r * 1.6f, y, pIman); c.drawLine(x, y - r * 1.6f, x, y + r * 1.6f, pIman); break;
            case I_CALCO: c.drawRect(x - r, y - r, x + r, y + r, pIman); c.drawLine(x - r, y - r, x + r, y + r, pIman); break;
            case I_CERCA: c.drawLine(x - r, y - r, x + r, y - r, pIman); c.drawLine(x + r, y - r, x - r, y + r, pIman); c.drawLine(x - r, y + r, x + r, y + r, pIman); break;
            default:
                pPto.setColor(0xFFFF6F00);
                c.drawCircle(x, y, dp(4), pPto);
        }
    }

    private void dibujarFantasma(Canvas c, Editar2D.Mover m) {
        pLin.setColor(0xAAFF6F00);
        pLin.setStrokeWidth(dp(2));
        for (Integer id : sel) {
            Boceto.Ent e = b.entPorId(id);
            if (e == null) continue;
            Boceto.Punto a = b.puntos.get(e.a);
            if (a == null) continue;
            if (e.tipo == Boceto.LINEA) {
                Boceto.Punto q = b.puntos.get(e.b);
                if (q == null) continue;
                double[] p1 = m.a(a.x, a.y), p2 = m.a(q.x, q.y);
                c.drawLine(sx(p1[0]), sy(p1[1]), sx(p2[0]), sy(p2[1]), pLin);
            } else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
                double s = 0, barr = 2 * Math.PI;
                if (e.tipo == Boceto.ARCO) {
                    Boceto.Punto p1 = b.puntos.get(e.b), p2 = b.puntos.get(e.c);
                    if (p1 == null || p2 == null) continue;
                    s = Editar2D.ang(a.x, a.y, p1.x, p1.y);
                    barr = Editar2D.norm(Editar2D.ang(a.x, a.y, p2.x, p2.y) - s);
                }
                double[] ant = null;
                for (int i = 0; i <= 24; i++) {
                    double an = s + barr * i / 24;
                    double[] p = m.a(a.x + e.r * Math.cos(an), a.y + e.r * Math.sin(an));
                    if (ant != null) c.drawLine(sx(ant[0]), sy(ant[1]), sx(p[0]), sy(p[1]), pLin);
                    ant = p;
                }
            } else {
                double[] p = m.a(a.x, a.y);
                c.drawCircle(sx(p[0]), sy(p[1]), dp(4), pLin);
            }
        }
    }

    /** La lupa: agranda lo que hay debajo del dedo para atinarle al punto. */
    private void dibujarLupa(Canvas c) {
        float R = dp(66), k = 3.5f;
        float cx = dedoX < getWidth() / 2f ? getWidth() - R - dp(10) : R + dp(10);
        float cy = dp(44) + R;
        if (dedoY < cy + R + dp(24)) cy = getHeight() - R - dp(16);
        double centroX = !Double.isNaN(fx) ? fx : mx(dedoX), centroY = !Double.isNaN(fx) ? fy : my(dedoY);
        double vEsc = esc;
        float vx = offX, vy = offY;
        Path circ = new Path();
        circ.addCircle(cx, cy, R, Path.Direction.CW);
        c.save();
        c.clipPath(circ);
        c.drawColor(Color.WHITE);
        esc = vEsc * k;
        offX = (float) (cx - centroX * esc);
        offY = (float) (cy + centroY * esc);
        enLupa = true;
        contenido(c);
        enLupa = false;
        esc = vEsc; offX = vx; offY = vy;
        c.restore();
        // la cruz y el borde
        pIman.setColor(0x88E65100);
        pIman.setStrokeWidth(dp(1));
        c.drawLine(cx - R, cy, cx + R, cy, pIman);
        c.drawLine(cx, cy - R, cx, cy + R, pIman);
        pIman.setColor(0xFFE65100);
        pIman.setStrokeWidth(dp(3));
        c.drawCircle(cx, cy, R, pIman);
        String nom = (iman != null && usaIman() ? NOM_IMAN[iman.tipo] : "");
        String s = "Lupa ×" + (int) k + (nom.isEmpty() ? "" : " · " + nom);
        pTxt.setTextSize(dp(12));
        pTxt.setFakeBoldText(true);
        float w = pTxt.measureText(s);
        pFondo.setColor(0xF2FFF3E0);
        c.drawRoundRect(cx - w / 2 - dp(6), cy + R + dp(2), cx + w / 2 + dp(6), cy + R + dp(20), dp(5), dp(5), pFondo);
        pTxt.setColor(Color.BLACK);
        c.drawText(s, cx - w / 2, cy + R + dp(15), pTxt);
    }

    private void letrero(Canvas c, String s, float x, float y) {
        pTxt.setTextSize(dp(13));
        pTxt.setFakeBoldText(true);
        float w = pTxt.measureText(s);
        pFondo.setColor(0xEEFFF3E0);
        c.drawRoundRect(x - dp(4), y - dp(15), x + w + dp(4), y + dp(5), dp(4), dp(4), pFondo);
        pTxt.setColor(0xFFE65100);
        c.drawText(s, x, y, pTxt);
    }

    /** Escribe el texto partido en renglones; devuelve dónde quedó el último renglón. */
    private float dibujarTextoLargo(Canvas c, String s, float x, float y, float ancho) {
        String[] pal = s.split(" ");
        StringBuilder ln = new StringBuilder();
        for (String p : pal) {
            if (pTxt.measureText(ln + " " + p) > ancho && ln.length() > 0) { c.drawText(ln.toString(), x, y, pTxt); y += dp(15); ln.setLength(0); }
            if (ln.length() > 0) ln.append(' ');
            ln.append(p);
        }
        if (ln.length() > 0) c.drawText(ln.toString(), x, y, pTxt);
        return y;
    }

    private void rejilla(Canvas c) {
        double paso = 10;
        while (paso * esc < dp(14)) paso *= 10;
        double x0m = mx(0), x1m = mx(getWidth()), y0m = my(getHeight()), y1m = my(0);
        for (int pase = 0; pase < 2; pase++) {
            double p = pase == 0 ? paso : paso * 10;
            pRej.setColor(Tema.negro ? (pase == 0 ? 0xFF161C26 : 0xFF222B38) : (pase == 0 ? 0xFFF1F3F5 : 0xFFDDE3E8));
            for (double x = Math.floor(x0m / p) * p; x <= x1m; x += p) c.drawLine(sx(x), 0, sx(x), getHeight(), pRej);
            for (double y = Math.floor(y0m / p) * p; y <= y1m; y += p) c.drawLine(0, sy(y), getWidth(), sy(y), pRej);
        }
        // v6.9: las rayas del 0,0 solo mientras se amarra al 0,0
        if (Tema.verCero) {
            pRej.setColor(0xFFFFB300);
            c.drawLine(sx(0), 0, sx(0), getHeight(), pRej);
            c.drawLine(0, sy(0), getWidth(), sy(0), pRej);
        }
    }

    /**
     * Dibuja el boceto. impreso = true: todo negro nítido (para el PDF), sin puntos ni marcas de amarre.
     */
    /** Versión 4.3: los puntos que todavía se pueden mover (sus líneas van en azul). */
    public java.util.Set<Integer> libres;

    public void revisar() {
        try { libres = b.ents.size() <= 160 ? b.puntosLibres(medidas) : null; } catch (Exception ex) { libres = null; }
    }

    private boolean suelta(Boceto.Ent e) {
        if (libres == null || e.tipo == Boceto.TEXTO) return false;
        return libres.contains(e.id) || libres.contains(e.a) || (e.b >= 0 && libres.contains(e.b)) || (e.c >= 0 && libres.contains(e.c));
    }

    public void pintar(Canvas c, boolean impreso) {
        float grueso = impreso ? 1.6f : dp(2.2f);
        // v6.7: boceto sobre una cara: la cara de la pieza se ve llena (opaca), para dibujar viendo la pieza
        if (!impreso) {
            try {
                java.util.List<Boceto.Ent> bordes = new java.util.ArrayList<>();
                for (Boceto.Ent e : b.ents) if (e.tipo == Boceto.LINEA && e.punteada) bordes.add(e);
                if (bordes.size() >= 3) {
                    android.graphics.Path pa = new android.graphics.Path();
                    java.util.Set<Integer> usados = new java.util.HashSet<>();
                    for (Boceto.Ent ini : bordes) {
                        if (usados.contains(ini.id)) continue;
                        usados.add(ini.id);
                        Boceto.Punto p0 = b.puntos.get(ini.a), p1 = b.puntos.get(ini.b);
                        if (p0 == null || p1 == null) continue;
                        pa.moveTo(sx(p0.x), sy(p0.y));
                        pa.lineTo(sx(p1.x), sy(p1.y));
                        int fin = ini.b;
                        boolean sigue = true;
                        while (sigue && fin != ini.a) {
                            sigue = false;
                            for (Boceto.Ent e : bordes) {
                                if (usados.contains(e.id)) continue;
                                int otro = e.a == fin ? e.b : e.b == fin ? e.a : -1;
                                if (otro < 0) continue;
                                Boceto.Punto q = b.puntos.get(otro);
                                if (q == null) continue;
                                usados.add(e.id);
                                pa.lineTo(sx(q.x), sy(q.y));
                                fin = otro;
                                sigue = true;
                                break;
                            }
                        }
                        pa.close();
                    }
                    Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
                    pf.setStyle(Paint.Style.FILL);
                    pf.setColor(0xFF78909C);   // la cara de la pieza, gris opaco
                    c.drawPath(pa, pf);
                }
            } catch (Exception ignored) { }
        }
        // versión 4.3: las figuras cerradas se sombrean (ya se pueden extruir)
        if (!impreso) {
            try {
                java.util.List<double[][]> pols = new java.util.ArrayList<>();
                Editar2D.figuras(b, pols);
                android.graphics.Path pa = new android.graphics.Path();
                pa.setFillType(android.graphics.Path.FillType.EVEN_ODD);
                for (double[][] pol : pols) {
                    if (pol == null || pol.length < 3) continue;
                    for (int i = 0; i < pol.length; i++) { if (i == 0) pa.moveTo(sx(pol[i][0]), sy(pol[i][1])); else pa.lineTo(sx(pol[i][0]), sy(pol[i][1])); }
                    pa.close();
                }
                Paint pf = new Paint();
                pf.setStyle(Paint.Style.FILL);
                pf.setColor(0x2A455A64);
                c.drawPath(pa, pf);
            } catch (Exception ignored) { }
        }
        // entidades
        for (Boceto.Ent e : b.ents) {
            boolean escogida = !impreso && sel.contains(e.id);
            pLin.setColor(escogida ? 0xFFFF8F00 : !impreso && suelta(e) && !e.punteada ? 0xFF1E88E5 : impreso ? Color.BLACK : Tema.linea());
            pLin.setPathEffect(e.punteada ? new android.graphics.DashPathEffect(new float[]{grueso * 4, grueso * 3}, 0) : null);
            pLin.setStrokeWidth(escogida ? grueso * 1.8f : grueso);
            Boceto.Punto a = b.puntos.get(e.a);
            if (a == null) continue;
            switch (e.tipo) {
                case Boceto.LINEA: {
                    Boceto.Punto q = b.puntos.get(e.b);
                    if (q != null) c.drawLine(sx(a.x), sy(a.y), sx(q.x), sy(q.y), pLin);
                    break;
                }
                case Boceto.CIRCULO:
                    c.drawCircle(sx(a.x), sy(a.y), (float) (e.r * esc), pLin);
                    break;
                case Boceto.ARCO: {
                    Boceto.Punto p1 = b.puntos.get(e.b), p2 = b.puntos.get(e.c);
                    if (p1 == null || p2 == null) break;
                    float r = (float) (e.r * esc);
                    double a1 = Math.toDegrees(Math.atan2(-(p1.y - a.y), p1.x - a.x));
                    double a2 = Math.toDegrees(Math.atan2(-(p2.y - a.y), p2.x - a.x));
                    // en la pantalla el eje Y va al revés: el arco va del inicio al final en contra del reloj (en mm)
                    double barrido = a1 - a2;
                    while (barrido <= 0) barrido += 360;
                    c.drawArc(new RectF(sx(a.x) - r, sy(a.y) - r, sx(a.x) + r, sy(a.y) + r), (float) a1, (float) -barrido, false, pLin);
                    break;
                }
                case Boceto.TEXTO: {
                    pTxt.setColor(escogida ? 0xFFFF8F00 : impreso ? Color.BLACK : Tema.linea());
                    pTxt.setFakeBoldText(false);
                    pTxt.setTextSize((float) Math.max(impreso ? 6 : dp(9), (e.r <= 0 ? 150 : e.r) * esc));
                    c.drawText(e.texto, sx(a.x), sy(a.y), pTxt);
                    break;
                }
            }
        }
        pLin.setPathEffect(null);
        // cotas
        for (Boceto.Restr r : b.restr) if (r.esCota()) cota(c, r, impreso);
        if (impreso) return;
        // versión 4.4: el doctor marca en rojo las puntas abiertas
        if (!impreso && sueltas != null) {
            Paint pr = new Paint(Paint.ANTI_ALIAS_FLAG);
            pr.setStyle(Paint.Style.STROKE);
            pr.setStrokeWidth(dp(3));
            pr.setColor(0xFFD32F2F);
            for (int id : sueltas) {
                Boceto.Punto q = b.puntos.get(id);
                if (q != null) c.drawCircle(sx(q.x), sy(q.y), dp(12), pr);
            }
        }
        // marcas de amarre
        pGlifo.setTextSize(dp(11));
        if (marcas) for (Boceto.Restr r : b.restr) {
            if (r.esCota()) continue;
            String g = r.tipo == Boceto.HORIZ ? "═" : r.tipo == Boceto.VERT ? "║" : r.tipo == Boceto.PERP ? "⊥" : r.tipo == Boceto.PARAL ? "∥"
                    : r.tipo == Boceto.IGUAL ? "=" : r.tipo == Boceto.FIJO ? "📌" : r.tipo == Boceto.TANG ? "◡" : "";
            if (r.tipo == Boceto.MEDIO || r.tipo == Boceto.SOBRE || r.tipo == Boceto.COINC) {
                Boceto.Punto p = b.puntos.get(r.p1);
                if (p != null) {
                    pIman.setColor(0xFF2E7D32);
                    pIman.setStrokeWidth(dp(1.5f));
                    c.drawCircle(sx(p.x), sy(p.y), dp(6), pIman);
                }
                continue;
            }
            for (int en : new int[]{r.e1, r.e2}) {
                Boceto.Ent e = b.entPorId(en);
                if (e == null) continue;
                float[] m = medio(e);
                pFondo.setColor(0xDDE8F5E9);
                float w = pGlifo.measureText(g);
                float yy = m[1] - dp(7);
                c.drawRoundRect(m[0] + dp(5), yy - dp(11), m[0] + dp(9) + w, yy + dp(3), dp(3), dp(3), pFondo);
                pGlifo.setColor(0xFF2E7D32);
                c.drawText(g, m[0] + dp(7), yy, pGlifo);
            }
            if (r.tipo == Boceto.FIJO) {
                Boceto.Punto p = b.puntos.get(r.p1);
                if (p != null) { pGlifo.setColor(0xFF2E7D32); c.drawText("📌", sx(p.x) + dp(4), sy(p.y) - dp(4), pGlifo); }
            }
        }
        // puntos
        for (Boceto.Punto p : b.puntos.values()) {
            boolean s = selPts.contains(p.id);
            pPto.setColor(s ? 0xFFFF8F00 : 0xFF1565C0);
            c.drawCircle(sx(p.x), sy(p.y), dp(s ? 6.5f : 3.2f), pPto);
        }
    }

    private float[] medio(Boceto.Ent e) {
        Boceto.Punto a = b.puntos.get(e.a);
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto q = b.puntos.get(e.b);
            return new float[]{(sx(a.x) + sx(q.x)) / 2, (sy(a.y) + sy(q.y)) / 2};
        }
        if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) return new float[]{sx(a.x), (float) (sy(a.y) - e.r * esc)};
        return new float[]{sx(a.x), sy(a.y)};
    }

    /** v6.2: la caja del dibujo en pantalla (sin textos ni líneas punteadas). */
    private float[] cajaDibujo() {
        float x0 = Float.MAX_VALUE, y0 = Float.MAX_VALUE, x1 = -Float.MAX_VALUE, y1 = -Float.MAX_VALUE;
        boolean hay = false;
        for (Boceto.Ent e : b.ents) {
            if (e.tipo == Boceto.TEXTO || e.punteada) continue;
            int[] ids = e.tipo == Boceto.LINEA ? new int[]{e.a, e.b} : new int[]{e.a};
            for (int id : ids) {
                Boceto.Punto q = b.puntos.get(id);
                if (q == null) continue;
                float rr = e.tipo == Boceto.LINEA ? 0 : (float) (e.r * esc);
                float X = sx(q.x), Y = sy(q.y);
                x0 = Math.min(x0, X - rr); x1 = Math.max(x1, X + rr); y0 = Math.min(y0, Y - rr); y1 = Math.max(y1, Y + rr);
                hay = true;
            }
        }
        return hay ? new float[]{x0, y0, x1, y1} : null;
    }

    /** Cuántas cotas del mismo tipo y del mismo lado van antes que esta (para escalonarlas). */
    private int nivelCota(Boceto.Restr r, float[] bx) {
        if (bx == null || (r.tipo != Boceto.C_HORIZ && r.tipo != Boceto.C_VERT)) return 0;
        int n = 0;
        for (Boceto.Restr o : b.restr) {
            if (o == r) break;
            if (o.tipo != r.tipo) continue;
            Boceto.Punto p = b.puntos.get(o.p1), q = b.puntos.get(o.p2), p0 = b.puntos.get(r.p1), q0 = b.puntos.get(r.p2);
            if (p == null || q == null || p0 == null || q0 == null) continue;
            boolean l1, l2;
            if (r.tipo == Boceto.C_HORIZ) { l1 = (sy(p.y) + sy(q.y)) / 2 <= (bx[1] + bx[3]) / 2; l2 = (sy(p0.y) + sy(q0.y)) / 2 <= (bx[1] + bx[3]) / 2; }
            else { l1 = (sx(p.x) + sx(q.x)) / 2 >= (bx[0] + bx[2]) / 2; l2 = (sx(p0.x) + sx(q0.x)) / 2 >= (bx[0] + bx[2]) / 2; }
            if (l1 == l2) n++;
        }
        return Math.min(n, 6);
    }

    /** Texto de una cota: el número, y si es fórmula también el nombre (ancho = 4000). */
    public String textoCota(Boceto.Restr r) {
        double v = b.medir(r);
        String num = r.tipo == Boceto.C_ANG ? Formula.n(v) + "°" : (r.tipo == Boceto.C_DIAM ? "Ø" : r.tipo == Boceto.C_RADIO ? "R" : "") + Formula.n(v);
        if (r.error != null) return "⚠ " + r.formula;
        boolean formula = Formula.numero(r.formula) == null && !r.formula.trim().isEmpty();
        return (r.candado ? "🔒" : "") + (formula ? r.formula.trim() + " = " + num : num);
    }

    private void cota(Canvas c, Boceto.Restr r, boolean impreso) {
        int col = impreso ? Color.BLACK : r.error != null ? 0xFFD32F2F : Tema.cota();
        pCota.setColor(col);
        pCota.setStrokeWidth(impreso ? 0.8f : dp(1.1f));
        pTxt.setColor(col);
        pTxt.setFakeBoldText(true);
        pTxt.setTextSize(impreso ? 8.5f : dp(12.5f));
        float sep = impreso ? 14 : dp(26);
        String t = textoCota(r);
        float ax1, ay1, ax2, ay2;   // los dos extremos medidos (pantalla)
        switch (r.tipo) {
            case Boceto.C_LARGO: case Boceto.C_DIST: case Boceto.C_HORIZ: case Boceto.C_VERT: case Boceto.C_PL: {
                Boceto.Punto p, q;
                if (r.tipo == Boceto.C_LARGO) {
                    Boceto.Ent e = b.entPorId(r.e1);
                    if (e == null) return;
                    p = b.puntos.get(e.a); q = b.puntos.get(e.b);
                } else if (r.tipo == Boceto.C_PL) {
                    double[] f = b.pie(r);
                    if (f == null) return;
                    p = b.puntos.get(r.p1); q = new Boceto.Punto(-1, f[0], f[1]);
                } else { p = b.puntos.get(r.p1); q = b.puntos.get(r.p2); }
                if (p == null || q == null) return;
                ax1 = sx(p.x); ay1 = sy(p.y); ax2 = sx(q.x); ay2 = sy(q.y);
                float dx, dy;   // hacia dónde se corre la línea de cota
                float l1x, l1y, l2x, l2y;
                // v6.2: las cotas siempre por fuera del dibujo (y escalonadas si hay varias del mismo lado)
                float[] bx = cajaDibujo();
                int nivel = nivelCota(r, bx);
                float paso = sep * (1 + 0.95f * nivel);
                if (r.tipo == Boceto.C_HORIZ) {
                    boolean arriba = bx == null || (ay1 + ay2) / 2 <= (bx[1] + bx[3]) / 2;
                    float yy = bx == null ? Math.min(ay1, ay2) - paso : arriba ? bx[1] - paso : bx[3] + paso;
                    l1x = ax1; l1y = yy; l2x = ax2; l2y = yy;
                } else if (r.tipo == Boceto.C_VERT) {
                    boolean der = bx == null || (ax1 + ax2) / 2 >= (bx[0] + bx[2]) / 2;
                    float xx = bx == null ? Math.max(ax1, ax2) + paso : der ? bx[2] + paso : bx[0] - paso;
                    l1x = xx; l1y = ay1; l2x = xx; l2y = ay2;
                } else {
                    float vx = ax2 - ax1, vy = ay2 - ay1, l = (float) Math.hypot(vx, vy);
                    if (l < 1) return;
                    dx = -vy / l; dy = vx / l;
                    if (bx != null) {
                        float mx = (ax1 + ax2) / 2 - (bx[0] + bx[2]) / 2, my = (ay1 + ay2) / 2 - (bx[1] + bx[3]) / 2;
                        if (dx * mx + dy * my < 0) { dx = -dx; dy = -dy; }   // hacia afuera, lejos del centro del dibujo
                    } else if (dy > 0 || (Math.abs(dy) < 0.01f && dx < 0)) { dx = -dx; dy = -dy; }
                    l1x = ax1 + dx * paso; l1y = ay1 + dy * paso; l2x = ax2 + dx * paso; l2y = ay2 + dy * paso;
                }
                c.drawLine(ax1, ay1, l1x, l1y, pCota);
                c.drawLine(ax2, ay2, l2x, l2y, pCota);
                c.drawLine(l1x, l1y, l2x, l2y, pCota);
                flecha(c, l1x, l1y, l2x, l2y, impreso);
                flecha(c, l2x, l2y, l1x, l1y, impreso);
                textoEnLinea(c, t, l1x, l1y, l2x, l2y, r, impreso);
                break;
            }
            case Boceto.C_RADIO: case Boceto.C_DIAM: {
                Boceto.Ent e = b.entPorId(r.e1);
                if (e == null) return;
                Boceto.Punto ce = b.puntos.get(e.a);
                if (ce == null) return;
                float cx = sx(ce.x), cy = sy(ce.y), rr = (float) (e.r * esc);
                float ux = 0.7071f, uy = -0.7071f;
                float ex = cx + ux * rr, ey = cy + uy * rr;
                if (r.tipo == Boceto.C_DIAM) c.drawLine(cx - ux * rr, cy - uy * rr, ex, ey, pCota);
                else c.drawLine(cx, cy, ex, ey, pCota);
                flecha(c, cx, cy, ex, ey, impreso);
                float tx = ex + ux * sep * 0.6f, ty = ey + uy * sep * 0.6f;
                c.drawLine(ex, ey, tx, ty, pCota);
                c.drawLine(tx, ty, tx + pTxt.measureText(t) + dp(4), ty, pCota);
                c.drawText(t, tx + dp(2), ty - dp(3), pTxt);
                zona(t, tx + dp(2), ty - dp(3), r, impreso);
                break;
            }
            case Boceto.C_ANG: {
                Boceto.Ent a = b.entPorId(r.e1), q = b.entPorId(r.e2);
                if (a == null || q == null) return;
                float[] m1 = medio(a), m2 = medio(q);
                float tx = (m1[0] + m2[0]) / 2, ty = (m1[1] + m2[1]) / 2;
                pCota.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(3), dp(3)}, 0));
                c.drawLine(m1[0], m1[1], tx, ty, pCota);
                c.drawLine(m2[0], m2[1], tx, ty, pCota);
                pCota.setPathEffect(null);
                String s = "∠ " + t;
                c.drawText(s, tx - pTxt.measureText(s) / 2, ty - dp(4), pTxt);
                zona(s, tx - pTxt.measureText(s) / 2, ty - dp(4), r, impreso);
                break;
            }
        }
    }

    private void flecha(Canvas c, float x1, float y1, float x2, float y2, boolean impreso) {
        float vx = x2 - x1, vy = y2 - y1, l = (float) Math.hypot(vx, vy);
        if (l < 1) return;
        vx /= l; vy /= l;
        float L = impreso ? 5 : dp(8), A = impreso ? 1.8f : dp(3);
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x1 + vx * L - vy * A, y1 + vy * L + vx * A);
        p.lineTo(x1 + vx * L + vy * A, y1 + vy * L - vx * A);
        p.close();
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setColor(pCota.getColor());
        c.drawPath(p, f);
    }

    private void textoEnLinea(Canvas c, String t, float x1, float y1, float x2, float y2, Boceto.Restr r, boolean impreso) {
        float mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
        double ang = Math.toDegrees(Math.atan2(y2 - y1, x2 - x1));
        if (ang > 90) ang -= 180;
        if (ang < -90) ang += 180;
        float w = pTxt.measureText(t);
        c.save();
        c.rotate((float) ang, mx, my);
        if (!impreso) {
            pFondo.setColor(0xF2FFFFFF);
            c.drawRect(mx - w / 2 - dp(2), my - dp(16), mx + w / 2 + dp(2), my - dp(2), pFondo);
        }
        c.drawText(t, mx - w / 2, my - (impreso ? 2 : dp(4)), pTxt);
        c.restore();
        if (!impreso && !enLupa) zonasCota.add(new Object[]{new RectF(mx - w / 2 - dp(6), my - dp(22), mx + w / 2 + dp(6), my + dp(6)), r});
    }

    private void zona(String t, float x, float y, Boceto.Restr r, boolean impreso) {
        if (impreso || enLupa) return;
        zonasCota.add(new Object[]{new RectF(x - dp(4), y - dp(18), x + pTxt.measureText(t) + dp(4), y + dp(6)), r});
    }

    /** Para el PDF: prepara la escala y dibuja en negro dentro de un rectángulo (puntos del papel). */
    public void imprimir(Canvas c, float izq, float arriba, float ancho, float alto) {
        double viejaEsc = esc;
        float vx = offX, vy = offY;
        double[] k = b.caja();
        double w = Math.max(100, k[2] - k[0]), h = Math.max(100, k[3] - k[1]);
        esc = Math.min((ancho - 60) / w, (alto - 60) / h);
        offX = (float) (izq + ancho / 2 - (k[0] + k[2]) / 2 * esc);
        offY = (float) (arriba + alto / 2 + (k[1] + k[3]) / 2 * esc);
        pintar(c, true);
        escalaImpresa = esc;
        esc = viejaEsc; offX = vx; offY = vy;
    }

    /** Escala del último PDF (puntos de papel por mm) para escribir «Escala 1:…». */
    public double escalaImpresa;
}
