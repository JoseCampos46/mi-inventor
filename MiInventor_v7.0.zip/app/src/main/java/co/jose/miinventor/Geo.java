package co.jose.miinventor;

/** Versión 5: cuentas de vectores y giros en 3D (para amarres con ángulo, bisagras y referencias). */
final class Geo {

    private Geo() { }

    static float dot(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    static float[] cross(float[] a, float[] b) {
        return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    static float[] add(float[] a, float[] b) { return new float[]{a[0] + b[0], a[1] + b[1], a[2] + b[2]}; }

    static float[] sub(float[] a, float[] b) { return new float[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }

    static float[] mul(float[] a, float k) { return new float[]{a[0] * k, a[1] * k, a[2] * k}; }

    static float[] addk(float[] a, float[] b, float k) { return new float[]{a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k}; }

    static float[] neg(float[] a) { return new float[]{-a[0], -a[1], -a[2]}; }

    static float len(float[] a) { return (float) Math.sqrt(dot(a, a)); }

    static float dist(float[] a, float[] b) { return len(sub(a, b)); }

    static float[] unit(float[] a) {
        float l = len(a);
        return l < 1e-9f ? new float[]{0, 0, 1} : new float[]{a[0] / l, a[1] / l, a[2] / l};
    }

    /** Un vector cualquiera perpendicular a a (unitario). */
    static float[] perp(float[] a) {
        float[] o = Math.abs(a[0]) < 0.9f ? new float[]{1, 0, 0} : new float[]{0, 1, 0};
        return unit(cross(a, o));
    }

    /** Ángulo entre dos direcciones, en grados (0 a 180). */
    static float angulo(float[] a, float[] b) {
        float c = dot(unit(a), unit(b));
        return (float) Math.toDegrees(Math.acos(Math.max(-1f, Math.min(1f, c))));
    }

    /** Matriz de giro alrededor del eje k (unitario), en grados, regla de la mano derecha. */
    static float[][] rot(float[] k, float grados) {
        float[] u = unit(k);
        double r = Math.toRadians(grados);
        float c = (float) Math.cos(r), s = (float) Math.sin(r), t = 1 - c;
        float x = u[0], y = u[1], z = u[2];
        return new float[][]{
                {t * x * x + c, t * x * y - s * z, t * x * z + s * y},
                {t * x * y + s * z, t * y * y + c, t * y * z - s * x},
                {t * x * z - s * y, t * y * z + s * x, t * z * z + c}};
    }

    static float[] apl(float[][] R, float[] v) {
        return new float[]{R[0][0] * v[0] + R[0][1] * v[1] + R[0][2] * v[2],
                R[1][0] * v[0] + R[1][1] * v[1] + R[1][2] * v[2],
                R[2][0] * v[0] + R[2][1] * v[1] + R[2][2] * v[2]};
    }

    /** El punto p girado con R alrededor del punto c. */
    static float[] girarPunto(float[][] R, float[] p, float[] c) { return add(c, apl(R, sub(p, c))); }

    /** El giro más corto que lleva la dirección a a la dirección b. */
    static float[][] rotEntre(float[] a, float[] b) {
        float[] ua = unit(a), ub = unit(b);
        float[] k = cross(ua, ub);
        float s = len(k), c = dot(ua, ub);
        if (s < 1e-6f) return c > 0 ? rot(new float[]{0, 0, 1}, 0) : rot(perp(ua), 180);
        return rot(k, (float) Math.toDegrees(Math.atan2(s, c)));
    }

    static boolean esNada(float[][] R) {
        return Math.abs(R[0][0] - 1) < 1e-6f && Math.abs(R[1][1] - 1) < 1e-6f && Math.abs(R[2][2] - 1) < 1e-6f;
    }

    /** Quita la basurita de las cuentas: 0.99999 → 1, 0.00001 → 0 (para que los giros de 90° queden exactos). */
    static float[] limpio(float[] v) {
        float[] r = new float[3];
        for (int i = 0; i < 3; i++) {
            float x = v[i];
            if (Math.abs(x) < 1e-5f) x = 0;
            else if (Math.abs(Math.abs(x) - 1) < 1e-5f) x = Math.signum(x);
            r[i] = x;
        }
        return r;
    }
}
