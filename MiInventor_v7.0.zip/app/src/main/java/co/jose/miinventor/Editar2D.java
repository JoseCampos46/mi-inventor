package co.jose.miinventor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Versión 3: las herramientas de «Modificar» y «Medir» del boceto 2D (todo en mm).
 * Cada función cambia el boceto y devuelve null si salió bien, o el aviso para el usuario.
 */
public final class Editar2D {

    private Editar2D() {}

    public interface Mover { double[] a(double x, double y); }

    // ---------------- Ayudas de geometría ----------------

    static Boceto.Punto P(Boceto b, int id) { return b.puntos.get(id); }

    /** Los puntos que usa una entidad. */
    static List<Integer> puntosDe(Boceto.Ent e) {
        List<Integer> l = new ArrayList<>();
        if (e.a >= 0) l.add(e.a);
        if (e.b >= 0) l.add(e.b);
        if (e.c >= 0) l.add(e.c);
        return l;
    }

    /** Cruce de dos rectas (infinitas): devuelve {x, y, t de la primera, u de la segunda} o null si son paralelas. */
    static double[] cruceRectas(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy) {
        double rx = bx - ax, ry = by - ay, sx = dx - cx, sy = dy - cy;
        double den = rx * sy - ry * sx;
        if (Math.abs(den) < 1e-12) return null;
        double t = ((cx - ax) * sy - (cy - ay) * sx) / den;
        double u = ((cx - ax) * ry - (cy - ay) * rx) / den;
        return new double[]{ax + rx * t, ay + ry * t, t, u};
    }

    /** Cruces de la recta a-b con un círculo: lista de {x, y, t}. */
    static List<double[]> cruceRectaCirculo(double ax, double ay, double bx, double by, double cx, double cy, double r) {
        List<double[]> l = new ArrayList<>();
        double dx = bx - ax, dy = by - ay;
        double A = dx * dx + dy * dy;
        if (A < 1e-12) return l;
        double B = 2 * (dx * (ax - cx) + dy * (ay - cy));
        double C = (ax - cx) * (ax - cx) + (ay - cy) * (ay - cy) - r * r;
        double D = B * B - 4 * A * C;
        if (D < 0) return l;
        double s = Math.sqrt(D);
        for (double t : new double[]{(-B - s) / (2 * A), (-B + s) / (2 * A)}) l.add(new double[]{ax + dx * t, ay + dy * t, t});
        if (D < 1e-9) l.remove(1);
        return l;
    }

    /** Ángulo (0..2π) de un punto visto desde el centro. */
    static double ang(double cx, double cy, double x, double y) {
        double a = Math.atan2(y - cy, x - cx);
        return a < 0 ? a + 2 * Math.PI : a;
    }

    /** ¿El ángulo a cae en el arco que va de a1 a a2 contra el reloj? */
    static boolean enArco(double a, double a1, double a2) {
        double barrido = norm(a2 - a1), d = norm(a - a1);
        return d <= barrido + 1e-9;
    }

    static double norm(double a) {
        while (a < 0) a += 2 * Math.PI;
        while (a >= 2 * Math.PI) a -= 2 * Math.PI;
        return a;
    }

    /** Puntos de cruce (x, y) entre dos entidades (líneas como segmentos, círculos, arcos). */
    static List<double[]> cruces(Boceto b, Boceto.Ent e, Boceto.Ent f) {
        List<double[]> r = new ArrayList<>();
        if (e.tipo == Boceto.TEXTO || f.tipo == Boceto.TEXTO) return r;
        if (e.tipo != Boceto.LINEA && f.tipo == Boceto.LINEA) { Boceto.Ent t = e; e = f; f = t; }
        if (e.tipo == Boceto.LINEA && f.tipo == Boceto.LINEA) {
            Boceto.Punto a = P(b, e.a), q = P(b, e.b), c = P(b, f.a), d = P(b, f.b);
            if (a == null || q == null || c == null || d == null) return r;
            double[] x = cruceRectas(a.x, a.y, q.x, q.y, c.x, c.y, d.x, d.y);
            if (x != null && x[2] > -1e-9 && x[2] < 1 + 1e-9 && x[3] > -1e-9 && x[3] < 1 + 1e-9) r.add(new double[]{x[0], x[1]});
            return r;
        }
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto a = P(b, e.a), q = P(b, e.b), c = P(b, f.a);
            if (a == null || q == null || c == null) return r;
            for (double[] x : cruceRectaCirculo(a.x, a.y, q.x, q.y, c.x, c.y, f.r)) {
                if (x[2] < -1e-9 || x[2] > 1 + 1e-9) continue;
                if (f.tipo == Boceto.ARCO && !enArcoEnt(b, f, x[0], x[1])) continue;
                r.add(new double[]{x[0], x[1]});
            }
            return r;
        }
        // círculo con círculo
        Boceto.Punto c1 = P(b, e.a), c2 = P(b, f.a);
        if (c1 == null || c2 == null) return r;
        double dx = c2.x - c1.x, dy = c2.y - c1.y, d = Math.hypot(dx, dy);
        if (d < 1e-9 || d > e.r + f.r || d < Math.abs(e.r - f.r)) return r;
        double a = (e.r * e.r - f.r * f.r + d * d) / (2 * d), h = Math.sqrt(Math.max(0, e.r * e.r - a * a));
        double mx = c1.x + dx * a / d, my = c1.y + dy * a / d;
        for (int s = -1; s <= 1; s += 2) {
            double x = mx + s * h * (-dy) / d, y = my + s * h * dx / d;
            if (e.tipo == Boceto.ARCO && !enArcoEnt(b, e, x, y)) continue;
            if (f.tipo == Boceto.ARCO && !enArcoEnt(b, f, x, y)) continue;
            r.add(new double[]{x, y});
            if (h < 1e-9) break;
        }
        return r;
    }

    static boolean enArcoEnt(Boceto b, Boceto.Ent arco, double x, double y) {
        Boceto.Punto c = P(b, arco.a), p1 = P(b, arco.b), p2 = P(b, arco.c);
        if (c == null || p1 == null || p2 == null) return false;
        return enArco(ang(c.x, c.y, x, y), ang(c.x, c.y, p1.x, p1.y), ang(c.x, c.y, p2.x, p2.y));
    }

    /** Las restricciones que siguen sirviendo cuando se copian estas entidades (las dos puntas adentro). */
    private static boolean adentro(Boceto.Restr r, Set<Integer> ents, Set<Integer> pts) {
        if (r.e1 >= 0 && !ents.contains(r.e1)) return false;
        if (r.e2 >= 0 && !ents.contains(r.e2)) return false;
        if (r.p1 >= 0 && !pts.contains(r.p1)) return false;
        if (r.p2 >= 0 && !pts.contains(r.p2)) return false;
        return r.tipo != Boceto.FIJO;
    }

    private static Set<Integer> puntosDeTodas(Boceto b, Collection<Integer> ents) {
        Set<Integer> s = new LinkedHashSet<>();
        for (Integer id : ents) { Boceto.Ent e = b.entPorId(id); if (e != null) s.addAll(puntosDe(e)); }
        return s;
    }

    // ---------------- Mover, copiar, rotar, espejo, escalar ----------------

    /**
     * Copia las entidades con sus puntos ya movidos. guardarHV: copiar también horizontal/vertical y cotas horizontales/verticales
     * (sirve cuando la copia queda derecha: mover, copiar, matriz en filas, espejo derecho, rotar 180°).
     * Devuelve los id de las entidades nuevas.
     */
    public static List<Integer> copiar(Boceto b, Collection<Integer> ents, Mover m, boolean guardarHV, double escala, boolean cambiaHV) {
        Set<Integer> es = new LinkedHashSet<>(ents);
        Set<Integer> ps = puntosDeTodas(b, es);
        Map<Integer, Integer> nuevo = new HashMap<>();
        for (Integer id : ps) {
            Boceto.Punto p = P(b, id);
            if (p == null) continue;
            double[] q = m.a(p.x, p.y);
            nuevo.put(id, b.punto(q[0], q[1]).id);
        }
        List<Integer> hechas = new ArrayList<>();
        for (Integer id : es) {
            Boceto.Ent e = b.entPorId(id);
            if (e == null) continue;
            Boceto.Ent c = b.ent(e.tipo);
            c.a = e.a >= 0 ? nuevo.getOrDefault(e.a, -1) : -1;
            c.b = e.b >= 0 ? nuevo.getOrDefault(e.b, -1) : -1;
            c.c = e.c >= 0 ? nuevo.getOrDefault(e.c, -1) : -1;
            c.r = e.r * escala;
            c.texto = e.texto;
            nuevo.put(id, c.id);
            hechas.add(c.id);
        }
        // un espejo pone los arcos al revés: se cambian inicio y final
        double[] o = m.a(0, 0), ux = m.a(1, 0), uy = m.a(0, 1);
        double det = (ux[0] - o[0]) * (uy[1] - o[1]) - (ux[1] - o[1]) * (uy[0] - o[0]);
        if (det < 0) for (Integer id : hechas) { Boceto.Ent c = b.entPorId(id); if (c.tipo == Boceto.ARCO) { int t = c.b; c.b = c.c; c.c = t; } }
        for (Boceto.Restr r : new ArrayList<>(b.restr)) {
            if (!adentro(r, es, ps)) continue;
            int t = r.tipo;
            boolean hv = t == Boceto.HORIZ || t == Boceto.VERT || t == Boceto.C_HORIZ || t == Boceto.C_VERT;
            if (hv && !guardarHV) continue;
            if (hv && cambiaHV) t = t == Boceto.HORIZ ? Boceto.VERT : t == Boceto.VERT ? Boceto.HORIZ : t == Boceto.C_HORIZ ? Boceto.C_VERT : Boceto.C_HORIZ;
            String f = r.formula;
            if (r.esCota() && escala != 1 && r.tipo != Boceto.C_ANG) {
                Double v = Formula.numero(f);
                if (v != null) f = Formula.n(v * escala);
            }
            Boceto.Restr c = b.restriccion(t, r.e1 >= 0 ? nuevo.get(r.e1) : -1, r.e2 >= 0 ? nuevo.get(r.e2) : -1,
                    r.p1 >= 0 ? nuevo.get(r.p1) : -1, r.p2 >= 0 ? nuevo.get(r.p2) : -1, f);
            c.off = r.off;
        }
        return hechas;
    }

    /** Mueve (o rota, o escala) las entidades en su sitio. Quita lo que deja de servir. */
    public static void transformar(Boceto b, Collection<Integer> ents, Mover m, boolean guardarHV, double escala, boolean cambiaHV) {
        Set<Integer> es = new LinkedHashSet<>(ents);
        Set<Integer> ps = puntosDeTodas(b, es);
        for (Integer id : ps) {
            Boceto.Punto p = P(b, id);
            if (p == null) continue;
            double[] q = m.a(p.x, p.y);
            p.x = q[0]; p.y = q[1];
        }
        for (Integer id : es) { Boceto.Ent e = b.entPorId(id); if (e != null) e.r *= escala; }
        for (Boceto.Restr r : new ArrayList<>(b.restr)) {
            boolean toca = es.contains(r.e1) || es.contains(r.e2) || ps.contains(r.p1) || ps.contains(r.p2);
            if (!toca) continue;
            boolean hv = r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT || r.tipo == Boceto.C_HORIZ || r.tipo == Boceto.C_VERT;
            if (hv && !guardarHV) { b.restr.remove(r); continue; }
            if (hv && cambiaHV) r.tipo = r.tipo == Boceto.HORIZ ? Boceto.VERT : r.tipo == Boceto.VERT ? Boceto.HORIZ : r.tipo == Boceto.C_HORIZ ? Boceto.C_VERT : Boceto.C_HORIZ;
            // lo que amarra al resto del dibujo (que no se movió) ya no sirve
            if (!adentro(r, es, ps) && r.tipo != Boceto.FIJO) { b.restr.remove(r); continue; }
            if (r.esCota() && escala != 1 && r.tipo != Boceto.C_ANG) {
                Double v = Formula.numero(r.formula);
                if (v != null) r.formula = Formula.n(v * escala);
            }
        }
        // los puntos fijos que se movieron siguen fijos en su sitio nuevo
    }

    public static Mover traslado(double dx, double dy) { return (x, y) -> new double[]{x + dx, y + dy}; }

    public static Mover giro(double cx, double cy, double grados) {
        double r = Math.toRadians(grados), c = Math.cos(r), s = Math.sin(r);
        return (x, y) -> new double[]{cx + (x - cx) * c - (y - cy) * s, cy + (x - cx) * s + (y - cy) * c};
    }

    public static Mover escala(double cx, double cy, double f) { return (x, y) -> new double[]{cx + (x - cx) * f, cy + (y - cy) * f}; }

    public static Mover espejo(double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        return (x, y) -> {
            if (l2 < 1e-12) return new double[]{x, y};
            double t = ((x - ax) * dx + (y - ay) * dy) / l2;
            double px = ax + dx * t, py = ay + dy * t;
            return new double[]{2 * px - x, 2 * py - y};
        };
    }

    /** ¿El giro deja las líneas derechas? 0: igual · 1: cambia horizontal por vertical · -1: ya no quedan derechas. */
    public static int giroDerecho(double grados) {
        double g = ((grados % 360) + 360) % 360;
        if (Math.abs(g) < 1e-6 || Math.abs(g - 180) < 1e-6 || Math.abs(g - 360) < 1e-6) return 0;
        if (Math.abs(g - 90) < 1e-6 || Math.abs(g - 270) < 1e-6) return 1;
        return -1;
    }

    // ---------------- Desfase ----------------

    /** Las líneas pegadas a esta, en cadena (como un rectángulo o una polilínea). Devuelve la cadena ordenada y si cierra. */
    static List<Boceto.Ent> cadena(Boceto b, Boceto.Ent e, boolean[] cerrada) {
        Map<Integer, List<Boceto.Ent>> porPunto = new HashMap<>();
        for (Boceto.Ent x : b.ents) if (x.tipo == Boceto.LINEA) {
            porPunto.computeIfAbsent(x.a, k -> new ArrayList<>()).add(x);
            porPunto.computeIfAbsent(x.b, k -> new ArrayList<>()).add(x);
        }
        List<Boceto.Ent> l = new ArrayList<>();
        l.add(e);
        Set<Integer> vistos = new HashSet<>();
        vistos.add(e.id);
        cerrada[0] = false;
        // hacia adelante (desde e.b)
        int punta = e.b;
        Boceto.Ent act = e;
        while (true) {
            List<Boceto.Ent> v = porPunto.get(punta);
            if (v == null || v.size() != 2) break;
            Boceto.Ent sig = v.get(0) == act ? v.get(1) : v.get(0);
            if (sig == e) { cerrada[0] = true; break; }
            if (vistos.contains(sig.id)) break;
            vistos.add(sig.id);
            l.add(sig);
            punta = sig.a == punta ? sig.b : sig.a;
            act = sig;
        }
        if (cerrada[0]) return l;
        // hacia atrás (desde e.a)
        punta = e.a;
        act = e;
        while (true) {
            List<Boceto.Ent> v = porPunto.get(punta);
            if (v == null || v.size() != 2) break;
            Boceto.Ent sig = v.get(0) == act ? v.get(1) : v.get(0);
            if (vistos.contains(sig.id)) break;
            vistos.add(sig.id);
            l.add(0, sig);
            punta = sig.a == punta ? sig.b : sig.a;
            act = sig;
        }
        return l;
    }

    /** Los vértices de una cadena de líneas en orden (n + 1 si es abierta, n si es cerrada). */
    static List<Integer> vertices(List<Boceto.Ent> cad, boolean cerrada) {
        List<Integer> v = new ArrayList<>();
        if (cad.size() == 1) { v.add(cad.get(0).a); v.add(cad.get(0).b); return v; }
        Boceto.Ent e0 = cad.get(0), e1 = cad.get(1);
        int primero = (e0.b == e1.a || e0.b == e1.b) ? e0.a : e0.b;
        v.add(primero);
        int act = primero;
        for (Boceto.Ent e : cad) {
            act = e.a == act ? e.b : e.a;
            v.add(act);
        }
        if (cerrada) v.remove(v.size() - 1);
        return v;
    }

    /** Desfase: copia paralela a la distancia d, hacia el lado donde tocó (x, y). Una línea de una cadena desfasa toda la cadena. */
    public static String desfase(Boceto b, int entId, double d, double x, double y) {
        Boceto.Ent e = b.entPorId(entId);
        if (e == null) return "Toque una línea, un círculo o un arco";
        if (d <= 0) return "La distancia debe ser mayor que cero";
        if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
            Boceto.Punto c = P(b, e.a);
            double dist = Math.hypot(x - c.x, y - c.y);
            double r = dist < e.r ? e.r - d : e.r + d;
            if (r <= 0.5) return "Hacia adentro no cabe: el radio es " + Formula.n(e.r) + " mm";
            if (e.tipo == Boceto.CIRCULO) {
                Boceto.Ent n = b.ent(Boceto.CIRCULO);
                n.a = e.a; n.r = r;
            } else {
                Boceto.Punto p1 = P(b, e.b), p2 = P(b, e.c);
                double a1 = Math.atan2(p1.y - c.y, p1.x - c.x), a2 = Math.atan2(p2.y - c.y, p2.x - c.x);
                Boceto.Punto q1 = b.punto(c.x + r * Math.cos(a1), c.y + r * Math.sin(a1)), q2 = b.punto(c.x + r * Math.cos(a2), c.y + r * Math.sin(a2));
                Boceto.Ent n = b.ent(Boceto.ARCO);
                n.a = e.a; n.b = q1.id; n.c = q2.id; n.r = r;
            }
            return null;
        }
        if (e.tipo != Boceto.LINEA) return "El texto no tiene desfase";
        boolean[] cerr = new boolean[1];
        List<Boceto.Ent> cad = cadena(b, e, cerr);
        List<Integer> v = vertices(cad, cerr[0]);
        int n = v.size();
        int nLados = cerr[0] ? n : n - 1;
        // normal izquierda de cada lado, en el sentido de los vértices
        double[][] nor = new double[nLados][];
        for (int i = 0; i < nLados; i++) {
            Boceto.Punto p = P(b, v.get(i)), q = P(b, v.get((i + 1) % n));
            double dx = q.x - p.x, dy = q.y - p.y, l = Math.hypot(dx, dy);
            if (l < 1e-9) return "Hay una línea sin largo";
            nor[i] = new double[]{-dy / l, dx / l};
        }
        // para qué lado: el del dedo respecto a la línea tocada
        int k = cad.indexOf(e);
        int ia = v.indexOf(e.a), ib = v.indexOf(e.b);
        int lado = Math.min(ia, ib);
        if (cerr[0] && Math.abs(ia - ib) > 1) lado = n - 1;
        Boceto.Punto pa = P(b, v.get(lado)), pb = P(b, v.get((lado + 1) % n));
        double cruz = (pb.x - pa.x) * (y - pa.y) - (pb.y - pa.y) * (x - pa.x);
        double s = cruz >= 0 ? d : -d;
        if (k < 0) return "No se encontró la línea";
        // los vértices nuevos: cruce de los lados corridos
        double[][] nv = new double[n][];
        for (int i = 0; i < n; i++) {
            int antes = i - 1, despues = i;
            if (!cerr[0] && i == 0) antes = -1;
            if (!cerr[0] && i == n - 1) despues = -1;
            if (cerr[0] && antes < 0) antes = n - 1;
            Boceto.Punto p = P(b, v.get(i));
            if (antes < 0 || despues < 0) {
                int lad = antes < 0 ? despues : antes;
                nv[i] = new double[]{p.x + nor[lad][0] * s, p.y + nor[lad][1] * s};
                continue;
            }
            Boceto.Punto a0 = P(b, v.get(antes)), a1 = p, b1 = P(b, v.get((despues + 1) % n));
            double[] x1 = {a0.x + nor[antes][0] * s, a0.y + nor[antes][1] * s}, x2 = {a1.x + nor[antes][0] * s, a1.y + nor[antes][1] * s};
            double[] y1 = {a1.x + nor[despues][0] * s, a1.y + nor[despues][1] * s}, y2 = {b1.x + nor[despues][0] * s, b1.y + nor[despues][1] * s};
            double[] c = cruceRectas(x1[0], x1[1], x2[0], x2[1], y1[0], y1[1], y2[0], y2[1]);
            nv[i] = c == null ? x2 : new double[]{c[0], c[1]};
        }
        int[] ids = new int[n];
        for (int i = 0; i < n; i++) ids[i] = b.punto(nv[i][0], nv[i][1]).id;
        for (int i = 0; i < nLados; i++) {
            Boceto.Ent orig = null;
            for (Boceto.Ent x0 : cad) {
                int a = v.get(i), q = v.get((i + 1) % n);
                if ((x0.a == a && x0.b == q) || (x0.a == q && x0.b == a)) orig = x0;
            }
            Boceto.Ent ln = b.ent(Boceto.LINEA);
            ln.a = ids[i]; ln.b = ids[(i + 1) % n];
            if (orig != null) {
                for (Boceto.Restr r : new ArrayList<>(b.restr))
                    if ((r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == orig.id) b.restriccion(r.tipo, ln.id, -1, -1, -1, null);
                boolean derecha = false;
                for (Boceto.Restr r : b.restr) if ((r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == orig.id) derecha = true;
                if (!derecha) b.restriccion(Boceto.PARAL, ln.id, orig.id, -1, -1, null);
            }
        }
        return null;
    }

    // ---------------- Recortar, extender, partir ----------------

    /** Recorta el pedazo de la entidad donde tocó, entre los cruces con las demás. */
    public static String recortar(Boceto b, int entId, double x, double y) {
        Boceto.Ent e = b.entPorId(entId);
        if (e == null) return "Toque el pedazo que quiere quitar";
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto a = P(b, e.a), q = P(b, e.b);
            double dx = q.x - a.x, dy = q.y - a.y, l2 = dx * dx + dy * dy;
            if (l2 < 1e-9) return "Esa línea no tiene largo";
            double tt = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / l2));
            List<double[]> cortes = new ArrayList<>();   // {t, entCortadora}
            for (Boceto.Ent f : b.ents) {
                if (f == e) continue;
                for (double[] c : cruces(b, e, f)) {
                    double t = ((c[0] - a.x) * dx + (c[1] - a.y) * dy) / l2;
                    if (t > 1e-6 && t < 1 - 1e-6) cortes.add(new double[]{t, f.id});
                }
            }
            if (cortes.isEmpty()) return "Esa línea no cruza con nada: para quitarla toda use 🗑 Borrar";
            cortes.sort((m, n) -> Double.compare(m[0], n[0]));
            double t0 = 0, t1 = 1; int f0 = -1, f1 = -1;
            for (double[] c : cortes) {
                if (c[0] <= tt) { t0 = c[0]; f0 = (int) c[1]; }
                else { t1 = c[0]; f1 = (int) c[1]; break; }
            }
            quitarCotasDe(b, e.id);
            if (t0 == 0 && t1 == 1) return "No se pudo recortar";
            if (t0 == 0) {          // se quita el comienzo
                Boceto.Punto n = b.punto(a.x + dx * t1, a.y + dy * t1);
                e.a = n.id;
                sobre(b, n.id, f1);
            } else if (t1 == 1) {   // se quita el final
                Boceto.Punto n = b.punto(a.x + dx * t0, a.y + dy * t0);
                e.b = n.id;
                sobre(b, n.id, f0);
            } else {                // se quita el medio: quedan dos líneas
                Boceto.Punto n0 = b.punto(a.x + dx * t0, a.y + dy * t0), n1 = b.punto(a.x + dx * t1, a.y + dy * t1);
                int viejoB = e.b;
                e.b = n0.id;
                Boceto.Ent otra = b.ent(Boceto.LINEA);
                otra.a = n1.id; otra.b = viejoB;
                copiarHV(b, e.id, otra.id);
                sobre(b, n0.id, f0);
                sobre(b, n1.id, f1);
            }
            b.limpiarPuntos();
            return null;
        }
        if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
            Boceto.Punto c = P(b, e.a);
            List<Double> angs = new ArrayList<>();
            for (Boceto.Ent f : b.ents) {
                if (f == e) continue;
                for (double[] k : cruces(b, e, f)) angs.add(ang(c.x, c.y, k[0], k[1]));
            }
            double at = ang(c.x, c.y, x, y);
            if (e.tipo == Boceto.CIRCULO) {
                if (angs.size() < 2) return "El círculo necesita cruzar en dos puntos para recortarlo";
                angs.sort(Double::compare);
                // el pedazo tocado va de a0 a a1 (contra el reloj); queda el resto: de a1 a a0
                double a0 = angs.get(angs.size() - 1), a1 = angs.get(0);
                for (int i = 0; i < angs.size(); i++) {
                    double s0 = angs.get(i), s1 = angs.get((i + 1) % angs.size());
                    if (enArco(at, s0, s1)) { a0 = s0; a1 = s1; break; }
                }
                Boceto.Punto q1 = b.punto(c.x + e.r * Math.cos(a1), c.y + e.r * Math.sin(a1));
                Boceto.Punto q2 = b.punto(c.x + e.r * Math.cos(a0), c.y + e.r * Math.sin(a0));
                e.tipo = Boceto.ARCO;
                e.b = q1.id; e.c = q2.id;
                quitarCotasDe(b, e.id);
                return null;
            }
            Boceto.Punto p1 = P(b, e.b), p2 = P(b, e.c);
            double s = ang(c.x, c.y, p1.x, p1.y), f = ang(c.x, c.y, p2.x, p2.y);
            List<Double> dentro = new ArrayList<>();
            for (double a : angs) if (enArco(a, s, f) && norm(a - s) > 1e-6 && norm(f - a) > 1e-6) dentro.add(norm(a - s));
            if (dentro.isEmpty()) return "Ese arco no cruza con nada";
            dentro.sort(Double::compare);
            double dt = norm(at - s), d0 = 0, d1 = norm(f - s);
            for (double k : dentro) { if (k <= dt) d0 = k; else { d1 = k; break; } }
            double barr = norm(f - s);
            if (d0 == 0) { e.b = b.punto(c.x + e.r * Math.cos(s + d1), c.y + e.r * Math.sin(s + d1)).id; }
            else if (Math.abs(d1 - barr) < 1e-9) { e.c = b.punto(c.x + e.r * Math.cos(s + d0), c.y + e.r * Math.sin(s + d0)).id; }
            else {
                int viejoC = e.c;
                e.c = b.punto(c.x + e.r * Math.cos(s + d0), c.y + e.r * Math.sin(s + d0)).id;
                Boceto.Ent otro = b.ent(Boceto.ARCO);
                otro.a = e.a; otro.r = e.r;
                otro.b = b.punto(c.x + e.r * Math.cos(s + d1), c.y + e.r * Math.sin(s + d1)).id;
                otro.c = viejoC;
            }
            b.limpiarPuntos();
            return null;
        }
        return "El texto no se recorta";
    }

    /** Alarga la punta de la línea más cercana a donde tocó hasta la primera cosa que encuentre. */
    public static String extender(Boceto b, int entId, double x, double y) {
        Boceto.Ent e = b.entPorId(entId);
        if (e == null || e.tipo != Boceto.LINEA) return "Toque una línea cerca de la punta que quiere alargar";
        Boceto.Punto a = P(b, e.a), q = P(b, e.b);
        boolean final_ = Math.hypot(x - q.x, y - q.y) < Math.hypot(x - a.x, y - a.y);
        Boceto.Punto desde = final_ ? a : q, punta = final_ ? q : a;
        double dx = punta.x - desde.x, dy = punta.y - desde.y, l = Math.hypot(dx, dy);
        if (l < 1e-9) return "Esa línea no tiene largo";
        double far = 1e7;
        double ex = punta.x + dx / l * far, ey = punta.y + dy / l * far;
        double mejor = Double.MAX_VALUE; double[] donde = null; int con = -1;
        for (Boceto.Ent f : b.ents) {
            if (f == e || f.tipo == Boceto.TEXTO) continue;
            List<double[]> cs = new ArrayList<>();
            if (f.tipo == Boceto.LINEA) {
                Boceto.Punto c = P(b, f.a), d = P(b, f.b);
                double[] k = cruceRectas(punta.x, punta.y, ex, ey, c.x, c.y, d.x, d.y);
                if (k != null && k[3] > -1e-9 && k[3] < 1 + 1e-9 && k[2] > 1e-9) cs.add(new double[]{k[0], k[1]});
            } else {
                Boceto.Punto c = P(b, f.a);
                for (double[] k : cruceRectaCirculo(punta.x, punta.y, ex, ey, c.x, c.y, f.r))
                    if (k[2] > 1e-9 && (f.tipo == Boceto.CIRCULO || enArcoEnt(b, f, k[0], k[1]))) cs.add(new double[]{k[0], k[1]});
            }
            for (double[] k : cs) {
                double dd = Math.hypot(k[0] - punta.x, k[1] - punta.y);
                if (dd > 0.01 && dd < mejor) { mejor = dd; donde = k; con = f.id; }
            }
        }
        if (donde == null) return "Al alargarla no toca nada";
        quitarCotasDe(b, e.id);
        boolean compartido = false;
        for (Boceto.Ent f : b.ents) if (f != e && puntosDe(f).contains(punta.id)) compartido = true;
        if (compartido) {
            Boceto.Punto n = b.punto(donde[0], donde[1]);
            if (final_) e.b = n.id; else e.a = n.id;
            sobre(b, n.id, con);
        } else {
            punta.x = donde[0]; punta.y = donde[1];
            sobre(b, punta.id, con);
        }
        return null;
    }

    /** Parte la línea (o el arco) en el punto (x, y): quedan dos que comparten ese punto. */
    public static String partir(Boceto b, int entId, double x, double y) {
        Boceto.Ent e = b.entPorId(entId);
        if (e == null) return "Toque la línea donde la quiere partir";
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto a = P(b, e.a), q = P(b, e.b);
            double dx = q.x - a.x, dy = q.y - a.y, l2 = dx * dx + dy * dy;
            double t = ((x - a.x) * dx + (y - a.y) * dy) / l2;
            if (t <= 0.001 || t >= 0.999) return "Toque más adentro de la línea, no en la punta";
            Boceto.Punto n = b.punto(a.x + dx * t, a.y + dy * t);
            int viejoB = e.b;
            e.b = n.id;
            Boceto.Ent otra = b.ent(Boceto.LINEA);
            otra.a = n.id; otra.b = viejoB;
            quitarCotasDe(b, e.id);
            copiarHV(b, e.id, otra.id);
            // las dos siguen en línea recta
            b.restriccion(Boceto.PARAL, e.id, otra.id, -1, -1, null);
            return null;
        }
        if (e.tipo == Boceto.ARCO) {
            Boceto.Punto c = P(b, e.a);
            if (!enArcoEnt(b, e, x, y)) return "Toque sobre el arco";
            double an = Math.atan2(y - c.y, x - c.x);
            Boceto.Punto n = b.punto(c.x + e.r * Math.cos(an), c.y + e.r * Math.sin(an));
            int viejoC = e.c;
            e.c = n.id;
            Boceto.Ent otro = b.ent(Boceto.ARCO);
            otro.a = e.a; otro.b = n.id; otro.c = viejoC; otro.r = e.r;
            b.restriccion(Boceto.IGUAL, e.id, otro.id, -1, -1, null);
            return null;
        }
        return "Solo se parten líneas y arcos";
    }

    // ---------------- Empalme y chaflán ----------------

    /** Redondea (radio) o corta (chaflán: distancia) la esquina del punto donde se juntan dos líneas. */
    public static String esquina(Boceto b, int puntoId, double medida, boolean redondo) {
        Boceto.Punto p = P(b, puntoId);
        if (p == null) return "Toque la esquina (el punto donde se juntan dos líneas)";
        List<Boceto.Ent> ls = new ArrayList<>();
        for (Boceto.Ent e : b.ents) if (e.tipo == Boceto.LINEA && (e.a == puntoId || e.b == puntoId)) ls.add(e);
        if (ls.size() != 2) return "En esa esquina deben juntarse exactamente dos líneas (hay " + ls.size() + ")";
        if (medida <= 0) return "La medida debe ser mayor que cero";
        Boceto.Ent l1 = ls.get(0), l2 = ls.get(1);
        Boceto.Punto o1 = P(b, l1.a == puntoId ? l1.b : l1.a), o2 = P(b, l2.a == puntoId ? l2.b : l2.a);
        double L1 = Math.hypot(o1.x - p.x, o1.y - p.y), L2 = Math.hypot(o2.x - p.x, o2.y - p.y);
        double[] u1 = {(o1.x - p.x) / L1, (o1.y - p.y) / L1}, u2 = {(o2.x - p.x) / L2, (o2.y - p.y) / L2};
        double cos = u1[0] * u2[0] + u1[1] * u2[1];
        double th = Math.acos(Math.max(-1, Math.min(1, cos)));
        if (th < 0.01 || th > Math.PI - 0.01) return "Las dos líneas están en línea recta: no hay esquina";
        double d = redondo ? medida / Math.tan(th / 2) : medida;
        if (d >= L1 - 0.01 || d >= L2 - 0.01) return "No cabe: las líneas son muy cortas para " + Formula.n(medida) + " mm";
        Boceto.Punto t1 = b.punto(p.x + u1[0] * d, p.y + u1[1] * d), t2 = b.punto(p.x + u2[0] * d, p.y + u2[1] * d);
        if (l1.a == puntoId) l1.a = t1.id; else l1.b = t1.id;
        if (l2.a == puntoId) l2.a = t2.id; else l2.b = t2.id;
        quitarCotasDe(b, l1.id);
        quitarCotasDe(b, l2.id);
        // los amarres y cotas que usaban la esquina se quitan (el punto desaparece)
        b.restr.removeIf(r -> r.p1 == puntoId || r.p2 == puntoId);
        if (redondo) {
            double bx = u1[0] + u2[0], by = u1[1] + u2[1], bl = Math.hypot(bx, by);
            double h = medida / Math.sin(th / 2);
            Boceto.Punto c = b.punto(p.x + bx / bl * h, p.y + by / bl * h);
            Boceto.Ent arco = b.ent(Boceto.ARCO);
            arco.a = c.id; arco.r = medida;
            // el arco va contra el reloj del inicio al final por el lado corto
            double a1 = ang(c.x, c.y, t1.x, t1.y), a2 = ang(c.x, c.y, t2.x, t2.y);
            if (norm(a2 - a1) <= Math.PI) { arco.b = t1.id; arco.c = t2.id; } else { arco.b = t2.id; arco.c = t1.id; }
            b.restriccion(Boceto.TANG, l1.id, arco.id, -1, -1, null);
            b.restriccion(Boceto.TANG, l2.id, arco.id, -1, -1, null);
            b.restriccion(Boceto.C_RADIO, arco.id, -1, -1, -1, Formula.n(medida));
        } else {
            Boceto.Ent ln = b.ent(Boceto.LINEA);
            ln.a = t1.id; ln.b = t2.id;
        }
        b.limpiarPuntos();
        return null;
    }

    // ---------------- Medir ----------------

    /** Área y perímetro de la figura cerrada que tiene adentro el punto (x, y): {área mm², perímetro mm} o null. */
    public static double[] area(Boceto b, double x, double y) {
        double[] mejor = null;
        Set<Integer> hechas = new HashSet<>();
        for (Boceto.Ent e : b.ents) {
            if (e.tipo == Boceto.CIRCULO) {
                Boceto.Punto c = P(b, e.a);
                if (c != null && Math.hypot(x - c.x, y - c.y) <= e.r) {
                    double a = Math.PI * e.r * e.r;
                    if (mejor == null || a < mejor[0]) mejor = new double[]{a, 2 * Math.PI * e.r};
                }
            }
            if (e.tipo != Boceto.LINEA || hechas.contains(e.id)) continue;
            boolean[] cerr = new boolean[1];
            List<Boceto.Ent> cad = cadena(b, e, cerr);
            for (Boceto.Ent k : cad) hechas.add(k.id);
            if (!cerr[0]) continue;
            List<Integer> v = vertices(cad, true);
            int n = v.size();
            double s = 0, per = 0;
            boolean dentro = false;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                Boceto.Punto pi = P(b, v.get(i)), pj = P(b, v.get(j));
                s += pj.x * pi.y - pi.x * pj.y;
                per += Math.hypot(pi.x - pj.x, pi.y - pj.y);
                if ((pi.y > y) != (pj.y > y) && x < (pj.x - pi.x) * (y - pi.y) / (pj.y - pi.y) + pi.x) dentro = !dentro;
            }
            double a = Math.abs(s) / 2;
            if (dentro && (mejor == null || a < mejor[0])) mejor = new double[]{a, per};
        }
        return mejor;
    }

    /** Ángulo entre dos líneas (0..180). */
    public static double anguloEntre(Boceto b, Boceto.Ent e, Boceto.Ent f) {
        Boceto.Punto a = P(b, e.a), q = P(b, e.b), c = P(b, f.a), d = P(b, f.b);
        double a1 = Math.atan2(q.y - a.y, q.x - a.x), a2 = Math.atan2(d.y - c.y, d.x - c.x);
        double g = Math.abs(Math.toDegrees(a1 - a2)) % 360;
        if (g > 180) g = 360 - g;
        return g;
    }

    // ---------------- Pedacitos ----------------

    /** Quita las cotas de largo e «igual» de una línea que cambió de largo. */
    static void quitarCotasDe(Boceto b, int entId) {
        b.restr.removeIf(r -> (r.tipo == Boceto.C_LARGO || r.tipo == Boceto.IGUAL || r.tipo == Boceto.C_RADIO || r.tipo == Boceto.C_DIAM)
                && (r.e1 == entId || r.e2 == entId));
    }

    static void copiarHV(Boceto b, int de, int a) {
        for (Boceto.Restr r : new ArrayList<>(b.restr))
            if ((r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == de) b.restriccion(r.tipo, a, -1, -1, -1, null);
    }

    /** El punto nuevo queda amarrado sobre la entidad que lo cortó (así sigue pegado si la otra se mueve). */
    static void sobre(Boceto b, int punto, int ent) {
        Boceto.Ent e = b.entPorId(ent);
        if (e == null || e.tipo == Boceto.TEXTO) return;
        b.restriccion(Boceto.SOBRE, ent, -1, punto, -1, null);
    }

    // ---------------- Versión 4: figuras cerradas para extruir ----------------

    /** Una figura cerrada: las piezas del borde, las de sus huecos y sus polígonos (mm). */
    public static class Figura {
        public List<Integer> borde;
        public final List<List<Integer>> huecos = new ArrayList<>();
        public double[][] pol;
        public final List<double[][]> polHuecos = new ArrayList<>();
    }

    /** Todas las figuras cerradas del boceto: círculos sueltos y cadenas de líneas y arcos. */
    static List<List<Integer>> lazos(Boceto b) {
        List<List<Integer>> r = new ArrayList<>();
        Map<Integer, List<Boceto.Ent>> porPunto = new HashMap<>();
        for (Boceto.Ent e : b.ents) {
            if (e.punteada) continue;   // v6.3: las líneas punteadas (construcción, dobleces) no cierran figuras
            if (e.tipo == Boceto.CIRCULO) { List<Integer> l = new ArrayList<>(); l.add(e.id); r.add(l); }
            int[] pp = extremos(e);
            if (pp == null) continue;
            porPunto.computeIfAbsent(pp[0], k -> new ArrayList<>()).add(e);
            porPunto.computeIfAbsent(pp[1], k -> new ArrayList<>()).add(e);
        }
        Set<Integer> vistos = new HashSet<>();
        for (Boceto.Ent e : b.ents) {
            if (e.punteada) continue;
            int[] pp = extremos(e);
            if (pp == null || vistos.contains(e.id)) continue;
            // seguir la cadena desde e hasta volver
            List<Integer> l = new ArrayList<>();
            Boceto.Ent act = e;
            int punta = pp[1];
            boolean cerrada = false;
            Set<Integer> aqui = new HashSet<>();
            while (true) {
                l.add(act.id);
                aqui.add(act.id);
                List<Boceto.Ent> v = porPunto.get(punta);
                if (v == null || v.size() != 2) break;
                Boceto.Ent sig = v.get(0) == act ? v.get(1) : v.get(0);
                if (sig == e) { cerrada = true; break; }
                if (aqui.contains(sig.id)) break;
                int[] sp = extremos(sig);
                punta = sp[0] == punta ? sp[1] : sp[0];
                act = sig;
            }
            if (cerrada) { vistos.addAll(aqui); r.add(l); }
        }
        return r;
    }

    private static int[] extremos(Boceto.Ent e) {
        if (e.tipo == Boceto.LINEA) return new int[]{e.a, e.b};
        if (e.tipo == Boceto.ARCO) return new int[]{e.b, e.c};
        return null;
    }

    /** El polígono (mm) de una figura cerrada dada por sus piezas (en orden de cadena). Null si ya no cierra. */
    public static double[][] poligono(Boceto b, List<Integer> ents) {
        List<double[]> pts = new ArrayList<>();
        if (ents.size() == 1) {
            Boceto.Ent e = b.entPorId(ents.get(0));
            if (e == null || e.tipo != Boceto.CIRCULO) return null;
            Boceto.Punto c = P(b, e.a);
            if (c == null) return null;
            for (int i = 0; i < 40; i++) { double a = 2 * Math.PI * i / 40; pts.add(new double[]{c.x + e.r * Math.cos(a), c.y + e.r * Math.sin(a)}); }
            return pts.toArray(new double[0][]);
        }
        List<Boceto.Ent> l = new ArrayList<>();
        for (Integer id : ents) { Boceto.Ent e = b.entPorId(id); if (e == null || extremos(e) == null) return null; l.add(e); }
        int[] p0 = extremos(l.get(0)), p1 = extremos(l.get(1));
        int act = (p0[1] == p1[0] || p0[1] == p1[1]) ? p0[0] : p0[1];
        int primero = act;
        for (Boceto.Ent e : l) {
            int[] pp = extremos(e);
            if (pp[0] != act && pp[1] != act) return null;
            int otro = pp[0] == act ? pp[1] : pp[0];
            Boceto.Punto a = P(b, act), q = P(b, otro);
            if (a == null || q == null) return null;
            pts.add(new double[]{a.x, a.y});
            if (e.tipo == Boceto.ARCO) {
                Boceto.Punto c = P(b, e.a);
                double s0 = ang(c.x, c.y, P(b, e.b).x, P(b, e.b).y), barr = norm(ang(c.x, c.y, P(b, e.c).x, P(b, e.c).y) - s0);
                int n = Math.max(2, (int) Math.ceil(barr / (Math.PI / 16)));
                boolean ida = act == e.b;
                for (int i = 1; i < n; i++) {
                    double an = ida ? s0 + barr * i / n : s0 + barr * (n - i) / n;
                    pts.add(new double[]{c.x + e.r * Math.cos(an), c.y + e.r * Math.sin(an)});
                }
            }
            act = otro;
        }
        if (act != primero) return null;
        return pts.toArray(new double[0][]);
    }

    static boolean adentro(double[][] pol, double x, double y) {
        boolean d = false;
        for (int i = 0, j = pol.length - 1; i < pol.length; j = i++)
            if ((pol[i][1] > y) != (pol[j][1] > y) && x < (pol[j][0] - pol[i][0]) * (y - pol[i][1]) / (pol[j][1] - pol[i][1]) + pol[i][0]) d = !d;
        return d;
    }

    static double areaPol(double[][] pol) {
        double a = 0;
        for (int i = 0, j = pol.length - 1; i < pol.length; j = i++) a += pol[j][0] * pol[i][1] - pol[i][0] * pol[j][1];
        return Math.abs(a) / 2;
    }

    /**
     * Versión 4.1: las «casillas» del dibujo, como el sombreado de AutoCAD: aunque las líneas se crucen o sigan de largo.
     * Se recorre el dibujo doblando siempre por el mismo lado; cada vuelta cerrada es una casilla.
     */
    public static List<List<Integer>> casillas(Boceto b) {
        List<List<Integer>> r = new ArrayList<>();
        // primero se parten las líneas donde se cruzan (solo para buscar; el dibujo no cambia)
        Map<Integer, List<double[]>> porPunto = new HashMap<>();   // punto → {ángulo de salida, ent, otro punto}
        for (Boceto.Ent e : b.ents) {
            if (e.punteada) continue;
            int[] pp = extremos(e);
            if (pp == null || pp[0] == pp[1]) continue;
            Boceto.Punto p0 = P(b, pp[0]), p1 = P(b, pp[1]);
            if (p0 == null || p1 == null) continue;
            double a0, a1;
            if (e.tipo == Boceto.LINEA) { a0 = Math.atan2(p1.y - p0.y, p1.x - p0.x); a1 = Math.atan2(p0.y - p1.y, p0.x - p1.x); }
            else {
                // arco: la dirección de salida es la tangente en cada punta
                Boceto.Punto c = P(b, e.a);
                double t0 = Math.atan2(p0.y - c.y, p0.x - c.x), t1 = Math.atan2(p1.y - c.y, p1.x - c.x);
                a0 = t0 + Math.PI / 2;   // del inicio sale contra el reloj
                a1 = t1 - Math.PI / 2;   // del final sale con el reloj
            }
            porPunto.computeIfAbsent(pp[0], k -> new ArrayList<>()).add(new double[]{a0, e.id, pp[1]});
            porPunto.computeIfAbsent(pp[1], k -> new ArrayList<>()).add(new double[]{a1, e.id, pp[0]});
        }
        for (List<double[]> l : porPunto.values()) l.sort((m, n) -> Double.compare(m[0], n[0]));
        Set<String> usados = new HashSet<>();
        for (Map.Entry<Integer, List<double[]>> en : porPunto.entrySet()) {
            for (double[] sal : en.getValue()) {
                String k0 = en.getKey() + ">" + (int) sal[1] + ">" + (int) sal[2];
                if (usados.contains(k0)) continue;
                List<Integer> cara = new ArrayList<>();
                int desde = en.getKey(), ent = (int) sal[1], hasta = (int) sal[2];
                int pasos = 0;
                boolean ok = false;
                while (pasos++ < 2000) {
                    String k = desde + ">" + ent + ">" + hasta;
                    if (usados.contains(k)) { ok = k.equals(k0); break; }
                    usados.add(k);
                    cara.add(ent);
                    // en «hasta», la siguiente salida justo antes (con el reloj) de la que regresa
                    List<double[]> sl = porPunto.get(hasta);
                    int idx = -1;
                    for (int i = 0; i < sl.size(); i++) if ((int) sl.get(i)[1] == ent && (int) sl.get(i)[2] == desde) { idx = i; break; }
                    if (idx < 0) break;
                    double[] sig = sl.get((idx - 1 + sl.size()) % sl.size());
                    desde = hasta; ent = (int) sig[1]; hasta = (int) sig[2];
                }
                if (!ok || cara.size() < 2) continue;
                // quitar las líneas que van y vuelven (las que sobresalen)
                boolean cambio = true;
                while (cambio) {
                    cambio = false;
                    for (int i = 0; i < cara.size(); i++) {
                        int j = (i + 1) % cara.size();
                        if (cara.size() > 1 && cara.get(i).equals(cara.get(j))) {
                            if (j > i) { cara.remove(j); cara.remove(i); } else { cara.remove(i); cara.remove(j); }
                            cambio = true;
                            break;
                        }
                    }
                }
                if (cara.size() >= 2) r.add(cara);
            }
        }
        return r;
    }

    /** Las figuras: círculos sueltos y casillas (sin la de afuera de todo). */
    static List<List<Integer>> figuras(Boceto b, List<double[][]> pols) {
        List<List<Integer>> r = new ArrayList<>();
        for (Boceto.Ent e : b.ents) if (e.tipo == Boceto.CIRCULO) { List<Integer> l = new ArrayList<>(); l.add(e.id); r.add(l); }
        for (List<Integer> c : casillas(b)) {
            double[][] p = poligono(b, c);
            if (p == null || p.length < 3) continue;
            double s = 0;
            for (int i = 0, j = p.length - 1; i < p.length; j = i++) s += p[j][0] * p[i][1] - p[i][0] * p[j][1];
            if (s <= 1e-6) continue;   // la vuelta de afuera va al revés: no es casilla
            r.add(c);
        }
        for (List<Integer> l : r) pols.add(poligono(b, l));
        return r;
    }

    /** La figura cerrada más pequeña que tiene adentro (x, y), con las figuras que quedan dentro de ella como huecos. */
    public static Figura figuraEn(Boceto b, double x, double y) {
        List<double[][]> pols = new ArrayList<>();
        List<List<Integer>> ls = figuras(b, pols);
        int mejor = -1;
        double am = Double.MAX_VALUE;
        for (int i = 0; i < ls.size(); i++) {
            double[][] p = pols.get(i);
            if (p == null || p.length < 3 || !adentro(p, x, y)) continue;
            double a = areaPol(p);
            if (a < am) { am = a; mejor = i; }
        }
        // el dedo puede caer dentro de un hueco: entonces se busca la figura que contiene a ese hueco
        if (mejor < 0) return null;
        Figura f = new Figura();
        f.borde = ls.get(mejor);
        f.pol = pols.get(mejor);
        for (int i = 0; i < ls.size(); i++) {
            if (i == mejor || pols.get(i) == null) continue;
            boolean comparte = false;
            for (Integer id : ls.get(i)) if (f.borde.contains(id)) comparte = true;
            if (comparte) continue;
            double[][] p = pols.get(i);
            boolean todo = true;
            for (double[] q : p) if (!adentro(f.pol, q[0], q[1])) { todo = false; break; }
            if (todo && areaPol(p) < am) { f.huecos.add(ls.get(i)); f.polHuecos.add(p); }
        }
        return f;
    }

    // ---------------- Versión 4.4: el doctor del boceto ----------------

    /** Las puntas sueltas: puntos donde llega una sola línea o arco (sin contar líneas punteadas). */
    public static List<Integer> puntasSueltas(Boceto b) {
        Map<Integer, Integer> grado = new HashMap<>();
        for (Boceto.Ent e : b.ents) {
            if (e.punteada) continue;
            int[] pp = extremos(e);
            if (pp == null || pp[0] == pp[1]) continue;
            grado.merge(pp[0], 1, Integer::sum);
            grado.merge(pp[1], 1, Integer::sum);
        }
        // un punto que cae sobre otra línea (amarre SOBRE o MEDIO) no está suelto
        java.util.Set<Integer> sobre = new java.util.HashSet<>();
        for (Boceto.Restr r : b.restr) if ((r.tipo == Boceto.SOBRE || r.tipo == Boceto.MEDIO) && r.p1 >= 0) sobre.add(r.p1);
        List<Integer> r = new ArrayList<>();
        for (Map.Entry<Integer, Integer> g : grado.entrySet()) if (g.getValue() == 1 && !sobre.contains(g.getKey())) r.add(g.getKey());
        return r;
    }

    /** Parejas de puntas sueltas más cercanas entre sí: {punta, punta, distancia}. */
    public static List<double[]> parejasSueltas(Boceto b, List<Integer> sueltas) {
        List<double[]> r = new ArrayList<>();
        List<Integer> quedan = new ArrayList<>(sueltas);
        while (quedan.size() >= 2) {
            double mejor = Double.MAX_VALUE; int ia = -1, ib = -1;
            for (int i = 0; i < quedan.size(); i++) for (int j = i + 1; j < quedan.size(); j++) {
                Boceto.Punto p = P(b, quedan.get(i)), q = P(b, quedan.get(j));
                if (p == null || q == null) continue;
                double d = Math.hypot(p.x - q.x, p.y - q.y);
                if (d < mejor) { mejor = d; ia = i; ib = j; }
            }
            if (ia < 0) break;
            r.add(new double[]{quedan.get(ia), quedan.get(ib), mejor});
            quedan.remove(ib); quedan.remove(ia);
        }
        return r;
    }
}
