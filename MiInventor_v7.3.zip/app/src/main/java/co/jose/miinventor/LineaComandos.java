package co.jose.miinventor;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * v7.3 ChpWork: la línea de comandos del boceto, como la de AutoCAD.
 * Arriba lo último que pasó, luego lo que pide el comando (en español) y lo que usted escribe.
 * Debajo el mini teclado propio: números (con / pulgadas, ″, coma para ancho,alto) y, con ABC, letras en el orden del celular.
 */
final class LineaComandos extends LinearLayout {

    interface Oyente {
        void enter(String texto);          // ENTER (texto puede venir vacío)
        void esc();                        // ESC: cancela lo que se está haciendo
        void tecladoCambio(boolean visible);
    }

    private final Activity act;
    private final float d;
    Oyente oyente;

    private final TextView hist, indic, entrada, botonTeclado;
    private final LinearLayout teclado;
    private String txt = "";
    private int cur = 0;
    private boolean letras;

    LineaComandos(Activity a) {
        super(a);
        act = a;
        d = a.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF05070A);
        g.setStroke((int) (1.5f * d), 0xFF3D5A80);
        setBackground(g);
        setPadding(dp(6), dp(3), dp(4), dp(3));

        hist = new TextView(a);
        hist.setTypeface(Typeface.MONOSPACE);
        hist.setTextSize(11);
        hist.setTextColor(0xFF8FA0B5);
        hist.setSingleLine(true);
        hist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        addView(hist, new LayoutParams(-1, -2));

        LinearLayout fila = new LinearLayout(a);
        fila.setGravity(Gravity.CENTER_VERTICAL);
        indic = new TextView(a);
        indic.setTypeface(Typeface.MONOSPACE);
        indic.setTextSize(12);
        indic.setTextColor(Color.WHITE);
        indic.setMaxLines(2);
        indic.setEllipsize(android.text.TextUtils.TruncateAt.END);
        fila.addView(indic, new LayoutParams(0, -2, 1f));
        botonTeclado = tecla("⌨", 0xFF1565C0, Color.WHITE, 18);
        botonTeclado.setOnClickListener(v -> mostrarTeclado(!tecladoVisible()));
        LayoutParams bp = new LayoutParams(dp(46), dp(34));
        bp.leftMargin = dp(4);
        fila.addView(botonTeclado, bp);
        addView(fila, new LayoutParams(-1, -2));

        entrada = new TextView(a);
        entrada.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        entrada.setTextSize(15);
        entrada.setTextColor(0xFFFFCF40);
        entrada.setSingleLine(true);
        addView(entrada, new LayoutParams(-1, -2));

        teclado = new LinearLayout(a);
        teclado.setOrientation(VERTICAL);
        teclado.setPadding(0, dp(3), 0, 0);
        addView(teclado, new LayoutParams(-1, -2));
        armarTeclado();
        teclado.setVisibility(GONE);
        pintar();
    }

    private int dp(float v) { return (int) (v * d); }

    // ---------------- Lo que se ve ----------------

    void indicacion(String s) { indic.setText(s == null ? "" : s); }

    void historial(String s) { hist.setText(s == null ? "" : s); }

    String texto() { return txt; }

    void limpiar() { txt = ""; cur = 0; pintar(); }

    boolean tecladoVisible() { return teclado.getVisibility() == VISIBLE; }

    void mostrarTeclado(boolean ver) {
        if (ver == tecladoVisible()) return;
        teclado.setVisibility(ver ? VISIBLE : GONE);
        colorear(botonTeclado, ver ? 0xFFFF8F00 : 0xFF1565C0);
        pintar();
        if (oyente != null) oyente.tecladoCambio(ver);
    }

    private void pintar() {
        String con = txt.substring(0, cur) + "▌" + txt.substring(cur);
        String vivo = vista(txt);
        entrada.setText("» " + con + (vivo.isEmpty() ? "" : "   " + vivo));
        entrada.setVisibility(tecladoVisible() || !txt.isEmpty() ? VISIBLE : GONE);
    }

    /** El resultado en vivo: 1/4 = 6.35 · 100,90 = 100 , 90. */
    private static String vista(String t) {
        if (t.trim().isEmpty()) return "";
        List<String> ps = partes(t);
        StringBuilder sb = new StringBuilder("= ");
        for (int i = 0; i < ps.size(); i++) {
            if (i > 0) sb.append(" , ");
            String f = aFormula(ps.get(i));
            if (f.isEmpty()) { sb.append("…"); continue; }
            if (f.replace("pulg", "").matches(".*[A-Za-zÁÉÍÓÚáéíóúñÑ].*")) { sb.append("fórmula"); continue; }
            try { sb.append(Formula.n(Formula.calcular(f, k -> null))); } catch (Throwable e) { sb.append("?"); }
        }
        return sb.toString();
    }

    // ---------------- Para el que usa lo escrito ----------------

    /** Parte lo escrito por las comas de afuera (no las que van dentro de paréntesis): «100,100» → [100, 100]. */
    static List<String> partes(String t) {
        List<String> r = new ArrayList<>();
        int nivel = 0, ini = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == '(') nivel++;
            else if (c == ')') nivel--;
            else if (c == ',' && nivel <= 0) { r.add(t.substring(ini, i).trim()); ini = i + 1; }
        }
        r.add(t.substring(ini).trim());
        return r;
    }

    /** Una parte escrita → fórmula: «/» = pulgadas (1/4 queda pulg(1/4), así la cota muestra 1/4″), ″ = pulgadas enteras, ÷ = dividir. */
    static String aFormula(String p) {
        String x = p == null ? "" : p.trim().replace('−', '-');
        if (x.isEmpty()) return "";
        if (x.matches("\\d+(\\.\\d+)?\\s*/\\s*\\d+")) return "pulg(" + x.replace(" ", "") + ")";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+)\\s+(\\d+)\\s*/\\s*(\\d+)$").matcher(x);
        if (m.matches()) return "pulg(" + m.group(1) + "+" + m.group(2) + "/" + m.group(3) + ")";
        return Teclado.pulgadas(x);
    }

    // ---------------- El mini teclado ----------------

    private void armarTeclado() {
        teclado.removeAllViews();
        if (!letras) {
            String[][] f = {
                    {"7", "8", "9", "/", "″", "⌫"},
                    {"4", "5", "6", "×", "÷", "("},
                    {"1", "2", "3", "−", "+", ")"},
                    {"0", "00", ".", ",", "◀", "▶"}};
            for (String[] r : f) fila(r, null, 40);
            fila(new String[]{"ABC", "ESC", "ENTER"}, new float[]{1, 1, 3}, 42);
        } else {
            fila(new String[]{"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"}, null, 40);
            fila(new String[]{"A", "S", "D", "F", "G", "H", "J", "K", "L", "Ñ"}, null, 40);
            fila(new String[]{"123", "Z", "X", "C", "V", "B", "N", "M", "⌫"}, new float[]{2, 1, 1, 1, 1, 1, 1, 1, 1}, 40);
            fila(new String[]{"ESPACIO", "ESC", "ENTER"}, new float[]{5, 1.5f, 3}, 42);
        }
    }

    private void fila(String[] ks, float[] pesos, int alto) {
        LinearLayout f = new LinearLayout(act);
        for (int i = 0; i < ks.length; i++) {
            String k = ks[i];
            boolean num = k.matches("[0-9.]+|[A-ZÑ]");
            int fondo = k.equals("ENTER") ? 0xFF2E7D32 : k.equals("ABC") || k.equals("123") ? 0xFF1565C0
                    : k.equals("⌫") || k.equals("ESC") ? 0xFFC62828 : num ? 0xFFE9EDF2 : 0xFFCFD8DC;
            int letra = k.equals("ENTER") || k.equals("ABC") || k.equals("123") || k.equals("⌫") || k.equals("ESC") ? Color.WHITE
                    : k.equals("/") || k.equals("″") ? 0xFFE65100 : 0xFF111111;
            TextView t = tecla(k, fondo, letra, k.length() > 2 ? 14 : 19);
            LayoutParams p = new LayoutParams(0, dp(alto), pesos == null ? 1f : pesos[i]);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            f.addView(t, p);
            t.setOnClickListener(v -> pulsar(k));
            if (k.equals("⌫")) t.setOnLongClickListener(v -> { limpiar(); return true; });
        }
        teclado.addView(f, new LayoutParams(-1, -2));
    }

    private void pulsar(String k) {
        switch (k) {
            case "ENTER": {
                String t = txt;
                limpiar();
                if (oyente != null) oyente.enter(t);
                return;
            }
            case "ESC": limpiar(); if (oyente != null) oyente.esc(); return;
            case "ABC": letras = true; armarTeclado(); return;
            case "123": letras = false; armarTeclado(); return;
            case "◀": if (cur > 0) cur--; pintar(); return;
            case "▶": if (cur < txt.length()) cur++; pintar(); return;
            case "⌫":
                if (cur > 0) { txt = txt.substring(0, cur - 1) + txt.substring(cur); cur--; }
                pintar();
                return;
            default: {
                String ins = k.equals("ESPACIO") ? " " : k.equals("−") ? "-" : k;
                txt = txt.substring(0, cur) + ins + txt.substring(cur);
                cur += ins.length();
                pintar();
            }
        }
    }

    private TextView tecla(String k, int fondo, int letra, int tam) {
        TextView t = new TextView(act);
        t.setText(k);
        t.setTextSize(tam);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(letra);
        t.setIncludeFontPadding(false);
        colorear(t, fondo);
        return t;
    }

    private void colorear(View t, int fondo) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(7 * d);
        t.setBackground(g);
    }
}
