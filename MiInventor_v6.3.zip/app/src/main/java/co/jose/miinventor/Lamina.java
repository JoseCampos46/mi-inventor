package co.jose.miinventor;

import java.util.ArrayList;
import java.util.List;

/** Versión 4.4: lámina doblada — los tramos en 3D, los bordes que se pueden doblar y el desarrollo plano. */
public class Lamina {

    public static final String[] CALIBRES = {"Cal 24", "Cal 22", "Cal 20", "Cal 18", "Cal 16", "Cal 14", "Cal 12", "1/8\"", "3/16\""};
    public static final float[] GRUESOS = {0.6f, 0.75f, 0.9f, 1.2f, 1.5f, 1.9f, 2.5f, 3.2f, 4.8f};

    /** Un borde donde se puede doblar (o donde ya hay un doblez). */
    public static class Borde {
        public float[] a, b, e, w, n;   // puntas (mundo), dirección del borde, hacia afuera, hacia arriba
        public int padre = -1, borde = -1;
        public float largo;
        public String nombre;
    }

    /** Un tramo doblado para dibujar en 3D: una placa con su marco. */
    public static class Tramo {
        public float[] marco;           // origen, eje X, eje Y, normal
        public float[][] rect;
        public boolean alReves;
    }

    static float[] mas(float[] a, float[] b, float k) { return new float[]{a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k}; }
    static float[] por(float[] a, float k) { return new float[]{a[0] * k, a[1] * k, a[2] * k}; }
    static float pp(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
    static float[] cruz(float[] a, float[] b) { return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }
    static float[] unir(float[] a) { float l = (float) Math.sqrt(pp(a, a)); return l < 1e-9f ? a : por(a, 1 / l); }

    public static float grueso(Pieza p) { return p.largo > 0 ? p.largo : 1.2f; }
    public static float radio(Pieza p) { return p.radio > 0 ? p.radio : grueso(p); }

    /** Los bordes de la cara principal (en el mundo). */
    public static List<Borde> bordesBase(Pieza p) {
        List<Borde> r = new ArrayList<>();
        if (p.marco == null || p.contorno == null || p.contorno.length < 3) return r;
        float[] o = {p.marco[0], p.marco[1], p.marco[2]}, ex = {p.marco[3], p.marco[4], p.marco[5]}, ey = {p.marco[6], p.marco[7], p.marco[8]}, n = {p.marco[9], p.marco[10], p.marco[11]};
        float[][] c = p.contorno;
        double ar = 0;
        for (int i = 0; i < c.length; i++) { float[] q = c[i], s = c[(i + 1) % c.length]; ar += q[0] * s[1] - s[0] * q[1]; }
        float sg = ar >= 0 ? 1 : -1;
        for (int i = 0; i < c.length; i++) {
            float[] q = c[i], s = c[(i + 1) % c.length];
            float dx = s[0] - q[0], dy = s[1] - q[1], l = (float) Math.hypot(dx, dy);
            if (l < 0.5f) continue;
            Borde b = new Borde();
            b.a = mas(mas(o, ex, q[0]), ey, q[1]);
            b.b = mas(mas(o, ex, s[0]), ey, s[1]);
            b.e = unir(new float[]{b.b[0] - b.a[0], b.b[1] - b.a[1], b.b[2] - b.a[2]});
            float wx = dy / l * sg, wy = -dx / l * sg;
            b.w = unir(mas(por(ex, wx), ey, wy));
            b.n = n;
            b.borde = i;
            b.largo = l;
            b.nombre = "Borde " + (i + 1) + " · " + Pieza.n(l) + " mm";
            r.add(b);
        }
        return r;
    }

    /** El largo que se ve en 3D (por fuera). */
    static float largoFuera(Pieza p, Pieza.Doblez d) {
        return d.porDentro ? d.largo + grueso(p) * (float) Math.tan(Math.toRadians(d.angulo) / 2) : d.largo;
    }

    /** El borde de donde sale cada doblez y la punta que deja (índice = doblez). */
    public static Borde[][] armar(Pieza p, List<Tramo> tramos) {
        List<Borde> base = bordesBase(p);
        int nd = p.dobleces.size();
        Borde[] desde = new Borde[nd], punta = new Borde[nd];
        boolean cambio = true;
        int vueltas = 0;
        while (cambio && vueltas++ < nd + 2) {
            cambio = false;
            for (int i = 0; i < nd; i++) {
                if (desde[i] != null) continue;
                Pieza.Doblez d = p.dobleces.get(i);
                Borde b = null;
                if (d.padre < 0) { for (Borde x : base) if (x.borde == d.borde) b = x; }
                else if (d.padre < nd && punta[d.padre] != null) b = punta[d.padre];
                if (b == null) continue;
                desde[i] = b;
                double th = Math.toRadians(d.angulo);
                float s = d.abajo ? -1 : 1, ct = (float) Math.cos(th), st = (float) Math.sin(th);
                float[] w2 = unir(mas(por(b.w, ct), b.n, s * st));
                float[] n2 = unir(mas(por(b.n, ct), b.w, -s * st));
                float L = largoFuera(p, d);
                Borde q = new Borde();
                q.a = mas(b.a, w2, L); q.b = mas(b.b, w2, L); q.e = b.e; q.w = w2; q.n = n2; q.padre = i; q.largo = b.largo;
                q.nombre = "Punta del doblez " + (i + 1) + " · " + Pieza.n(b.largo) + " mm";
                punta[i] = q;
                if (tramos != null) {
                    Tramo t = new Tramo();
                    float[] nr = cruz(b.e, w2);
                    // el grueso va hacia adentro (sobre la lámina de donde sale)
                    float[] hacia = pp(n2, b.w) <= 0 ? n2 : por(n2, -1);
                    t.alReves = pp(hacia, nr) < 0;
                    t.marco = new float[]{b.a[0], b.a[1], b.a[2], b.e[0], b.e[1], b.e[2], w2[0], w2[1], w2[2], nr[0], nr[1], nr[2]};
                    t.rect = new float[][]{{0, 0}, {b.largo, 0}, {b.largo, L}, {0, L}};
                    tramos.add(t);
                }
                cambio = true;
            }
        }
        return new Borde[][]{desde, punta};
    }

    /** Los bordes libres donde se puede hacer un doblez nuevo. */
    public static List<Borde> bordesLibres(Pieza p) {
        List<Borde> r = new ArrayList<>();
        for (Borde b : bordesBase(p)) {
            boolean usado = false;
            for (Pieza.Doblez d : p.dobleces) if (d.padre < 0 && d.borde == b.borde) usado = true;
            if (!usado) r.add(b);
        }
        Borde[][] a = armar(p, null);
        for (int i = 0; i < p.dobleces.size(); i++) {
            if (a[1][i] == null) continue;
            boolean usado = false;
            for (Pieza.Doblez d : p.dobleces) if (d.padre == i) usado = true;
            if (!usado) r.add(a[1][i]);
        }
        return r;
    }

    // ---------------- Desarrollo ----------------

    static float ossb(Pieza p, Pieza.Doblez d) { return (radio(p) + grueso(p)) * (float) Math.tan(Math.toRadians(d.angulo) / 2); }
    static float ba(Pieza p, Pieza.Doblez d) { return (float) Math.toRadians(d.angulo) * (radio(p) + p.kFactor * grueso(p)); }

    /** El desarrollo plano dibujado en un boceto nuevo (mm, con las líneas de doblez punteadas). Devuelve {ancho, alto}. */
    public static double[] desarrollo(Pieza p, Boceto b) {
        float[][] c = p.contorno;
        int nd = p.dobleces.size();
        double ar = 0;
        for (int i = 0; i < c.length; i++) { float[] q = c[i], s = c[(i + 1) % c.length]; ar += q[0] * s[1] - s[0] * q[1]; }
        float sg = ar >= 0 ? 1 : -1;
        // el hijo de cada doblez (el doblez que sale de su punta)
        int[] hijo = new int[nd];
        java.util.Arrays.fill(hijo, -1);
        for (int i = 0; i < nd; i++) { int pa = p.dobleces.get(i).padre; if (pa >= 0 && pa < nd) hijo[pa] = i; }
        java.util.Set<Integer> bordesConDoblez = new java.util.HashSet<>();
        for (Pieza.Doblez d : p.dobleces) if (d.padre < 0) bordesConDoblez.add(d.borde);
        List<double[]> lineas = new ArrayList<>();   // x1,y1,x2,y2, punteada(0/1)
        List<Object[]> textos = new ArrayList<>();
        List<double[]> tramos = new ArrayList<>();   // v6.2: la medida de cada pestaña
        for (int i = 0; i < c.length; i++) if (!bordesConDoblez.contains(i))
            lineas.add(new double[]{c[i][0], c[i][1], c[(i + 1) % c.length][0], c[(i + 1) % c.length][1], 0});
        for (int i = 0; i < nd; i++) {
            Pieza.Doblez d = p.dobleces.get(i);
            if (d.padre >= 0) continue;
            float[] q = c[d.borde % c.length], s = c[(d.borde + 1) % c.length];
            double dx = s[0] - q[0], dy = s[1] - q[1], l = Math.hypot(dx, dy);
            if (l < 0.5) continue;
            double wx = dy / l * sg, wy = -dx / l * sg;
            // la cadena de dobleces que salen de este borde
            double pos = 0;          // dónde empieza el material de este tramo (desde el borde)
            int k = i;
            boolean primero = true;
            while (k >= 0) {
                Pieza.Doblez dk = p.dobleces.get(k);
                float os = ossb(p, dk), b2 = ba(p, dk);
                int h = hijo[k];
                float plano = largoFuera(p, dk) - os - (h >= 0 ? ossb(p, p.dobleces.get(h)) : 0);
                double centro = (primero ? -os : pos) + b2 / 2;
                double fin = (primero ? -os : pos) + b2 + plano;
                double inicio = primero ? 0 : pos;
                // línea de doblez punteada
                lineas.add(new double[]{q[0] + wx * centro, q[1] + wy * centro, s[0] + wx * centro, s[1] + wy * centro, 1});
                                // v6.3: el letrero va en la mitad de la pestaña, lejos de las esquinas y de las cotas
                double medio = (centro + fin) / 2;
                textos.add(new Object[]{(q[0] + s[0]) / 2 + wx * medio, (q[1] + s[1]) / 2 + wy * medio, Pieza.n(dk.angulo) + "° " + (dk.abajo ? "⬇" : "⬆")});
                // los lados del tramo
                lineas.add(new double[]{q[0] + wx * inicio, q[1] + wy * inicio, q[0] + wx * fin, q[1] + wy * fin, 0});
                lineas.add(new double[]{s[0] + wx * inicio, s[1] + wy * inicio, s[0] + wx * fin, s[1] + wy * fin, 0});
                if (h < 0) lineas.add(new double[]{q[0] + wx * fin, q[1] + wy * fin, s[0] + wx * fin, s[1] + wy * fin, 0});
                tramos.add(new double[]{s[0] + wx * inicio, s[1] + wy * inicio, s[0] + wx * fin, s[1] + wy * fin});
                pos = fin;
                primero = false;
                k = h;
            }
        }
        // los huecos
        for (float[][] hu : p.agujeros) for (int i = 0; i < hu.length; i++)
            lineas.add(new double[]{hu[i][0], hu[i][1], hu[(i + 1) % hu.length][0], hu[(i + 1) % hu.length][1], 0});
        // v6.2: también los huecos y cortes hechos con boceto sobre la cara
        List<double[]> redondos = new ArrayList<>();   // x, y, diámetro
        for (Pieza.Hueco hu : p.huecos) {
            if (hu.tipo == 4 && hu.forma != null && hu.forma.length >= 3) {
                float[][] f = hu.forma;
                for (int i = 0; i < f.length; i++) lineas.add(new double[]{f[i][0], f[i][1], f[(i + 1) % f.length][0], f[(i + 1) % f.length][1], 0});
            } else if (hu.tipo == 0 || hu.tipo == 3) redondos.add(new double[]{hu.s, hu.u, hu.d1});
            else if (hu.tipo == 1 || hu.tipo == 2) {
                double a = hu.d1 / 2.0, bb = (hu.tipo == 1 ? hu.d1 : hu.d2) / 2.0;
                double[][] r = {{hu.s - a, hu.u - bb}, {hu.s + a, hu.u - bb}, {hu.s + a, hu.u + bb}, {hu.s - a, hu.u + bb}};
                for (int i = 0; i < 4; i++) lineas.add(new double[]{r[i][0], r[i][1], r[(i + 1) % 4][0], r[(i + 1) % 4][1], 0});
            }
        }
        // al boceto, redondeado a centésimas y con las puntas compartidas
        java.util.Map<String, Boceto.Punto> pts = new java.util.HashMap<>();
        double x0 = Double.MAX_VALUE, x1 = -Double.MAX_VALUE, y0 = Double.MAX_VALUE, y1 = -Double.MAX_VALUE;
        Boceto.Punto pIzq = null, pDer = null, pAba = null, pArr = null;
        for (double[] ln : lineas) {
            Boceto.Punto pa = pto(b, pts, ln[0], ln[1]), pb = pto(b, pts, ln[2], ln[3]);
            if (pa == pb) continue;
            Boceto.Ent e = b.linea(pa, pb);
            e.punteada = ln[4] == 1;
            if (e.punteada) continue;
            for (Boceto.Punto q : new Boceto.Punto[]{pa, pb}) {
                if (q.x < x0) { x0 = q.x; pIzq = q; }
                if (q.x > x1) { x1 = q.x; pDer = q; }
                if (q.y < y0) { y0 = q.y; pAba = q; }
                if (q.y > y1) { y1 = q.y; pArr = q; }
            }
        }
        for (Object[] t : textos) {
            Boceto.Ent e = b.ent(Boceto.TEXTO);
            e.a = b.punto((double) t[0], (double) t[1]).id;
            e.r = Math.max(6, Math.min(25, (x1 - x0) / 25));
            e.texto = (String) t[2];
        }
        for (double[] rd : redondos) {
            Boceto.Ent e = b.ent(Boceto.CIRCULO);
            e.a = pto(b, pts, rd[0], rd[1]).id;
            e.r = rd[2] / 2;
            b.restriccion(Boceto.C_DIAM, e.id, -1, -1, -1, Pieza.n((float) rd[2]));
        }
        for (double[] t : tramos) {
            Boceto.Punto pa = pto(b, pts, t[0], t[1]), pb = pto(b, pts, t[2], t[3]);
            if (pa != pb) b.restriccion(Boceto.C_DIST, -1, -1, pa.id, pb.id, Pieza.n((float) Math.hypot(t[2] - t[0], t[3] - t[1])));
        }
        if (pIzq != null && pDer != null && pIzq != pDer) b.restriccion(Boceto.C_HORIZ, -1, -1, pIzq.id, pDer.id, Pieza.n((float) (x1 - x0)));
        if (pAba != null && pArr != null && pAba != pArr) b.restriccion(Boceto.C_VERT, -1, -1, pAba.id, pArr.id, Pieza.n((float) (y1 - y0)));
        // v6.2: el desarrollo es un plano de corte, no un boceto para arreglar: todo queda fijo (sin "faltan medidas")
        for (Boceto.Punto q : b.puntos.values()) q.fijo = true;
        return new double[]{x1 - x0, y1 - y0};
    }

    private static Boceto.Punto pto(Boceto b, java.util.Map<String, Boceto.Punto> pts, double x, double y) {
        x = Math.round(x * 100) / 100.0;
        y = Math.round(y * 100) / 100.0;
        String k = x + "," + y;
        Boceto.Punto p = pts.get(k);
        if (p == null) { p = b.punto(x, y); pts.put(k, p); }
        return p;
    }
}
