package co.jose.miinventor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Dibujo en 3D (vista sin perspectiva, como los planos). Versión 2: un dedo corre la vista (o gira con 🔄,
 * o arrastra la pieza con ✋ Mover), dos dedos acercan y corren.
 * Tocar una pieza la escoge.
 */
public class Vista3D extends View {

    public interface AlEscoger { void escogida(int id); }
    /** Versión 2: el dedo arrastró la pieza escogida (mm en X, Y, Z). */
    public interface AlMover { void mover(int id, float dx, float dy, float dz); void soltar(); }

    /** Versión 2: 0 = un dedo corre la vista · 1 = un dedo gira (orbitar) · 2 = un dedo arrastra la pieza. */
    public static final int CORRER = 0, GIRAR = 1, MOVER = 2;
    public int modo = CORRER;
    public AlMover alMover;
    private float acX, acY, acZ;   // lo arrastrado que falta pasar (se pasa de 5 en 5 mm)

    public List<Pieza> piezas = new ArrayList<>();
    public int escogida = -1;
    public AlEscoger alEscoger;

    private float giro = -35, elev = 25;   // grados
    private float zoom = 1, panX, panY;
    private float escalaBase = 0.1f;
    private final float[] centro = {0, 0, 0};

    private final Paint pCara = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBorde = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTxt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pEje = new Paint(Paint.ANTI_ALIAS_FLAG);

    public Vista3D(Context c) {
        super(c);
        pBorde.setStyle(Paint.Style.STROKE);
        pBorde.setStrokeWidth(dp(0.8f));
        pBorde.setColor(0x66000000);
        pTxt.setTextSize(dp(12));
        pTxt.setFakeBoldText(true);
        pEje.setStrokeWidth(dp(2));
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    public void vista(float g, float e) { giro = g; elev = e; encuadrar(); }

    /** v6.4: la cámara del recorrido: giro, elevación, acercamiento y el punto que se mira (mm). */
    public void camara(float g, float e, float z, float cx, float cy, float cz) {
        giro = g; elev = e; zoom = z; panX = 0; panY = 0;
        centro[0] = cx; centro[1] = cy; centro[2] = cz;
        pivote = false;
        invalidate();
    }

    public float giro() { return giro; }
    public float elev() { return elev; }
    public float[] centro() { return centro.clone(); }

    /** Pone todo el trabajo dentro de la pantalla. Versión 3: mide lo que se ve de verdad, para que llene la pantalla. */
    public void encuadrar() {
        zoom = 1; panX = 0; panY = 0;
        float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, mx = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        Map<Integer, Pieza> mapa = mapa();
        List<float[]> pts = new ArrayList<>();
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] e = {s[0] + d[0] * p.largo, s[1] + d[1] * p.largo, s[2] + d[2] * p.largo};
            float r = Math.max(p.a, p.b) / 2;
            if (p.tipo == Pieza.PLACA && p.lamina && p.marco != null)
                for (Lamina.Tramo t : tramos(p)) for (float[] q : t.rect)
                    pts.add(new float[]{t.marco[0] + t.marco[3] * q[0] + t.marco[6] * q[1], t.marco[1] + t.marco[4] * q[0] + t.marco[7] * q[1], t.marco[2] + t.marco[5] * q[0] + t.marco[8] * q[1]});
            if (p.tipo == Pieza.PLACA && p.contorno != null) {
                float[][] ee = ejes(p);
                for (float[] q : p.contorno) for (float[] o : new float[][]{s, e})
                    pts.add(new float[]{o[0] + ee[1][0] * q[0] + ee[2][0] * q[1], o[1] + ee[1][1] * q[0] + ee[2][1] * q[1], o[2] + ee[1][2] * q[0] + ee[2][2] * q[1]});
                continue;
            }
            for (float[] q : new float[][]{s, e})
                for (int k = 0; k < 8; k++) pts.add(new float[]{q[0] + ((k & 1) == 0 ? -r : r), q[1] + ((k & 2) == 0 ? -r : r), q[2] + ((k & 4) == 0 ? -r : r)});
        }
        if (pts.isEmpty()) { pts.add(new float[]{0, 0, 0}); pts.add(new float[]{1000, 1000, 1000}); }
        for (float[] q : pts) for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], q[k]); mx[k] = Math.max(mx[k], q[k]); }
        for (int k = 0; k < 3; k++) centro[k] = (mn[k] + mx[k]) / 2f;
        pivote = false;
        // lo que ocupa en la pantalla con este giro (a escala 1)
        double g = Math.toRadians(giro), el = Math.toRadians(elev);
        float cg1 = (float) Math.cos(g), sg1 = (float) Math.sin(g), ce1 = (float) Math.cos(el), se1 = (float) Math.sin(el);
        float x0 = Float.MAX_VALUE, x1 = -Float.MAX_VALUE, y0 = Float.MAX_VALUE, y1 = -Float.MAX_VALUE;
        for (float[] q : pts) {
            float x = q[0] - centro[0], y = q[1] - centro[1], z = q[2] - centro[2];
            float px = x * cg1 - y * sg1, yy = x * sg1 + y * cg1, arriba = z * ce1 + yy * se1;
            x0 = Math.min(x0, px); x1 = Math.max(x1, px); y0 = Math.min(y0, arriba); y1 = Math.max(y1, arriba);
        }
        float w = getWidth() > 0 ? getWidth() : dp(360), h = getHeight() > 0 ? getHeight() : dp(300);
        float anchoMm = Math.max(150, x1 - x0), altoMm = Math.max(150, y1 - y0);
        escalaBase = Math.min(w * 0.88f / anchoMm, (h - dp(40)) * 0.86f / altoMm);
        panX = -(x0 + x1) / 2 * escalaBase;
        panY = (y0 + y1) / 2 * escalaBase - dp(6);
        invalidate();
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        // versión 4.1: solo la primera vez; si sale una barrita abajo, la vista se queda donde estaba
        if (ow == 0 || oh == 0) encuadrar();
        else { panY += (h - oh) / 2f; invalidate(); }
    }

    // ---------------- Proyección ----------------

    private float cg, sg, ce, se, esc;

    private void prepararCamara() {
        double g = Math.toRadians(giro), e = Math.toRadians(elev);
        cg = (float) Math.cos(g); sg = (float) Math.sin(g);
        ce = (float) Math.cos(e); se = (float) Math.sin(e);
        esc = escalaBase * zoom;
    }

    /** Devuelve {x pantalla, y pantalla, profundidad}. */
    private float[] proyectar(float x, float y, float z) {
        x -= centro[0]; y -= centro[1]; z -= centro[2];
        float x1 = x * cg - y * sg;
        float y1 = x * sg + y * cg;
        float arriba = z * ce + y1 * se;
        float prof = y1 * ce - z * se;
        return new float[]{getWidth() / 2f + pxEf + x1 * esc, getHeight() / 2f + pyEf - arriba * esc, prof};
    }

    /** Qué tan de frente se ve una cara (para darle luz). */
    private float deFrente(float[] n) {
        float y1 = n[0] * sg + n[1] * cg;
        return y1 * ce - n[2] * se;   // negativo: mira hacia uno
    }

    private static class Cara {
        boolean csg;   // v6.6: viene del sólido cortado (se rellena sin rayitas entre triángulos)
        float[] xs, ys;
        float[][] hx, hy;        // versión 4: huecos de la cara (placas)
        float prof;
        int color;
        boolean borde = true;
        int pieza = -1, tipo;    // versión 4: de qué pieza es · 0 costado, 5 punta final, 6 punta inicio, 9 hueco
        float[] nrm, p0;         // normal y un punto de la cara (mm)
        float[][] w;             // versión 5: las esquinas de la cara en el mundo (mm)
        float[] seg;             // v6.3: solo estas rayas como borde (x1, y1, x2, y2, …) en las piezas con cortes
    }

    // ---------------- Versión 4: tocar caras ----------------

    /** Lo que se tocó: pieza, tipo de cara (0 costado, 5 punta final, 6 punta inicio), normal y el punto exacto (mm). */
    public interface AlTocarCara { void tocada(int pieza, int tipo, float[] nrm, float[] punto); }

    public AlTocarCara pideCara;              // mientras no sea null, tocar escoge caras
    /** Versión 4.3: tocar la pantalla para escoger una figura de un boceto. */
    public interface AlTocarPlano { void tocado(float x, float y); }
    public AlTocarPlano pideToque;
    public List<Hoja> hojas = new ArrayList<>();
    public int hojaResaltada = -1;
    /** Versión 4.4: bordes de lámina que se pueden doblar (en naranja). */
    public List<float[][]> bordesNaranja;

    /** El borde naranja más cerca del dedo (-1 si ninguno a menos de 40 dp). */
    public int bordeCerca(float x, float y) {
        if (bordesNaranja == null) return -1;
        prepararCamara();
        pxEf = panX; pyEf = panY;
        int mejor = -1;
        double dm = dp(60);
        for (int i = 0; i < bordesNaranja.size(); i++) {
            float[][] bo = bordesNaranja.get(i);
            float[] a = proyectar(bo[0][0], bo[0][1], bo[0][2]), b = proyectar(bo[1][0], bo[1][1], bo[1][2]);
            double vx = b[0] - a[0], vy = b[1] - a[1], l2 = vx * vx + vy * vy;
            double t = l2 < 1e-6 ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * vx + (y - a[1]) * vy) / l2));
            double d = Math.hypot(a[0] + vx * t - x, a[1] + vy * t - y);
            if (d < dm) { dm = d; mejor = i; }
        }
        return mejor;
    }

    private static List<Lamina.Tramo> tramos(Pieza p) {
        List<Lamina.Tramo> ts = new ArrayList<>();
        Lamina.armar(p, ts);
        return ts;
    }

    private static Pieza tramo(Pieza p, Lamina.Tramo t) {
        Pieza q = new Pieza();
        q.id = p.id; q.tipo = Pieza.PLACA; q.lamina = true;
        q.marco = t.marco; q.contorno = t.rect; q.largo = p.largo; q.alReves = t.alReves;
        q.medida = ""; q.calibre = "";
        return q;
    }

    /** El punto del plano (p0, n) que queda bajo el dedo. */
    public float[] enPlano(float x, float y, float[] p0, float[] n) { return desproyectar(x, y, p0, n); }
    public int resA = -1, resB = -1;          // caras resaltadas (naranja y azul)
    public float[] resNrmA, resNrmB;
    /** Versión 6.1: un punto de la cara resaltada (para que no se prendan otras caras paralelas). */
    public float[] resPtoA, resPtoB;
    /** Un punto de la última cara tocada. */
    public float[] caraP0;
    /** Versión 6.1: al tocar una cara (sin comando), se avisa para mostrar el menú de la cara. */
    public interface AlTocarCaraLibre { void cara(int pieza, float[] nrm, float[] punto, float[][] esquinas); }
    public AlTocarCaraLibre alCara;
    /** Líneas punteadas (dobleces de la lámina). */
    public List<float[][]> punteadas;
    private Pieza pzActual;
    private float[][] ejesActual;
    private final List<Cara> vistas = new ArrayList<>();   // las caras que se dibujaron (para tocar)

    private boolean esResaltada(int pieza, float[] n, int cual, float[] p0) {
        int id = cual == 0 ? resA : resB;
        float[] r = cual == 0 ? resNrmA : resNrmB;
        float[] pt = cual == 0 ? resPtoA : resPtoB;
        if (!(id == pieza && r != null && n != null && r[0] * n[0] + r[1] * n[1] + r[2] * n[2] > 0.995f)) return false;
        if (pt == null || p0 == null) return true;
        // versión 6.1: que sea la misma cara (mismo plano), no otra paralela
        return Math.abs((p0[0] - pt[0]) * n[0] + (p0[1] - pt[1]) * n[1] + (p0[2] - pt[2]) * n[2]) < 0.6f;
    }

    /** El punto (mm) sobre el plano de la cara que queda bajo el dedo. */
    private float[] desproyectar(float x, float y, float[] p0, float[] n) {
        prepararCamara();
        float x1 = (x - getWidth() / 2f - pxEf) / esc, arriba = -(y - getHeight() / 2f - pyEf) / esc;
        // punto = A + prof·B
        float[] A = mundo(x1, arriba, 0), B = mundo(x1, arriba, 1);
        float[] dB = {B[0] - A[0], B[1] - A[1], B[2] - A[2]};
        float den = dB[0] * n[0] + dB[1] * n[1] + dB[2] * n[2];
        if (Math.abs(den) < 1e-6) return A;
        float t = ((p0[0] - A[0]) * n[0] + (p0[1] - A[1]) * n[1] + (p0[2] - A[2]) * n[2]) / den;
        return new float[]{A[0] + dB[0] * t, A[1] + dB[1] * t, A[2] + dB[2] * t};
    }

    private float[] mundo(float x1, float arriba, float prof) {
        float y1 = arriba * se + prof * ce, z = arriba * ce - prof * se;
        float x = x1 * cg + y1 * sg, y = -x1 * sg + y1 * cg;
        return new float[]{x + centro[0], y + centro[1], z + centro[2]};
    }

    private static boolean dentro(float[] xs, float[] ys, float x, float y) {
        boolean d = false;
        for (int i = 0, j = xs.length - 1; i < xs.length; j = i++)
            if ((ys[i] > y) != (ys[j] > y) && x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]) d = !d;
        return d;
    }

    /** La cara más cercana bajo el dedo (la que se dibujó de última). */
    private boolean tocarCara(float x, float y) {
        for (int i = vistas.size() - 1; i >= 0; i--) {
            Cara k = vistas.get(i);
            if (k.pieza < 0 || k.tipo == 9 || !dentro(k.xs, k.ys, x, y)) continue;
            boolean enHueco = false;
            if (k.hx != null) for (int h = 0; h < k.hx.length; h++) if (dentro(k.hx[h], k.hy[h], x, y)) enHueco = true;
            if (enHueco) continue;
            float[] q = desproyectar(x, y, k.p0, k.nrm);
            caraPts = k.w;
            caraP0 = k.p0;
            pideCara.tocada(k.pieza, k.tipo, k.nrm, q);
            return true;
        }
        // versión 5: los planos de referencia también se pueden tocar (pieza = -1000 - id)
        if (aceptaPlanos) for (int i = planosVistos.size() - 1; i >= 0; i--) {
            Object[] pv = planosVistos.get(i);
            Ref r = (Ref) pv[0];
            if (!dentro((float[]) pv[1], (float[]) pv[2], x, y)) continue;
            float[] q = desproyectar(x, y, r.o, r.v);
            caraPts = null;
            pideCara.tocada(-1000 - r.id, 0, r.v, q);
            return true;
        }
        return false;
    }

    // ---------------- Versión 5: referencias, ejes para escoger y puntos marcados ----------------

    /** Las esquinas (mundo) de la última cara tocada (null si fue un plano de referencia). */
    public float[][] caraPts;
    public List<Ref> refs = new ArrayList<>();
    public boolean aceptaPlanos;
    private final List<Object[]> planosVistos = new ArrayList<>();
    /** Ejes que se pueden escoger (en morado, con número). */
    public List<float[][]> lineasEje;
    public int ejeResaltado = -1;
    /** Los ejes de los tubos y huecos, solo para verlos (morado clarito). */
    public List<float[][]> ejesVer;
    /** Puntos marcados (amarillo), por ejemplo el punto escogido para "punto con punto". */
    public List<float[]> marcas;
    public String version = "";

    /** Un punto del mundo en la pantalla (x, y). */
    public float[] pantalla(float[] p) {
        prepararCamara();
        pxEf = panX; pyEf = panY;
        return proyectar(p[0], p[1], p[2]);
    }

    /** El eje morado más cerca del dedo (-1 si ninguno a menos de 40 dp). */
    public int ejeCerca(float x, float y) {
        if (lineasEje == null) return -1;
        prepararCamara();
        pxEf = panX; pyEf = panY;
        int mejor = -1;
        double dm = dp(60);
        for (int i = 0; i < lineasEje.size(); i++) {
            float[][] l = lineasEje.get(i);
            float[] a = proyectar(l[0][0], l[0][1], l[0][2]), b = proyectar(l[1][0], l[1][1], l[1][2]);
            double vx = b[0] - a[0], vy = b[1] - a[1], l2 = vx * vx + vy * vy;
            double t = l2 < 1e-6 ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * vx + (y - a[1]) * vy) / l2));
            double d = Math.hypot(a[0] + vx * t - x, a[1] + vy * t - y);
            if (d < dm) { dm = d; mejor = i; }
        }
        return mejor;
    }

    /** La esquina o la mitad de una arista de la cara que queda más cerca del punto q. */
    static float[] imantar(float[][] pts, float[] q, boolean conCentro) {
        if (pts == null || pts.length == 0) return q;
        float[] mejor = pts[0];
        float dm = Float.MAX_VALUE;
        float[] cen = {0, 0, 0};
        for (int i = 0; i < pts.length; i++) {
            float[] a = pts[i], b = pts[(i + 1) % pts.length];
            float[] mid = {(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2};
            for (float[] c : new float[][]{a, mid}) {
                float d = Geo.dist(c, q);
                if (d < dm) { dm = d; mejor = c; }
            }
            cen = Geo.add(cen, a);
        }
        if (conCentro) {
            cen = Geo.mul(cen, 1f / pts.length);
            if (Geo.dist(cen, q) < dm) mejor = cen;
        }
        return mejor.clone();
    }

    private void dibujarRefs(Canvas c) {
        planosVistos.clear();
        Paint pl = new Paint(Paint.ANTI_ALIAS_FLAG);
        pl.setStyle(Paint.Style.STROKE);
        pl.setStrokeWidth(dp(1.6f));
        Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (Ref r : refs) {
            if (!r.visible) continue;
            if (r.tipo == Ref.PLANO) {
                float[] ey = r.ey(), ex = r.ex;
                float h = r.tam / 2;
                float[][] esq = {Geo.add(Geo.addk(r.o, ex, -h), Geo.mul(ey, -h)), Geo.add(Geo.addk(r.o, ex, h), Geo.mul(ey, -h)),
                        Geo.add(Geo.addk(r.o, ex, h), Geo.mul(ey, h)), Geo.add(Geo.addk(r.o, ex, -h), Geo.mul(ey, h))};
                float[] xs = new float[4], ys = new float[4];
                Path pa = new Path();
                for (int i = 0; i < 4; i++) {
                    float[] q = proyectar(esq[i]);
                    xs[i] = q[0]; ys[i] = q[1];
                    if (i == 0) pa.moveTo(q[0], q[1]); else pa.lineTo(q[0], q[1]);
                }
                pa.close();
                pf.setColor(aceptaPlanos ? 0x3364B5F6 : 0x2264B5F6);
                c.drawPath(pa, pf);
                pl.setColor(0xFF64B5F6);
                c.drawPath(pa, pl);
                planosVistos.add(new Object[]{r, xs, ys});
                pTxt.setColor(0xFF90CAF9);
                c.drawText("▱ " + r.nombre, xs[3] + dp(4), ys[3] + dp(14), pTxt);
            } else if (r.tipo == Ref.EJE) {
                float[] a = proyectar(Geo.addk(r.o, r.v, -r.tam / 2)), b = proyectar(Geo.addk(r.o, r.v, r.tam / 2));
                pl.setColor(0xFFCE93D8);
                linea(c, a, b, pl, true);
                pTxt.setColor(0xFFCE93D8);
                c.drawText("╱ " + r.nombre, b[0] + dp(4), b[1], pTxt);
            } else {
                float[] q = proyectar(r.o);
                pf.setColor(0xFFFFEB3B);
                Path d = new Path();
                d.moveTo(q[0], q[1] - dp(6)); d.lineTo(q[0] + dp(6), q[1]); d.lineTo(q[0], q[1] + dp(6)); d.lineTo(q[0] - dp(6), q[1]); d.close();
                c.drawPath(d, pf);
                pTxt.setColor(0xFFFFEB3B);
                c.drawText(r.nombre, q[0] + dp(8), q[1] - dp(4), pTxt);
            }
        }
        if (punteadas != null) {
            Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
            pp.setStrokeWidth(dp(1.8f));
            pp.setColor(0xFFFFFFFF);
            for (float[][] l : punteadas) linea(c, proyectar(l[0]), proyectar(l[1]), pp, true);
        }
        if (ejesVer != null && lineasEje == null) {
            Paint pv = new Paint(Paint.ANTI_ALIAS_FLAG);
            pv.setStrokeWidth(dp(1.5f));
            pv.setColor(0xAACE93D8);
            for (float[][] l : ejesVer) linea(c, proyectar(l[0]), proyectar(l[1]), pv, true);
        }
        if (lineasEje != null) {
            Paint pm = new Paint(Paint.ANTI_ALIAS_FLAG);
            pm.setStyle(Paint.Style.STROKE);
            for (int i = 0; i < lineasEje.size(); i++) {
                float[][] l = lineasEje.get(i);
                float[] a = proyectar(l[0]), b = proyectar(l[1]);
                boolean res = i == ejeResaltado;
                pm.setStrokeWidth(dp(res ? 4 : 2.5f));
                pm.setColor(res ? 0xFFFF6D00 : 0xFFE040FB);
                linea(c, a, b, pm, true);
                pTxt.setColor(res ? 0xFFFF6D00 : 0xFFE040FB);
                c.drawText("" + (i + 1), b[0] + dp(3), b[1] - dp(3), pTxt);
            }
        }
        if (marcas != null) {
            Paint pk = new Paint(Paint.ANTI_ALIAS_FLAG);
            pk.setColor(0xFFFFEB3B);
            pk.setStyle(Paint.Style.STROKE);
            pk.setStrokeWidth(dp(2.5f));
            for (float[] m : marcas) {
                float[] q = proyectar(m);
                c.drawCircle(q[0], q[1], dp(8), pk);
                c.drawLine(q[0] - dp(12), q[1], q[0] + dp(12), q[1], pk);
                c.drawLine(q[0], q[1] - dp(12), q[0], q[1] + dp(12), pk);
            }
        }
        pTxt.setColor(Color.WHITE);
    }

    /** Una línea (punteada si se pide). */
    private void linea(Canvas c, float[] a, float[] b, Paint p, boolean punteada) {
        if (!punteada) { c.drawLine(a[0], a[1], b[0], b[1], p); return; }
        float dx = b[0] - a[0], dy = b[1] - a[1], l = (float) Math.hypot(dx, dy);
        if (l < 1) return;
        float paso = dp(9);
        for (float t = 0; t < l; t += paso * 2) {
            float t2 = Math.min(l, t + paso * 1.3f);
            c.drawLine(a[0] + dx * t / l, a[1] + dy * t / l, a[0] + dx * t2 / l, a[1] + dy * t2 / l, p);
        }
    }

    private static float[] suma(float[] a, float[] b, float k) { return new float[]{a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k}; }

    private static float[] cruz(float[] a, float[] b) {
        return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static float[] unir(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return l < 1e-6 ? new float[]{0, 0, 1} : new float[]{v[0] / l, v[1] / l, v[2] / l};
    }

    /** Los ejes de la sección: s (ancho) y u (alto), perpendiculares a la pieza. */
    static float[][] ejes(Pieza p) {
        if (p.marco != null) {
            float[] m = p.marco;
            return new float[][]{{m[9], m[10], m[11]}, {m[3], m[4], m[5]}, {m[6], m[7], m[8]}};
        }
        float[] d = p.direccion();
        float[] u;
        if (Math.abs(d[2]) < 0.95f) u = unir(new float[]{-d[0] * d[2], -d[1] * d[2], 1 - d[2] * d[2]});
        else u = unir(new float[]{-d[0] * d[1], 1 - d[1] * d[1], -d[2] * d[1]});
        float[] s = unir(cruz(d, u));
        for (int k = 0; k < (p.giro & 3); k++) { float[] ns = u; u = new float[]{-s[0], -s[1], -s[2]}; s = ns; }
        return new float[][]{d, s, u};
    }

    /** La forma de la sección, como uno o dos polígonos en (s, u). */
    static List<float[][]> seccion(Pieza p) {
        List<float[][]> r = new ArrayList<>();
        float a = p.a, b = p.b, t = Math.max(1, p.t);
        if (p.tipo == Pieza.PLACA) {
            if (p.contorno != null && p.contorno.length >= 3) r.add(p.contorno);
            else r.add(rect(0, 0, 100, 100));
            return r;
        }
        switch (p.tipo) {
            case 2: {
                int n = 12;
                float[][] pol = new float[n][2];
                for (int i = 0; i < n; i++) { double an = 2 * Math.PI * i / n; pol[i][0] = (float) Math.cos(an) * a / 2; pol[i][1] = (float) Math.sin(an) * a / 2; }
                r.add(pol);
                break;
            }
            case 3:
                r.add(rect(-a / 2, -b / 2, a / 2, -b / 2 + t));
                r.add(rect(-a / 2, -b / 2 + t, -a / 2 + t, b / 2));
                break;
            case 4:
                r.add(rect(-a / 2, -t / 2, a / 2, t / 2));
                break;
            default:
                r.add(rect(-a / 2, -b / 2, a / 2, b / 2));
        }
        return r;
    }

    private static float[][] rect(float s0, float u0, float s1, float u1) {
        return new float[][]{{s0, u0}, {s1, u0}, {s1, u1}, {s0, u1}};
    }

    // ---------------- Dibujo ----------------

    // Versión 3: lupa mientras el dedo está quieto encima (o arrastrando una pieza)
    private boolean lupa, enLupa;
    private float dedoX, dedoY, pxEf, pyEf;
    private int candidata = -1;

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D1018);
        prepararCamara();
        pxEf = panX; pyEf = panY;
        escena(c);
        // v6.6: sin ejes largos ni «0,0,0» (el iconito X-Y-Z de la esquina basta)
        dibujarHojas(c);
        dibujarRefs(c);
        if (bordesNaranja != null) {
            Paint pn = new Paint(Paint.ANTI_ALIAS_FLAG);
            pn.setStrokeWidth(dp(4));
            pn.setColor(0xFFFF9800);
            pTxt.setColor(0xFFFF9800);
            int i = 1;
            for (float[][] bo : bordesNaranja) {
                float[] a = proyectar(bo[0][0], bo[0][1], bo[0][2]), b = proyectar(bo[1][0], bo[1][1], bo[1][2]);
                c.drawLine(a[0], a[1], b[0], b[1], pn);
                c.drawText("" + i++, (a[0] + b[0]) / 2 + dp(4), (a[1] + b[1]) / 2 - dp(4), pTxt);
            }
            pTxt.setColor(Color.WHITE);
        }
        if (pivote) {
            float[] q = proyectar(centro[0], centro[1], centro[2]);
            Paint pv = new Paint(Paint.ANTI_ALIAS_FLAG);
            pv.setStyle(Paint.Style.STROKE);
            pv.setStrokeWidth(dp(2.2f));
            pv.setColor(0xFFFF9800);
            c.drawCircle(q[0], q[1], dp(9), pv);
            c.drawLine(q[0] - dp(13), q[1], q[0] + dp(13), q[1], pv);
            c.drawLine(q[0], q[1] - dp(13), q[0], q[1] + dp(13), pv);
        }
        dibujarEjes(c);
        // v6.5: sin lupa
    }

    private void dibujarLupa(Canvas c) {
        float R = dp(64), k = 3f;
        float cx = dedoX < getWidth() / 2f ? getWidth() - R - dp(10) : R + dp(10);
        float cy = R + dp(10);
        if (dedoY < cy + R + dp(20)) cy = getHeight() - R - dp(10);
        Path circ = new Path();
        circ.addCircle(cx, cy, R, Path.Direction.CW);
        c.save();
        c.clipPath(circ);
        c.drawColor(0xFF0D1018);
        prepararCamara();
        esc *= k;
        enLupa = true;
        // el punto bajo el dedo queda en el centro de la lupa
        pxEf = cx + (getWidth() / 2f + panX - dedoX) * k - getWidth() / 2f;
        pyEf = cy + (getHeight() / 2f + panY - dedoY) * k - getHeight() / 2f;
        escena(c);
        enLupa = false;
        c.restore();
        prepararCamara();
        pxEf = panX; pyEf = panY;
        pEje.setColor(0x88FFB300);
        pEje.setStrokeWidth(dp(1));
        c.drawLine(cx - R, cy, cx + R, cy, pEje);
        c.drawLine(cx, cy - R, cx, cy + R, pEje);
        Paint borde = new Paint(Paint.ANTI_ALIAS_FLAG);
        borde.setStyle(Paint.Style.STROKE);
        borde.setStrokeWidth(dp(3));
        borde.setColor(0xFFFFB300);
        c.drawCircle(cx, cy, R, borde);
        pEje.setStrokeWidth(dp(2));
        String s = "Lupa ×3" + (candidata >= 0 ? " · T" + candidata : "");
        pTxt.setColor(Color.WHITE);
        c.drawText(s, cx - pTxt.measureText(s) / 2, cy + R + dp(16), pTxt);
    }

    private void escena(Canvas c) {
        Map<Integer, Pieza> mapa = mapa();
        List<Cara> caras = new ArrayList<>();
        for (Pieza p : piezas) if (!p.oculta) armarCaras(p, mapa, caras);
        Collections.sort(caras, (x, y) -> Float.compare(y.prof, x.prof));
        if (!enLupa) { vistas.clear(); vistas.addAll(caras); }
        Path path = new Path();
        for (Cara k : caras) {
            path.reset();
            path.moveTo(k.xs[0], k.ys[0]);
            for (int i = 1; i < k.xs.length; i++) path.lineTo(k.xs[i], k.ys[i]);
            path.close();
            if (k.hx != null) {
                path.setFillType(Path.FillType.EVEN_ODD);
                for (int h = 0; h < k.hx.length; h++) {
                    path.moveTo(k.hx[h][0], k.hy[h][0]);
                    for (int i = 1; i < k.hx[h].length; i++) path.lineTo(k.hx[h][i], k.hy[h][i]);
                    path.close();
                }
            } else path.setFillType(Path.FillType.WINDING);
            pCara.setColor(k.color);
            if (k.csg) { pCara.setStyle(Paint.Style.FILL_AND_STROKE); pCara.setStrokeWidth(1.6f); }
            c.drawPath(path, pCara);
            pCara.setStyle(Paint.Style.FILL);
            if (k.borde) c.drawPath(path, pBorde);
            if (k.seg != null) for (int i = 0; i + 3 < k.seg.length; i += 4) c.drawLine(k.seg[i], k.seg[i + 1], k.seg[i + 2], k.seg[i + 3], pBorde);
        }
        // v6.6: sin letreros de nombre en el 3D (al tocar la pieza sale el nombre un momento)
    }

    private void armarCaras(Pieza p, Map<Integer, Pieza> mapa, List<Cara> caras) {
        // versión 4.4: la lámina doblada = la cara principal + cada doblez como una placa más
        if (p.tipo == Pieza.PLACA && p.lamina && p.marco != null && !p.dobleces.isEmpty()) {
            for (Lamina.Tramo t : tramos(p)) armarCaras(tramo(p, t), mapa, caras);
        }
        float[][] e = ejes(p);
        pzActual = p; ejesActual = e;
        float[] d = e[0], s = e[1], u = e[2];
        float[] ini = p.inicio(mapa, 0);
        float[] fin = suma(ini, d, p.largo);
        int base = p.tinte != 0 ? p.tinte : p.id == candidata && lupa ? 0xFFFF7043 : p.tipo == 3 ? 0xFFEF9F27 : p.tipo == 4 ? 0xFF90A4AE
                : p.tipo == Pieza.PLACA ? (p.lamina ? 0xFFB0BEC5 : 0xFF64B5F6) : 0xFF5DCAA5;
        // versión 4: puntas cortadas inclinadas
        float ti = (float) Math.tan(Math.toRadians(Math.max(-75, Math.min(75, p.corteIni))));
        float tf = (float) Math.tan(Math.toRadians(Math.max(-75, Math.min(75, p.corteFin))));
        float[] wi = unir(new float[]{s[0] * p.ciS + u[0] * p.ciU, s[1] * p.ciS + u[1] * p.ciU, s[2] * p.ciS + u[2] * p.ciU});
        float[] wf = unir(new float[]{s[0] * p.cfS + u[0] * p.cfU, s[1] * p.cfS + u[1] * p.cfU, s[2] * p.cfS + u[2] * p.cfU});
        float[] nIni = unir(new float[]{-d[0] + ti * wi[0], -d[1] + ti * wi[1], -d[2] + ti * wi[2]});
        float[] nFin = unir(new float[]{d[0] + tf * wf[0], d[1] + tf * wf[1], d[2] + tf * wf[2]});
        boolean placa = p.tipo == Pieza.PLACA;
        List<float[][]> secs = seccion(p);
        // las placas tienen huecos: del boceto y los perforados
        List<float[][]> hue = new ArrayList<>();
        if (placa) {
            hue.addAll(p.agujeros);
            for (Pieza.Hueco h : p.huecos) hue.add(poligonoHueco(h));
        }
        if (placa && !p.cortes.isEmpty() && !(p.lamina && !p.dobleces.isEmpty())) {   // v6.3: pieza con cortes = resta de sólidos
            if (carasCsg(p, ini, d, s, u, secs, hue, base, caras)) return;
        }
        for (float[][] pol : secs) {
            int n = pol.length;
            boolean ccw = area(pol) >= 0;
            float[][] a3 = new float[n][], b3 = new float[n][];
            for (int i = 0; i < n; i++) {
                float[] off = {s[0] * pol[i][0] + u[0] * pol[i][1], s[1] * pol[i][0] + u[1] * pol[i][1], s[2] * pol[i][0] + u[2] * pol[i][1]};
                float ki = off[0] * wi[0] + off[1] * wi[1] + off[2] * wi[2], kf = off[0] * wf[0] + off[1] * wf[1] + off[2] * wf[2];
                a3[i] = suma(suma(ini, off, 1), d, ti * ki);
                b3[i] = suma(suma(fin, off, 1), d, -tf * kf);
            }
            // costados
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float[] nrm;
                if (placa || n > 4) {
                    float es = pol[j][0] - pol[i][0], eu = pol[j][1] - pol[i][1];
                    float ns = ccw ? eu : -eu, nu = ccw ? -es : es;
                    nrm = unir(new float[]{s[0] * ns + u[0] * nu, s[1] * ns + u[1] * nu, s[2] * ns + u[2] * nu});
                } else {
                    float ms = (pol[i][0] + pol[j][0]) / 2, mu = (pol[i][1] + pol[j][1]) / 2;
                    nrm = unir(new float[]{s[0] * ms + u[0] * mu, s[1] * ms + u[1] * mu, s[2] * ms + u[2] * mu});
                }
                agregar(caras, new float[][]{a3[i], a3[j], b3[j], b3[i]}, nrm, base, n <= 4 || placa, p.id, 0);
            }
            // tapas (con los huecos de la placa)
            Cara kf = agregar(caras, b3, nFin, base, true, p.id, 5);
            float[][] inv = new float[n][];
            for (int i = 0; i < n; i++) inv[i] = a3[n - 1 - i];
            Cara ki = agregar(caras, inv, nIni, base, true, p.id, 6);
            if (placa && !hue.isEmpty()) {
                for (Cara k : new Cara[]{kf, ki}) {
                    if (k == null) continue;
                    float[] org = k == kf ? fin : ini;
                    k.hx = new float[hue.size()][];
                    k.hy = new float[hue.size()][];
                    for (int h = 0; h < hue.size(); h++) {
                        float[][] hp = hue.get(h);
                        k.hx[h] = new float[hp.length];
                        k.hy[h] = new float[hp.length];
                        for (int i = 0; i < hp.length; i++) {
                            float[] q = proyectar(org[0] + s[0] * hp[i][0] + u[0] * hp[i][1], org[1] + s[1] * hp[i][0] + u[1] * hp[i][1], org[2] + s[2] * hp[i][0] + u[2] * hp[i][1]);
                            k.hx[h][i] = q[0];
                            k.hy[h][i] = q[1];
                        }
                    }
                }
                // las paredes de adentro de cada hueco
                for (float[][] hp : hue) {
                    int m = hp.length;
                    boolean hc = area(hp) >= 0;
                    for (int i = 0; i < m; i++) {
                        int j = (i + 1) % m;
                        float es = hp[j][0] - hp[i][0], eu = hp[j][1] - hp[i][1];
                        float ns = hc ? -eu : eu, nu = hc ? es : -es;   // hacia el centro del hueco
                        float[] nrm = unir(new float[]{s[0] * ns + u[0] * nu, s[1] * ns + u[1] * nu, s[2] * ns + u[2] * nu});
                        float[] oi = {s[0] * hp[i][0] + u[0] * hp[i][1], s[1] * hp[i][0] + u[1] * hp[i][1], s[2] * hp[i][0] + u[2] * hp[i][1]};
                        float[] oj = {s[0] * hp[j][0] + u[0] * hp[j][1], s[1] * hp[j][0] + u[1] * hp[j][1], s[2] * hp[j][0] + u[2] * hp[j][1]};
                        Cara k = agregar(caras, new float[][]{suma(ini, oi, 1), suma(ini, oj, 1), suma(fin, oj, 1), suma(fin, oi, 1)}, nrm, 0xFF37474F, false, p.id, 9);
                        if (k != null) k.prof += 0.5f;
                    }
                }
            }
        }
        if (placa) return;
        // huecos de los tubos: un parche oscuro sobre la cara (y en la de enfrente si es pasante)
        for (Pieza.Hueco h : p.huecos) {
            int[] lados = h.pasante ? new int[]{h.cara, opuesta(h.cara)} : new int[]{h.cara};
            for (int cr : lados) {
                float[] nrm, lado1;
                float sobre;
                switch (cr) {
                    case 1: nrm = new float[]{-u[0], -u[1], -u[2]}; lado1 = s; break;
                    case 2: nrm = s; lado1 = u; break;
                    case 3: nrm = new float[]{-s[0], -s[1], -s[2]}; lado1 = u; break;
                    default: nrm = u; lado1 = s;
                }
                sobre = p.alcance(nrm);
                float[] cen = suma(suma(ini, d, h.pos), nrm, sobre + 0.6f);
                if (h.tipo == 3) {   // avellanado: un anillo más claro alrededor
                    Cara an = hacer(circulo(cen, d, lado1, h.d1 * 0.9f, 14), nrm, 0xFF607D8B);
                    if (an != null) { an.prof -= 0.8f; an.borde = false; caras.add(an); }
                }
                float largoH = h.d1, anchoH = h.tipo == 2 ? h.d2 : h.d1;
                float[][] pts;
                if (h.tipo == 4 && h.forma != null) {
                    // versión 4.5: maquinado — la forma va medida desde el inicio de la pieza
                    float[] b0 = suma(ini, nrm, sobre + 0.6f);
                    pts = new float[h.forma.length][];
                    for (int i = 0; i < h.forma.length; i++) pts[i] = suma(suma(b0, d, h.forma[i][0]), lado1, h.forma[i][1]);
                } else if (h.tipo == 2) {
                    float[][] r = ranura(largoH, anchoH);
                    pts = new float[r.length][];
                    for (int i = 0; i < r.length; i++) pts[i] = suma(suma(cen, d, r[i][0]), lado1, r[i][1]);
                } else if (h.tipo == 0 || h.tipo == 3) pts = circulo(cen, d, lado1, h.d1 / 2, 12);
                else {
                    pts = new float[4][];
                    for (int i = 0; i < 4; i++) {
                        float ca = (i == 0 || i == 3 ? -1 : 1) * largoH / 2, cb = (i < 2 ? -1 : 1) * anchoH / 2;
                        pts[i] = suma(suma(cen, d, ca), lado1, cb);
                    }
                }
                Cara k = hacer(pts, nrm, 0xFF101010);
                if (k != null) { k.prof -= 1; k.borde = false; caras.add(k); }
            }
        }
    }

    // ---------------- v6.3: piezas con cortes en cualquier cara ----------------

    private final Map<Integer, Object[]> cacheCsg = new HashMap<>();

    private static double[] dd(float[] v) { return new double[]{v[0], v[1], v[2]}; }

    private boolean carasCsg(Pieza p, float[] ini, float[] d, float[] s, float[] u, List<float[][]> secs, List<float[][]> hue, int base, List<Cara> caras) {
        StringBuilder k = new StringBuilder();
        for (float[] v : new float[][]{ini, d, s, u}) k.append(v[0]).append(',').append(v[1]).append(',').append(v[2]).append(';');
        k.append(p.largo).append('|');
        for (float[][] pol : secs) for (float[] q : pol) k.append(q[0]).append(',').append(q[1]).append(';');
        k.append('|');
        for (float[][] pol : hue) for (float[] q : pol) k.append(q[0]).append(',').append(q[1]).append(';');
        k.append('|');
        for (Pieza.Corte c : p.cortes) {
            for (float[] q : c.forma) k.append(q[0]).append(',').append(q[1]).append(',').append(q[2]).append(';');
            k.append(c.n[0]).append(c.n[1]).append(c.n[2]).append(c.pasante).append(c.hondo).append('/');
        }
        String key = k.toString();
        Object[] cc = cacheCsg.get(p.id);
        List<Csg.Pol> sol;
        List<List<double[][]>> ar;
        Object arbol;
        if (cc != null && key.equals(cc[0])) {
            @SuppressWarnings("unchecked") List<Csg.Pol> s0 = (List<Csg.Pol>) cc[1];
            @SuppressWarnings("unchecked") List<List<double[][]>> a0 = (List<List<double[][]>>) cc[2];
            sol = s0; ar = a0; arbol = cc[3];
        } else {
            try {
                double[] D = dd(d), S = dd(s), U = dd(u), I = dd(ini);
                double[] dir = {D[0] * p.largo, D[1] * p.largo, D[2] * p.largo};
                sol = new ArrayList<>();
                float tam = p.largo;
                for (float[][] pol : secs) {
                    double[][] q = new double[pol.length][];
                    for (int i = 0; i < pol.length; i++) { q[i] = new double[]{pol[i][0], pol[i][1]}; tam = Math.max(tam, Math.abs(pol[i][0]) + Math.abs(pol[i][1])); }
                    sol.addAll(Csg.prisma(q, I, S, U, dir));
                }
                for (float[][] pol : hue) {   // los huecos de arriba a abajo
                    double[][] q = new double[pol.length][];
                    for (int i = 0; i < pol.length; i++) q[i] = new double[]{pol[i][0], pol[i][1]};
                    double[] o = {I[0] - D[0], I[1] - D[1], I[2] - D[2]};
                    double[] dl = {D[0] * (p.largo + 2), D[1] * (p.largo + 2), D[2] * (p.largo + 2)};
                    sol = Csg.restar(sol, Csg.prisma(q, o, S, U, dl));
                }
                for (Pieza.Corte c : p.cortes) {
                    if (c.forma == null || c.forma.length < 3) continue;
                    double[] n = {D[0] * c.n[0] + S[0] * c.n[1] + U[0] * c.n[2], D[1] * c.n[0] + S[1] * c.n[1] + U[1] * c.n[2], D[2] * c.n[0] + S[2] * c.n[1] + U[2] * c.n[2]};
                    double ln = Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
                    if (ln < 1e-6) continue;
                    n[0] /= ln; n[1] /= ln; n[2] /= ln;
                    // una base en el plano de la cara
                    double[] bx = Math.abs(n[2]) < 0.9 ? new double[]{-n[1], n[0], 0} : new double[]{1, 0, 0};
                    double lb = Math.sqrt(bx[0] * bx[0] + bx[1] * bx[1] + bx[2] * bx[2]);
                    bx[0] /= lb; bx[1] /= lb; bx[2] /= lb;
                    double[] by = {n[1] * bx[2] - n[2] * bx[1], n[2] * bx[0] - n[0] * bx[2], n[0] * bx[1] - n[1] * bx[0]};
                    double[][] w = new double[c.forma.length][];
                    for (int i = 0; i < c.forma.length; i++) {
                        float[] f = c.forma[i];
                        w[i] = new double[]{I[0] + D[0] * f[0] + S[0] * f[1] + U[0] * f[2], I[1] + D[1] * f[0] + S[1] * f[1] + U[1] * f[2], I[2] + D[2] * f[0] + S[2] * f[1] + U[2] * f[2]};
                    }
                    double[] o = {w[0][0] + n[0], w[0][1] + n[1], w[0][2] + n[2]};   // arranca 1 mm afuera de la cara
                    double[][] q = new double[w.length][];
                    for (int i = 0; i < w.length; i++) {
                        double rx = w[i][0] - w[0][0], ry = w[i][1] - w[0][1], rz = w[i][2] - w[0][2];
                        q[i] = new double[]{rx * bx[0] + ry * bx[1] + rz * bx[2], rx * by[0] + ry * by[1] + rz * by[2]};
                    }
                    double hondo = c.pasante ? 4 * tam + 20 : c.hondo + 1;
                    sol = Csg.restar(sol, Csg.prisma(q, o, bx, by, new double[]{-n[0] * hondo, -n[1] * hondo, -n[2] * hondo}));
                }
                // v6.6: árbol BSP para pintar en el orden exacto (el hueco ya no queda pintado encima de la pieza)
                arbol = Csg.arbol(sol);
                sol = Csg.todosDe(arbol);
                ar = Csg.aristas(sol);
            } catch (Throwable t) {
                return false;   // si algo sale mal se dibuja la pieza sin el corte
            }
            cacheCsg.put(p.id, new Object[]{key, sol, ar, arbol});
        }
        java.util.IdentityHashMap<Csg.Pol, Integer> idx = new java.util.IdentityHashMap<>();
        for (int i = 0; i < sol.size(); i++) idx.put(sol.get(i), i);
        List<Csg.Pol> ord = new ArrayList<>();
        Csg.orden(arbol, new double[]{sg * ce, cg * ce, -se}, ord);
        List<Cara> mias = new ArrayList<>();
        for (Csg.Pol q : ord) {
            Integer ii = idx.get(q);
            if (ii == null) continue;
            int i = ii;
            float[][] pts = new float[q.v.size()][];
            for (int j = 0; j < pts.length; j++) { double[] v = q.v.get(j); pts[j] = new float[]{(float) v[0], (float) v[1], (float) v[2]}; }
            float[] nrm = {(float) q.n[0], (float) q.n[1], (float) q.n[2]};
            Cara kk = agregar(caras, pts, nrm, base, false, p.id, 0);
            if (kk == null) continue;
            List<double[][]> la = ar.get(i);
            float[] sg = new float[la.size() * 4];
            for (int j = 0; j < la.size(); j++) {
                double[][] l = la.get(j);
                float[] a = proyectar((float) l[0][0], (float) l[0][1], (float) l[0][2]), b = proyectar((float) l[1][0], (float) l[1][1], (float) l[1][2]);
                sg[4 * j] = a[0]; sg[4 * j + 1] = a[1]; sg[4 * j + 2] = b[0]; sg[4 * j + 3] = b[1];
            }
            kk.seg = sg;
            kk.csg = true;
            mias.add(kk);
        }
        // todas a la misma hondura, en el orden del árbol: así el pintado global no las revuelve
        if (!mias.isEmpty()) {
            float suma = 0;
            for (Cara m : mias) suma += m.prof;
            float med = suma / mias.size();
            for (int j = 0; j < mias.size(); j++) mias.get(j).prof = med + (mias.size() - j) * 1e-4f;
        }
        return true;
    }

    private static int opuesta(int cara) { return cara == 0 ? 1 : cara == 1 ? 0 : cara == 2 ? 3 : 2; }

    private static float[][] circulo(float[] cen, float[] a, float[] b, float r, int n) {
        float[][] pts = new float[n][];
        for (int i = 0; i < n; i++) {
            double an = 2 * Math.PI * i / n;
            pts[i] = suma(suma(cen, a, (float) Math.cos(an) * r), b, (float) Math.sin(an) * r);
        }
        return pts;
    }

    static float area(float[][] pol) {
        float a = 0;
        for (int i = 0, j = pol.length - 1; i < pol.length; j = i++) a += pol[j][0] * pol[i][1] - pol[i][0] * pol[j][1];
        return a / 2;
    }

    /** Un hueco perforado en una placa, como polígono (s, u). */
    /** Versión 4.5: ranura con las puntas redondas (colisa). Centro (0,0), largo total y ancho. */
    static float[][] ranura(float largo, float ancho) {
        float r = ancho / 2, c = Math.max(0, largo / 2 - r);
        float[][] p = new float[20][2];
        for (int i = 0; i < 10; i++) {
            double an = -Math.PI / 2 + Math.PI * i / 9;
            p[i][0] = c + (float) Math.cos(an) * r; p[i][1] = (float) Math.sin(an) * r;
            p[10 + i][0] = -c - (float) Math.cos(an) * r; p[10 + i][1] = -(float) Math.sin(an) * r;
        }
        return p;
    }

    static float[][] poligonoHueco(Pieza.Hueco h) {
        if (h.tipo == 4 && h.forma != null) return h.forma;
        if (h.tipo == 2) {
            float[][] r = ranura(h.d1, h.d2);
            for (float[] q : r) { q[0] += h.s; q[1] += h.u; }
            return r;
        }
        if (h.tipo == 0 || h.tipo == 3) {
            float[][] r = new float[20][2];
            for (int i = 0; i < 20; i++) { double an = 2 * Math.PI * i / 20; r[i][0] = h.s + (float) Math.cos(an) * h.d1 / 2; r[i][1] = h.u + (float) Math.sin(an) * h.d1 / 2; }
            return r;
        }
        float a = h.d1 / 2, b = (h.tipo == 2 ? h.d2 : h.d1) / 2;
        return new float[][]{{h.s - a, h.u - b}, {h.s + a, h.u - b}, {h.s + a, h.u + b}, {h.s - a, h.u + b}};
    }

    private Cara agregar(List<Cara> caras, float[][] pts, float[] nrm, int base, boolean borde, int pieza, int tipo) {
        float f = deFrente(nrm);
        if (f > 0.02f) return null;   // no se ve: mira para el otro lado
        if (pzActual != null && pzActual.id == pieza && !pzActual.colores.isEmpty() && ejesActual != null) {
            float lx = Geo.dot(nrm, ejesActual[0]), ly = Geo.dot(nrm, ejesActual[1]), lz = Geo.dot(nrm, ejesActual[2]);
            for (double[] c : pzActual.colores) if (lx * c[0] + ly * c[1] + lz * c[2] > 0.995) base = (int) (long) c[3];
        }
        if (esResaltada(pieza, nrm, 0, pts[0])) base = 0xFFFF6D00;
        else if (esResaltada(pieza, nrm, 1, pts[0])) base = 0xFF2979FF;
        float luz = 0.45f + 0.55f * Math.min(1f, -f);
        int col = Color.rgb(Math.round(Color.red(base) * luz), Math.round(Color.green(base) * luz), Math.round(Color.blue(base) * luz));
        Cara k = hacer(pts, nrm, col);
        // v6.7: los muros de la casa sin rayas de unión (salían dos líneas encima de puertas y ventanas)
        if (k != null) { k.borde = borde && base != Casa3D.MURO; k.pieza = pieza; k.tipo = tipo; k.nrm = nrm; k.p0 = pts[0]; k.w = pts; caras.add(k); }
        return k;
    }

    private Cara hacer(float[][] pts, float[] nrm, int col) {
        if (deFrente(nrm) > 0.02f) return null;
        Cara k = new Cara();
        k.xs = new float[pts.length];
        k.ys = new float[pts.length];
        float pr = 0;
        for (int i = 0; i < pts.length; i++) {
            float[] q = proyectar(pts[i][0], pts[i][1], pts[i][2]);
            k.xs[i] = q[0];
            k.ys[i] = q[1];
            pr += q[2];
        }
        k.prof = pr / pts.length;
        k.color = col;
        return k;
    }

    /** Las flechitas X (rojo), Y (verde), Z (azul) en la esquina. */
    // versión 4.4: en vez del orbe, dos barras tipo regla: abajo gira, a la derecha sube o baja la mirada
    private int rueda;   // 0 nada · 1 barra de abajo · 2 barra de la derecha
    private static final float LENTO = 0.12f;   // grados por pixel: muy despacio

    private boolean enBarraAbajo(float x, float y) { return y > getHeight() - dp(46) && x < getWidth() - dp(46); }
    private boolean enBarraLado(float x, float y) { return x > getWidth() - dp(46) && y < getHeight() - dp(46); }

    private void dibujarBarras(Canvas c) {
        float w = getWidth(), h = getHeight();
        Paint pb = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF ra = new RectF(dp(4), h - dp(40), w - dp(48), h - dp(4));
        pb.setStyle(Paint.Style.FILL);
        pb.setColor(rueda == 1 ? 0xEE37474F : 0xCC263238);
        c.drawRoundRect(ra, dp(8), dp(8), pb);
        pb.setStyle(Paint.Style.STROKE);
        pb.setStrokeWidth(dp(1.2f));
        pb.setColor(0xFF90A4AE);
        float paso = dp(14), corr = ((-giro / LENTO) % paso + paso) % paso;
        int k = 0;
        for (float x = ra.left + corr; x < ra.right; x += paso, k++) {
            float alto = k % 3 == 0 ? dp(12) : dp(7);
            c.drawLine(x, ra.centerY() - alto, x, ra.centerY() + alto, pb);
        }
        pb.setColor(0xFFFFB300);
        pb.setStrokeWidth(dp(3));
        c.drawLine(ra.centerX(), ra.top + dp(2), ra.centerX(), ra.bottom - dp(2), pb);
        float g = ((giro % 360) + 360) % 360;
        pTxt.setColor(0xFFFFB300);
        c.drawText("⟷ giro " + Math.round(g) + "°", ra.centerX() + dp(8), ra.centerY() + dp(5), pTxt);
        RectF rl = new RectF(w - dp(40), dp(4), w - dp(4), h - dp(48));
        pb.setStyle(Paint.Style.FILL);
        pb.setColor(rueda == 2 ? 0xEE37474F : 0xCC263238);
        c.drawRoundRect(rl, dp(8), dp(8), pb);
        pb.setStyle(Paint.Style.STROKE);
        pb.setStrokeWidth(dp(1.2f));
        pb.setColor(0xFF90A4AE);
        float corr2 = ((elev / LENTO) % paso + paso) % paso;
        k = 0;
        for (float y = rl.top + corr2; y < rl.bottom; y += paso, k++) {
            float ancho = k % 3 == 0 ? dp(12) : dp(7);
            c.drawLine(rl.centerX() - ancho, y, rl.centerX() + ancho, y, pb);
        }
        pb.setColor(0xFFFFB300);
        pb.setStrokeWidth(dp(3));
        c.drawLine(rl.left + dp(2), rl.centerY(), rl.right - dp(2), rl.centerY(), pb);
        c.drawText("↕", rl.centerX() - dp(5), rl.bottom - dp(24), pTxt);
        float ev = ((elev + 180) % 360 + 360) % 360 - 180;
        c.drawText(Math.round(ev) + "°", rl.left + dp(3), rl.bottom - dp(8), pTxt);
        pTxt.setColor(Color.WHITE);
    }

    private void dibujarEjes(Canvas c) {
        dibujarBarras(c);
        if (version != null && !version.isEmpty()) {   // v6.6: en la casa va vacío (el título ya está arriba)
            Paint pv = new Paint(Paint.ANTI_ALIAS_FLAG);
            pv.setTextSize(dp(13));
            pv.setFakeBoldText(true);
            pv.setColor(0xFFFFB300);
            String vt = version;   // v6.6: que no se monte debajo de 🎥 REC, 📷 FOTO y ⋮
            float maxW = getWidth() - dp(60) - dp(170);
            while (vt.length() > 4 && pv.measureText(vt) > maxW) vt = vt.substring(0, vt.length() - 2);
            if (!vt.equals(version)) vt = vt + "…";
            c.drawText(vt, dp(60), dp(30), pv);
        }
        float ox = dp(34), oy = dp(84), L = dp(22);
        float[][] ejes = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int[] col = {0xFFEF5350, 0xFF66BB6A, 0xFF42A5F5};
        String[] nom = {"X", "Y", "Z"};
        for (int i = 0; i < 3; i++) {
            float x1 = ejes[i][0] * cg - ejes[i][1] * sg;
            float y1 = ejes[i][0] * sg + ejes[i][1] * cg;
            float arriba = ejes[i][2] * ce + y1 * se;
            pEje.setColor(col[i]);
            c.drawLine(ox, oy, ox + x1 * L, oy - arriba * L, pEje);
            pTxt.setColor(col[i]);
            c.drawText(nom[i], ox + x1 * (L + dp(6)) - dp(4), oy - arriba * (L + dp(6)) + dp(4), pTxt);
        }
    }

    // ---------------- Dedos ----------------

    private float x0, y0, ax, ay, d0, z0, px0, py0, mx0, my0;
    private boolean dos, movio;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = ax = e.getX(); y0 = ay = e.getY();
                dos = false; movio = false;
                rueda = enBarraAbajo(x0, y0) ? 1 : enBarraLado(x0, y0) ? 2 : 0;
                if (rueda != 0) { lupa = false; invalidate(); return true; }
                acX = acY = acZ = 0;
                dedoX = x0; dedoY = y0;
                pxEf = panX; pyEf = panY;
                candidata = buscar(x0, y0);
                lupa = true;
                invalidate();
                if (modo == MOVER) {
                    // se arrastra la pieza que está bajo el dedo (o la escogida)
                    int id = buscar(x0, y0);
                    if (id >= 0 && id != escogida) { escogida = id; invalidate(); if (alEscoger != null) alEscoger.escogida(id); }
                }
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dos = true;
                    lupa = false;
                    d0 = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    z0 = zoom; px0 = panX; py0 = panY;
                    mx0 = (e.getX(0) + e.getX(1)) / 2; my0 = (e.getY(0) + e.getY(1)) / 2;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dos && e.getPointerCount() >= 2) {
                    float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    if (d0 > 0) zoom = Math.max(0.2f, Math.min(25f, z0 * d / d0));
                    panX = px0 + (e.getX(0) + e.getX(1)) / 2 - mx0;
                    panY = py0 + (e.getY(0) + e.getY(1)) / 2 - my0;
                    invalidate();
                    return true;
                }
                if (dos) return true;
                float dx = e.getX() - ax, dy = e.getY() - ay;
                if (rueda != 0) {
                    movio = true;
                    if (rueda == 1) giro -= dx * LENTO;
                    else elev += dy * LENTO;   // versión 5: da vueltas completas, sin tope
                    ax = e.getX(); ay = e.getY();
                    invalidate();
                    return true;
                }
                if (Math.hypot(e.getX() - x0, e.getY() - y0) > dp(8)) movio = true;
                dedoX = e.getX(); dedoY = e.getY();
                if (movio && !(modo == MOVER && escogida >= 0)) lupa = false;
                if (movio) {
                    if (modo == GIRAR) {
                        giro -= dx * 0.13f;   // versión 4.1: orbitar lento
                        elev += dy * 0.13f;
                    } else if (modo == MOVER && escogida >= 0 && alMover != null) {
                        // de pantalla a mm: derecha de la pantalla y arriba de la pantalla
                        prepararCamara();
                        float kx = dx / esc, ky = -dy / esc;
                        acX += cg * kx + sg * se * ky;
                        acY += -sg * kx + cg * se * ky;
                        acZ += ce * ky;
                        float px = Math.round(acX / 5) * 5f, py = Math.round(acY / 5) * 5f, pz = Math.round(acZ / 5) * 5f;
                        if (px != 0 || py != 0 || pz != 0) { alMover.mover(escogida, px, py, pz); acX -= px; acY -= py; acZ -= pz; }
                    } else {
                        panX += dx;
                        panY += dy;
                    }
                    invalidate();
                }
                ax = e.getX(); ay = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
                if (rueda != 0) {
                    rueda = 0;
                    invalidate();
                    return true;
                }
                lupa = false;
                candidata = -1;
                invalidate();
                if (!dos && !movio) tocarUnaODos(e.getX(), e.getY());
                if (modo == MOVER && movio && alMover != null) alMover.soltar();
                return true;
        }
        return true;
    }

    /** Escoge la pieza más cercana al dedo. */
    // versión 4.3: doble toque en la pieza = pivote ahí (la vista gira alrededor de ese punto)
    private boolean pivote;
    private long ultToque;
    private float ultX, ultY;

    private boolean dobleToque(float x, float y) {
        long ahora = System.currentTimeMillis();
        boolean d = ahora - ultToque < 380 && Math.hypot(x - ultX, y - ultY) < dp(36);
        ultToque = d ? 0 : ahora; ultX = x; ultY = y;
        return d;
    }

    private boolean ponerPivote(float x, float y) {
        for (int i = vistas.size() - 1; i >= 0; i--) {
            Cara k = vistas.get(i);
            if (k.pieza < 0 || k.tipo == 9 || k.p0 == null || k.nrm == null || !dentro(k.xs, k.ys, x, y)) continue;
            boolean enHueco = false;
            if (k.hx != null) for (int h = 0; h < k.hx.length; h++) if (dentro(k.hx[h], k.hy[h], x, y)) enHueco = true;
            if (enHueco) continue;
            float[] q = desproyectar(x, y, k.p0, k.nrm);
            // versión 5: el punto de giro se pega a la esquina o a la mitad de la arista más cercana
            // versión 6: se ilumina solo la cara tocada (no toda la pieza)
            resA = k.pieza; resNrmA = k.nrm; resPtoA = k.p0;
            float[] qCara = q;
            if (alCara != null && k.tipo != 9) alCara.cara(k.pieza, k.nrm, qCara, k.w);
            q = imantar(k.w, q, false);
            float[] sp = proyectar(q[0], q[1], q[2]);
            centro[0] = q[0]; centro[1] = q[1]; centro[2] = q[2];
            panX = sp[0] - getWidth() / 2f;
            panY = sp[1] - getHeight() / 2f;
            pivote = true;
            invalidate();
            return true;
        }
        return false;
    }

    /** Doble toque en el Orbe: la vista recta más cercana (cada 45° y piso, esquina o arriba). */
    private void enderezar() {
        giro = Math.round(giro / 45f) * 45f;
        float[] el = {0, 35, 89};
        float mejor = 0;
        for (float v : el) if (Math.abs(Math.abs(elev) - v) < Math.abs(Math.abs(elev) - mejor)) mejor = v;
        elev = Math.signum(elev == 0 ? 1 : elev) * mejor;
        invalidate();
    }

    /** v6.5: doble toque sobre una pieza = cambiar su largo o ir a su boceto original. */
    public interface AlDoble { void doble(int pieza); }
    public AlDoble alDoble;
    private long ultimoToque;
    private float utX, utY;
    private Runnable toqueEsperando;

    private void tocarUnaODos(float x, float y) {
        long ahora = System.currentTimeMillis();
        if (alDoble != null && pideToque == null && pideCara == null) {
            if (toqueEsperando != null && ahora - ultimoToque < 320 && Math.hypot(x - utX, y - utY) < dp(40)) {
                removeCallbacks(toqueEsperando);
                toqueEsperando = null;
                int p = buscar(x, y);
                if (p >= 0) { escogida = p; invalidate(); alDoble.doble(p); }
                return;
            }
            ultimoToque = ahora; utX = x; utY = y;
            toqueEsperando = () -> { toqueEsperando = null; tocar(x, y); };
            postDelayed(toqueEsperando, 330);
            return;
        }
        tocar(x, y);
    }

    private void tocar(float x, float y) {
        if (pideToque != null) { pideToque.tocado(x, y); return; }
        if (pideCara != null) { tocarCara(x, y); return; }
        int mejor = buscar(x, y);
        // versión 4.4: tocar una pieza pone ahí el pivote; las barras giran alrededor de ese punto
        if (mejor >= 0) ponerPivote(x, y);
        else { resA = -1; resNrmA = null; }
        escogida = mejor;
        invalidate();
        if (alEscoger != null) alEscoger.escogida(mejor);
    }

    /** La pieza más cercana al dedo (-1 si ninguna). */
    private int buscar(float x, float y) {
        prepararCamara();
        pxEf = panX; pyEf = panY;
        // versión 4: primero la cara que está bajo el dedo
        for (int i = vistas.size() - 1; i >= 0; i--) {
            Cara k = vistas.get(i);
            if (k.pieza >= 0 && dentro(k.xs, k.ys, x, y)) return k.pieza;
        }
        Map<Integer, Pieza> mapa = mapa();
        int mejor = -1;
        float dist = dp(36);
        for (Pieza p : piezas) {
            float[] s = p.inicio(mapa, 0), d = p.direccion();
            float[] a = proyectar(s[0], s[1], s[2]);
            float[] b = proyectar(s[0] + d[0] * p.largo, s[1] + d[1] * p.largo, s[2] + d[2] * p.largo);
            float vx = b[0] - a[0], vy = b[1] - a[1];
            float l2 = vx * vx + vy * vy;
            float tt = l2 < 1 ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * vx + (y - a[1]) * vy) / l2));
            float dd = (float) Math.hypot(x - (a[0] + vx * tt), y - (a[1] + vy * tt));
            if (dd < dist) { dist = dd; mejor = p.id; }
        }
        return mejor;
    }

    // ---------------- Versión 4.3: los bocetos en su plano ----------------

    private void dibujarHojas(Canvas c) {
        Paint pl = new Paint(Paint.ANTI_ALIAS_FLAG);
        pl.setStyle(Paint.Style.STROKE);
        Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
        pf.setStyle(Paint.Style.FILL);
        for (Hoja h : hojas) {
            boolean res = h.id == hojaResaltada;
            if ((!h.visible && !res) || h.b.vacio()) continue;
            // las figuras cerradas, sombreadas
            try {
                List<double[][]> pols = new ArrayList<>();
                Editar2D.figuras(h.b, pols);
                Path pa = new Path();
                pa.setFillType(Path.FillType.EVEN_ODD);
                for (double[][] pol : pols) {
                    if (pol == null || pol.length < 3) continue;
                    for (int i = 0; i < pol.length; i++) {
                        float[] q = proyectar(h.mundo(pol[i][0], pol[i][1]));
                        if (i == 0) pa.moveTo(q[0], q[1]); else pa.lineTo(q[0], q[1]);
                    }
                    pa.close();
                }
                pf.setColor(res ? 0x55FFB300 : 0x33CFD8DC);
                c.drawPath(pa, pf);
            } catch (Exception ignored) { }
            pl.setColor(res ? 0xFFFFB300 : 0xFFECEFF1);
            pl.setStrokeWidth(dp(res ? 2.2f : 1.4f));
            for (Boceto.Ent e : h.b.ents) {
                Boceto.Punto a = h.b.puntos.get(e.a);
                if (a == null) continue;
                if (e.tipo == Boceto.LINEA) {
                    Boceto.Punto q = h.b.puntos.get(e.b);
                    if (q == null) continue;
                    float[] p1 = proyectar(h.mundo(a.x, a.y)), p2 = proyectar(h.mundo(q.x, q.y));
                    c.drawLine(p1[0], p1[1], p2[0], p2[1], pl);
                } else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
                    double a1 = 0, barrido = 2 * Math.PI;
                    if (e.tipo == Boceto.ARCO) {
                        Boceto.Punto p1 = h.b.puntos.get(e.b), p2 = h.b.puntos.get(e.c);
                        if (p1 == null || p2 == null) continue;
                        a1 = Math.atan2(p1.y - a.y, p1.x - a.x);
                        barrido = Math.atan2(p2.y - a.y, p2.x - a.x) - a1;
                        while (barrido <= 0) barrido += 2 * Math.PI;
                    }
                    int n = 40;
                    float[] ant = null;
                    for (int i = 0; i <= n; i++) {
                        double an = a1 + barrido * i / n;
                        float[] q = proyectar(h.mundo(a.x + e.r * Math.cos(an), a.y + e.r * Math.sin(an)));
                        if (ant != null) c.drawLine(ant[0], ant[1], q[0], q[1], pl);
                        ant = q;
                    }
                }
            }
            // el nombre del boceto
            float[] o = proyectar(h.mundo(0, 0));
            pTxt.setColor(res ? 0xFFFFB300 : 0xFFB0BEC5);
            c.drawText("✏ " + h.nombre, o[0] + dp(6), o[1] - dp(6), pTxt);
            pTxt.setColor(Color.WHITE);
        }
    }

    private float[] proyectar(float[] p) { return proyectar(p[0], p[1], p[2]); }
}
