package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Mi Inventor 5: amarres por ejes, ángulo, bisagra, paralelo, perpendicular, punto, fijar; planos, ejes y puntos de referencia.
 * Mi Inventor 4: amarrar tocando caras, perforar, cortar (inglete y tope), extruir el boceto a placas;
 * boceto 2D paramétrico (en mm) con lupa, imanes, herramientas de modificar, medir y DXF;
 * estructuras 3D en tubo, ángulo y platina (amarradas por cara),
 * y un mini Excel de medidas que manda en los dos. Lista de corte para comprar barras de 6 m.
 */
public class InventorActivity extends Activity {

    private static final String ULTIMO = "_ultimo";
    private static final float BARRA = 6000f, DISCO = 3f;   // barra de 6 m y lo que se come el disco al cortar
    private static final int ABRIR_ARCHIVO = 41, ABRIR_DXF = 42, GRABAR = 43;
    private static final int FONDO = 0xFF151A26;

    /** Versión que se ve en la pantalla (para saber en cuál va). */
    static final String VERSION = "Chepe CAD v6.6";
    private final List<Pieza> piezas = new ArrayList<>();
    // versión 5: planos, ejes y puntos de referencia
    private final List<Ref> refs = new ArrayList<>();
    private boolean verEjesPiezas = true;
    private TextView btnTerminar;
    private View raizPrincipal;
    private CasaEditor casa;   // v6.4: la casa con su editor de planta   // v6.2.1: dice 🟩 Pieza cuando el boceto ya tiene su pieza (o es un desarrollo)   // v6.2: lo redondo trae su eje a la vista (se puede ocultar)
    private final Medidas medidas = new Medidas();
    private Vista3D vista;
    private VistaBoceto boceto;
    private LinearLayout lista, listaMedidas;
    private FrameLayout contenedor;
    private View panel2D, panel3D, panelMedidas;
    private final TextView[] pestanas = new TextView[3];
    private final List<TextView> botonesModo3D = new ArrayList<>();
    private int esquina3D = -1;
    private boolean ladoDer;
    private String nombreProyecto = "Sin nombre";
    private int escogida = -1;
    private int pestana = 0;
    // versión 4.3: varios bocetos, cada uno en su plano (como en Inventor)
    private final List<Hoja> hojas = new ArrayList<>();
    private Hoja hoja;
    private TextView cabeza2D;

    // deshacer / rehacer: copias livianas del proyecto
    private final List<String> atras = new ArrayList<>(), adelante = new ArrayList<>();

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(FONDO);
        getWindow().setNavigationBarColor(FONDO);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(FONDO);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));

        contenedor = new FrameLayout(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1f);
        raiz.addView(contenedor, cp);
        panel2D = armar2D();
        panel3D = armar3D();
        panelMedidas = armarMedidas();
        contenedor.addView(panel2D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panel3D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panelMedidas, new FrameLayout.LayoutParams(-1, -1));
        // versión 6: arriba no hay nada más que el ☰ (todo se escoge ahí)
        TextView menu = boton("☰", 0xEE263238, this::menuPrincipal);
        menu.setTextSize(24);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(48), dp(44));
        mp.gravity = Gravity.TOP | Gravity.LEFT;
        contenedor.addView(menu, mp);
        TextView mas = boton("⋮", 0xEE263238, this::menuMas);   // v6.5: ⋮ a la derecha
        mas.setTextSize(24);
        FrameLayout.LayoutParams mq = new FrameLayout.LayoutParams(dp(48), dp(44));
        mq.gravity = Gravity.TOP | Gravity.RIGHT;
        contenedor.addView(mas, mq);
        // v6.6: 🎥 grabar pantalla y 📷 pantallazo, junto al ⋮, en todas las secciones
        View[] rf = botonesGrabar();
        FrameLayout.LayoutParams rq = new FrameLayout.LayoutParams(dp(56), dp(44));
        rq.gravity = Gravity.TOP | Gravity.RIGHT;
        rq.rightMargin = dp(52 + 54);
        contenedor.addView(rf[0], rq);
        FrameLayout.LayoutParams fq = new FrameLayout.LayoutParams(dp(50), dp(44));
        fq.gravity = Gravity.TOP | Gravity.RIGHT;
        fq.rightMargin = dp(52);
        contenedor.addView(rf[1], fq);
        setContentView(raiz);
        raizPrincipal = raiz;

        hojas.add(Hoja.nueva(1, 0));
        hoja = hojas.get(0);
        boceto.b = hoja.b;
        vista.hojas = hojas;
        // versión 6: se abre el último documento (pieza, lámina, casa o montaje)
        casaDeEjemplo();
        String act = getPreferences(MODE_PRIVATE).getString("docAct", "");
        boolean abierto = !act.isEmpty() && new File(carpetaLib(), act + ".json").exists();
        if (abierto) abrirDoc(act, true);
        else {
            abrir(ULTIMO, true);
            if (modoFalta) migrar();
            if ("Sin nombre".equals(nombreProyecto) || nombreProyecto.isEmpty()) {
                nombreProyecto = nombresLib().contains("T1") ? siguienteNombre("T1") : "T1";
                if (!esMontaje()) modo = PIEZA;
                guardarDoc(true);
            }
        }
        aplicarModo();
        pestana = getPreferences(MODE_PRIVATE).getInt("pestana", 0);
        if (MONTAJE.equals(modo) && pestana == 0) pestana = 1;
        mostrar(pestana);
        recalcular();
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardar(ULTIMO, true);
        guardarDoc(true);
        getPreferences(MODE_PRIVATE).edit().putInt("pestana", pestana).apply();
        if (casa != null) { casa.guardar(); getPreferences(MODE_PRIVATE).edit().putString("docAct", casa.nombre).apply(); }
    }

    private void cerrarApp() {
        new AlertDialog.Builder(this).setMessage("¿Cerrar Chepe CAD? El trabajo queda guardado y al abrir sigue donde iba.")
                .setPositiveButton("✕ Cerrar", (d, w) -> {
                    guardar(ULTIMO, true);
                    guardarDoc(true);
                    getPreferences(MODE_PRIVATE).edit().putInt("pestana", pestana).apply();
                    finish();
                })
                .setNegativeButton("Seguir", null).show();
    }

    @Override
    public void onBackPressed() {
        if (casa != null) { casa.guardar(); super.onBackPressed(); return; }
        if (toquePanel) { cerrarPanel(); aviso("Cancelado"); return; }
        if (vista.pideToque != null) { vista.pideToque = null; vista.hojaResaltada = -1; vista.bordesNaranja = null; vista.invalidate(); aviso("Cancelado"); return; }
        if (barra3D != null && barra3D.getVisibility() == View.VISIBLE) { cerrarPanel(); return; }
        if (pestana == 0 && boceto.modo != VistaBoceto.VER) { listo2D(); return; }
        if (pestana == 0 && (!boceto.sel.isEmpty() || !boceto.selPts.isEmpty())) { boceto.limpiarSeleccion(); return; }
        super.onBackPressed();
    }

    private void mostrar(int k) {
        pestana = k;
        panel2D.setVisibility(k == 0 ? View.VISIBLE : View.GONE);
        panel3D.setVisibility(k == 1 ? View.VISIBLE : View.GONE);
        panelMedidas.setVisibility(k == 2 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) if (pestanas[i] != null) colorear(pestanas[i], i == k ? 0xFF1E88E5 : 0xFF37474F);
        if (k == 2) pintarMedidas();
    }

    // ---------------- Ayudas ----------------

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        colorear(t, color);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private void colorear(TextView t, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
    }

    private LinearLayout fila(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, peso());
        return l;
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private Pieza porId(int id) {
        for (Pieza p : piezas) if (p.id == id) return p;
        return null;
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    private int nuevoId() {
        int m = 0;
        for (Pieza p : piezas) m = Math.max(m, p.id);
        return m + 1;
    }

    // ---------------- Deshacer ----------------

    /** Guarda una copia antes de cambiar algo. */
    private void antes() {
        try {
            atras.add(proyecto(false).toString());
            if (atras.size() > 60) atras.remove(0);
            adelante.clear();
        } catch (Exception ignored) {}
    }

    private void deshacer() {
        if (atras.isEmpty()) { aviso("No hay nada para deshacer"); return; }
        try {
            adelante.add(proyecto(false).toString());
            cargarSinPerderCalcos(new JSONObject(atras.remove(atras.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo deshacer"); }
    }

    private void rehacer() {
        if (adelante.isEmpty()) { aviso("No hay nada para rehacer"); return; }
        try {
            atras.add(proyecto(false).toString());
            cargarSinPerderCalcos(new JSONObject(adelante.remove(adelante.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo rehacer"); }
    }

    /** Volver a la copia que se acaba de guardar (cuando algo no cuadró). */
    private void revertir() {
        if (atras.isEmpty()) return;
        try { cargarSinPerderCalcos(new JSONObject(atras.remove(atras.size() - 1))); } catch (Exception ignored) {}
    }

    // ---------------- Todo se recalcula desde la tablita ----------------

    private void fijos() {
        medidas.fijos.clear();
        float total = 0;
        for (Pieza p : piezas) { medidas.fijos.put("T" + p.id, (double) p.largo); total += p.largo; }
        medidas.fijos.put("total", (double) total);
        medidas.fijos.put("piezas", (double) piezas.size());
    }

    /** Tablita → piezas 3D → boceto 2D. Devuelve true si el boceto cuadró. */
    private boolean recalcular() {
        fijos();
        medidas.calcular();
        String err = null;
        for (Pieza p : piezas) { String e = p.aplicarFormulas(medidas); if (err == null) err = e; }
        fijos();
        medidas.calcular();
        seguirPiezas();
        for (Hoja h : hojas) if (h != hoja) h.b.resolver(medidas, -1);
        boolean ok = boceto.b.resolver(medidas, -1);
        boceto.calco = hoja == null ? null : hoja.calco;
        boceto.verCalco = hoja == null || hoja.verCalco;
        boceto.revisar();
        pintarCabeza();
        actualizarPlacas();
        actualizarMaquinados();
        pintarOps();
        boceto.invalidate();
        vista.escogida = escogida;
        lineasDoblez();
        vista.ejesVer = null;
        if (verEjesPiezas) {
            List<float[][]> ls = new ArrayList<>();
            for (EjeC e : ejesCandidatos()) if (e.pieza >= 0) ls.add(new float[][]{e.a, e.b});
            vista.ejesVer = ls;
        }
        vista.invalidate();
        pintarLista();
        if (pestana == 2) pintarMedidas();
        if (err != null) aviso("⚠ " + err);
        return ok;
    }

    // =====================================================================
    //                              BOCETO 2D
    // =====================================================================

    // Versión 3: abajo van 4 grupos (Dibujar, Modificar, Amarrar, Medir); cada uno muestra sus herramientas.
    private static final int G_DIBUJAR = 0, G_MODIFICAR = 1, G_AMARRAR = 2, G_MEDIR = 3;
    private int grupo2D = G_DIBUJAR;
    private final TextView[] botonesGrupo = new TextView[4];
    private LinearLayout cajaHerr, casilla;
    private EditText casilla1, casilla2;
    private int ultimoModoCasilla = -1;
    private TextView casillaEt1, casillaEt2;
    private String herrActiva = "Ver";
    private final Map<String, TextView> botonesHerr = new HashMap<>();
    private double ultDesfase = 50, ultRadio = 20, ultChaflan = 20;

    private View armar2D() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        boceto = new VistaBoceto(this);
        boceto.medidas = medidas;
        boceto.orto = getPreferences(MODE_PRIVATE).getBoolean("orto", false);
        boceto.oyente = new VistaBoceto.Oyente() {
            @Override public void antes() { InventorActivity.this.antes(); }
            @Override public void cambio() { boceto.b.resolver(medidas, -1); boceto.revisar(); pintarCabeza(); boceto.invalidate(); }
            @Override public void pedirCota(Boceto.Restr nueva) { InventorActivity.this.pedirCota(nueva, null); }
            @Override public void pedirDistancia(int p1, int p2) { InventorActivity.this.pedirDistancia(p1, p2); }
            @Override public void editarCota(Boceto.Restr r) { InventorActivity.this.editarCota(r); }
            @Override public void pedirTexto(double x, double y) { InventorActivity.this.pedirTexto(x, y); }
            @Override public void seleccion() { }
            @Override public void aviso(String s) { InventorActivity.this.aviso(s); }
        };
        // versión 4.3: arriba dice qué boceto es, en qué plano y si ya está completo
        cabeza2D = new TextView(this);
        cabeza2D.setTextColor(Color.WHITE);
        cabeza2D.setTextSize(13);
        cabeza2D.setPadding(dp(56), dp(5), dp(165), dp(5));
        GradientDrawable gc = new GradientDrawable();
        gc.setColor(0xFF1A2F4A);
        gc.setCornerRadius(dp(8));
        cabeza2D.setBackground(gc);
        cabeza2D.setOnClickListener(v -> menuBocetos());
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-1, -2);
        chp.bottomMargin = dp(4);
        l.addView(cabeza2D, chp);
        l.addView(boceto, new LinearLayout.LayoutParams(-1, 0, 1f));

        // la casilla para escribir medidas (línea, rectángulo, círculo, polígono)
        casilla = new LinearLayout(this);
        casilla.setGravity(Gravity.CENTER_VERTICAL);
        casillaEt1 = etiquetaCasilla();
        casilla1 = campoCasilla();
        casillaEt2 = etiquetaCasilla();
        casilla2 = campoCasilla();
        casilla.addView(casillaEt1, new LinearLayout.LayoutParams(-2, -1));
        casilla.addView(casilla1, new LinearLayout.LayoutParams(0, -1, 1f));
        casilla.addView(casillaEt2, new LinearLayout.LayoutParams(-2, -1));
        casilla.addView(casilla2, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView ok = boton("OK", 0xFF2E7D32, this::okCasilla);
        LinearLayout.LayoutParams okp = new LinearLayout.LayoutParams(dp(56), -1);
        okp.leftMargin = dp(4);
        casilla.addView(ok, okp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(46));
        cp.topMargin = dp(4);
        l.addView(casilla, cp);
        casilla.setVisibility(View.GONE);

        // los 4 grupos
        LinearLayout grupos = new LinearLayout(this);
        filaGrupos = grupos;
        String[] ng = {"✏ Dibujar", "🛠 Modificar", "🔗 Amarrar", "📐 Medir"};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            botonesGrupo[i] = boton(ng[i], 0xFF37474F, () -> grupo2D(k));
            botonesGrupo[i].setTextSize(13);
            grupos.addView(botonesGrupo[i], peso());
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(40));
        gp.topMargin = dp(4);
        l.addView(grupos, gp);

        cajaHerr = new LinearLayout(this);
        cajaHerr.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHerr, new LinearLayout.LayoutParams(-1, -2));

        // fila fija
        LinearLayout f = new LinearLayout(this);
        f.addView(boton("↶\nAtrás", 0xFF5E35B1, this::deshacer), peso());
        f.addView(boton("↷\nAdelante", 0xFF5E35B1, this::rehacer), peso());
        f.addView(boton("⛶\nVer todo", 0xFF455A64, boceto::encuadrar), peso());
        f.addView(boton("🩺\nDoctor", 0xFF388E3C, this::doctor), peso());   // v6.6
        f.addView(boton("🗑\nBorrar", 0xFFC62828, this::borrar2D), peso());
        f.addView(boton("✖\nCancelar", 0xFF6D4C41, this::cancelar2D), peso());
        btnTerminar = boton("✓\nListo", 0xFF2E7D32, this::listoTodo);   // v6.3: un solo botón, sin «Terminar»
        f.addView(btnTerminar, peso());
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(46));
        fp.topMargin = dp(4);
        l.addView(f, fp);
        // versión 4.2: la lista de operaciones (se abre y se cierra)
        l.addView(armarOps());
        svOps = new ScrollView(this);
        listaOps = new LinearLayout(this);
        listaOps.setOrientation(LinearLayout.VERTICAL);
        svOps.addView(listaOps);
        svOps.setVisibility(View.VISIBLE);   // v6.6: la lista de operaciones siempre a la vista
        l.addView(svOps, new LinearLayout.LayoutParams(-1, 0, 0.42f));
        grupo2D(G_DIBUJAR);
        return l;
    }

    private TextView etiquetaCasilla() {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    private EditText campoCasilla() {
        EditText e = new EditText(this);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.BLACK);
        e.setHintTextColor(0xFF90A4AE);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(7));
        e.setBackground(g);
        // v6.4: sin el teclado del celular; sale el teclado propio de Chepe CAD
        e.setShowSoftInputOnFocus(false);
        e.setFocusable(false);
        e.setOnClickListener(v -> Teclado.pedirFormula(this, "Escriba la medida", Teclado.tx(e), t -> e.setText(t)));
        return e;
    }

    /** Muestra el grupo de herramientas (Dibujar, Modificar, Amarrar o Medir). */
    private LinearLayout filaGrupos;

    private void grupo2D(int k) {
        grupo2D = k;
        boolean des = esDesarrollo(hoja);   // v6.5: el desarrollo no lleva herramientas de dibujo, solo para sacarlo
        if (filaGrupos != null) filaGrupos.setVisibility(des ? View.GONE : View.VISIBLE);
        for (int i = 0; i < 4; i++) colorear(botonesGrupo[i], i == k ? 0xFF546E7A : 0xFF37474F);   // v6.3: la pestaña escogida se nota sin prenderse
        cajaHerr.removeAllViews();
        botonesHerr.clear();
        List<Object[]> h = new ArrayList<>();   // {texto, color, acción}
        int gris = 0xFF455A64, verde = gris;   // v6.3: todo apagado; solo se prende lo que está trabajando
        if (des) {
            h.add(new Object[]{"🖨\nPDF", 0xFFC62828, (Runnable) this::pdf2D});
            h.add(new Object[]{"🖼\nPNG", 0xFF6A1B9A, (Runnable) () -> png2D(false)});
            h.add(new Object[]{"📐\nDXF", 0xFF1565C0, (Runnable) this::exportarDxf});
            h.add(new Object[]{"💬\nWhatsApp", 0xFF25A244, (Runnable) () -> png2D(true)});
            h.add(new Object[]{"↩\nVolver a\nla lámina", 0xFF2E7D32, (Runnable) this::terminarBoceto});
        } else
        switch (k) {
            case G_DIBUJAR:
                h.add(new Object[]{"✋\nVer", gris, (Runnable) () -> herr("Ver", VistaBoceto.VER)});
                h.add(new Object[]{"╱\nLínea", gris, (Runnable) () -> herr("Línea", VistaBoceto.LINEA)});
                h.add(new Object[]{"⌇\nPolilínea", gris, (Runnable) () -> { herr("Polilínea", VistaBoceto.LINEA); boceto.polilinea = true; aviso("Polilínea: toque punta por punta; con ✓ Listo se cierra sola"); }});
                h.add(new Object[]{"▭\nRectáng.", gris, (Runnable) () -> herr("Rectáng.", VistaBoceto.RECT)});
                h.add(new Object[]{"◯\nCírculo", gris, (Runnable) () -> herr("Círculo", VistaBoceto.CIRCULO)});
                h.add(new Object[]{"◠\nArco", gris, (Runnable) () -> herr("Arco", VistaBoceto.ARCO)});
                h.add(new Object[]{"⬡\nPolígono", gris, (Runnable) () -> herr("Polígono", VistaBoceto.POLIGONO)});
                h.add(new Object[]{"A\nTexto", gris, (Runnable) () -> herr("Texto", VistaBoceto.TEXTO)});
                h.add(new Object[]{"┼\nOrto", boceto.orto ? 0xFF1E88E5 : gris, (Runnable) this::orto});
                h.add(new Object[]{"📐\nCalco DXF", hoja != null && hoja.calco != null ? 0xFF1E88E5 : gris, (Runnable) this::menuCalco});
                break;
            case G_MODIFICAR:
                h.add(new Object[]{"⬚\nCuadro", gris, (Runnable) () -> herr("Cuadro", VistaBoceto.CUADRO)});
                h.add(new Object[]{"✥\nMover", gris, (Runnable) this::moverSel});
                h.add(new Object[]{"⧉\nCopiar", gris, (Runnable) this::copiarSel});
                h.add(new Object[]{"⟳\nRotar", gris, (Runnable) this::rotarSel});
                h.add(new Object[]{"⇋\nEspejo", gris, (Runnable) this::espejoSel});
                h.add(new Object[]{"⤢\nEscalar", gris, (Runnable) this::escalarSel});
                h.add(new Object[]{"⫽\nDesfase", gris, (Runnable) this::desfase});
                h.add(new Object[]{"✂\nRecortar", gris, (Runnable) this::recortar});
                h.add(new Object[]{"⟷\nExtender", gris, (Runnable) this::extender});
                h.add(new Object[]{"◜\nEmpalme", gris, (Runnable) () -> esquina(true)});
                h.add(new Object[]{"◸\nChaflán", gris, (Runnable) () -> esquina(false)});
                h.add(new Object[]{"⫶\nPartir", gris, (Runnable) this::partir});
                h.add(new Object[]{"▦\nMatriz", gris, (Runnable) this::matriz});
                h.add(new Object[]{"⊶\nUnir", gris, (Runnable) this::unirLineas});
                h.add(new Object[]{"⊹\nDescomponer", gris, (Runnable) this::descomponer});
                h.add(new Object[]{"↦\nLongitud", gris, (Runnable) this::longitud});
                break;
            case G_AMARRAR:
                h.add(new Object[]{"═\nHorizontal", verde, (Runnable) () -> amarrar(Boceto.HORIZ)});
                h.add(new Object[]{"║\nVertical", verde, (Runnable) () -> amarrar(Boceto.VERT)});
                h.add(new Object[]{"⊥\n90°", verde, (Runnable) () -> amarrar(Boceto.PERP)});
                h.add(new Object[]{"∥\nParalela", verde, (Runnable) () -> amarrar(Boceto.PARAL)});
                h.add(new Object[]{"=\nIgual", verde, (Runnable) () -> amarrar(Boceto.IGUAL)});
                h.add(new Object[]{"⊙\nUnir punto", verde, (Runnable) () -> amarrar(Boceto.COINC)});
                h.add(new Object[]{"◡\nTangente", verde, (Runnable) () -> amarrar(Boceto.TANG)});
                h.add(new Object[]{"📌\nFijo", verde, (Runnable) () -> amarrar(Boceto.FIJO)});
                h.add(new Object[]{"📏\nCota", gris, (Runnable) () -> herr("Cota", VistaBoceto.COTA)});
                h.add(new Object[]{"∠\nÁngulo", gris, (Runnable) this::cotaAngulo});
                h.add(new Object[]{"🗑\nQuitar", gris, (Runnable) this::amarrar2D});
                h.add(new Object[]{"⊕\nAl 0,0", gris, (Runnable) this::alCero});
                h.add(new Object[]{"⫴\nEntre paral.", gris, (Runnable) this::cotaParalelas});
                h.add(new Object[]{"⟂\nPunto-línea", gris, (Runnable) this::cotaPuntoLinea});
                h.add(new Object[]{"⊢⊢\nCota continua", gris, (Runnable) () -> cotasSeguidas(false)});
                h.add(new Object[]{"⊢\nLínea base", gris, (Runnable) () -> cotasSeguidas(true)});
                h.add(new Object[]{"👁\nMarcas", boceto.marcas ? 0xFF1E88E5 : gris, (Runnable) () -> { boceto.marcas = !boceto.marcas; boceto.invalidate(); grupo2D(G_AMARRAR); }});
                break;
            default:
                h.add(new Object[]{"✋\nEscoger", gris, (Runnable) () -> herr("Ver", VistaBoceto.VER)});
                h.add(new Object[]{"↔\nDistancia", gris, (Runnable) this::medirDistancia});
                h.add(new Object[]{"▨\nÁrea", gris, (Runnable) this::medirArea});
                h.add(new Object[]{"∠\nÁngulo", gris, (Runnable) this::medirAngulo});
        }
        LinearLayout fila = null;
        for (int i = 0; i < h.size(); i++) {
            if (i % 4 == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
                p.topMargin = dp(4);
                cajaHerr.addView(fila, p);
            }
            Object[] o = h.get(i);
            String txt = (String) o[0];
            TextView t = boton(txt, (Integer) o[1], (Runnable) o[2]);
            t.setTag(o[1]);
            botonesHerr.put(txt.substring(txt.indexOf('\n') + 1), t);
            fila.addView(t, peso());
        }
        if (k == G_AMARRAR || k == G_MEDIR || k == G_MODIFICAR) {
            if (boceto.modo != VistaBoceto.VER) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; }
        }
        boceto.medicion = null;
        boceto.lineaMedida = null;
        marcarHerr();
        mostrarCasilla();
    }

    /** Pone la herramienta de dibujo y la marca en naranja. */
    private void herr(String nombre, int modo) {
        herrActiva = nombre;
        boceto.ponerModo(modo);
        boceto.medicion = null;
        boceto.lineaMedida = null;
        marcarHerr();
        mostrarCasilla();
    }

    private void marcarHerr() {
        for (Map.Entry<String, TextView> e : botonesHerr.entrySet()) {
            TextView t = e.getValue();
            int base = t.getTag() instanceof Integer ? (Integer) t.getTag() : 0xFF455A64;
            boolean activa = e.getKey().equals(herrActiva) && !"Ver".equals(herrActiva) && !"Escoger".equals(herrActiva);
            colorear(t, activa ? 0xFFFF8F00 : base);
        }
    }

    /** Versión 6.1: ✖ Cancelar lo que se está haciendo (lo ya hecho se quita con ↶ Atrás). */
    private void cancelar2D() {
        boceto.terminar();
        boceto.b.limpiarPuntos();
        boceto.ponerModo(VistaBoceto.VER);
        boceto.limpiarSeleccion();
        boceto.medicion = null;
        boceto.lineaMedida = null;
        herrActiva = "Ver";
        marcarHerr();
        mostrarCasilla();
        recalcular();
        aviso("✖ Cancelado");
    }

    /** v6.3: ✓ Listo. Si hay una herramienta trabajando, la termina; si no, revisa el boceto y pasa a la pieza. */
    private void listoTodo() {
        if (boceto.modo != VistaBoceto.VER) {
            listo2D();
            aviso("✓ Listo. Toque ✓ Listo otra vez para pasar a la pieza");
            return;
        }
        if (hoja != null && hoja.pieza >= 0 && !esDesarrollo(hoja)) { preguntaCara(); return; }
        terminarBoceto();
    }

    private boolean pedirElevacion;

    /** v6.5: en el boceto de una cara, la figura cerrada ¿perfora o eleva? */
    private void preguntaCara() {
        new AlertDialog.Builder(this).setTitle("¿Qué hace la figura sobre la cara?")
                .setItems(new String[]{"✂ Perforar / cortar (pasante o con hondo)", "⬆ Elevación (sale hacia afuera)", "✏ Seguir dibujando"}, (d, w) -> {
                    if (w == 2) return;
                    pedirElevacion = w == 1;
                    if (boceto.modo != VistaBoceto.VER) listo2D();
                    terminarBoceto();
                }).show();
    }

    /** v6.5: apenas la figura queda cerrada (rectángulo, círculo o polígono con OK) salen las herramientas del sólido. */
    private void figuraCerrada() {
        if (hoja == null || esMontaje() || esDesarrollo(hoja) || figurasDe(hoja) == 0) return;
        if (hoja.pieza >= 0) { preguntaCara(); return; }
        if (!placasDe(hoja).isEmpty()) return;   // ya es pieza: al terminar se actualiza sola
        String crear = LAMINA.equals(modo) ? "📐 Hacer la lámina (calibre)" : "⬆ Extruir (elevación)";
        new AlertDialog.Builder(this).setTitle("✔ Figura cerrada: ya puede ser sólido")
                .setItems(new String[]{crear, "✏ Seguir dibujando"}, (d, w) -> {
                    if (w != 0) return;
                    if (boceto.modo != VistaBoceto.VER) listo2D();
                    terminarBoceto();
                }).show();
    }

    /** v6.3: ⊕ Al 0,0: la figura se corre y queda pegada al 0,0 por el punto, la mitad de la línea, el centro del círculo o el centro de la figura. */
    private void alCero() {
        Boceto bb = boceto.b;
        if (hoja != null && hoja.pieza >= 0) { aviso("En un boceto sobre una cara se amarra a las aristas de la pieza (las líneas punteadas)"); return; }
        List<Integer> pts = new ArrayList<>();
        for (Integer id : boceto.selPts) if (bb.puntos.containsKey(id)) pts.add(id);
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo != Boceto.TEXTO) s.add(e); }
        if (pts.size() == 1 && s.isEmpty()) { Boceto.Punto p = bb.puntos.get(pts.get(0)); llevarCero(p.x, p.y, pts.get(0), null, null); return; }
        if (pts.isEmpty() && s.size() == 1) {
            Boceto.Ent e = s.get(0);
            if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) { Boceto.Punto c = bb.puntos.get(e.a); llevarCero(c.x, c.y, e.a, null, null); return; }
            Boceto.Punto a = bb.puntos.get(e.a), b2 = bb.puntos.get(e.b);
            List<double[][]> pols = new ArrayList<>();
            List<List<Integer>> figs = Editar2D.figuras(bb, pols);
            List<Integer> fig = null;
            for (List<Integer> f : figs) if (f.contains(e.id)) fig = f;
            if (fig == null) { llevarCero((a.x + b2.x) / 2, (a.y + b2.y) / 2, -1, e, null); return; }
            final List<Integer> figF = fig;
            new AlertDialog.Builder(this).setTitle("⊕ ¿Qué va al 0,0?")
                    .setItems(new String[]{"La mitad de esta línea", "El centro de la figura"}, (d, w) -> {
                        if (w == 0) llevarCero((a.x + b2.x) / 2, (a.y + b2.y) / 2, -1, e, null);
                        else centroAlCero(figF);
                    }).show();
            return;
        }
        aviso("⊕ Toque UNA cosa: una esquina (punto), una línea (su mitad o el centro de la figura) o un círculo (su centro), y luego ⊕ Al 0,0");
    }

    private void centroAlCero(List<Integer> fig) {
        Boceto bb = boceto.b;
        double x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18;
        List<Integer> ps = new ArrayList<>();
        for (Integer id : fig) {
            Boceto.Ent e = bb.entPorId(id);
            if (e == null) continue;
            for (int pid : new int[]{e.a, e.b, e.c}) {
                Boceto.Punto p = bb.puntos.get(pid);
                if (p == null || e.tipo != Boceto.LINEA && pid != e.b && pid != e.c) continue;
                ps.add(pid);
                x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y); x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y);
            }
        }
        if (ps.isEmpty()) return;
        // las dos esquinas opuestas: la más cerca de abajo-izquierda y la más cerca de arriba-derecha
        int pa = -1, pc = -1; double da = 1e18, dc = 1e18;
        for (int id : ps) {
            Boceto.Punto p = bb.puntos.get(id);
            double d1 = Math.hypot(p.x - x0, p.y - y0), d2 = Math.hypot(p.x - x1, p.y - y1);
            if (d1 < da) { da = d1; pa = id; }
            if (d2 < dc) { dc = d2; pc = id; }
        }
        if (pa == pc) { aviso("No encontré las esquinas de esa figura"); return; }
        Boceto.Punto A = bb.puntos.get(pa), C = bb.puntos.get(pc);
        llevarCero((A.x + C.x) / 2, (A.y + C.y) / 2, -1, null, new int[]{pa, pc});
    }

    /** Corre todo el boceto para que (x, y) quede en el 0,0 y lo deja amarrado ahí. */
    private void llevarCero(double x, double y, int punto, Boceto.Ent linea, int[] diagonal) {
        Boceto bb = boceto.b;
        antes();
        bb.restr.removeIf(r -> r.tipo == Boceto.FIJO);   // el amarre viejo al piso se cambia por el 0,0
        for (Boceto.Punto p : bb.puntos.values()) { p.fijo = false; p.x -= x; p.y -= y; }
        if (punto >= 0) bb.restriccion(Boceto.FIJO, -1, -1, punto, -1, null);
        else {
            Boceto.Punto o = bb.punto(0, 0);
            Boceto.Ent ref = linea;
            if (ref == null) {   // diagonal de construcción (punteada) para el centro de la figura
                ref = bb.linea(bb.puntos.get(diagonal[0]), bb.puntos.get(diagonal[1]));
                ref.punteada = true;
            }
            bb.restriccion(Boceto.MEDIO, ref.id, -1, o.id, -1, null);
            bb.restriccion(Boceto.FIJO, -1, -1, o.id, -1, null);
        }
        boceto.limpiarSeleccion();
        recalcular();
        boceto.encuadrar();
        aviso("⊕ Quedó pegado al 0,0. Así mismo llega la pieza al montaje");
    }

    private void listo2D() {
        boceto.terminar();
        boceto.ponerModo(VistaBoceto.VER);
        herrActiva = "Ver";
        marcarHerr();
        mostrarCasilla();
        recalcular();
    }

    private void orto() {
        boceto.orto = !boceto.orto;
        getPreferences(MODE_PRIVATE).edit().putBoolean("orto", boceto.orto).apply();
        aviso(boceto.orto ? "Orto prendido: las líneas salen derechas o paradas" : "Orto apagado");
        grupo2D(G_DIBUJAR);
        boceto.invalidate();
    }

    // ---------------- La casilla de medidas ----------------

    private void mostrarCasilla() {
        int m = boceto.modo;
        boolean ver = m == VistaBoceto.LINEA || m == VistaBoceto.RECT || m == VistaBoceto.CIRCULO || m == VistaBoceto.POLIGONO;
        casilla.setVisibility(ver ? View.VISIBLE : View.GONE);
        if (!ver) return;
        if (m != ultimoModoCasilla) { casilla1.setText(""); casilla2.setText(""); ultimoModoCasilla = m; }   // v6.4: casillas limpias al cambiar de herramienta
        casilla2.setVisibility(m == VistaBoceto.CIRCULO ? View.GONE : View.VISIBLE);
        casillaEt2.setVisibility(m == VistaBoceto.CIRCULO ? View.GONE : View.VISIBLE);
        if (m == VistaBoceto.LINEA) { casillaEt1.setText("Largo"); casillaEt2.setText("Ángulo"); casilla1.setHint("mm"); casilla2.setHint("0°"); }
        else if (m == VistaBoceto.RECT) { casillaEt1.setText("Ancho"); casillaEt2.setText("Alto"); casilla1.setHint("mm"); casilla2.setHint("mm"); }
        else if (m == VistaBoceto.CIRCULO) { casillaEt1.setText("Diámetro"); casilla1.setHint("mm o fórmula"); }
        else { casillaEt1.setText("Lados"); casillaEt2.setText("Radio"); casilla1.setText(String.valueOf(boceto.lados)); casilla2.setHint("mm"); }
    }

    /** Evalúa lo escrito: un número o una fórmula de la tablita. */
    private Double valorDe(String txt) {
        String t = txt == null ? "" : txt.trim();
        if (t.isEmpty()) return null;
        Double n = Formula.numero(t);
        if (n != null) return n;
        try { return medidas.evaluar(t); } catch (Exception e) { aviso("⚠ " + e.getMessage()); return null; }
    }

    private void okCasilla() {
        int m = boceto.modo;
        String t1 = Teclado.tx(casilla1).trim(), t2 = Teclado.tx(casilla2).trim();
        Double v1 = valorDe(t1);
        if (v1 == null) { if (t1.isEmpty()) aviso("Escriba la medida"); return; }
        String err;
        antes();
        if (m == VistaBoceto.LINEA) {
            Double ang = t2.isEmpty() ? Double.valueOf(0) : valorDe(t2);
            if (ang == null) { atras.remove(atras.size() - 1); return; }
            err = boceto.lineaPorMedida(t1, v1, ang);
        } else if (m == VistaBoceto.RECT) {
            Double v2 = valorDe(t2);
            if (v2 == null) { atras.remove(atras.size() - 1); aviso("Escriba el alto"); return; }
            err = boceto.rectPorMedida(t1, v1, t2, v2);
        } else if (m == VistaBoceto.CIRCULO) {
            err = boceto.circuloPorMedida(t1, v1);
        } else {
            int n = (int) Math.round(v1);
            if (n < 3 || n > 60) { atras.remove(atras.size() - 1); aviso("Los lados van de 3 a 60"); return; }
            boceto.lados = n;
            Double v2 = valorDe(t2);
            if (v2 == null) { atras.remove(atras.size() - 1); aviso("Lados: " + n + ". Ahora toque el centro y una punta, o escriba el radio"); return; }
            err = boceto.poligonoPorMedida(n, v2);
        }
        if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
        if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se puso: choca con otra medida o amarre"); return; }
        if (m == VistaBoceto.LINEA) { casilla1.setText(""); casilla2.setText(""); casilla1.requestFocus(); }
        else { if (m != VistaBoceto.POLIGONO) { casilla1.setText(""); casilla2.setText(""); } figuraCerrada(); }
    }

    // ---------------- Modificar ----------------

    private List<Integer> escogidas() {
        List<Integer> l = new ArrayList<>();
        for (Integer id : boceto.sel) if (boceto.b.entPorId(id) != null) l.add(id);
        return l;
    }

    /** Si no hay nada escogido: avisa y deja la hoja en «escoger». */
    private boolean faltaEscoger(String que) {
        if (!escogidas().isEmpty()) return false;
        boceto.ponerModo(VistaBoceto.VER);
        herrActiva = "Ver";
        marcarHerr();
        aviso("Primero toque lo que quiere " + que + " (queda en naranja) y vuelva a tocar el botón");
        return true;
    }

    private VistaBoceto.Pedido pedido(String nombre, VistaBoceto.AlTerminar fin, String... ayudas) {
        herrActiva = nombre;
        marcarHerr();
        VistaBoceto.Pedido p = new VistaBoceto.Pedido(fin, ayudas);
        return p;
    }

    private void moverSel() {
        if (escogidas().isEmpty()) {
            herr("Mover", VistaBoceto.MOVER);
            aviso("Arrastre un punto. Para mover piezas enteras: escójalas primero y toque ✥ Mover");
            return;
        }
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Mover", t -> {
            antes();
            Editar2D.transformar(boceto.b, s, Editar2D.traslado(t.get(1).x - t.get(0).x, t.get(1).y - t.get(0).y), true, 1, false);
            despuesDeModificar("Movido");
        }, "Mover: toque el punto de agarre (por ejemplo una esquina)", "Ahora toque a dónde va ese punto");
        p.fantasma = 1;
        boceto.pedir(p);
    }

    private void copiarSel() {
        if (faltaEscoger("copiar")) return;
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Copiar", t -> {
            antes();
            List<Integer> nuevas = Editar2D.copiar(boceto.b, s, Editar2D.traslado(t.get(1).x - t.get(0).x, t.get(1).y - t.get(0).y), true, 1, false);
            boceto.sel.clear();
            boceto.sel.addAll(nuevas);
            despuesDeModificar("Copiado (la copia quedó escogida)");
        }, "Copiar: toque el punto de agarre", "Ahora toque dónde va la copia");
        p.fantasma = 1;
        boceto.pedir(p);
    }

    private void rotarSel() {
        if (faltaEscoger("rotar")) return;
        List<Integer> s = escogidas();
        boceto.pedir(pedido("Rotar", t -> {
            VistaBoceto.Toque c = t.get(0);
            Teclado.pedir(this, "⟳ Grados (negativo = con el reloj)", Double.NaN, gg -> {
                double g = gg;
                antes();
                // v6.5: rotar exacto: un 📌 de lo que gira (fuera del punto de giro) lo frenaba (90° salía 85°)
                Set<Integer> pts = new HashSet<>();
                for (Integer id : s) { Boceto.Ent e2 = boceto.b.entPorId(id); if (e2 != null) { pts.add(e2.a); pts.add(e2.b); pts.add(e2.c); } }
                boceto.b.restr.removeIf(r -> r.tipo == Boceto.FIJO && pts.contains(r.p1) && boceto.b.puntos.get(r.p1) != null
                        && Math.hypot(boceto.b.puntos.get(r.p1).x - c.x, boceto.b.puntos.get(r.p1).y - c.y) > 0.5);
                for (Integer id : pts) { Boceto.Punto q = boceto.b.puntos.get(id); if (q != null && Math.hypot(q.x - c.x, q.y - c.y) > 0.5) q.fijo = false; }
                int d = Editar2D.giroDerecho(g);
                Editar2D.transformar(boceto.b, s, Editar2D.giro(c.x, c.y, g), d >= 0, 1, d == 1);
                despuesDeModificar("Rotado " + Formula.n(g) + "°");
            });
        }, "Rotar: toque el punto alrededor del cual gira"));
    }

    private void espejoSel() {
        if (faltaEscoger("voltear en espejo")) return;
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Espejo", t -> {
            double ax = t.get(0).x, ay = t.get(0).y, bx = t.get(1).x, by = t.get(1).y;
            if (Math.hypot(bx - ax, by - ay) < 0.5) { aviso("Los dos puntos del espejo deben ser distintos"); return; }
            boolean derecho = Math.abs(bx - ax) < 1e-6 || Math.abs(by - ay) < 1e-6;
            new AlertDialog.Builder(this).setTitle("⇋ Espejo")
                    .setItems(new String[]{"Dejar el original y la copia", "Quitar el original"}, (d, w) -> {
                        antes();
                        List<Integer> nuevas = Editar2D.copiar(boceto.b, s, Editar2D.espejo(ax, ay, bx, by), derecho, 1, false);
                        if (w == 1) for (Integer id : s) { Boceto.Ent e = boceto.b.entPorId(id); if (e != null) boceto.b.borrar(e); }
                        boceto.sel.clear();
                        boceto.sel.addAll(nuevas);
                        despuesDeModificar("Espejo hecho");
                    }).setNegativeButton("Cancelar", null).show();
        }, "Espejo: toque el primer punto de la línea del espejo", "Ahora toque el segundo punto de la línea del espejo");
        p.fantasma = 2;
        boceto.pedir(p);
    }

    private void escalarSel() {
        if (faltaEscoger("agrandar o achicar")) return;
        List<Integer> s = escogidas();
        boceto.pedir(pedido("Escalar", t -> {
            VistaBoceto.Toque c = t.get(0);
            EditText e = campoTexto("2", "");
            dialogo("⤢ Escalar: cuántas veces (2 = el doble, 0.5 = la mitad)", e, "Escalar", () -> {
                Double f = valorDe(Teclado.tx(e));
                if (f == null || f <= 0) { aviso("Escriba un número mayor que cero"); return; }
                antes();
                Editar2D.transformar(boceto.b, s, Editar2D.escala(c.x, c.y, f), true, f, false);
                despuesDeModificar("Escalado ×" + Formula.n(f));
            });
        }, "Escalar: toque el punto que se queda quieto"));
    }

    private void desfase() {
        EditText e = campoTexto(Formula.n(ultDesfase), "mm");
        dialogo("⫽ Desfase: a cuántos mm (o fórmula, ej. tubo)", e, "Seguir", () -> {
            Double d = valorDe(Teclado.tx(e));
            if (d == null || d <= 0) { aviso("Escriba una distancia mayor que cero"); return; }
            ultDesfase = d;
            VistaBoceto.Pedido p = pedido("Desfase", t -> {
                antes();
                String err = Editar2D.desfase(boceto.b, t.get(0).ent, d, t.get(1).x, t.get(1).y);
                if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
                despuesDeModificar(null);
            }, "Desfase " + Formula.n(d) + " mm: toque la línea, el círculo o el arco (una línea de un rectángulo desfasa todo el rectángulo)",
                    "Ahora toque hacia qué lado (adentro o afuera)");
            p.quiereEnt[0] = true;
            p.repetir = true;
            p.linea = false;
            boceto.pedir(p);
        });
    }

    private void recortar() {
        VistaBoceto.Pedido p = pedido("Recortar", t -> {
            antes();
            String err = Editar2D.recortar(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Recortar: toque el pedazo que sobra (se corta hasta donde cruza con otra cosa). Siga tocando; termine con ✓ Listo");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void extender() {
        VistaBoceto.Pedido p = pedido("Extender", t -> {
            antes();
            String err = Editar2D.extender(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Extender: toque la línea cerca de la punta que quiere alargar (llega hasta lo primero que encuentre)");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void partir() {
        VistaBoceto.Pedido p = pedido("Partir", t -> {
            antes();
            String err = Editar2D.partir(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Partir: toque la línea donde la quiere partir (sirve el imán de la mitad)");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void esquina(boolean redondo) {
        EditText e = campoTexto(Formula.n(redondo ? ultRadio : ultChaflan), "mm");
        dialogo(redondo ? "◜ Empalme: radio (mm o fórmula)" : "◸ Chaflán: cuánto se corta en cada lado (mm)", e, "Seguir", () -> {
            Double v = valorDe(Teclado.tx(e));
            if (v == null || v <= 0) { aviso("Escriba una medida mayor que cero"); return; }
            if (redondo) ultRadio = v; else ultChaflan = v;
            VistaBoceto.Pedido p = pedido(redondo ? "Empalme" : "Chaflán", t -> {
                antes();
                String err = Editar2D.esquina(boceto.b, t.get(0).punto, v, redondo);
                if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
                despuesDeModificar(null);
            }, (redondo ? "Empalme R" : "Chaflán ") + Formula.n(v) + ": toque la esquina (el punto donde se juntan dos líneas)");
            p.quierePunto[0] = true;
            p.repetir = true;
            p.linea = false;
            boceto.pedir(p);
        });
    }

    private void matriz() {
        if (faltaEscoger("repetir")) return;
        List<Integer> s = escogidas();
        new AlertDialog.Builder(this).setTitle("▦ Matriz: repetir lo escogido")
                .setItems(new String[]{"▦ En filas y columnas", "◎ En círculo"}, (d, w) -> {
                    if (w == 0) matrizFilas(s); else matrizCirculo(s);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void matrizFilas(List<Integer> s) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Columnas (cuántas a lo ancho, contando la original)"));
        EditText col = campoTexto("4", ""); l.addView(col);
        l.addView(etiqueta("Distancia entre columnas (mm, negativo = a la izquierda)"));
        EditText dx = campoTexto("100", ""); l.addView(dx);
        l.addView(etiqueta("Filas (cuántas hacia arriba, contando la original)"));
        EditText fil = campoTexto("1", ""); l.addView(fil);
        l.addView(etiqueta("Distancia entre filas (mm, negativo = hacia abajo)"));
        EditText dy = campoTexto("100", ""); l.addView(dy);
        new AlertDialog.Builder(this).setTitle("▦ Matriz en filas y columnas").setView(l)
                .setPositiveButton("Hacer", (d, w) -> {
                    Double c = valorDe(Teclado.tx(col)), f = valorDe(Teclado.tx(fil));
                    Double x = valorDe(Teclado.tx(dx)), y = valorDe(Teclado.tx(dy));
                    if (c == null || f == null || x == null || y == null) return;
                    int nc = (int) Math.round(c), nf = (int) Math.round(f);
                    if (nc < 1 || nf < 1 || nc * nf > 400) { aviso("Entre 1 y 400 copias en total"); return; }
                    antes();
                    for (int i = 0; i < nc; i++) for (int j = 0; j < nf; j++) {
                        if (i == 0 && j == 0) continue;
                        Editar2D.copiar(boceto.b, s, Editar2D.traslado(i * x, j * y), true, 1, false);
                    }
                    despuesDeModificar((nc * nf - 1) + " copias");
                }).setNegativeButton("Cancelar", null).show();
    }

    private void matrizCirculo(List<Integer> s) {
        boceto.pedir(pedido("Matriz", t -> {
            VistaBoceto.Toque c = t.get(0);
            LinearLayout l = new LinearLayout(this);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setPadding(dp(18), dp(4), dp(18), 0);
            l.addView(etiqueta("Cuántas en total (contando la original)"));
            EditText n = campoTexto("6", ""); l.addView(n);
            l.addView(etiqueta("Ángulo que ocupan (360 = la vuelta completa)"));
            EditText g = campoTexto("360", ""); l.addView(g);
            new AlertDialog.Builder(this).setTitle("◎ Matriz en círculo").setView(l)
                    .setPositiveButton("Hacer", (d, w) -> {
                        Double nn = valorDe(Teclado.tx(n)), gg = valorDe(Teclado.tx(g));
                        if (nn == null || gg == null) return;
                        int k = (int) Math.round(nn);
                        if (k < 2 || k > 360) { aviso("Entre 2 y 360"); return; }
                        double paso = Math.abs(gg - 360) < 1e-6 ? 360.0 / k : gg / (k - 1);
                        antes();
                        for (int i = 1; i < k; i++) {
                            int dd = Editar2D.giroDerecho(paso * i);
                            Editar2D.copiar(boceto.b, s, Editar2D.giro(c.x, c.y, paso * i), dd >= 0, 1, dd == 1);
                        }
                        despuesDeModificar((k - 1) + " copias en círculo");
                    }).setNegativeButton("Cancelar", null).show();
        }, "Matriz en círculo: toque el centro"));
    }

    /** Después de modificar: se resuelve; si algo no cuadró se avisa (se puede deshacer). */
    private void despuesDeModificar(String ok) {
        boolean bien = recalcular();
        if (!bien) aviso("⚠ Quedó algo que no cuadra con las medidas o amarres. Toque ↶ Atrás si no le gusta");
        else if (ok != null) aviso("✔ " + ok);
        if (boceto.pedido == null) { herrActiva = "Ver"; marcarHerr(); }
    }

    private void dialogo(String titulo, View v, String si, Runnable r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(v);
        new AlertDialog.Builder(this).setTitle(titulo).setView(l)
                .setPositiveButton(si, (d, w) -> r.run())
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Amarrar (botones directos) ----------------

    private void amarrar(int tipo) {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null) s.add(e); }
        List<Integer> pts = new ArrayList<>();
        for (Integer id : boceto.selPts) if (bb.puntos.containsKey(id)) pts.add(id);
        if (boceto.modo != VistaBoceto.VER) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; marcarHerr(); mostrarCasilla(); }
        String falta = null;
        switch (tipo) {
            case Boceto.HORIZ: case Boceto.VERT: {
                List<Boceto.Ent> ls = new ArrayList<>();
                for (Boceto.Ent e : s) if (e.tipo == Boceto.LINEA) ls.add(e);
                if (ls.isEmpty()) { falta = "Toque una o varias líneas"; break; }
                antes();
                for (Boceto.Ent e : ls) {
                    bb.restr.removeIf(r -> (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == e.id);
                    bb.restriccion(tipo, e.id, -1, -1, -1, null);
                }
                terminarAmarre();
                return;
            }
            case Boceto.PERP: case Boceto.PARAL:
                if (s.size() != 2 || s.get(0).tipo != Boceto.LINEA || s.get(1).tipo != Boceto.LINEA) { falta = "Toque exactamente dos líneas"; break; }
                poner(tipo, s.get(0).id, s.get(1).id, -1, -1);
                boceto.limpiarSeleccion();
                return;
            case Boceto.IGUAL:
                if (s.size() < 2) { falta = "Toque dos o más líneas (o círculos)"; break; }
                {
                    boolean lineas = s.get(0).tipo == Boceto.LINEA;
                    for (Boceto.Ent e : s) if ((e.tipo == Boceto.LINEA) != lineas || e.tipo == Boceto.TEXTO) { falta = "Todas deben ser líneas, o todas círculos y arcos"; break; }
                    if (falta != null) break;
                    antes();
                    for (int i = 1; i < s.size(); i++) bb.restriccion(Boceto.IGUAL, s.get(0).id, s.get(i).id, -1, -1, null);
                    terminarAmarre();
                    return;
                }
            case Boceto.COINC:
                if (pts.size() == 2) { poner(Boceto.COINC, -1, -1, pts.get(0), pts.get(1)); boceto.limpiarSeleccion(); return; }
                if (pts.size() == 1 && s.size() == 1 && s.get(0).tipo != Boceto.TEXTO) { poner(Boceto.SOBRE, s.get(0).id, -1, pts.get(0), -1); boceto.limpiarSeleccion(); return; }
                falta = "Toque dos puntos (quedan unidos), o un punto y una línea (el punto queda sobre la línea)";
                break;
            case Boceto.TANG: {
                Boceto.Ent ln = null, ci = null;
                for (Boceto.Ent e : s) { if (e.tipo == Boceto.LINEA) ln = e; else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) ci = e; }
                if (s.size() != 2 || ln == null || ci == null) { falta = "Toque una línea y un círculo (o arco)"; break; }
                poner(Boceto.TANG, ln.id, ci.id, -1, -1);
                boceto.limpiarSeleccion();
                return;
            }
            case Boceto.FIJO:
                if (pts.isEmpty()) { falta = "Toque uno o dos puntos para dejarlos fijos (o sueltos si ya estaban fijos)"; break; }
                antes();
                for (Integer p : pts) {
                    boolean ya = false;
                    for (Boceto.Restr r : bb.restr) if (r.tipo == Boceto.FIJO && r.p1 == p) ya = true;
                    if (ya) bb.restr.removeIf(r -> r.tipo == Boceto.FIJO && r.p1 == p);
                    else bb.restriccion(Boceto.FIJO, -1, -1, p, -1, null);
                }
                terminarAmarre();
                return;
        }
        if (falta != null) aviso(falta);
    }

    private void terminarAmarre() {
        if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)"); return; }
        boceto.limpiarSeleccion();
    }

    /** v6.3: ⫴ distancia entre dos líneas paralelas (por ejemplo, el grueso de un muro). */
    private void cotaParalelas() {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) s.add(e); }
        if (s.size() != 2) { aviso("Toque las dos líneas paralelas y luego ⫴ Entre paral."); return; }
        Boceto.Ent l1 = s.get(0), l2 = s.get(1);
        boolean yaParal = false;
        for (Boceto.Restr r : bb.restr) {
            if (r.tipo == Boceto.PARAL && (r.e1 == l1.id && r.e2 == l2.id || r.e1 == l2.id && r.e2 == l1.id)) yaParal = true;
        }
        boolean hv1 = false, hv2 = false;
        for (Boceto.Restr r : bb.restr) if (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) { if (r.e1 == l1.id) hv1 = true; if (r.e1 == l2.id) hv2 = true; }
        // v6.6: un borde de la cara (punteado y fijo) ya está quieto: si la otra línea ya es ═ o ║, no se repite el amarre (eso chocaba)
        boolean f1 = fijaLinea(bb, l1), f2 = fijaLinea(bb, l2);
        if (!yaParal && !((hv1 || f1) && (hv2 || f2))) { antes(); bb.restriccion(Boceto.PARAL, l1.id, l2.id, -1, -1, null); }
        if (f1 && !f2) { Boceto.Ent t = l1; l1 = l2; l2 = t; }   // la cota va de la línea que se mueve al borde quieto
        Boceto.Restr r = new Boceto.Restr();
        r.tipo = Boceto.C_PL; r.e1 = l1.id; r.p1 = l2.a;
        pedirCota(r, null);
        boceto.limpiarSeleccion();
    }

    private static boolean fijaLinea(Boceto bb, Boceto.Ent e) {
        if (e.punteada) return true;
        Boceto.Punto a = bb.puntos.get(e.a), b = bb.puntos.get(e.b);
        return a != null && b != null && a.fijo && b.fijo;
    }

    /** v6.3: ⟂ distancia de un punto a una línea. */
    private void cotaPuntoLinea() {
        Boceto bb = boceto.b;
        Boceto.Ent ln = null;
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) ln = e; }
        int pt = -1;
        for (Integer id : boceto.selPts) if (bb.puntos.containsKey(id)) pt = id;
        if (pt < 0) for (Integer id : boceto.sel) {   // v6.5: si escogió un círculo, vale su centro
            Boceto.Ent e = bb.entPorId(id);
            if (e != null && (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO)) pt = e.a;
        }
        if (ln == null || pt < 0) { aviso("Toque el centro (o el círculo) y un borde, y luego ⟂ Punto-línea"); return; }
        Boceto.Restr r = new Boceto.Restr();
        r.tipo = Boceto.C_PL; r.e1 = ln.id; r.p1 = pt;
        pedirCota(r, null);
        boceto.limpiarSeleccion();
    }

    // ---------------- v6.6: herramientas de GnaCAD ----------------

    /** ⊶ Unir: dos líneas en fila (que se tocan o casi) quedan como una sola. */
    private void unirLineas() {
        Boceto bb = boceto.b;
        List<Boceto.Ent> ls = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) ls.add(e); }
        if (ls.size() < 2) { aviso("Con ✋ Ver toque las líneas que quiere unir y luego ⊶ Unir"); return; }
        antes();
        int unidas = 0;
        boolean otra = true;
        while (otra) {
            otra = false;
            for (int i = 0; i < ls.size() && !otra; i++) for (int j = 0; j < ls.size() && !otra; j++) {
                if (i == j) continue;
                Boceto.Ent a = ls.get(i), b = ls.get(j);
                int[][] pares = {{a.b, b.a, a.a, b.b}, {a.b, b.b, a.a, b.a}, {a.a, b.a, a.b, b.b}, {a.a, b.b, a.b, b.a}};
                for (int[] q : pares) {
                    Boceto.Punto m1 = bb.puntos.get(q[0]), m2 = bb.puntos.get(q[1]), e1 = bb.puntos.get(q[2]), e2 = bb.puntos.get(q[3]);
                    if (m1 == null || m2 == null || e1 == null || e2 == null) continue;
                    if (Math.hypot(m1.x - m2.x, m1.y - m2.y) > 1) continue;
                    // en fila: la punta del medio está sobre la recta de las puntas de afuera
                    double L = Math.hypot(e2.x - e1.x, e2.y - e1.y);
                    if (L < 1) continue;
                    double dist = Math.abs((e2.x - e1.x) * (e1.y - m1.y) - (e1.x - m1.x) * (e2.y - e1.y)) / L;
                    if (dist > 0.5) continue;
                    Boceto.Ent n = bb.linea(e1, e2);
                    for (Boceto.Restr r : bb.restr) if ((r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && (r.e1 == a.id || r.e1 == b.id)) { bb.restriccion(r.tipo, n.id, -1, -1, -1, null); break; }
                    bb.borrar(a); bb.borrar(b);
                    ls.remove(a); ls.remove(b); ls.add(n);
                    unidas++; otra = true;
                    break;
                }
            }
        }
        boceto.limpiarSeleccion();
        recalcular();
        aviso(unidas == 0 ? "⚠ Esas líneas no están en fila o no se tocan" : "⊶ Unidas: " + unidas + (unidas == 1 ? " unión" : " uniones"));
    }

    /** ⊹ Descomponer: la figura queda como líneas sueltas, sin los amarres de forma (═ ║ ∥ ⊥ = ◡). */
    private void descomponer() {
        Boceto bb = boceto.b;
        Set<Integer> ids = new HashSet<>(boceto.sel);
        if (ids.isEmpty()) { aviso("Con ✋ Ver toque lo que quiere descomponer y luego ⊹ Descomponer"); return; }
        antes();
        int n0 = bb.restr.size();
        bb.restr.removeIf(r -> (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT || r.tipo == Boceto.PARAL || r.tipo == Boceto.PERP || r.tipo == Boceto.IGUAL || r.tipo == Boceto.TANG)
                && (ids.contains(r.e1) || ids.contains(r.e2)));
        int q = n0 - bb.restr.size();
        boceto.limpiarSeleccion();
        recalcular();
        aviso("⊹ Descompuesta: se quitaron " + q + " amarres de forma; las cotas quedan");
    }

    /** ↦ Longitud: cambia el largo de la línea escribiendo la medida (queda como cota). */
    private void longitud() {
        Boceto bb = boceto.b;
        Boceto.Ent ln = null;
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) ln = e; }
        if (ln == null) { aviso("Con ✋ Ver toque la línea y luego ↦ Longitud"); return; }
        final Boceto.Ent L = ln;
        Teclado.pedirFormula(this, "↦ Largo de la línea", Formula.n(Math.round(bb.largo(L) * 10) / 10.0), t -> {
            antes();
            Boceto.Restr c = null;
            for (Boceto.Restr r : bb.restr) if (r.tipo == Boceto.C_LARGO && r.e1 == L.id) c = r;
            if (c != null) c.formula = t; else bb.restriccion(Boceto.C_LARGO, L.id, -1, -1, -1, t);
            if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se pudo: choca con otra medida o amarre"); return; }
            boceto.limpiarSeleccion();
        });
    }

    private final List<Integer> cadenaCotas = new ArrayList<>();

    /** ⊢⊢ Cota continua (cada punto con el anterior) o ⊢ Línea base (todos desde el primero), como en AutoCAD. */
    private void cotasSeguidas(boolean base) {
        new AlertDialog.Builder(this).setTitle(base ? "⊢ Línea base" : "⊢⊢ Cota continua")
                .setItems(new String[]{"↔ Horizontales", "↕ Verticales"}, (d, w) -> {
                    cadenaCotas.clear();
                    final int tipo = w == 0 ? Boceto.C_HORIZ : Boceto.C_VERT;
                    VistaBoceto.Pedido p = pedido(base ? "Línea base" : "Cota continua", t -> {
                        int k = t.get(0).punto;
                        if (k < 0) { aviso("Toque encima de un punto"); return; }
                        if (!cadenaCotas.isEmpty()) {
                            int de = base ? cadenaCotas.get(0) : cadenaCotas.get(cadenaCotas.size() - 1);
                            Boceto.Punto a = boceto.b.puntos.get(de), b = boceto.b.puntos.get(k);
                            if (a != null && b != null && de != k) {
                                antes();
                                double v = Math.abs(tipo == Boceto.C_HORIZ ? b.x - a.x : b.y - a.y);
                                boceto.b.restriccion(tipo, -1, -1, de, k, Formula.n(Math.round(v * 10) / 10.0));
                                if (!recalcular()) { revertir(); recalcular(); aviso("⚠ Esa cota choca con otra"); return; }
                            }
                        }
                        cadenaCotas.add(k);
                        aviso(cadenaCotas.size() == 1 ? "Ahora toque el siguiente punto" : "Siga tocando puntos; ✓ Listo para terminar");
                    }, base ? "Línea base: toque el punto de arranque y luego los demás" : "Cota continua: toque los puntos en orden");
                    p.repetir = true;
                    p.linea = false;
                    p.quierePunto[0] = true;
                    boceto.pedir(p);
                }).show();
    }

    private void cotaAngulo() {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) s.add(e); }
        if (s.size() != 2) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; marcarHerr(); aviso("Toque dos líneas y luego ∠ Ángulo"); return; }
        Boceto.Restr r = new Boceto.Restr();
        r.tipo = Boceto.C_ANG; r.e1 = s.get(0).id; r.e2 = s.get(1).id;
        pedirCota(r, null);
        boceto.limpiarSeleccion();
    }

    // ---------------- Medir ----------------

    private void mostrarMedida(String txt, double[] linea) {
        boceto.medicion = txt;
        boceto.lineaMedida = linea;
        boceto.invalidate();
    }

    private void medirDistancia() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Distancia", t -> {
            double ax = t.get(0).x, ay = t.get(0).y, bx = t.get(1).x, by = t.get(1).y;
            double d = Math.hypot(bx - ax, by - ay), g = Math.toDegrees(Math.atan2(by - ay, bx - ax));
            mostrarMedida("Distancia " + Formula.n(Math.round(d * 10) / 10.0) + " mm · ↔ " + Formula.n(Math.round(Math.abs(bx - ax) * 10) / 10.0)
                    + " · ↕ " + Formula.n(Math.round(Math.abs(by - ay) * 10) / 10.0) + " · " + Formula.n(Math.round(g * 10) / 10.0) + "°", new double[]{ax, ay, bx, by});
        }, "Distancia: toque el primer punto", "Ahora toque el segundo punto");
        p.repetir = true;
        boceto.pedir(p);
    }

    private void medirArea() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Área", t -> {
            double[] a = Editar2D.area(boceto.b, t.get(0).x, t.get(0).y);
            if (a == null) { mostrarMedida(null, null); aviso("Toque adentro de una figura cerrada (rectángulo, polígono o círculo)"); return; }
            mostrarMedida("Área " + String.format(Locale.US, "%.3f", a[0] / 1e6) + " m² (" + Formula.n(Math.round(a[0])) + " mm²) · Perímetro "
                    + Formula.n(Math.round(a[1] * 10) / 10.0) + " mm", null);
        }, "Área: toque adentro de una figura cerrada");
        p.repetir = true;
        p.linea = false;
        p.crudo = true;
        boceto.pedir(p);
    }

    private void medirAngulo() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Ángulo", t -> {
            Boceto.Ent e = boceto.b.entPorId(t.get(0).ent), f = boceto.b.entPorId(t.get(1).ent);
            if (e == null || f == null || e.tipo != Boceto.LINEA || f.tipo != Boceto.LINEA) { aviso("Toque dos líneas"); return; }
            double g = Editar2D.anguloEntre(boceto.b, e, f);
            mostrarMedida("Ángulo " + Formula.n(Math.round(g * 10) / 10.0) + "° (el otro lado " + Formula.n(Math.round((180 - g) * 10) / 10.0) + "°)", null);
        }, "Ángulo: toque la primera línea", "Ahora toque la segunda línea");
        p.quiereEnt[0] = true;
        p.quiereEnt[1] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private EditText campoTexto(String valor, String pista) {
        EditText e = new EditText(this);
        e.setTextSize(18);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        // v6.6: las casillas de medida salen VACÍAS y abren el teclado de Chepe CAD; las de nombre, el del celular solo al tocarlas
        boolean medida = Teclado.esNumero(valor) || pista != null && pista.matches("(?i).*(mm|grados|f[oó]rmula).*");
        if (medida) Teclado.numero(this, e, pista == null || pista.isEmpty() ? "Escriba la medida" : "Escriba la medida (" + pista + ")", valor);
        else {
            e.setText(valor);
            e.setHint(pista != null && pista.matches(".*[0-9].*") ? "" : pista);
            Teclado.letras(this, e);
        }
        return e;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(0xFF90A4AE);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    /** Escribir el valor de una cota nueva: un número (mm) o una fórmula de la tablita; y si quiere, ponerle nombre. */
    private void pedirCota(Boceto.Restr nueva, String sugerido) {
        Boceto bb = boceto.b;
        double actual = bb.medir(nueva);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Medida en mm, o fórmula (ej. ancho - 2*tubo)"));
        EditText val = campoTexto(sugerido != null ? sugerido : Formula.n(actual), "");
        l.addView(val);
        l.addView(etiqueta("Nombre para la tablita (opcional, ej. ancho)"));
        EditText nom = campoTexto("", "sin nombre");
        l.addView(nom);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[nueva.tipo]).setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String v = Teclado.tx(val).trim();
                    if (v.isEmpty()) return;
                    String n = Teclado.tx(nom).trim();
                    antes();
                    if (!n.isEmpty()) {
                        String ok = Medidas.nombreValido(n);
                        if (ok == null) { aviso("Ese nombre no sirve: use letras y números, sin espacios"); atras.remove(atras.size() - 1); return; }
                        Medidas.Fila f = medidas.buscar(ok);
                        if (f == null) { f = new Medidas.Fila(ok, v); medidas.filas.add(f); } else f.formula = v;
                        nueva.formula = ok;
                    } else nueva.formula = v;
                    bb.restr.add(nueva);
                    if (!recalcular() || nueva.error != null) {
                        String por = nueva.error != null ? nueva.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se puso: " + por);
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirDistancia(int p1, int p2) {
        new AlertDialog.Builder(this).setTitle("📏 Distancia entre los dos puntos")
                .setItems(new String[]{"↔ Horizontal", "↕ Vertical", "⤢ Alineada (en línea recta)"}, (d, w) -> {
                    Boceto.Restr r = new Boceto.Restr();
                    r.tipo = w == 0 ? Boceto.C_HORIZ : w == 1 ? Boceto.C_VERT : Boceto.C_DIST;
                    r.p1 = p1; r.p2 = p2;
                    pedirCota(r, null);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void editarCota(Boceto.Restr r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Hoy mide " + boceto.textoCota(r) + (r.error != null ? "\n⚠ " + r.error : "")));
        l.addView(etiqueta("Nuevo valor (mm) o fórmula"));
        EditText val = campoTexto(r.formula, "");
        l.addView(val);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[r.tipo]).setView(l)
                .setPositiveButton("Cambiar", (d, w) -> {
                    String v = Teclado.tx(val).trim();
                    if (v.isEmpty() || v.equals(r.formula)) return;
                    antes();
                    int i = boceto.b.restr.indexOf(r);
                    // si la cota es solo el nombre de una fila, se cambia la fila (así se mueve todo lo que la usa)
                    Medidas.Fila f = medidas.buscar(r.formula);
                    if (f != null && Formula.numero(v) != null) f.formula = v; else r.formula = v;
                    boolean ok = recalcular();
                    Boceto.Restr rr = i >= 0 && i < boceto.b.restr.size() ? boceto.b.restr.get(i) : r;
                    if (!ok || rr.error != null) {
                        String por = rr.error != null ? rr.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se cambió: " + por);
                    }
                })
                .setNeutralButton("🗑 Quitar cota", (d, w) -> { antes(); boceto.b.restr.remove(r); recalcular(); })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirTexto(double x, double y) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        EditText t = campoTexto("", "Ej. COCINA");
        l.addView(t);
        l.addView(etiqueta("Alto de la letra (mm)"));
        EditText al = campoTexto("150", "");
        al.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(al);
        new AlertDialog.Builder(this).setTitle("A Texto").setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String s = Teclado.tx(t).trim();
                    if (s.isEmpty()) return;
                    antes();
                    Boceto.Punto p = boceto.b.punto(x, y);
                    Boceto.Ent e = boceto.b.ent(Boceto.TEXTO);
                    e.a = p.id;
                    e.texto = s;
                    Double h = Formula.numero(Teclado.tx(al));
                    e.r = h == null || h <= 0 ? 150 : h;
                    boceto.invalidate();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🗑 Quitar: los amarres y cotas de lo escogido, para quitar el que sobre. */
    private void amarrar2D() {
        Boceto bb = boceto.b;
        Set<Integer> s = new HashSet<>(boceto.sel), pts = new HashSet<>(boceto.selPts);
        List<Boceto.Restr> suyas = new ArrayList<>();
        for (Boceto.Restr r : bb.restr) {
            boolean es = s.contains(r.e1) || s.contains(r.e2) || pts.contains(r.p1) || pts.contains(r.p2);
            if (s.isEmpty() && pts.isEmpty()) es = true;
            if (es) suyas.add(r);
        }
        if (suyas.isEmpty()) {
            aviso(s.isEmpty() && pts.isEmpty() ? "No hay amarres ni cotas" : "Eso que escogió no tiene amarres ni cotas");
            return;
        }
        String[] nom = new String[suyas.size()];
        for (int i = 0; i < nom.length; i++) {
            Boceto.Restr r = suyas.get(i);
            nom[i] = "🗑 " + Boceto.NOMBRES[r.tipo] + (r.esCota() ? " (" + boceto.textoCota(r) + ")" : "");
        }
        new AlertDialog.Builder(this).setTitle(s.isEmpty() && pts.isEmpty() ? "🗑 Quitar (todos los amarres)" : "🗑 Quitar amarre de lo escogido")
                .setItems(nom, (d, w) -> { antes(); bb.restr.remove(suyas.get(w)); recalcular(); })
                .setNegativeButton("Cerrar", null).show();
    }

    private void poner(int tipo, int e1, int e2, int p1, int p2) {
        antes();
        boceto.b.restriccion(tipo, e1, e2, p1, p2, null);
        if (!recalcular()) {
            revertir();
            recalcular();
            aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)");
        }
    }

    private void borrar2D() {
        Boceto bb = boceto.b;
        if (boceto.sel.isEmpty() && boceto.selPts.isEmpty()) { aviso("Con ✋ Ver toque lo que quiere borrar"); return; }
        antes();
        for (Integer id : new ArrayList<>(boceto.sel)) { Boceto.Ent e = bb.entPorId(id); if (e != null) bb.borrar(e); }
        for (Integer p : new ArrayList<>(boceto.selPts)) {
            for (Boceto.Ent e : new ArrayList<>(bb.ents)) if (e.a == p || e.b == p || e.c == p) bb.borrar(e);
            bb.puntos.remove(p);
            bb.limpiarPuntos();
        }
        boceto.limpiarSeleccion();
        recalcular();
    }

    /** El boceto en PDF tamaño carta, todo en negro nítido, con su escala. */
    private void pdf2D() {
        if (boceto.b.vacio()) { aviso("El boceto está vacío"); return; }
        try {
            PdfDocument doc = new PdfDocument();
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create());
            hojaCarta(pg.getCanvas());
            doc.finishPage(pg);
            guardarPdf(doc, "MiInventor_Plano_");
        } catch (Exception ex) {
            aviso("No se pudo hacer el PDF");
        }
    }

    /** El plano en hoja carta (612 × 792 puntos): sirve para el PDF y para el PNG. */
    private void hojaCarta(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTextSize(13);
        p.setFakeBoldText(true);
        c.drawText("CHEPE CAD · " + nombreProyecto, 40, 45, p);
        p.setFakeBoldText(false);
        p.setTextSize(9.5f);
        boceto.imprimir(c, 36, 60, 540, 640);
        double esc = boceto.escalaImpresa;   // puntos de papel por mm
        long e = Math.max(1, Math.round(1 / (esc / 72.0 * 25.4)));
        c.drawText("Medidas en milímetros · Escala aprox. 1:" + e + " · " + new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "CO")).format(new Date()), 40, 735, p);
        // las medidas con nombre de la tablita, abajo
        StringBuilder sb = new StringBuilder();
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            if (sb.length() > 0) sb.append("   ");
            sb.append(f.nombre).append(" = ").append(v == null ? "⚠" : Formula.n(v));
        }
        if (sb.length() > 0) c.drawText(sb.length() > 110 ? sb.substring(0, 110) + "…" : sb.toString(), 40, 752, p);
        Paint marco = new Paint();
        marco.setStyle(Paint.Style.STROKE);
        marco.setColor(Color.BLACK);
        marco.setStrokeWidth(1);
        c.drawRect(30, 55, 582, 720, marco);
    }

    /** v6.5: el plano como imagen PNG (hoja carta a 150 ppp); con WhatsApp se manda de una. */
    private void png2D(boolean whatsapp) {
        if (boceto.b.vacio()) { aviso("El boceto está vacío"); return; }
        try {
            android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(1275, 1650, android.graphics.Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bm);
            c.drawColor(Color.WHITE);
            c.scale(1275f / 612f, 1650f / 792f);
            hojaCarta(c);
            ContentValues cv = new ContentValues();
            String nom = "ChepeCAD_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                    + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".png";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o); }
            bm.recycle();
            if (!whatsapp) { aviso("✔ PNG guardado en Descargas/MiBarra/MiInventor"); return; }
            Intent i = new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent w = new Intent(i).setPackage("com.whatsapp");
            try { startActivity(w); } catch (Exception e) { try { startActivity(Intent.createChooser(i, "Enviar el plano")); } catch (Exception ignored) {} }
        } catch (Exception ex) {
            aviso("No se pudo hacer la imagen");
        }
    }

    void guardarPdf(PdfDocument doc, String prefijo) throws Exception {
        ContentValues cv = new ContentValues();
        String nom = prefijo + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".pdf";
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        try (OutputStream o = getContentResolver().openOutputStream(u)) { doc.writeTo(o); }
        doc.close();
        aviso("✔ PDF guardado en Descargas/MiBarra/MiInventor");
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception ignored) {}
    }

    // =====================================================================
    //                              MEDIDAS (mini Excel)
    // =====================================================================

    private View armarMedidas() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView ay = new TextView(this);
        ay.setText("Cada medida tiene nombre y fórmula. Las cotas del 2D y las piezas del 3D pueden usar estos nombres: "
                + "cambia un número y se rehace todo. Funciones: redondear( ), arriba( ), abajo( ), min( ; ), max( ; ), si(cond; sí; no).");
        ay.setTextColor(0xFFB0BEC5);
        ay.setTextSize(13);
        ay.setPadding(dp(56), dp(4), dp(6), dp(6));
        l.addView(ay);
        ScrollView sv = new ScrollView(this);
        listaMedidas = new LinearLayout(this);
        listaMedidas.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listaMedidas);
        l.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout acc = fila(
                boton("➕ Agregar medida", 0xFF00897B, () -> editarFila(null)),
                boton("💬 WhatsApp", 0xFF25A244, () -> compartirTexto(textoMedidas())),
                boton("↶ Atrás", 0xFF5E35B1, this::deshacer));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(46));
        ap.topMargin = dp(4);
        l.addView(acc, ap);
        return l;
    }

    private void pintarMedidas() {
        listaMedidas.removeAllViews();
        if (medidas.filas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay medidas. Toque ➕ Agregar medida, o en el 2D ponga una cota y escríbale un nombre.\n\n"
                    + "Ejemplo:\n  ancho = 4000\n  tubo = 40\n  travesano = ancho - 2*tubo\n  tubos_6m = arriba(total / 6000)");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            listaMedidas.addView(t);
        }
        int n = 1;
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            String err = medidas.errorDe(f.nombre);
            boolean soloNumero = Formula.numero(f.formula) != null;
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(err != null ? 0xFF4A1C1C : 0xFF1E2A3A);
            g.setCornerRadius(dp(8));
            r.setBackground(g);
            TextView num = new TextView(this);
            num.setText(String.valueOf(n++));
            num.setTextColor(0xFF78909C);
            num.setTextSize(12);
            r.addView(num, new LinearLayout.LayoutParams(dp(22), -2));
            TextView t = new TextView(this);
            t.setText(f.nombre + (soloNumero ? "" : "\n= " + f.formula));
            t.setTextColor(Color.WHITE);
            t.setTextSize(15);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView val = new TextView(this);
            val.setText(err != null ? "⚠ " + err : Formula.n(v == null ? 0 : v));
            val.setTextColor(err != null ? 0xFFFF8A80 : 0xFFFFD54A);
            val.setTextSize(err != null ? 12 : 17);
            val.setTypeface(Typeface.DEFAULT_BOLD);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(err != null ? dp(150) : -2, -2));
            r.setOnClickListener(x -> editarFila(f));
            r.setOnLongClickListener(x -> {
                new AlertDialog.Builder(this).setMessage("¿Borrar la medida «" + f.nombre + "»? Lo que la use quedará con error.")
                        .setPositiveButton("Borrar", (d, w) -> { antes(); medidas.filas.remove(f); recalcular(); })
                        .setNegativeButton("Cancelar", null).show();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            listaMedidas.addView(r, lp);
        }
        // los valores que pone la app
        TextView sub = new TextView(this);
        StringBuilder s = new StringBuilder("Valores de la app (solo leer):\n");
        for (Map.Entry<String, Double> e : medidas.fijos.entrySet()) s.append(e.getKey()).append(" = ").append(Formula.n(e.getValue())).append("   ");
        sub.setText(s.toString().trim());
        sub.setTextColor(0xFF90A4AE);
        sub.setTextSize(13);
        sub.setPadding(dp(8), dp(12), dp(8), dp(8));
        listaMedidas.addView(sub);
    }

    private void editarFila(Medidas.Fila f) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Nombre (sin espacios, ej. ancho)"));
        EditText nom = campoTexto(f == null ? "" : f.nombre, "ancho");
        l.addView(nom);
        l.addView(etiqueta("Valor o fórmula (ej. 4000  ·  ancho - 2*tubo)"));
        EditText fo = campoTexto(f == null ? "" : f.formula, "4000");
        l.addView(fo);
        new AlertDialog.Builder(this).setTitle(f == null ? "➕ Medida nueva" : "✏ " + f.nombre).setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = Medidas.nombreValido(Teclado.tx(nom));
                    String v = Teclado.tx(fo).trim();
                    if (n == null) { aviso("El nombre debe empezar con letra, sin espacios ni signos (y no puede ser T1, total…)"); return; }
                    if (v.isEmpty()) { aviso("Escriba el valor o la fórmula"); return; }
                    Medidas.Fila otra = medidas.buscar(n);
                    if (otra != null && otra != f) { aviso("Ya hay una medida «" + n + "»"); return; }
                    antes();
                    String viejo = f == null ? null : f.nombre;
                    Medidas.Fila x = f == null ? new Medidas.Fila() : f;
                    x.nombre = n;
                    x.formula = v;
                    if (f == null) medidas.filas.add(x);
                    // si cambió el nombre, se cambia también donde se usaba
                    if (viejo != null && !Formula.plano(viejo).equals(Formula.plano(n))) renombrar(viejo, n);
                    if (!recalcular()) {
                        revertir();
                        recalcular();
                        aviso("⚠ Con ese valor el dibujo no cuadra: no se cambió");
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Cambia un nombre dentro de todas las fórmulas. */
    private void renombrar(String viejo, String nuevo) {
        String re = "(?i)(?<![\\p{L}\\p{N}_])" + java.util.regex.Pattern.quote(viejo) + "(?![\\p{L}\\p{N}_])";
        for (Medidas.Fila f : medidas.filas) f.formula = f.formula.replaceAll(re, nuevo);
        for (Boceto.Restr r : boceto.b.restr) r.formula = r.formula.replaceAll(re, nuevo);
        for (Pieza p : piezas) for (Map.Entry<String, String> e : p.f.entrySet()) e.setValue(e.getValue().replaceAll(re, nuevo));
    }

    private String textoMedidas() {
        StringBuilder s = new StringBuilder("CHEPE CAD · MEDIDAS · ").append(nombreProyecto).append("\n\n");
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            s.append(f.nombre).append(" = ");
            if (Formula.numero(f.formula) == null) s.append(f.formula).append(" = ");
            s.append(v == null ? "⚠ error" : Formula.n(v)).append(" mm\n");
        }
        return s.toString();
    }

    // =====================================================================
    //                              3D
    // =====================================================================

    private boolean movioPieza, avisoFija;

    private View armar3D() {
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        vista = new Vista3D(this);
        vista.piezas = piezas;
        vista.refs = refs;
        vista.version = VERSION;
        vista.alCara = this::menuCara;
        vista.alDoble = this::menuDoble;
        vista.alEscoger = id -> {
            escogida = id; pintarLista();
            Pieza pz = porId(id);   // v6.6: el nombre sale un momento (en el 3D ya no hay letreros)
            if (pz != null) { if (toastNombre != null) toastNombre.cancel(); toastNombre = Toast.makeText(this, pz.nombre(), Toast.LENGTH_SHORT); toastNombre.show(); }
        };
        vista.alMover = new Vista3D.AlMover() {
            @Override public void mover(int id, float dx, float dy, float dz) {
                Pieza p = porId(id);
                if (p == null) return;
                if (p.fija) { if (!avisoFija) { aviso("📌 " + p.nombre() + " está fija. Suéltela en 🔗 Amarrar → 📌 Fijar"); avisoFija = true; } return; }
                if (!movioPieza) { antes(); movioPieza = true; }
                p.cx += dx; p.cy += dy; p.cz += dz;
                p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                vista.invalidate();
            }
            @Override public void soltar() { movioPieza = false; avisoFija = false; pintarLista(); }
        };
        raiz.addView(vista, new LinearLayout.LayoutParams(-1, 0, 1.15f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(4);
        raiz.addView(armarPanel3D(), pp);

        LinearLayout vistas = new LinearLayout(this);
        TextView b3d = boton("🧊 3D 1/4", 0xFF37474F, null);
        b3d.setOnClickListener(x -> {
            // versión 4.2: cada toque mira desde otra esquina
            esquina3D = (esquina3D + 1) % 4;
            vista.vista(-35 + 90 * esquina3D, 25);
            b3d.setText("🧊 3D " + (esquina3D + 1) + "/4");
        });
        vistas.addView(b3d, peso());
        vistas.addView(boton("Frente", 0xFF37474F, () -> vista.vista(0, 0)), peso());
        TextView bLado = boton("Lado ⇄", 0xFF37474F, null);
        bLado.setOnClickListener(x -> { ladoDer = !ladoDer; vista.vista(ladoDer ? -90 : 90, 0); aviso(ladoDer ? "Visto por la derecha" : "Visto por la izquierda"); });
        vistas.addView(bLado, peso());
        vistas.addView(boton("Arriba", 0xFF37474F, () -> vista.vista(0, 89)), peso());
        vistas.addView(boton("⛶ Todo", 0xFF37474F, () -> vista.encuadrar()), peso());
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(36));
        vp.topMargin = dp(4);
        raiz.addView(vistas, vp);

        // Versión 2: qué hace un dedo (versión 6: «mover pieza» solo en el montaje)
        filaModos = new LinearLayout(this);
        String[][] md = {{"✋ Correr vista", "" + Vista3D.CORRER}, {"✥ Mover pieza", "" + Vista3D.MOVER}};
        for (String[] m : md) {
            final int k = Integer.parseInt(m[1]);
            TextView t = boton(m[0], 0xFF37474F, () -> modo3D(k));
            t.setTag(k);
            botonesModo3D.add(t);
            filaModos.addView(t, peso());
        }
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(36));
        mp.topMargin = dp(4);
        raiz.addView(filaModos, mp);

        // versión 6: los botones cambian según lo que se está haciendo (pieza, lámina, casa o montaje)
        cajaAcciones = new LinearLayout(this);
        cajaAcciones.setOrientation(LinearLayout.VERTICAL);
        raiz.addView(cajaAcciones, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        sv.addView(lista);
        // v6.6: la lista toma solo lo que necesita (máximo un tercio); el resto es para el 3D, sin espacio vacío abajo
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(120));
        lp.topMargin = dp(4);
        raiz.addView(sv, lp);
        svLista = sv;
        modo3D(Vista3D.CORRER);
        return raiz;
    }

    private void modo3D(int m) {
        if (vista.modo == m && m != Vista3D.CORRER) m = Vista3D.CORRER;   // versión 4.2: tocar otra vez lo apaga
        vista.modo = m;
        for (TextView t : botonesModo3D) colorear(t, ((Integer) t.getTag()) == m ? 0xFFFF8F00 : 0xFF37474F);
        if (m == Vista3D.MOVER) aviso("Arrastre la pieza con el dedo (se mueve de 5 en 5 mm)");
    }

    private String resumen(Pieza p) {
        StringBuilder s = new StringBuilder();
        s.append(p.fija ? "📌 " : "").append(p.nombre()).append(" · ").append(p.referencia()).append("\n")
                .append(Pieza.n(p.largo)).append(" mm");
        if (p.f.containsKey("largo")) s.append(" (= ").append(p.f.get("largo")).append(")");
        s.append(" · ").append(p.marco != null && p.tipo != Pieza.PLACA ? "⟳ girada" : Pieza.DIRS[p.dir].substring(0, 1));
        if (Math.abs(p.incl) > 0.01f) s.append(" inclinado ").append(Pieza.n(p.incl)).append("°");
        Pieza pp = porId(p.padre);
        if (pp != null) {
            s.append(" · unido a ").append(pp.nombre()).append(p.punto == 0 ? " (inicio" : p.punto == 1 ? " (final" : " (a " + Pieza.n(p.aMm) + " mm");
            s.append(p.cara > 0 ? ", " + Pieza.CARAS_UNION[p.cara].toLowerCase() : "").append(")");
            String cor = p.textoUnion();
            int k = cor.indexOf(" · corrido");
            if (k >= 0) s.append(cor.substring(k));
            if (Math.abs(p.sep) > 0.01f) s.append(" · separ. ").append(Pieza.n(p.sep)).append(" mm");
        }
        if (!p.huecos.isEmpty()) s.append(" · ").append(p.huecos.size()).append(p.huecos.size() == 1 ? " hueco" : " huecos");
        return s.toString();
    }

    private ScrollView svLista;
    private Toast toastNombre;

    /** v6.6: la lista de abajo crece con lo que tiene, hasta un tercio de la pantalla. */
    private void ajustarLista() {
        if (svLista == null) return;
        int filas = 0;
        for (int i = 0; i < lista.getChildCount(); i++) filas++;
        int alto = Math.min(filas * dp(50) + dp(8), getResources().getDisplayMetrics().heightPixels / 3);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) svLista.getLayoutParams();
        if (lp != null && lp.height != alto) { lp.height = alto; svLista.setLayoutParams(lp); }
    }

    private void pintarLista() {
        lista.post(this::ajustarLista);
        if (lista == null) return;
        lista.removeAllViews();
        if (!refs.isEmpty()) {
            tituloArbol("📏 Referencias (planos, ejes, puntos)");
            for (Ref r : new ArrayList<>(refs)) filaArbol(r.texto(), 0xFF2A2340, false, r.visible,
                    () -> aviso(r.nombre + (r.tipo == Ref.PLANO ? ": se puede usar para un boceto o para amarrar" : r.tipo == Ref.EJE ? ": aparece al amarrar por ejes" : "")),
                    () -> { r.visible = !r.visible; recalcular(); },
                    () -> editarRef(r),
                    () -> { antes(); refs.remove(r); recalcular(); });
        }
        boolean hayBoceto = false;
        if (!esMontaje()) for (Hoja h : hojas) if (!h.b.vacio() || hojas.size() > 1) hayBoceto = true;
        if (hayBoceto) {
            tituloArbol("🌳 Árbol del montaje · ✏ Bocetos");
            for (Hoja h : hojas) filaArbol("✏ " + h.nombre + " · " + h.plano + usadoEn(h), 0xFF1A2F4A, false, h.visible,
                    () -> { vista.hojaResaltada = vista.hojaResaltada == h.id ? -1 : h.id; vista.invalidate(); },
                    () -> { h.visible = !h.visible; vista.invalidate(); pintarLista(); },
                    () -> abrirHoja(h), () -> borrarHoja(h));
            if (!piezas.isEmpty()) tituloArbol("🧩 Piezas");
        }
        if (!piezas.isEmpty()) {
            for (Pieza p : piezas) filaArbol((p.lamina ? "📐 " : p.tipo == Pieza.PLACA ? "⬆ " : "") + resumen(p), p.tipo == Pieza.PLACA ? 0xFF123044 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34,
                    p.id == escogida, !p.oculta,
                    () -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); },
                    () -> { p.oculta = !p.oculta; if (p.oculta && escogida == p.id) escogida = -1; vista.escogida = escogida; vista.invalidate(); pintarLista(); },
                    () -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); if (esMontaje() && p.lib != null && !p.lib.isEmpty()) abrirPiezaDeMontaje(); else editar(p); },
                    () -> eliminar(p));
            if (!esMontaje()) for (Pieza p : piezas) {
                if (!p.lamina || p.dobleces.isEmpty()) continue;
                tituloArbol("↪ Dobleces de " + p.nombre() + " (toque para cambiar)");
                for (int i = 0; i < p.dobleces.size(); i++) {
                    final Pieza.Doblez db = p.dobleces.get(i);
                    final int k = i;
                    filaDoblez(p, db, k);
                }
            }
            if (esMontaje()) for (Pieza p : piezas) {
                List<String> am = new ArrayList<>(p.amarres);
                if (p.padre >= 0 && !hayPegada(p)) am.add(0, "🔗 pegada a " + (porId(p.padre) == null ? "otra pieza" : porId(p.padre).nombre()));
                if (p.fija) am.add(0, "📌 fija");
                if (am.isEmpty()) continue;
                tituloArbol("🔗 Amarres de " + p.nombre());
                for (String t : am) filaAmarre(p, t);
            }
            return;
        }
        if (hayBoceto) return;
        if (piezas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Toque ✏ Boceto para dibujar una figura y luego ⬆ Extruir, o ➕ Tubo para poner un tubo.\n\nCada pieza arranca en el punto 0 o pegada a otra pieza (al inicio, al final o a una medida), "
                    + "y puede quedar separada los milímetros que usted diga.\n\nUn dedo corre la vista (o gira con 🔄, o arrastra la pieza con ✥), dos dedos acercan. "
                    + "En el largo puede escribir una fórmula de la tablita, por ejemplo: ancho - 2*tubo.");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            lista.addView(t);
            return;
        }
        for (Pieza p : piezas) {
            TextView t = new TextView(this);
            t.setText(resumen(p));
            t.setTextColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            t.setTextSize(14);
            t.setPadding(dp(10), dp(7), dp(8), dp(7));
            GradientDrawable g = new GradientDrawable();
            g.setColor(p.id == escogida ? 0xFFFFB300 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34);
            g.setCornerRadius(dp(8));
            t.setBackground(g);
            t.setOnClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); });
            t.setOnLongClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); opcionesPieza(p); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            lista.addView(t, lp);
        }
    }

    private void opcionesPieza(Pieza p) {
        new AlertDialog.Builder(this).setTitle(p.nombre())
                .setItems(new String[]{"✏ Editar", "⧉ Copiar (queda pegada al final de esta)", "⟳ Rotar", "🔗 Amarrar a otra pieza", "🗑 Eliminar"}, (d, w) -> {
                    if (w == 0) editar(p);
                    else if (w == 1) copiarEscogida();
                    else if (w == 2) rotar();
                    else if (w == 3) amarrar3D();
                    else eliminar(p);
                }).show();
    }

    private void copiarEscogida() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        antes();
        Pieza c = p.copia(nuevoId());
        if (c == null) return;
        if (c.lib != null && !c.lib.isEmpty()) c.titulo = c.lib + ":" + (instancias(c.lib) + 1);
        else if (c.titulo != null && !c.titulo.isEmpty()) c.titulo = c.titulo + " copia";
        c.fija = false;
        c.amarres.clear();
        c.padre = p.id;
        c.punto = 1;
        c.sep = 0;
        c.cx = c.cy = c.cz = 0;
        c.f.remove("sep"); c.f.remove("cx"); c.f.remove("cy"); c.f.remove("cz"); c.f.remove("aMm");
        piezas.add(c);
        escogida = c.id;
        vista.encuadrar();
        recalcular();
        aviso("Copia " + c.nombre() + " pegada al final de " + p.nombre());
    }

    /** Las piezas que cuelgan de esta (para no amarrar en círculo y para rotar todo junto). */
    private Set<Integer> descendientes(int id) {
        Set<Integer> r = new HashSet<>();
        boolean cambio = true;
        r.add(id);
        while (cambio) {
            cambio = false;
            for (Pieza p : piezas) if (!r.contains(p.id) && r.contains(p.padre)) { r.add(p.id); cambio = true; }
        }
        return r;
    }

    /** Al eliminar o soltar, lo que estaba unido se queda en su puesto. */
    private void soltarEnSuPuesto(Pieza h) {
        Map<Integer, Pieza> m = mapa();
        float[] ini = h.inicio(m, 0), dir = h.direccion();
        h.padre = -1;
        h.cara = 0;
        h.cx = ini[0] - dir[0] * h.sep;
        h.cy = ini[1] - dir[1] * h.sep;
        h.cz = ini[2] - dir[2] * h.sep;
        h.f.remove("cx"); h.f.remove("cy"); h.f.remove("cz");
    }

    private void eliminar(Pieza p) {
        new AlertDialog.Builder(this).setMessage("¿Eliminar " + p.nombre() + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    antes();
                    for (Pieza h : piezas) if (h.padre == p.id) soltarEnSuPuesto(h);
                    piezas.remove(p);
                    escogida = -1;
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** ⟳ Rotar 90°: la pieza y todo lo que tiene pegado giran juntos. */
    private void rotar() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        new AlertDialog.Builder(this).setTitle("⟳ Rotar " + p.nombre() + " (y lo que tiene pegado)")
                .setItems(new String[]{"↻ 90° en el piso (alrededor de Z)", "↻ 90° parándola (alrededor de X)", "↻ 90° de lado (alrededor de Y)",
                        "↕ Cambiar la inclinación…", "🔁 Girar la sección 90° (ángulo o platina)",
                        "∡ Girar a cualquier ángulo (X, Y o Z)…", "🚪 Girar sobre un eje o una arista…"}, (d, w) -> {
                    if (p.fija) { aviso("📌 " + p.nombre() + " está fija. Suéltela en 🔗 Amarrar → 📌 Fijar"); return; }
                    if (w == 3) {
                        if (p.marco != null && p.tipo != Pieza.PLACA) aviso("Esta pieza está girada libre: use ∡ Girar a cualquier ángulo");
                        else inclinacion(p);
                        return;
                    }
                    if (w == 5) { anguloLibre(p); return; }
                    if (w == 6) { empezarEjes(13); return; }
                    antes();
                    if (w == 4) {
                        if (p.marco != null) girarPieza(p, p.inicio(mapaPiezas(), 0), p.direccion(), 90, false);
                        else p.giro = (p.giro + 1) & 3;
                        recalcular();
                        return;
                    }
                    // versión 5: si alguna está girada libre (o es placa), se gira con cuentas exactas
                    boolean libre = false;
                    for (Integer id : descendientes(p.id)) { Pieza x = porId(id); if (x != null && x.marco != null) libre = true; }
                    if (libre) {
                        float[][] ax = {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}};
                        girarPieza(p, p.inicio(mapaPiezas(), 0), ax[w], 90, false);
                        vista.encuadrar();
                        recalcular();
                        return;
                    }
                    for (Integer id : descendientes(p.id)) {
                        Pieza x = porId(id);
                        if (x == null) continue;
                        x.dir = Pieza.girarDir(x.dir, w);
                        if (x != p) {
                            float[] v = Pieza.girarVec(new float[]{x.cx, x.cy, x.cz}, w);
                            x.cx = v[0]; x.cy = v[1]; x.cz = v[2];
                        }
                    }
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cerrar", null).show();
    }

    private void inclinacion(Pieza p) {
        EditText e = campoTexto(Pieza.n(p.incl), "grados");
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        new AlertDialog.Builder(this).setTitle("Inclinación de " + p.nombre() + " (0 = derecho)").setView(e)
                .setPositiveButton("Listo", (d, w) -> {
                    Double v = Formula.numero(Teclado.tx(e));
                    if (v == null) return;
                    antes();
                    p.incl = v.floatValue();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🔗 Amarrar la pieza escogida a otra (o soltarla dejándola en su puesto). */

    // ---------------- Versión 4.2: lista de operaciones del boceto 2D y tabla de propiedades ----------------

    private LinearLayout listaOps;
    private ScrollView svOps;
    private TextView tiraOps;
    private boolean opsAbiertas = true;

    private View armarOps() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        tiraOps = boton("📋 Operaciones del boceto ▼", 0xFF263238, null);
        tiraOps.setTextSize(13);
        tiraOps.setOnClickListener(v -> {
            opsAbiertas = !opsAbiertas;
            svOps.setVisibility(opsAbiertas ? View.VISIBLE : View.GONE);
            pintarOps();
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(34));
        tp.topMargin = dp(4);
        c.addView(tiraOps, tp);
        return c;
    }

    private String nombreEnt(Map<Integer, String> nom, int id) {
        String n = nom.get(id);
        return n == null ? "?" : n;
    }

    /** Nombres cortos: L1, L2… líneas · C1… círculos · A1… arcos · X1… textos. */
    private Map<Integer, String> nombres2D() {
        Map<Integer, String> m = new HashMap<>();
        int l = 0, c = 0, a = 0, x = 0;
        for (Boceto.Ent e : boceto.b.ents) {
            String n = e.tipo == Boceto.LINEA ? "L" + (++l) : e.tipo == Boceto.CIRCULO ? "C" + (++c) : e.tipo == Boceto.ARCO ? "A" + (++a) : "X" + (++x);
            m.put(e.id, n);
        }
        return m;
    }

    private void filaOp(String txt, int fondo, boolean escogida, View.OnClickListener al) { filaOp(txt, fondo, escogida, al, null); }

    /** v6.6: cada renglón con ✏ Arreglar y 🗑 Borrar. */
    private void filaOp(String txt, int fondo, boolean escogida, View.OnClickListener al, Runnable borrar) {
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(escogida ? Color.BLACK : Color.WHITE);
        t.setTextSize(14);
        t.setPadding(dp(10), dp(6), dp(8), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(escogida ? 0xFFFFB300 : fondo);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setOnClickListener(al);
        f.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (borrar != null) {
            TextView ar = boton("✏", 0xFF1565C0, () -> al.onClick(t));
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(44), dp(36));
            ap.leftMargin = dp(3);
            f.addView(ar, ap);
            TextView bo = boton("🗑", 0xFFC62828, borrar);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(44), dp(36));
            bp.leftMargin = dp(3);
            f.addView(bo, bp);
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(3);
        listaOps.addView(f, p);
    }

    private void pintarOps() {
        if (tiraOps == null) return;
        Boceto bb = boceto.b;
        int total = bb.ents.size() + bb.restr.size() + placasDe(hoja).size();
        tiraOps.setText("📋 Operaciones del boceto (" + total + ") " + (opsAbiertas ? "▲" : "▼"));
        if (!opsAbiertas) return;
        listaOps.removeAllViews();
        if (total == 0) { filaOp("Todavía no hay nada dibujado", 0xFF263238, false, v -> { }); return; }
        Map<Integer, String> nom = nombres2D();
        for (Boceto.Ent e : bb.ents) {
            Boceto.Punto a = bb.puntos.get(e.a);
            if (a == null) continue;
            String txt;
            if (e.tipo == Boceto.LINEA) {
                Boceto.Punto q = bb.puntos.get(e.b);
                if (q == null) continue;
                double ang = Math.toDegrees(Math.atan2(q.y - a.y, q.x - a.x));
                txt = nom.get(e.id) + " · Línea · " + Formula.n(Math.round(bb.largo(e) * 10) / 10.0) + " mm · " + Formula.n(Math.round(ang * 10) / 10.0) + "°";
                for (Boceto.Restr r : bb.restr) {
                    if (r.e1 != e.id) continue;
                    if (r.tipo == Boceto.HORIZ) txt += " · ═";
                    if (r.tipo == Boceto.VERT) txt += " · ║";
                }
            } else if (e.tipo == Boceto.CIRCULO) txt = nom.get(e.id) + " · Círculo · Ø " + Formula.n(Math.round(e.r * 20) / 10.0) + " · centro " + Formula.n(Math.round(a.x)) + ", " + Formula.n(Math.round(a.y));
            else if (e.tipo == Boceto.ARCO) txt = nom.get(e.id) + " · Arco · R " + Formula.n(Math.round(e.r * 10) / 10.0) + " · centro " + Formula.n(Math.round(a.x)) + ", " + Formula.n(Math.round(a.y));
            else txt = nom.get(e.id) + " · Texto · «" + e.texto + "»";
            final Boceto.Ent ent = e;
            boolean mala = boceto.sueltas != null && (boceto.sueltas.contains(e.a) || boceto.sueltas.contains(e.b));
            if (mala) txt += " · ⚠ abierta";
            filaOp(txt, mala ? 0xFF8E2424 : 0xFF1E3A34, boceto.sel.contains(e.id), v -> {
                boceto.sel.clear(); boceto.selPts.clear(); boceto.sel.add(ent.id); boceto.invalidate(); pintarOps();
                tablaEnt(ent);
            }, () -> { antes(); bb.borrar(ent); bb.limpiarPuntos(); boceto.limpiarSeleccion(); recalcular(); });
        }
        for (Boceto.Restr r : bb.restr) {
            final Boceto.Restr rr = r;
            String quien = (r.e1 >= 0 ? nombreEnt(nom, r.e1) : "") + (r.e2 >= 0 ? " y " + nombreEnt(nom, r.e2) : "")
                    + (r.p1 >= 0 ? (r.e1 >= 0 ? ", " : "") + "punto" : "");
            Runnable quitar = () -> { antes(); bb.restr.remove(rr); recalcular(); };
            if (r.esCota())
                filaOp("📏 Cota · " + Boceto.NOMBRES[r.tipo] + " = " + boceto.textoCota(r) + " (" + quien + ")", 0xFF1A2F4A, false, v -> editarCota(rr), quitar);
            else
                filaOp("🔗 Amarre · " + Boceto.NOMBRES[r.tipo] + " (" + quien + ")", 0xFF2A2F36, false, v ->
                        new AlertDialog.Builder(this).setTitle("🔗 " + Boceto.NOMBRES[rr.tipo])
                                .setMessage("¿Quitar este amarre?")
                                .setPositiveButton("🗑 Quitar", (d, w) -> quitar.run())
                                .setNegativeButton("Dejarlo", null).show(), quitar);
        }
        for (Pieza p : placasDe(hoja))
            filaOp("⬆ Extrusión · " + p.nombre() + " · " + Pieza.n(p.largo) + " mm" + (p.agujeros.isEmpty() ? "" : " · " + p.agujeros.size() + " huecos"), 0xFF123044, false, v -> editarPlaca(p));
    }

    /** La tabla de propiedades de una línea, círculo, arco o texto del boceto. */
    private void tablaEnt(Boceto.Ent e) {
        Boceto bb = boceto.b;
        Boceto.Punto a = bb.puntos.get(e.a);
        if (a == null) return;
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        String nombre = nombres2D().get(e.id);
        Boceto.Restr cota = null;
        for (Boceto.Restr r : bb.restr)
            if (r.e1 == e.id && (r.tipo == Boceto.C_LARGO || r.tipo == Boceto.C_DIAM || r.tipo == Boceto.C_RADIO)) cota = r;
        final Boceto.Restr cotaF = cota;
        if (e.tipo == Boceto.LINEA) {
            Boceto.Punto q = bb.puntos.get(e.b);
            EditText x1 = celda(l, "Inicio X", Formula.n(r2(a.x))), y1 = celda(l, "Inicio Y", Formula.n(r2(a.y)));
            EditText x2 = celda(l, "Final X", Formula.n(r2(q.x))), y2 = celda(l, "Final Y", Formula.n(r2(q.y)));
            String lg = cota != null ? cota.formula : Formula.n(r2(bb.largo(e)));
            EditText lar = celda(l, cota != null ? "Largo (cota)" : "Largo", lg);
            double ang0 = Math.toDegrees(Math.atan2(q.y - a.y, q.x - a.x));
            EditText ang = celda(l, "Ángulo (grados)", Formula.n(r2(ang0)));
            tablaDialogo("📋 " + nombre + " · Línea", l, e, () -> {
                Double vx1 = valorDe(Teclado.tx(x1)), vy1 = valorDe(Teclado.tx(y1)), vx2 = valorDe(Teclado.tx(x2)), vy2 = valorDe(Teclado.tx(y2));
                Double va = valorDe(Teclado.tx(ang));
                if (vx1 == null || vy1 == null || vx2 == null || vy2 == null || va == null) { aviso("Revise los números"); return false; }
                a.x = vx1; a.y = vy1; q.x = vx2; q.y = vy2;
                String tl = Teclado.tx(lar).trim();
                Double vl = valorDe(tl);
                if (Math.abs(va - ang0) > 0.01 || (vl != null && Math.abs(vl - Math.hypot(q.x - a.x, q.y - a.y)) > 0.01)) {
                    double L = vl != null ? vl : Math.hypot(q.x - a.x, q.y - a.y), an = Math.toRadians(va);
                    q.x = a.x + L * Math.cos(an); q.y = a.y + L * Math.sin(an);
                    if (Math.abs(va - ang0) > 0.01) bb.restr.removeIf(r -> (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == e.id);
                }
                if (!tl.equals(lg) && vl != null) {
                    if (cotaF != null) cotaF.formula = tl;
                    else bb.restriccion(Boceto.C_LARGO, e.id, -1, -1, -1, tl);
                }
                return true;
            });
        } else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) {
            boolean circ = e.tipo == Boceto.CIRCULO;
            EditText cx = celda(l, "Centro X", Formula.n(r2(a.x))), cy = celda(l, "Centro Y", Formula.n(r2(a.y)));
            String md = cota != null ? cota.formula : Formula.n(r2(circ ? e.r * 2 : e.r));
            EditText med = celda(l, circ ? "Diámetro" : "Radio", md);
            tablaDialogo("📋 " + nombre + (circ ? " · Círculo" : " · Arco"), l, e, () -> {
                Double vx = valorDe(Teclado.tx(cx)), vy = valorDe(Teclado.tx(cy));
                String tm = Teclado.tx(med).trim();
                Double vm = valorDe(tm);
                if (vx == null || vy == null || vm == null || vm <= 0) { aviso("Revise los números"); return false; }
                double dx = vx - a.x, dy = vy - a.y;
                a.x = vx; a.y = vy;
                if (!circ) for (int k : new int[]{e.b, e.c}) { Boceto.Punto p = bb.puntos.get(k); if (p != null) { p.x += dx; p.y += dy; } }
                if (!tm.equals(md)) {
                    if (cotaF != null) cotaF.formula = tm;
                    else if (circ) bb.restriccion(Boceto.C_DIAM, e.id, -1, -1, -1, tm);
                    else bb.restriccion(Boceto.C_RADIO, e.id, -1, -1, -1, tm);
                }
                return true;
            });
        } else {
            EditText tx = celda(l, "Texto", e.texto);
            tx.setInputType(InputType.TYPE_CLASS_TEXT);
            EditText alto = celda(l, "Alto de letra (mm)", Formula.n(r2(e.r)));
            EditText px = celda(l, "X", Formula.n(r2(a.x))), py = celda(l, "Y", Formula.n(r2(a.y)));
            tablaDialogo("📋 " + nombre + " · Texto", l, e, () -> {
                Double va = valorDe(Teclado.tx(alto)), vx = valorDe(Teclado.tx(px)), vy = valorDe(Teclado.tx(py));
                if (va == null || vx == null || vy == null) { aviso("Revise los números"); return false; }
                e.texto = Teclado.tx(tx);
                e.r = va; a.x = vx; a.y = vy;
                return true;
            });
        }
    }

    private static double r2(double v) { return Math.round(v * 100) / 100.0; }

    /** Una fila de la tabla: el nombre a la izquierda y la casilla a la derecha (se corrige con el cursor). */
    private EditText celda(LinearLayout l, String etiqueta, String valor) {
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextSize(14);
        t.setTextColor(Color.WHITE);
        f.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        EditText e = campoCasilla();
        e.setText("");   // v6.6: vacía; lo que había queda guardado y sale en el teclado
        e.setTag(valor);
        f.addView(e, new LinearLayout.LayoutParams(0, dp(42), 1.2f));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(4);
        l.addView(f, p);
        return e;
    }

    private interface Guardar { boolean hacer(); }

    private void tablaDialogo(String titulo, LinearLayout l, Boceto.Ent e, Guardar g) {
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle(titulo).setView(sv)
                .setPositiveButton("✓ Guardar", (d, w) -> {
                    antes();
                    if (!g.hacer()) { atras.remove(atras.size() - 1); return; }
                    if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se pudo: choca con otra medida o amarre"); }
                })
                .setNeutralButton("🗑 Borrar", (d, w) -> { antes(); boceto.b.borrar(e); boceto.limpiarSeleccion(); recalcular(); })
                .setNegativeButton("Cancelar", null).show();
    }

    // =====================================================================
    //          VERSIÓN 4: amarrar tocando caras, perforar, cortar, extruir
    // =====================================================================

    private LinearLayout barra3D;
    private TextView panelTitulo;
    private LinearLayout panelCaja;

    private View armarPanel3D() {
        barra3D = new LinearLayout(this);
        barra3D.setOrientation(LinearLayout.VERTICAL);
        barra3D.setPadding(dp(6), dp(4), dp(6), dp(4));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        barra3D.setBackground(g);
        panelTitulo = new TextView(this);
        panelTitulo.setTextColor(Color.WHITE);
        panelTitulo.setTextSize(14);
        panelTitulo.setTypeface(Typeface.DEFAULT_BOLD);
        barra3D.addView(panelTitulo);
        panelCaja = new LinearLayout(this);
        panelCaja.setOrientation(LinearLayout.VERTICAL);
        barra3D.addView(panelCaja);
        barra3D.setVisibility(View.GONE);
        return barra3D;
    }

    private void panel(String titulo) {
        panelTitulo.setText(titulo);
        panelCaja.removeAllViews();
        barra3D.setVisibility(View.VISIBLE);
        if (cajaAcciones != null) cajaAcciones.setVisibility(View.GONE);   // v6.2: no tantos botones prendidos
    }

    private void cerrarPanel() {
        barra3D.setVisibility(View.GONE);
        if (cajaAcciones != null) cajaAcciones.setVisibility(View.VISIBLE);
        vista.pideCara = null;
        vista.aceptaPlanos = false;
        vista.marcas = null;
        vista.lineasEje = null;
        vista.ejeResaltado = -1;
        if (toquePanel) { vista.pideToque = null; vista.bordesNaranja = null; }
        toquePanel = false;
        vista.resA = vista.resB = -1;
        vista.resPtoA = vista.resPtoB = null;
        vista.invalidate();
    }

    private LinearLayout filaPanel() {
        LinearLayout f = new LinearLayout(this);
        f.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(42));
        p.topMargin = dp(4);
        panelCaja.addView(f, p);
        return f;
    }

    private EditText campoPanel(LinearLayout fila, String etiqueta, String valor) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setPadding(dp(4), 0, dp(4), 0);
        fila.addView(t, new LinearLayout.LayoutParams(-2, -1));
        t.setGravity(Gravity.CENTER_VERTICAL);
        EditText e = campoCasilla();
        e.setText("");   // v6.6: vacía
        e.setTag(valor);
        fila.addView(e, new LinearLayout.LayoutParams(0, -1, 1f));
        return e;
    }

    private static float punto3(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    private static float[] menos(float[] a, float[] b) { return new float[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }

    private static float r5(float v) { return Math.round(v / 5f) * 5f; }

    private static float r1(float v) { return Math.round(v * 10f) / 10f; }

    private Map<Integer, Pieza> mapaPiezas() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    /** La dirección (0..5) que más se parece al vector. */
    private static int dirMasCercana(float[] v) {
        float[][] base = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {-1, 0, 0}, {0, -1, 0}, {0, 0, -1}};
        int m = 0;
        float mejor = -9;
        for (int i = 0; i < 6; i++) { float k = punto3(base[i], v); if (k > mejor) { mejor = k; m = i; } }
        return m;
    }

    /** ¿b está pegada (directa o indirectamente) a a? */
    private boolean dependeDe(Pieza b, Pieza a) {
        Pieza x = b;
        for (int i = 0; i < 80 && x != null; i++) {
            if (x.id == a.id) return true;
            x = x.padre >= 0 ? porId(x.padre) : null;
        }
        return false;
    }

    // ---------------- 🔗 Amarrar tocando caras ----------------

    private int amA = -1, amTipoA, amClase, amPaso;
    private float[] amNrmA, amPuntoA, amN1, amQ1;
    private float[][] amPtsA;

    /** Versión 4.5: primero se escoge qué amarre (como en Inventor). */
    /** Versión 5: los 10 amarres del montaje (distintos a los del boceto). */
    private void amarrar3D() {
        mostrar(1);
        panel("🔗 Amarrar piezas · ¿qué amarre?");
        LinearLayout f1 = filaPanel();
        f1.addView(boton("🟰 Cara con cara", 0xFF00897B, () -> empezarAmarre(0)), peso());
        f1.addView(boton("▭ Al nivel", 0xFF1565C0, () -> empezarAmarre(1)), peso());
        f1.addView(boton("⊙ Eje con eje", 0xFF6A1B9A, () -> empezarEjes(5)), peso());
        LinearLayout f2 = filaPanel();
        f2.addView(boton("🔩 Meter en hueco", 0xFF6D4C41, () -> empezarEjes(6)), peso());
        f2.addView(boton("∠ Ángulo", 0xFF00838F, () -> empezarAmarre(7)), peso());
        f2.addView(boton("🚪 Bisagra", 0xFF5D4037, () -> empezarEjes(8)), peso());
        LinearLayout f3 = filaPanel();
        f3.addView(boton("∥ Paralelo", 0xFF283593, () -> empezarAmarre(9)), peso());
        f3.addView(boton("⊥ Perpendicular", 0xFF283593, () -> empezarAmarre(10)), peso());
        f3.addView(boton("⧉ Centrar", 0xFF5E35B1, () -> empezarAmarre(3)), peso());
        LinearLayout f4 = filaPanel();
        f4.addView(boton("• Punto con punto", 0xFFF9A825, () -> empezarAmarre(11)), peso());
        f4.addView(boton("📐 Filo de doblez", 0xFF546E7A, () -> empezarAmarre(4)), peso());
        f4.addView(boton("📌 Fijar", 0xFFAD1457, this::fijar), peso());
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
    }

    /** 📌 Fijar o soltar la pieza escogida. */
    private void fijar() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere fijar"); return; }
        antes();
        p.fija = !p.fija;
        cerrarPanel();
        recalcular();
        aviso(p.fija ? "📌 " + p.nombre() + " quedó fija: no se mueve al amarrar ni al arrastrar" : "🔓 " + p.nombre() + " ya se puede mover");
    }

    private static String paso1(int clase) {
        switch (clase) {
            case 0: return "🟰 Cara con cara · paso 1 de 2: toque la cara de la pieza que va a mover";
            case 1: return "▭ Al nivel · paso 1 de 2: toque la cara de la pieza que va a mover";
            case 3: return "⧉ Centrar · paso 1 de 3: toque la pieza que va a quedar en la mitad";
            case 4: return "📐 Filo · paso 1 de 2: toque el filo (el canto) de la lámina o la cara que va a mover";
            case 7: return "∠ Ángulo · paso 1 de 2: toque la cara de la pieza que va a girar";
            case 9: return "∥ Paralelo · paso 1 de 2: toque la cara de la pieza que va a girar";
            case 10: return "⊥ Perpendicular · paso 1 de 2: toque la cara de la pieza que va a girar";
            case 11: return "• Punto con punto · paso 1 de 2: toque cerca de la esquina (o mitad de arista) de la pieza que va a mover";
            default: return "Toque la cara de la pieza que va a mover";
        }
    }

    private static String paso2(int clase) {
        switch (clase) {
            case 0: return "paso 2 de 2: toque la cara (o un plano ▱) donde se pega ";
            case 1: return "paso 2 de 2: toque la cara (o un plano ▱) con la que queda al nivel ";
            case 3: return "paso 2 de 3: toque la primera cara de los lados de ";
            case 4: return "paso 2 de 2: toque la cara o filo donde se pega ";
            case 7: case 9: case 10: return "paso 2 de 2: toque la cara de la otra pieza (o un plano ▱) para ";
            case 11: return "paso 2 de 2: toque cerca de la esquina donde llega ";
            default: return "paso 2 de 2: toque la otra cara · ";
        }
    }

    private Ref refPorId(int id) {
        for (Ref r : refs) if (r.id == id) return r;
        return null;
    }

    private void moverA(Pieza a, float[] t, String que) {
        if (a.fija) { aviso("📌 " + a.nombre() + " está fija y no se mueve. Suéltela en 📌 Fijar"); return; }
        if (Math.abs(t[0]) + Math.abs(t[1]) + Math.abs(t[2]) < 0.01f) { aviso("✔ " + a.nombre() + " ya estaba " + que); return; }
        antes();
        a.cx += t[0]; a.cy += t[1]; a.cz += t[2];
        a.f.remove("cx"); a.f.remove("cy"); a.f.remove("cz");
        escogida = a.id;
        anotarAmarre(a, "quedó " + que);
        recalcular();
        aviso("✔ " + a.nombre() + " quedó " + que);
    }

    /** Versión 6: cada amarre queda escrito en la pieza (se ve en el árbol con 🗑 para quitarlo). */
    private void anotarAmarre(Pieza a, String t) {
        if (a == null) return;
        a.amarres.remove(t);
        a.amarres.add(t);
        while (a.amarres.size() > 12) a.amarres.remove(0);
    }

    /** Quitar un amarre: la pieza queda suelta en su sitio para poderla cambiar de lugar. */
    private void quitarAmarre(Pieza p, String t) {
        antes();
        p.amarres.remove(t);
        if (t.startsWith("🔗 pegada a") && p.padre >= 0) soltarEnSuPuesto(p);
        recalcular();
        aviso("🔓 Amarre quitado: " + p.nombre() + " queda suelta en su sitio (✥ Mover pieza para correrla)");
    }

    /** El centro de una pieza (mitad del largo y de la sección). */
    private float[] centroDe(Pieza p) {
        float[] ini = p.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(p);
        float cs = 0, cu = 0;
        if (p.tipo == Pieza.PLACA && p.contorno != null && p.contorno.length > 0) {
            for (float[] q : p.contorno) { cs += q[0]; cu += q[1]; }
            cs /= p.contorno.length; cu /= p.contorno.length;
        }
        float L = p.largo / 2;
        return new float[]{ini[0] + e[0][0] * L + e[1][0] * cs + e[2][0] * cu, ini[1] + e[0][1] * L + e[1][1] * cs + e[2][1] * cu, ini[2] + e[0][2] * L + e[1][2] * cs + e[2][2] * cu};
    }

    private static float[] escalar(float[] a, float k) { return new float[]{a[0] * k, a[1] * k, a[2] * k}; }

    private void empezarAmarre(int clase) {
        mostrar(1);
        amA = -1;
        amClase = clase;
        amPaso = 0;
        panel("🔗 " + paso1(clase));
        LinearLayout f = filaPanel();
        Pieza esc = porId(escogida);
        if (esc != null && esc.padre >= 0)
            f.addView(boton("🔓 Soltar " + esc.nombre(), 0xFF6D4C41, () -> { antes(); soltarEnSuPuesto(esc); cerrarPanel(); recalcular(); aviso("✔ " + esc.nombre() + " quedó suelta en su sitio"); }), peso());
        f.addView(boton("✋ Mover la vista", 0xFF37474F, () -> aviso("Con dos dedos puede correr y acercar la vista mientras amarra")), peso());
        f.addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        vista.resA = vista.resB = -1;
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (amA < 0) {
                if (tipo == 9) return;
                if (pieza <= -1000) { aviso("Primero toque la pieza que va a mover (no el plano)"); return; }
                Pieza pa = porId(pieza);
                if (pa == null) return;
                if (pa.fija) { aviso("📌 " + pa.nombre() + " está fija. Toque primero la pieza que se mueve"); return; }
                amA = pieza; amTipoA = tipo; amNrmA = nrm; amPuntoA = q;
                amPtsA = vista.caraPts;
                if (amClase == 11) {
                    amPuntoA = Vista3D.imantar(amPtsA, q, true);
                    List<float[]> mk = new ArrayList<>();
                    mk.add(amPuntoA);
                    vista.marcas = mk;
                }
                vista.aceptaPlanos = amClase == 0 || amClase == 1 || amClase == 7 || amClase == 9 || amClase == 10;
                vista.resA = pieza; vista.resNrmA = nrm; vista.resPtoA = vista.caraP0;
                vista.invalidate();
                String para = amClase == 7 ? "medir el ángulo" : amClase == 9 ? "quedar paralela" : amClase == 10 ? "quedar en escuadra" : pa.nombre();
                panelTitulo.setText("🔗 " + paso2(amClase) + para);
                return;
            }
            // versión 5: la segunda vez se puede tocar un plano de referencia
            if (pieza <= -1000) {
                Ref r = refPorId(-1000 - pieza);
                Pieza a = porId(amA);
                if (r == null || a == null) return;
                if (amClase == 0 || amClase == 1) {
                    vista.pideCara = null;
                    float k = punto3(menos(q, amPuntoA), nrm);
                    cerrarPanel();
                    moverA(a, escalar(nrm, k), "sobre " + r.nombre);
                    return;
                }
                if (amClase == 7 || amClase == 9 || amClase == 10) { girarHacia(a, nrm, r.nombre); return; }
                aviso("Aquí toque una pieza, no un plano");
                return;
            }
            if (pieza == amA && amClase != 3) { aviso("Toque una cara de OTRA pieza"); return; }
            Pieza a = porId(amA), b = porId(pieza);
            if (a == null || b == null) return;
            if (amClase == 7 || amClase == 9 || amClase == 10 || amClase == 11) {
                if (dependeDe(b, a)) { aviso("No se puede: " + b.nombre() + " está pegada a " + a.nombre() + ". Amarre al revés."); return; }
                if (amClase == 11) {
                    vista.pideCara = null;
                    float[] pb = Vista3D.imantar(vista.caraPts, q, true);
                    cerrarPanel();
                    moverA(a, menos(pb, amPuntoA), "con su punto en el de " + b.nombre());
                    return;
                }
                girarHacia(a, nrm, b.nombre());
                return;
            }
            if (amClase == 1) {   // al ras: mismo lado, mismo plano
                if (punto3(amNrmA, nrm) < 0.7f) { aviso("Esas caras no miran para el mismo lado. Para que se toquen use 🟰 Cara con cara"); return; }
                vista.pideCara = null;
                float k = punto3(menos(q, amPuntoA), nrm);
                cerrarPanel();
                moverA(a, escalar(nrm, k), "al ras con " + b.nombre());
                return;
            }
            if (amClase == 2) {   // eje con eje
                float[] dA = a.direccion(), dB = b.direccion();
                if (Math.abs(punto3(dA, dB)) < 0.98f) { aviso("Esas piezas no van paralelas; primero gírela (⟳ Rotar)"); return; }
                vista.pideCara = null;
                float[] cA = centroDe(a), cB = centroDe(b);
                float[] t = menos(cB, cA);
                float k = punto3(t, dA);
                t = menos(t, escalar(dA, k));
                cerrarPanel();
                moverA(a, t, "en el mismo eje de " + b.nombre());
                return;
            }
            if (amClase == 3) {   // centrar entre dos caras
                if (amPaso == 0) {
                    amN1 = nrm; amQ1 = q; amPaso = 1;
                    vista.resB = pieza; vista.resNrmB = nrm; vista.resPtoB = vista.caraP0;
                    vista.invalidate();
                    panelTitulo.setText("🔗 ⧉ Centrar · paso 3 de 3: toque la cara del otro lado");
                    return;
                }
                if (punto3(amN1, nrm) > -0.7f) { aviso("La segunda cara debe quedar enfrente de la primera"); return; }
                vista.pideCara = null;
                float mid = (punto3(amQ1, amN1) + punto3(q, amN1)) / 2;
                float k = mid - punto3(centroDe(a), amN1);
                cerrarPanel();
                moverA(a, escalar(amN1, k), "centrada entre las dos caras");
                return;
            }
            if (dependeDe(b, a)) { aviso("No se puede: " + b.nombre() + " está pegada a " + a.nombre() + ". Amarre al revés."); return; }
            antes();
            aplicarAmarre(a, amTipoA, b, tipo, nrm, q);
            vista.pideCara = null;
            vista.resB = pieza; vista.resNrmB = nrm; vista.resPtoB = vista.caraP0;
            escogida = a.id;
            recalcular();
            panelAmarre(a, b);
        };
        vista.invalidate();
    }

    private void aplicarAmarre(Pieza a, int tipoA, Pieza b, int tipoB, float[] nB, float[] pB) {
        Map<Integer, Pieza> m = mapaPiezas();
        float[] dA = a.direccion();
        boolean punta = tipoA == 5 || tipoA == 6 || Math.abs(punto3(dA, nB)) > 0.7f;
        if (punta && a.tipo != Pieza.PLACA) {
            boolean recto = Math.max(Math.abs(nB[0]), Math.max(Math.abs(nB[1]), Math.abs(nB[2]))) > 0.999f;
            if (a.marco == null && recto) { a.dir = dirMasCercana(nB); a.incl = 0; }
            else girarEjes(a, Geo.rotEntre(a.direccion(), nB));   // versión 5: la punta queda exacta contra la cara
        }
        a.padre = b.id;
        a.sep = 0; a.luz = 0; a.en1 = 0; a.en2 = 0;
        a.cx = a.cy = a.cz = 0;
        for (String k : new String[]{"cx", "cy", "cz", "sep", "aMm"}) a.f.remove(k);
        float[] sB = b.inicio(m, 0), dB = b.direccion();
        float[][] eB = Vista3D.ejes(b);
        if (tipoB == 5 || tipoB == 6) {
            a.cara = 5;
            a.punto = tipoB == 5 ? 1 : 0;
            float[] org = a.punto == 1 ? new float[]{sB[0] + dB[0] * b.largo, sB[1] + dB[1] * b.largo, sB[2] + dB[2] * b.largo} : sB;
            float e1 = punto3(menos(pB, org), eB[1]), e2 = punto3(menos(pB, org), eB[2]);
            if (b.tipo == Pieza.PLACA) { a.en1 = r5(e1); a.en2 = r5(e2); }
        } else {
            float ks = punto3(nB, eB[1]), ku = punto3(nB, eB[2]);
            a.cara = Math.abs(ku) >= Math.abs(ks) ? (ku > 0 ? 1 : 2) : (ks > 0 ? 4 : 3);
            float t = punto3(menos(pB, sB), dB);
            float borde = Math.max(30, b.largo * 0.05f);
            if (t < borde) a.punto = 0;
            else if (t > b.largo - borde) a.punto = 1;
            else { a.punto = 2; a.aMm = r5(t); }
            if (b.tipo == Pieza.PLACA) {
                float[] t1 = Pieza.ejeT1(b, a.cara);
                float[] eje = {sB[0] + dB[0] * t, sB[1] + dB[1] * t, sB[2] + dB[2] * t};
                a.en1 = r5(punto3(menos(pB, eje), t1));
            }
        }
    }

    /** La barrita después de amarrar: separación, a lo largo, al ras, alineación, voltear. Los números se aplican al escribirlos. */
    private void panelAmarre(Pieza a, Pieza b) {
        panel("🔗 " + a.nombre() + " pegada a " + b.nombre() + " (" + Pieza.CARAS_UNION[a.cara].toLowerCase() + ")");
        LinearLayout f1 = filaPanel();
        EditText luz = campoPanel(f1, "Separación", Pieza.n(a.luz));
        EditText largo = campoPanel(f1, "A lo largo", Pieza.n(a.punto == 0 ? 0 : a.punto == 1 ? b.largo : a.aMm));
        final boolean[] quieto = {false};
        Runnable leer = () -> {
            if (quieto[0]) return;
            Double v = valorDe(Teclado.tx(luz));
            if (v != null) a.luz = v.floatValue();
            if (a.cara != 5) {
                Double w = valorDe(Teclado.tx(largo));
                if (w != null) { a.punto = 2; a.aMm = w.floatValue(); a.f.remove("aMm"); }
            }
            recalcular();
        };
        android.text.TextWatcher tw = new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence c, int x, int y, int z) { }
            @Override public void afterTextChanged(android.text.Editable e) { leer.run(); }
        };
        luz.addTextChangedListener(tw);
        largo.addTextChangedListener(tw);
        // poner un número sin disparar el aplicar dos veces
        java.util.function.Consumer<Float> ponerLargo = v -> { quieto[0] = true; largo.setText(Pieza.n(v)); quieto[0] = false; };
        LinearLayout f2 = filaPanel();
        f2.addView(boton("⟵ Al inicio", 0xFF455A64, () -> { a.punto = 2; a.aMm = 0; ponerLargo.accept(0f); leer.run(); }), peso());
        f2.addView(boton("Al final ⟶", 0xFF455A64, () -> {
            // que las dos puntas queden parejas al final
            float k = punto3(a.direccion(), b.direccion());
            float v = k > 0.9f ? b.largo - a.largo : k < -0.9f ? b.largo : b.largo;
            a.punto = 2; a.aMm = Math.max(0, v);
            ponerLargo.accept(a.aMm);
            leer.run();
        }), peso());
        f2.addView(boton("Centrada", 0xFF455A64, () -> { alinear(a, b, 0); leer.run(); }), peso());
        f2.addView(boton("⇄ Voltear", 0xFF5E35B1, () -> {
            if (a.tipo != Pieza.PLACA) {
                if (a.marco != null) { for (int i : new int[]{3, 4, 5, 9, 10, 11}) a.marco[i] = -a.marco[i]; }
                else a.dir = (a.dir + 3) % 6;
            }
            leer.run();
        }), peso());
        LinearLayout f3 = filaPanel();
        f3.addView(boton("Borde 1", 0xFF455A64, () -> { alinear(a, b, 1); leer.run(); }), peso());
        f3.addView(boton("Borde 2", 0xFF455A64, () -> { alinear(a, b, 2); leer.run(); }), peso());
        f3.addView(boton("Cancelar", 0xFF455A64, () -> { revertir(); cerrarPanel(); recalcular(); }), peso());
        f3.addView(boton("✓ Listo", 0xFF2E7D32, () -> {
            leer.run();
            for (String x : new ArrayList<>(a.amarres)) if (x.startsWith("🔗 pegada a")) a.amarres.remove(x);
            anotarAmarre(a, "🔗 pegada a " + b.nombre() + " (" + Pieza.CARAS_UNION[a.cara].toLowerCase() + (Math.abs(a.luz) > 0.01f ? ", separada " + Pieza.n(a.luz) + " mm" : "") + ")");
            cerrarPanel(); recalcular(); aviso("✔ " + a.nombre() + " amarrada a " + b.nombre());
        }), peso());
    }

    private void alinear(Pieza a, Pieza b, int k) {
        float[] t1 = Pieza.ejeT1(b, a.cara);
        if (k == 0) { a.en1 = 0; if (a.cara == 5 && b.tipo != Pieza.PLACA) a.en2 = 0; return; }
        float[] nt = {-t1[0], -t1[1], -t1[2]};
        if (k == 1) a.en1 = -(b.alcance(nt) - a.alcance(nt));
        else a.en1 = b.alcance(t1) - a.alcance(t1);
    }

    // =====================================================================
    //          VERSIÓN 5: GIRAR LIBRE, AMARRES CON ÁNGULO Y POR EJES
    // =====================================================================

    private android.text.TextWatcher alEscribir(Runnable r) {
        return new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence c, int x, int y, int z) { }
            @Override public void afterTextChanged(android.text.Editable e) { r.run(); }
        };
    }

    /** Un punto o una dirección del mundo, medido en los ejes de la pieza. */
    private float[] aLocal(Pieza p, float[] w, boolean punto) {
        float[] ini = p.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(p);
        float[] v = punto ? Geo.sub(w, ini) : w;
        return new float[]{Geo.dot(v, e[0]), Geo.dot(v, e[1]), Geo.dot(v, e[2])};
    }

    /** Lo contrario: de los ejes de la pieza al mundo. */
    private float[] aMundo(Pieza p, float[] l, boolean punto) {
        float[] ini = p.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(p);
        float[] r = Geo.add(Geo.add(Geo.mul(e[0], l[0]), Geo.mul(e[1], l[1])), Geo.mul(e[2], l[2]));
        return punto ? Geo.add(ini, r) : r;
    }

    /** Correr la pieza (mm del mundo). */
    private void trasladar(Pieza a, float[] t) {
        a.cx += t[0]; a.cy += t[1]; a.cz += t[2];
        a.f.remove("cx"); a.f.remove("cy"); a.f.remove("cz");
    }

    /** Solo gira los ejes de la pieza (la cadena la pone en su sitio). */
    private void girarEjes(Pieza x, float[][] R) {
        float[] ini = x.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(x);
        float[] d = Geo.limpio(Geo.apl(R, e[0])), s = Geo.limpio(Geo.apl(R, e[1])), u = Geo.limpio(Geo.apl(R, e[2]));
        float[] o = x.alReves ? Geo.addk(ini, d, x.largo) : ini;
        x.marco = new float[]{o[0], o[1], o[2], s[0], s[1], s[2], u[0], u[1], u[2], d[0], d[1], d[2]};
    }

    private void girarPieza(Pieza p, float[] c, float[] k, float grados, boolean soltar) {
        girarPiezaR(p, c, Geo.rot(k, grados), soltar);
    }

    /**
     * Gira la pieza p (y todo lo que tiene pegado) con R alrededor del punto c.
     * soltar = true: la pieza queda suelta en su nuevo sitio (para bisagras y ángulos).
     */
    private void girarPiezaR(Pieza p, float[] c, float[][] R, boolean soltar) {
        Map<Integer, Pieza> m = mapaPiezas();
        Set<Integer> desc = descendientes(p.id);
        Map<Integer, float[]> inis = new HashMap<>();
        Map<Integer, float[][]> ejs = new HashMap<>();
        for (Integer id : desc) {
            Pieza x = porId(id);
            if (x == null) continue;
            inis.put(id, x.inicio(m, 0));
            ejs.put(id, Vista3D.ejes(x));
        }
        for (Integer id : desc) {
            Pieza x = porId(id);
            if (x == null || !inis.containsKey(id)) continue;
            float[] ini = inis.get(id);
            float[][] e = ejs.get(id);
            float[] d = Geo.limpio(Geo.apl(R, e[0])), s = Geo.limpio(Geo.apl(R, e[1])), u = Geo.limpio(Geo.apl(R, e[2]));
            float[] o;
            if (x == p) {
                float[] st = Geo.girarPunto(R, ini, c);
                if (soltar || x.padre < 0) {
                    if (soltar) {
                        x.padre = -1; x.cara = 0; x.punto = 1; x.sep = 0; x.luz = 0; x.en1 = 0; x.en2 = 0;
                        x.cx = 0; x.cy = 0; x.cz = 0;
                        for (String k : new String[]{"cx", "cy", "cz", "sep", "aMm"}) x.f.remove(k);
                    }
                    o = Geo.sub(Geo.sub(st, Geo.mul(d, x.sep)), new float[]{x.cx, x.cy, x.cz});
                } else o = st;
            } else {
                float[] cv = Geo.apl(R, new float[]{x.cx, x.cy, x.cz});
                x.cx = cv[0]; x.cy = cv[1]; x.cz = cv[2];
                x.f.remove("cx"); x.f.remove("cy"); x.f.remove("cz");
                o = Geo.girarPunto(R, ini, c);
            }
            if (x.alReves) o = Geo.addk(o, d, x.largo);
            x.marco = new float[]{o[0], o[1], o[2], s[0], s[1], s[2], u[0], u[1], u[2], d[0], d[1], d[2]};
        }
    }

    // ---------------- ∠ Ángulo, ∥ Paralelo, ⊥ Perpendicular ----------------

    private Pieza angA;
    private float[] angLocN, angLocP, angNB;

    private void girarHacia(Pieza a, float[] nB, String nomB) {
        vista.pideCara = null;
        vista.aceptaPlanos = false;
        angA = a;
        angNB = nB.clone();
        angLocN = aLocal(a, amNrmA, false);
        angLocP = aLocal(a, amPuntoA, true);
        float phi = Geo.angulo(amNrmA, nB);
        antes();
        if (amClase == 9) {
            aplicarAngulo(phi < 90 ? 0 : 180);
            anotarAmarre(a, "∥ paralela a " + nomB);
            cerrarPanel();
            recalcular();
            aviso("✔ " + a.nombre() + " quedó paralela a " + nomB);
            return;
        }
        if (amClase == 10) {
            aplicarAngulo(90);
            anotarAmarre(a, "⊥ en escuadra con " + nomB);
            cerrarPanel();
            recalcular();
            aviso("✔ " + a.nombre() + " quedó en escuadra con " + nomB);
            return;
        }
        panelAngulo(a, nomB, Math.round(phi));
    }

    /** Gira la pieza para que su cara quede a «theta» grados de la otra (0 = paralelas mirando igual, 90 = escuadra, 180 = enfrentadas). */
    private void aplicarAngulo(float theta) {
        Pieza a = angA;
        if (a == null) return;
        float[] nA = Geo.unit(aMundo(a, angLocN, false)), pv = aMundo(a, angLocP, true);
        float phi = Geo.angulo(nA, angNB);
        float[] k = Geo.cross(nA, angNB);
        if (Geo.len(k) < 1e-4f) {
            float[][] e = Vista3D.ejes(a);
            float[] w = Math.abs(Geo.dot(e[0], nA)) < 0.9f ? e[0] : e[1];
            k = Geo.sub(w, Geo.mul(nA, Geo.dot(w, nA)));
        }
        float alfa = phi - theta;
        if (Math.abs(alfa) < 0.01f) return;
        girarPieza(a, pv, Geo.unit(k), alfa, true);
    }

    private void panelAngulo(Pieza a, String nomB, float inicial) {
        panel("∠ " + a.nombre() + " a un ángulo de " + nomB);
        LinearLayout f1 = filaPanel();
        EditText ang = campoPanel(f1, "Ángulo °", Pieza.n(inicial));
        final boolean[] quieto = {false};
        Runnable leer = () -> {
            if (quieto[0]) return;
            Double v = valorDe(Teclado.tx(ang));
            if (v == null) return;
            aplicarAngulo(v.floatValue());
            recalcular();
        };
        ang.addTextChangedListener(alEscribir(leer));
        LinearLayout f2 = filaPanel();
        for (int g : new int[]{0, 45, 90, 135, 180}) {
            f2.addView(boton(g + "°", 0xFF455A64, () -> { quieto[0] = true; ang.setText(String.valueOf(g)); quieto[0] = false; leer.run(); }), peso());
        }
        LinearLayout f3 = filaPanel();
        f3.addView(boton("Cancelar", 0xFF455A64, () -> { revertir(); cerrarPanel(); recalcular(); }), peso());
        f3.addView(boton("✓ Listo", 0xFF2E7D32, () -> { anotarAmarre(a, "∠ a " + ang.getText() + "° de " + nomB); cerrarPanel(); recalcular(); aviso("✔ " + a.nombre() + " quedó a " + ang.getText() + "° de " + nomB); }), peso());
        aviso("0° = paralelas mirando igual · 90° = en escuadra · 180° = enfrentadas");
    }

    // ---------------- ⊙ Eje con eje, 🔩 Meter en hueco, 🚪 Bisagra (por ejes) ----------------

    /** Un eje que se puede escoger: el de un tubo, el de un hueco, una arista o un eje de referencia. */
    private static class EjeC {
        int pieza = -1;
        String nombre = "";
        float[] a, b;
        boolean filo;
    }

    private EjeC ejeC(int pieza, String nombre, float[] a, float[] b) {
        EjeC e = new EjeC();
        e.pieza = pieza; e.nombre = nombre; e.a = a; e.b = b;
        return e;
    }

    /** Todos los ejes: de cada tubo, de cada hueco (en tubos y en placas) y los ejes de referencia. */
    private List<EjeC> ejesCandidatos() {
        List<EjeC> r = new ArrayList<>();
        Map<Integer, Pieza> m = mapaPiezas();
        for (Pieza p : piezas) {
            if (p.oculta) continue;
            float[] ini = p.inicio(m, 0);
            float[][] e = Vista3D.ejes(p);
            float[] d = e[0];
            if (p.tipo != Pieza.PLACA) {
                r.add(ejeC(p.id, p.nombre() + " · eje del " + (p.tipo == 2 ? "tubo redondo" : "perfil"), ini, Geo.addk(ini, d, p.largo)));
                for (int i = 0; i < p.huecos.size(); i++) {
                    Pieza.Hueco h = p.huecos.get(i);
                    if (h.tipo == 4) continue;
                    float[] nrm = h.cara == 1 ? Geo.neg(e[2]) : h.cara == 2 ? e[1] : h.cara == 3 ? Geo.neg(e[1]) : e[2];
                    float[] c0 = Geo.addk(ini, d, h.pos);
                    r.add(ejeC(p.id, "hueco " + (i + 1) + " de " + p.nombre(), Geo.addk(c0, nrm, p.alcance(nrm)), Geo.addk(c0, nrm, -p.alcance(Geo.neg(nrm)))));
                }
            } else {
                List<float[]> cs = new ArrayList<>();
                // v6.2: una pieza redonda (barra o tubo dibujado con círculo) trae su eje
                if (p.contorno != null && p.contorno.length >= 12) {
                    float ss = 0, uu = 0;
                    for (float[] q : p.contorno) { ss += q[0]; uu += q[1]; }
                    ss /= p.contorno.length; uu /= p.contorno.length;
                    double rmin = 1e18, rmax = 0;
                    for (float[] q : p.contorno) { double rr = Math.hypot(q[0] - ss, q[1] - uu); rmin = Math.min(rmin, rr); rmax = Math.max(rmax, rr); }
                    if (rmax > 0 && (rmax - rmin) / rmax < 0.03) {
                        float[] c0 = Geo.add(Geo.addk(ini, e[1], ss), Geo.mul(e[2], uu));
                        r.add(ejeC(p.id, p.nombre() + " · eje de lo redondo", c0, Geo.addk(c0, d, p.largo)));
                    }
                }
                for (Pieza.Hueco h : p.huecos) if (h.tipo != 4) cs.add(new float[]{h.s, h.u});
                for (float[][] ag : p.agujeros) {
                    if (ag.length == 0) continue;
                    float ss = 0, uu = 0;
                    for (float[] q : ag) { ss += q[0]; uu += q[1]; }
                    cs.add(new float[]{ss / ag.length, uu / ag.length});
                }
                int i = 1;
                for (float[] su : cs) {
                    float[] c0 = Geo.add(Geo.addk(ini, e[1], su[0]), Geo.mul(e[2], su[1]));
                    r.add(ejeC(p.id, "hueco " + (i++) + " de " + p.nombre(), c0, Geo.addk(c0, d, p.largo)));
                }
            }
        }
        for (Ref f : refs) if (f.tipo == Ref.EJE && f.visible) r.add(ejeC(-1, f.nombre, Geo.addk(f.o, f.v, -f.tam / 2), Geo.addk(f.o, f.v, f.tam / 2)));
        return r;
    }

    private List<EjeC> ejesC = new ArrayList<>();
    private int ejA = -1;
    private boolean ejFinA, toquePanel;
    private Pieza ejPieza;
    private float[] ejC, ejT;
    private float ejGiro, ejSep;

    /** Las líneas moradas que se ven para escoger (las muy cortas se alargan para poder tocarlas). */
    private void mostrarEjes() {
        List<float[][]> ls = new ArrayList<>();
        for (EjeC e : ejesC) {
            float L = Geo.dist(e.a, e.b);
            if (L >= 120) ls.add(new float[][]{e.a, e.b});
            else {
                float[] mid = Geo.mul(Geo.add(e.a, e.b), 0.5f), k = Geo.unit(Geo.sub(e.b, e.a));
                ls.add(new float[][]{Geo.addk(mid, k, -60), Geo.addk(mid, k, 60)});
            }
        }
        vista.lineasEje = ls;
        vista.invalidate();
    }

    private void empezarEjes(int clase) {
        mostrar(1);
        if (clase == 13 && porId(escogida) == null) { aviso("Toque primero la pieza que va a girar"); return; }
        vista.pideCara = null;
        vista.aceptaPlanos = false;
        amClase = clase;
        ejA = -1;
        ejesC = ejesCandidatos();
        String t;
        switch (clase) {
            case 5: t = "⊙ Eje con eje · paso 1 de 2: toque el eje (línea morada) de la pieza que va a mover"; break;
            case 6: t = "🔩 Meter en hueco · paso 1 de 2: toque el eje del tornillo o pasador, cerca de la punta que entra"; break;
            case 8: t = "🚪 Bisagra · paso 1 de 2: toque el eje del hueco de la pieza que va a girar, cerca de la cara que se apoya"; break;
            default: t = "🚪 Girar " + porId(escogida).nombre() + ": toque el eje o la arista sobre la que gira";
        }
        panel(t);
        LinearLayout f = filaPanel();
        f.addView(boton("📐 Tomar una arista", 0xFF6D4C41, this::ejeDeArista), peso());
        f.addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        mostrarEjes();
        toquePanel = true;
        vista.pideToque = (x, y) -> {
            int i = vista.ejeCerca(x, y);
            if (i < 0) { aviso("Toque cerca de una línea morada punteada (un eje)"); return; }
            tocarEje(i, x, y);
        };
        if (ejesC.isEmpty()) aviso("No hay ejes: perfore las piezas (🔩 Perforar) o toque 📐 Tomar una arista");
    }

    /** Escoger una arista de una cara para usarla de eje. */
    private void ejeDeArista() {
        toquePanel = true;
        vista.pideToque = null;
        panelTitulo.setText("📐 Toque la cara que tiene la arista");
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            float[][] pts = vista.caraPts;
            if (pieza <= -1000 || pts == null || tipo == 9) return;
            vista.pideCara = null;
            List<float[][]> bs = new ArrayList<>();
            for (int i = 0; i < pts.length; i++) bs.add(new float[][]{pts[i], pts[(i + 1) % pts.length]});
            vista.bordesNaranja = bs;
            vista.invalidate();
            panelTitulo.setText("📐 Toque la arista (naranja) que sirve de eje, cerca de la punta que va a usar");
            vista.pideToque = (x, y) -> {
                int i = vista.bordeCerca(x, y);
                if (i < 0) { aviso("Toque cerca de una arista naranja"); return; }
                float[][] l = bs.get(i);
                vista.bordesNaranja = null;
                Pieza pz = porId(pieza);
                EjeC e = ejeC(pieza, "arista de " + (pz == null ? "pieza" : pz.nombre()), l[0], l[1]);
                e.filo = true;
                ejesC.add(e);
                mostrarEjes();
                vista.pideToque = (x2, y2) -> {
                    int j = vista.ejeCerca(x2, y2);
                    if (j < 0) { aviso("Toque cerca de una línea morada punteada (un eje)"); return; }
                    tocarEje(j, x2, y2);
                };
                tocarEje(ejesC.size() - 1, x, y);
            };
        };
    }

    private void terminarEjes() {
        vista.pideToque = null;
        vista.lineasEje = null;
        vista.ejeResaltado = -1;
        vista.bordesNaranja = null;
        toquePanel = false;
        ejA = -1;
    }

    private void tocarEje(int i, float x, float y) {
        if (i < 0 || i >= ejesC.size()) return;
        EjeC e = ejesC.get(i);
        float[] sa = vista.pantalla(e.a), sb = vista.pantalla(e.b);
        boolean finB = Math.hypot(x - sb[0], y - sb[1]) < Math.hypot(x - sa[0], y - sa[1]);
        if (amClase == 13) {   // ⟳ Rotar → girar sobre un eje
            Pieza a = porId(escogida);
            if (a == null) { cerrarPanel(); return; }
            Pieza b = e.pieza >= 0 ? porId(e.pieza) : null;
            if (b != null && b != a && dependeDe(b, a)) { aviso("Ese eje es de " + b.nombre() + ", que está pegada a " + a.nombre() + ". Escoja otro"); return; }
            if (a.fija) { aviso("📌 " + a.nombre() + " está fija"); return; }
            terminarEjes();
            antes();
            ejPieza = a;
            ejC = finB ? e.b.clone() : e.a.clone();
            ejT = Geo.unit(Geo.sub(e.b, e.a));
            ejGiro = 0; ejSep = 0;
            panelEjes("🚪 Girar " + a.nombre() + " sobre " + e.nombre);
            return;
        }
        if (ejA < 0) {
            if (e.pieza < 0) { aviso("Primero toque un eje de la pieza que va a mover (no una referencia)"); return; }
            Pieza a = porId(e.pieza);
            if (a == null) return;
            if (a.fija) { aviso("📌 " + a.nombre() + " está fija. Toque primero el eje de la pieza que se mueve"); return; }
            ejA = i;
            ejFinA = finB;
            vista.ejeResaltado = i;
            vista.invalidate();
            String t = amClase == 5 ? "⊙ paso 2 de 2: toque el eje donde va a quedar " : amClase == 6 ? "🔩 paso 2 de 2: toque el eje del hueco, cerca de la boca por donde entra "
                    : "🚪 paso 2 de 2: toque el eje del hueco de la otra pieza, cerca de la cara donde se apoya ";
            panelTitulo.setText(t + a.nombre());
            return;
        }
        EjeC ea = ejesC.get(ejA);
        if (e.pieza >= 0 && e.pieza == ea.pieza) { aviso("Toque un eje de OTRA pieza"); return; }
        Pieza a = porId(ea.pieza), b = e.pieza >= 0 ? porId(e.pieza) : null;
        if (a == null) return;
        if (b != null && dependeDe(b, a)) { aviso("No se puede: " + b.nombre() + " está pegada a " + a.nombre() + ". Amarre al revés."); return; }
        terminarEjes();
        float[] a0 = ejFinA ? ea.b : ea.a, a1 = ejFinA ? ea.a : ea.b;
        float[] b0 = finB ? e.b : e.a, b1 = finB ? e.a : e.b;
        float[] kA = Geo.unit(Geo.sub(a1, a0)), kB = Geo.unit(Geo.sub(b1, b0));
        boolean filo = ea.filo || e.filo;
        float[] t;
        if (amClase == 5 || filo) t = Geo.dot(kA, kB) >= 0 ? kB : Geo.neg(kB);   // el giro más corto
        else if (amClase == 6) t = kB;            // el pasador entra por donde entra el hueco
        else t = Geo.neg(kB);                       // bisagra: queda encima, apoyada
        antes();
        float[][] R = Geo.rotEntre(kA, t);
        if (!Geo.esNada(R)) girarPiezaR(a, a0, R, true);
        float[] v = Geo.sub(b0, a0);
        if (amClase == 5) v = Geo.sub(v, Geo.mul(t, Geo.dot(v, t)));
        trasladar(a, v);
        ejPieza = a;
        ejC = Geo.add(a0, v);
        ejT = t;
        ejGiro = 0; ejSep = 0;
        escogida = a.id;
        recalcular();
        String nb = b != null ? b.nombre() : e.nombre;
        panelEjes(amClase == 5 ? "⊙ " + a.nombre() + " en el eje de " + nb : amClase == 6 ? "🔩 " + a.nombre() + " metida en el " + e.nombre
                : "🚪 " + a.nombre() + " con bisagra en " + nb);
    }

    /** La barrita después de amarrar por ejes: girar sobre el eje, correr a lo largo, voltear. */
    private void panelEjes(String titulo) {
        panel(titulo);
        final float sg = amClase == 6 ? -1 : 1;   // en «meter en hueco», separar = sacarlo
        LinearLayout f1 = filaPanel();
        EditText giro = campoPanel(f1, "Giro °", "0");
        EditText corr = campoPanel(f1, amClase == 6 || amClase == 8 ? "Separación" : "Corrido", "0");
        final boolean[] quieto = {false};
        Runnable leer = () -> {
            if (quieto[0] || ejPieza == null) return;
            Double g = valorDe(Teclado.tx(giro)), s = valorDe(Teclado.tx(corr));
            if (g != null && Math.abs(g - ejGiro) > 0.001) { girarPieza(ejPieza, ejC, ejT, (float) (g - ejGiro), true); ejGiro = g.floatValue(); }
            if (s != null && Math.abs(s - ejSep) > 0.001) { trasladar(ejPieza, Geo.mul(ejT, sg * (float) (s - ejSep))); ejSep = s.floatValue(); }
            recalcular();
        };
        giro.addTextChangedListener(alEscribir(leer));
        corr.addTextChangedListener(alEscribir(leer));
        LinearLayout f2 = filaPanel();
        f2.addView(boton("−15°", 0xFF455A64, () -> { quieto[0] = true; giro.setText(Pieza.n(ejGiro - 15)); quieto[0] = false; leer.run(); }), peso());
        f2.addView(boton("+15°", 0xFF455A64, () -> { quieto[0] = true; giro.setText(Pieza.n(ejGiro + 15)); quieto[0] = false; leer.run(); }), peso());
        f2.addView(boton("⇄ Voltear", 0xFF5E35B1, () -> {
            if (ejPieza == null) return;
            float[] pv = Geo.addk(ejC, ejT, sg * ejSep);
            girarPieza(ejPieza, pv, Geo.perp(ejT), 180, true);
            recalcular();
        }), peso());
        LinearLayout f3 = filaPanel();
        f3.addView(boton("Cancelar", 0xFF455A64, () -> { revertir(); cerrarPanel(); recalcular(); }), peso());
        f3.addView(boton("✓ Listo", 0xFF2E7D32, () -> {
            cerrarPanel();
            recalcular();
            if (ejPieza != null) {
                anotarAmarre(ejPieza, Teclado.tx(panelTitulo).replaceFirst("^\\S+ \\S+ ", "") + (Math.abs(ejGiro) > 0.01f ? ", girada " + Pieza.n(ejGiro) + "°" : ""));
                aviso("✔ " + ejPieza.nombre() + " quedó amarrada" + (Math.abs(ejGiro) > 0.01f ? ", girada " + Pieza.n(ejGiro) + "°" : ""));
            }
        }), peso());
    }

    /** ∡ Girar a cualquier ángulo alrededor de X, Y o Z (en su punto de inicio). */
    private void anguloLibre(Pieza p) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] eje = {0};
        l.addView(etiqueta("Alrededor de"));
        grupoBotones(l, new String[]{"Z (en el piso)", "X (parándola)", "Y (de lado)"}, eje, 3, null);
        l.addView(etiqueta("Grados (+ o −)"));
        EditText g = campoTexto("30", "grados");
        g.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        l.addView(g);
        new AlertDialog.Builder(this).setTitle("∡ Girar " + p.nombre()).setView(l)
                .setPositiveButton("Girar", (d, w) -> {
                    Double v = valorDe(Teclado.tx(g));
                    if (v == null) return;
                    float[][] ax = {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}};
                    antes();
                    girarPieza(p, p.inicio(mapaPiezas(), 0), ax[eje[0]], v.floatValue(), false);
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    // =====================================================================
    //                 VERSIÓN 5: 📏 REFERENCIAS (planos, ejes, puntos)
    // =====================================================================

    private int nuevoIdRef() {
        int m = 0;
        for (Ref r : refs) m = Math.max(m, r.id);
        return m + 1;
    }

    private String nombreRef(int tipo) {
        int n = 1;
        for (Ref r : refs) if (r.tipo == tipo && !r.nombre.startsWith("Plano base")) n++;
        return Ref.TIPOS[tipo] + " " + n;
    }

    private void agregarRef(Ref r) {
        antes();
        refs.add(r);
        cerrarPanel();
        recalcular();
        aviso("✔ " + r.nombre + " listo. Se ve en el montaje y en el árbol (👁 para ocultarlo)");
    }

    private interface AlTocar { void tocada(int pieza, float[] q, float[] nrm, float[][] pts); }

    /** Pide tocar una cara (o un plano, si se deja). */
    private void pedirCara(String titulo, boolean planos, AlTocar al) {
        mostrar(1);
        panel(titulo);
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        vista.aceptaPlanos = planos;
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (tipo == 9) return;
            al.tocada(pieza, q, nrm, vista.caraPts);
        };
        vista.invalidate();
    }

    private interface AlArista { void arista(float[] a, float[] b, float[] nrm, int pieza); }

    /** Pide tocar una cara y luego una de sus aristas (naranja). */
    private void pedirArista(String titulo, AlArista al) {
        pedirCara(titulo + " · toque la cara que tiene la arista", false, (pieza, q, nrm, pts) -> {
            if (pts == null) return;
            vista.pideCara = null;
            List<float[][]> bs = new ArrayList<>();
            for (int i = 0; i < pts.length; i++) bs.add(new float[][]{pts[i], pts[(i + 1) % pts.length]});
            vista.bordesNaranja = bs;
            vista.invalidate();
            panelTitulo.setText(titulo + " · toque la arista naranja");
            toquePanel = true;
            vista.pideToque = (x, y) -> {
                int i = vista.bordeCerca(x, y);
                if (i < 0) { aviso("Toque cerca de una arista naranja"); return; }
                vista.bordesNaranja = null;
                vista.pideToque = null;
                al.arista(bs.get(i)[0], bs.get(i)[1], nrm, pieza);
            };
        });
    }

    /** Pide n puntos: cada toque se pega a la esquina, a la mitad de la arista o al centro de la cara más cercano. */
    private void pedirPuntos(String titulo, int n, java.util.function.Consumer<List<float[]>> al) {
        List<float[]> ps = new ArrayList<>();
        pedirCara(titulo + " · punto 1 de " + n, false, (pieza, q, nrm, pts) -> {
            if (pts == null) return;
            ps.add(Vista3D.imantar(pts, q, true));
            vista.marcas = new ArrayList<>(ps);
            vista.invalidate();
            if (ps.size() < n) { panelTitulo.setText(titulo + " · punto " + (ps.size() + 1) + " de " + n); return; }
            vista.pideCara = null;
            al.accept(ps);
        });
    }

    /** Pide un número y luego hace algo con él. */
    private void pedirNumero(String titulo, String valor, java.util.function.Consumer<Float> al) {
        EditText e = campoTexto(valor, "mm o grados");
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        new AlertDialog.Builder(this).setTitle(titulo).setView(e)
                .setPositiveButton("Listo", (d, w) -> { Double v = valorDe(Teclado.tx(e)); if (v != null) al.accept(v.floatValue()); else cerrarPanel(); })
                .setNegativeButton("Cancelar", (d, w) -> cerrarPanel()).show();
    }

    private List<Ref> planosRef() {
        List<Ref> l = new ArrayList<>();
        for (Ref r : refs) if (r.tipo == Ref.PLANO) l.add(r);
        return l;
    }

    /** Escoger un plano de referencia de una lista. */
    private void escogerPlano(String titulo, java.util.function.Consumer<Ref> al) {
        List<Ref> ps = planosRef();
        if (ps.isEmpty()) { aviso("No hay planos todavía: haga uno en 📏 Referencias (o prenda los planos base)"); return; }
        String[] nom = new String[ps.size()];
        for (int i = 0; i < nom.length; i++) nom[i] = "▱ " + ps.get(i).nombre;
        new AlertDialog.Builder(this).setTitle(titulo).setItems(nom, (d, w) -> al.accept(ps.get(w))).setNegativeButton("Cancelar", null).show();
    }

    private void referencias() {
        mostrar(1);
        String[] op = {"▱ Planos base XY · XZ · YZ (ver / ocultar)", "▱ Plano corrido desde una cara", "▱ Plano corrido desde otro plano",
                "▱ Plano girado sobre una arista", "▱ Plano por la mitad entre dos caras", "▱ Plano por tres puntos",
                "╱ Eje por dos puntos", "╱ Eje sobre una arista", "╱ Eje donde se cruzan dos planos",
                "• Punto en una esquina o mitad de arista", "• Punto en el centro de una cara",
                verEjesPiezas ? "👁 Ocultar los ejes de tubos y huecos" : "👁 Ver los ejes de tubos y huecos"};
        new AlertDialog.Builder(this).setTitle("📏 Referencias (no son piezas, son ayudas)").setItems(op, (d, w) -> {
            switch (w) {
                case 0: planosBase(); break;
                case 1:
                    pedirCara("▱ Plano corrido: toque la cara", false, (pieza, q, nrm, pts) -> {
                        vista.pideCara = null;
                        pedirNumero("¿A cuántos mm de la cara? (0 = sobre la cara, − = hacia adentro)", "0",
                                v -> agregarRef(Ref.plano(nuevoIdRef(), nombreRef(Ref.PLANO), Geo.addk(q, nrm, v), nrm)));
                    });
                    break;
                case 2:
                    escogerPlano("▱ ¿Desde qué plano?", r -> pedirNumero("¿A cuántos mm de " + r.nombre + "? (+ o −)", "100", v -> {
                        Ref n = Ref.plano(nuevoIdRef(), nombreRef(Ref.PLANO), Geo.addk(r.o, r.v, v), r.v);
                        n.ex = r.ex.clone();
                        n.tam = r.tam;
                        agregarRef(n);
                    }));
                    break;
                case 3:
                    pedirArista("▱ Plano girado", (a, b, nrm, pieza) -> pedirNumero("¿Cuántos grados se gira sobre la arista? (0 = sobre la cara)", "45", g -> {
                        float[] k = Geo.unit(Geo.sub(b, a));
                        float[] n = Geo.apl(Geo.rot(k, g), nrm);
                        Ref r = Ref.plano(nuevoIdRef(), nombreRef(Ref.PLANO), Geo.mul(Geo.add(a, b), 0.5f), n);
                        r.ex = k;
                        r.tam = Math.max(400, Geo.dist(a, b) + 200);
                        agregarRef(r);
                    }));
                    break;
                case 4: {
                    final float[][] uno = new float[2][];
                    pedirCara("▱ Plano por la mitad: toque la primera cara", false, (pieza, q, nrm, pts) -> {
                        if (uno[0] == null) {
                            uno[0] = q; uno[1] = nrm;
                            List<float[]> mk = new ArrayList<>();
                            mk.add(q);
                            vista.marcas = mk;
                            vista.invalidate();
                            panelTitulo.setText("▱ Plano por la mitad: toque la cara del otro lado");
                            return;
                        }
                        if (Math.abs(Geo.dot(uno[1], nrm)) < 0.95f) { aviso("Las dos caras deben ser paralelas (una frente a la otra)"); return; }
                        vista.pideCara = null;
                        agregarRef(Ref.plano(nuevoIdRef(), nombreRef(Ref.PLANO), Geo.mul(Geo.add(uno[0], q), 0.5f), uno[1]));
                    });
                    break;
                }
                case 5:
                    pedirPuntos("▱ Plano por tres puntos", 3, ps -> {
                        float[] n = Geo.cross(Geo.sub(ps.get(1), ps.get(0)), Geo.sub(ps.get(2), ps.get(0)));
                        if (Geo.len(n) < 1e-3f) { aviso("Esos tres puntos están en línea; escoja otros"); cerrarPanel(); return; }
                        float[] c = Geo.mul(Geo.add(Geo.add(ps.get(0), ps.get(1)), ps.get(2)), 1f / 3);
                        agregarRef(Ref.plano(nuevoIdRef(), nombreRef(Ref.PLANO), c, n));
                    });
                    break;
                case 6:
                    pedirPuntos("╱ Eje por dos puntos", 2, ps -> {
                        if (Geo.dist(ps.get(0), ps.get(1)) < 0.5f) { aviso("Los dos puntos son el mismo"); cerrarPanel(); return; }
                        agregarRef(Ref.eje(nuevoIdRef(), nombreRef(Ref.EJE), Geo.mul(Geo.add(ps.get(0), ps.get(1)), 0.5f), Geo.sub(ps.get(1), ps.get(0)), Geo.dist(ps.get(0), ps.get(1)) + 200));
                    });
                    break;
                case 7:
                    pedirArista("╱ Eje sobre una arista", (a, b, nrm, pieza) ->
                            agregarRef(Ref.eje(nuevoIdRef(), nombreRef(Ref.EJE), Geo.mul(Geo.add(a, b), 0.5f), Geo.sub(b, a), Geo.dist(a, b) + 200)));
                    break;
                case 8:
                    escogerPlano("╱ Primer plano", p1 -> escogerPlano("╱ Segundo plano", p2 -> {
                        float[] v = Geo.cross(p1.v, p2.v);
                        if (Geo.len(v) < 1e-3f) { aviso("Esos planos son paralelos: no se cruzan"); return; }
                        float d1 = Geo.dot(p1.v, p1.o), d2 = Geo.dot(p2.v, p2.o);
                        float[] q = Geo.mul(Geo.cross(Geo.sub(Geo.mul(p2.v, d1), Geo.mul(p1.v, d2)), v), 1f / Geo.dot(v, v));
                        float[] k = Geo.unit(v), mid = Geo.mul(Geo.add(p1.o, p2.o), 0.5f);
                        q = Geo.addk(q, k, Geo.dot(Geo.sub(mid, q), k));
                        agregarRef(Ref.eje(nuevoIdRef(), nombreRef(Ref.EJE), q, k, Math.max(p1.tam, p2.tam)));
                    }));
                    break;
                case 9:
                    pedirCara("• Punto: toque cerca de la esquina o de la mitad de la arista", false, (pieza, q, nrm, pts) -> {
                        if (pts == null) return;
                        vista.pideCara = null;
                        agregarRef(Ref.punto(nuevoIdRef(), nombreRef(Ref.PUNTO), Vista3D.imantar(pts, q, false)));
                    });
                    break;
                case 10:
                    pedirCara("• Punto: toque la cara", false, (pieza, q, nrm, pts) -> {
                        if (pts == null) return;
                        vista.pideCara = null;
                        float[] c = {0, 0, 0};
                        for (float[] x : pts) c = Geo.add(c, x);
                        agregarRef(Ref.punto(nuevoIdRef(), nombreRef(Ref.PUNTO), Geo.mul(c, 1f / pts.length)));
                    });
                    break;
                default:
                    verEjesPiezas = !verEjesPiezas;
                    recalcular();
                    aviso(verEjesPiezas ? "Los ejes de tubos y huecos se ven en morado punteado" : "Ejes ocultos");
            }
        }).setNegativeButton("Cerrar", null).show();
    }

    /** Los tres planos base en el punto 0: se crean la primera vez; después se prenden o se apagan. */
    private void planosBase() {
        List<Ref> base = new ArrayList<>();
        for (Ref r : refs) if (r.tipo == Ref.PLANO && r.nombre.startsWith("Plano base")) base.add(r);
        antes();
        if (base.isEmpty()) {
            refs.add(Ref.plano(nuevoIdRef(), "Plano base XY (piso)", new float[]{0, 0, 0}, new float[]{0, 0, 1}));
            refs.add(Ref.plano(nuevoIdRef(), "Plano base XZ (frente)", new float[]{0, 0, 0}, new float[]{0, -1, 0}));
            refs.add(Ref.plano(nuevoIdRef(), "Plano base YZ (lado)", new float[]{0, 0, 0}, new float[]{1, 0, 0}));
            aviso("▱ Planos base listos (en azul)");
        } else {
            boolean ver = !base.get(0).visible;
            for (Ref r : base) r.visible = ver;
            aviso(ver ? "Planos base a la vista" : "Planos base ocultos");
        }
        recalcular();
    }

    private void editarRef(Ref r) {
        EditText t = campoTexto(r.nombre, "nombre");
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        l.addView(etiqueta("Nombre"));
        l.addView(t);
        EditText tam = null;
        if (r.tipo != Ref.PUNTO) {
            l.addView(etiqueta(r.tipo == Ref.PLANO ? "Tamaño del cuadro (mm, solo para verlo)" : "Largo de la línea (mm, solo para verla)"));
            tam = campoTexto(Pieza.n(r.tam), "mm");
            l.addView(tam);
        }
        final EditText fTam = tam;
        new AlertDialog.Builder(this).setTitle("✏ " + r.nombre).setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    antes();
                    String n = Teclado.tx(t).trim();
                    if (!n.isEmpty()) r.nombre = n;
                    if (fTam != null) { Double v = valorDe(Teclado.tx(fTam)); if (v != null && v > 10) r.tam = v.floatValue(); }
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    // =====================================================================
    //     VERSIÓN 6: COMO INVENTOR — PIEZA, LÁMINA, CASA Y MONTAJE APARTE
    // =====================================================================

    static final String PIEZA = "pieza", LAMINA = "lamina", CASA = "casa", MONTAJE = "montaje", PLANTA = "planta";
    /** Qué documento está abierto: cada uno es un archivo aparte en la librería. */
    private String modo = PIEZA;
    private boolean modoFalta;
    /** Si se abrió una pieza desde un montaje, a qué montaje se vuelve. */
    private String volverA = "";
    private LinearLayout filaModos, cajaAcciones;

    private boolean esMontaje() { return MONTAJE.equals(modo); }

    private String etiquetaModo() {
        switch (modo) {
            case LAMINA: return "📐 Lámina «" + nombreProyecto + "»";
            case CASA: return "🧱 Casa «" + nombreProyecto + "»";
            case MONTAJE: return "🧩 Montaje «" + nombreProyecto + "»";
            default: return "🟩 Pieza «" + nombreProyecto + "»";
        }
    }

    /** La carpeta de la librería: Descargas/MiBarra/MiInventor/Libreria (si no se puede, la de adentro de la app). */
    private File libCache;

    private File carpetaLib() {
        if (libCache != null && libCache.isDirectory()) return libCache;
        try {
            File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MiBarra/MiInventor/Libreria");
            if (!f.exists()) f.mkdirs();
            // se prueba de verdad que se pueda escribir ahí
            File t = new File(f, "_prueba.json");
            try (FileWriter w = new FileWriter(t)) { w.write("{}"); }
            if (t.exists()) { t.delete(); libCache = f; return f; }
        } catch (Exception ignored) { }
        File f = new File(getFilesDir(), "libreria");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private static String limpio(String n) { return n == null ? "" : n.trim().replaceAll("[/\\\\:*?\"<>|]", "-"); }

    /** Guarda el documento abierto en la librería (con su nombre). */
    private void guardarDoc(boolean callado) {
        if (nombreProyecto == null || nombreProyecto.isEmpty() || "Sin nombre".equals(nombreProyecto)) return;
        try {
            try (FileWriter w = new FileWriter(new File(carpetaLib(), limpio(nombreProyecto) + ".json"))) { w.write(proyecto().toString()); }
            getPreferences(MODE_PRIVATE).edit().putString("docAct", limpio(nombreProyecto)).apply();
            if (!callado) aviso("💾 «" + nombreProyecto + "» guardado en Descargas/MiBarra/MiInventor/Libreria");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo guardar «" + nombreProyecto + "»");
        }
    }

    private JSONObject leerDoc(String nombre) {
        try {
            File f = new File(carpetaLib(), nombre + ".json");
            if (!f.exists()) return null;
            return new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
        } catch (Exception e) { return null; }
    }

    /** Abre un documento de la librería (pieza, lámina, casa o montaje). */
    private void abrirDoc(String nombre, boolean callado) {
        JSONObject o = leerDoc(nombre);
        if (o == null) { aviso("No se encontró «" + nombre + "» en la librería"); return; }
        if (PLANTA.equals(o.optString("modo"))) { abrirCasa(nombre, CasaPlano.deJson(o.optJSONObject("plano"))); return; }
        try {
            atras.clear(); adelante.clear();
            cargar(o);
            nombreProyecto = nombre;
            if (modoFalta) modo = MONTAJE;
            escogida = -1;
            if (esMontaje()) refrescarInstancias();
            getPreferences(MODE_PRIVATE).edit().putString("docAct", nombre).apply();
            aplicarModo();
            vista.encuadrar();
            boceto.encuadrar();
            mostrar(esMontaje() ? 1 : (piezas.isEmpty() ? 0 : 1));
            recalcular();
            if (!callado) aviso("✔ Abierto: " + etiquetaModo());
        } catch (Exception e) { aviso("No se pudo abrir «" + nombre + "»"); }
    }

    // ---------------- v6.4: la casa por cuartos ----------------

    private void abrirCasa(String nombre, CasaPlano p) {
        guardarDoc(true);
        casa = new CasaEditor(this, nombre, p, carpetaLib());
        setContentView(casa.vista());
        getPreferences(MODE_PRIVATE).edit().putString("docAct", nombre).apply();
        casa.guardar();
    }

    private void cerrarCasa() {
        if (casa == null) return;
        casa.guardar();
        casa = null;
        setContentView(raizPrincipal);
    }

    private void nuevaCasa() {
        if (casa != null) casa.guardar();
        List<String> ya = nombresLib();
        int n = 1;
        while (ya.contains("Casa " + n)) n++;
        EditText e = campoTexto("Casa " + n, "nombre");
        new AlertDialog.Builder(this).setTitle("🏠 Nombre de la casa").setView(e)
                .setPositiveButton("Crear", (d, w) -> {
                    String nom = limpio(Teclado.tx(e));
                    if (nom.isEmpty() || nom.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    if (nombresLib().contains(nom)) { aviso("Ya hay uno que se llama «" + nom + "»"); return; }
                    CasaPlano p = new CasaPlano();
                    p.ancho = 8000; p.fondo = 6000;
                    casa = null;
                    abrirCasa(nom, p);
                    aviso("🏠 Toque 🏠 Casa para las medidas por fuera; ➕ Cuarto para ir armando");
                }).setNegativeButton("Cancelar", null).show();
    }

    /** La primera vez: la casa 111026 queda lista en la librería para verla y practicar. */
    private void casaDeEjemplo() {
        try {
            File f = new File(carpetaLib(), "Casa 111026.json");
            if (f.exists() || getPreferences(MODE_PRIVATE).getBoolean("ejemplo111026", false)) return;
            JSONObject o = new JSONObject();
            o.put("v", 7); o.put("modo", PLANTA); o.put("nombre", "Casa 111026"); o.put("plano", CasaPlano.casa111026().json());
            try (FileWriter w = new FileWriter(f)) { w.write(o.toString()); }
            getPreferences(MODE_PRIVATE).edit().putBoolean("ejemplo111026", true).apply();
        } catch (Exception ignored) { }
    }

    private List<String> nombresLib() {
        List<String> r = new ArrayList<>();
        File[] fs = carpetaLib().listFiles(x -> x.getName().endsWith(".json") && !x.getName().startsWith("_"));
        if (fs == null) return r;
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        for (File f : fs) r.add(f.getName().substring(0, f.getName().length() - 5));
        return r;
    }

    private String modoDe(String nombre) {
        JSONObject o = leerDoc(nombre);
        return o == null ? "" : o.optString("modo", MONTAJE);
    }

    private static String icono(String m) {
        return LAMINA.equals(m) ? "📐" : CASA.equals(m) ? "🧱" : PLANTA.equals(m) ? "🏠" : MONTAJE.equals(m) ? "🧩" : "🟩";
    }

    /** ☰ El menú de las tres rayitas: aquí se escoge qué hacer (como en Inventor: Archivo → Nuevo). */
    /** v6.5: ☰ (izquierda) = solo para CREAR, como Inventor/SolidWorks. */
    void menuPrincipal() {
        List<String> op = new ArrayList<>();
        List<Runnable> ac = new ArrayList<>();
        Runnable salirCasa = () -> { if (casa != null) cerrarCasa(); };
        if (casa == null && !volverA.isEmpty() && !esMontaje()) { op.add("⬅ Volver al montaje «" + volverA + "»"); ac.add(this::volverAlMontaje); }
        op.add("🟩 Chepe Pieza · pieza nueva (boceto → extrusión)"); ac.add(() -> { salirCasa.run(); nuevoDoc(PIEZA); });
        op.add("📐 Chepe Lámina · lámina nueva (calibre → dobleces)"); ac.add(() -> { salirCasa.run(); nuevoDoc(LAMINA); });
        op.add("🏠 Chepe Casa · casa nueva (planta por cuartos)"); ac.add(this::nuevaCasa);
        op.add("🧩 Montaje nuevo (juntar piezas)"); ac.add(() -> { salirCasa.run(); nuevoDoc(MONTAJE); });
        op.add("📐 Pieza nueva desde un DXF"); ac.add(() -> { salirCasa.run(); dxfNuevo = true; nuevoDoc(PIEZA); });
        op.add("✂ Chepe Corte · barras (P1 a P50)"); ac.add(() -> new Cortes(this, carpetaLib()).pantallaBarras());
        op.add("✂ Chepe Corte · láminas (vidrio, tablero, alucobond)"); ac.add(() -> new Cortes(this, carpetaLib()).pantallaLaminas());
        new AlertDialog.Builder(this).setTitle("☰ Crear · " + VERSION)
                .setItems(op.toArray(new String[0]), (d, w) -> ac.get(w).run()).show();
    }

    /** v6.5: ⋮ (derecha) = todo lo demás: guardar, librería, archivo, enviar, ayuda, cerrar. */
    void menuMas() {
        List<String> op = new ArrayList<>();
        List<Runnable> ac = new ArrayList<>();
        if (casa != null) {
            op.add("💾 Guardar «" + casa.nombre + "»"); ac.add(() -> { casa.guardar(); aviso("✔ Guardada"); });
            op.add("📚 Librería (abrir, copiar, cambiar nombre, borrar)"); ac.add(() -> { cerrarCasa(); libreria(); });
            op.add("📋 Lista de operaciones de la casa"); ac.add(() -> casa.operaciones());
            op.add("🖨 PDF carta de la planta"); ac.add(() -> casa.pdf());
            op.add("📥 Abrir archivo de casa (el que le manda Claude)"); ac.add(this::pedirArchivo);
            op.add("❓ Ayuda"); ac.add(this::ayuda);
            op.add("✕ Cerrar Chepe CAD"); ac.add(() -> { casa.guardar(); cerrarApp(); });
            new AlertDialog.Builder(this).setTitle("⋮ " + VERSION + " · 🏠 «" + casa.nombre + "»")
                    .setItems(op.toArray(new String[0]), (d, w) -> ac.get(w).run()).show();
            return;
        }
        op.add("💾 Guardar «" + nombreProyecto + "»"); ac.add(() -> guardarDoc(false));
        op.add("📚 Librería (abrir, copiar, cambiar nombre, borrar)"); ac.add(this::libreria);
        if (!esMontaje()) { op.add(pestana == 0 ? "🧊 Ver la pieza en 3D" : "✏ Ver el boceto"); ac.add(() -> mostrar(pestana == 0 ? 1 : 0)); }
        op.add("📂 Archivo (PDF, PNG, DXF)"); ac.add(this::menuProyecto);
        op.add("💬 Enviar el plano por WhatsApp"); ac.add(() -> png2D(true));
        op.add("📋 Lista de corte de este trabajo"); ac.add(this::listaCorte);
        op.add("📊 Medidas y fórmulas"); ac.add(() -> mostrar(2));
        op.add("📥 Abrir archivo de casa (el que le manda Claude)"); ac.add(this::pedirArchivo);
        op.add("❓ Ayuda"); ac.add(this::ayuda);
        op.add("✕ Cerrar Chepe CAD"); ac.add(this::cerrarApp);
        new AlertDialog.Builder(this).setTitle("⋮ " + VERSION + " · " + etiquetaModo())
                .setItems(op.toArray(new String[0]), (d, w) -> ac.get(w).run()).show();
    }

    // ---------------- v6.6: grabadora y pantallazo ----------------

    private final List<TextView> botonesRec = new ArrayList<>();
    private final android.os.Handler relojH = new android.os.Handler(android.os.Looper.getMainLooper());

    /** Los dos botones (sirven aquí y en la casa). */
    View[] botonesGrabar() {
        TextView rec = boton("🎥\nREC", 0xFFC62828, this::grabar);
        rec.setTextSize(11);
        botonesRec.add(rec);
        TextView foto = boton("📷\nFOTO", 0xEE37474F, this::foto);
        foto.setTextSize(11);
        return new View[]{rec, foto};
    }

    void grabar() {
        if (Grabadora.grabando) { Grabadora.detener(this); return; }   // ⏹ DETENER: para de una
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);
        try {
            android.media.projection.MediaProjectionManager mpm = (android.media.projection.MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), GRABAR);
            aviso("Toque «Empezar» para grabar (sin sonido)");
        } catch (Exception e) { aviso("Este celular no deja grabar la pantalla"); }
    }

    private void pintarRec() {
        String t;
        if (Grabadora.grabando) {
            long s = (System.currentTimeMillis() - Grabadora.inicio) / 1000;
            t = "⏹ " + s / 60 + ":" + String.format(Locale.US, "%02d", s % 60);
        } else t = "🎥\nREC";
        for (TextView b : botonesRec) { b.setText(t); colorear(b, Grabadora.grabando ? 0xFFB71C1C : 0xFFC62828); }
    }

    private void relojRec() {
        pintarRec();
        relojH.postDelayed(() -> { if (Grabadora.grabando || System.currentTimeMillis() - Grabadora.inicio < 4000) relojRec(); else pintarRec(); }, 1000);
    }

    /** 📷 Pantallazo de lo que se ve en Chepe CAD. */
    void foto() {
        try {
            View v = getWindow().getDecorView().getRootView();
            int w = v.getWidth(), h = v.getHeight();
            if (w <= 0 || h <= 0) return;
            android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888);
            v.draw(new Canvas(bm));
            String nom = "ChepeCAD_foto_" + new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()) + ".png";
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bo);
            bm.recycle();
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(bo.toByteArray()); }
            listoArchivo(u, nom, bo.size(), false);
        } catch (Exception e) { aviso("No se pudo tomar el pantallazo"); }
    }

    /** Ya quedó guardado en el celular; si quiere, se manda de una a Claude. */
    private void listoArchivo(Uri u, String nom, long bytes, boolean video) {
        String tam = bytes > 0 ? String.format(Locale.US, "%.1f MB", bytes / 1048576.0) : "";
        new AlertDialog.Builder(this).setTitle(video ? "🎥 Video guardado" : "📷 Pantallazo guardado")
                .setMessage(nom + "\n" + tam + (video ? " · 360 · sin sonido" : "") + "\nQuedó en Descargas/MiBarra/MiInventor")
                .setPositiveButton("Enviar a Claude", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND).setType(video ? "video/mp4" : "image/png").putExtra(Intent.EXTRA_STREAM, u)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(new Intent(i).setPackage("com.anthropic.claude")); }
                    catch (Exception e) { try { startActivity(Intent.createChooser(i, "Enviar a Claude")); } catch (Exception ignored) { } }
                })
                .setNegativeButton("Solo guardar", null).show();
    }

    private void pedirArchivo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        try { startActivityForResult(i, ABRIR_ARCHIVO); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
    }

    private void ayuda() {
        new AlertDialog.Builder(this).setTitle("❓ Ayuda · " + VERSION).setMessage(
                "☰ (izquierda): crear pieza, lámina, casa, montaje o cortes.\n"
                + "⋮ (derecha): guardar, librería, archivos, WhatsApp, lista de corte, medidas.\n\n"
                + "BOCETO: dibuje con medidas y OK. Cuando la figura cierra sale ⬆ Extruir.\n"
                + "PIEZA: un toque en una cara = boceto en esa cara o color. Doble toque = cambiar el largo o ir al boceto original. 🔩 Agujero = escoja la broca y toque la cara.\n"
                + "DESARROLLO: solo para sacar PDF, PNG, DXF o WhatsApp.\n"
                + "🎥 REC graba la pantalla sin sonido (toque otra vez para detener). 📷 FOTO toma el pantallazo. Los dos ofrecen «Enviar a Claude».\n"
                + "🩺 DOCTOR: si la figura no cierra, muestra dónde y la arregla.\n"
                + "CASA: ✚ Cuarto, 🚪 Puerta, 🪟 Ventana, 🧱 Muro suelto; toque una cota para cambiarla.")
                .setPositiveButton("Entendido", null).show();
    }

    /** Documento nuevo: se guarda el que estaba, se pide el nombre y se empieza vacío. */
    private void nuevoDoc(String m) {
        guardarDoc(true);
        List<String> ya = nombresLib();
        int n = 1;
        String base = PIEZA.equals(m) ? "T" : LAMINA.equals(m) ? "L" : CASA.equals(m) ? "Casa " : "Montaje ";
        while (ya.contains(base + n)) n++;
        EditText e = campoTexto(base + n, "nombre");
        new AlertDialog.Builder(this).setTitle(icono(m) + " Nombre de la " + (MONTAJE.equals(m) ? "nuevo montaje" : CASA.equals(m) ? "casa" : LAMINA.equals(m) ? "lámina" : "pieza"))
                .setView(e)
                .setPositiveButton("Crear", (d, w) -> {
                    String nom = limpio(Teclado.tx(e));
                    if (nom.isEmpty() || nom.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    if (nombresLib().contains(nom)) { aviso("Ya hay uno que se llama «" + nom + "» en la librería"); return; }
                    if (MONTAJE.equals(m) || CASA.equals(m)) { crearDoc(m, nom, 0); return; }
                    // v6.2: como Inventor, primero se escoge el plano del boceto; así la pieza llega parada o acostada al montaje
                    String[] pl = {"⬜ Plano XY (piso): lo que dibuje sale hacia arriba · columnas paradas",
                            "▯ Plano XZ (frente): vigas y marcos vistos de frente",
                            "▯ Plano YZ (lado): sale hacia el lado"};
                    new AlertDialog.Builder(this).setTitle("✏ ¿En qué plano dibuja el boceto de «" + nom + "»?")
                            .setItems(pl, (d2, w2) -> crearDoc(m, nom, w2)).setCancelable(false).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** v6.2: arma el documento nuevo con el boceto en el plano escogido (0 = XY, 1 = XZ, 2 = YZ). */
    private void crearDoc(String m, String nom, int plano) {
                    atras.clear(); adelante.clear();
                    piezas.clear(); medidas.filas.clear(); refs.clear();
                    hojas.clear(); hojas.add(Hoja.nueva(1, plano)); hoja = hojas.get(0); boceto.b = hoja.b; boceto.anclarAuto = true; boceto.limpiarSeleccion();
                    escogida = -1;
                    nombreProyecto = nom;
                    modo = m;
                    if (!MONTAJE.equals(m)) volverA = "";
                    aplicarModo();
                    guardarDoc(true);
                    if (MONTAJE.equals(m)) {
                        mostrar(1);
                        vista.encuadrar();
                        recalcular();
                        aviso("🧩 Montaje vacío. Toque 📥 Insertar para traer piezas de la librería");
                    } else {
                        mostrar(0);
                        boceto.encuadrar();
                        recalcular();
                        grupo2D(G_DIBUJAR);
                        if (dxfNuevo) { pedirDxf(); return; }
                        aviso(CASA.equals(m) ? "✏ Dibuje la planta de las paredes (con su grueso) y toque ✓ Listo"
                                : "✏ " + hoja.plano + ": dibuje el perfil desde el 0,0 y toque ✓ Listo para extruirlo");
                    }
    }

    /** Los botones del 3D cambian según el documento. */
    private void aplicarModo() {
        if (vista == null || cajaAcciones == null) return;
        vista.version = VERSION + " · " + etiquetaModo();
        filaModos.setVisibility(esMontaje() ? View.VISIBLE : View.GONE);
        if (!esMontaje()) modo3D(Vista3D.CORRER);
        cajaAcciones.removeAllViews();
        List<Object[]> b = new ArrayList<>();
        if (esMontaje()) {
            b.add(new Object[]{"📥\nInsertar", 0xFF00897B, (Runnable) this::insertar});
            b.add(new Object[]{"🔗\nAmarrar", 0xFF00897B, (Runnable) this::amarrar3D});
            b.add(new Object[]{"⟳\nRotar", 0xFF6A1B9A, (Runnable) this::rotar});
            b.add(new Object[]{"⧉\nCopiar", 0xFF5E35B1, (Runnable) this::copiarEscogida});
            b.add(new Object[]{"⇋\nEspejo", 0xFF5E35B1, (Runnable) this::espejo});
            b.add(new Object[]{"▦\nArreglo", 0xFF5E35B1, (Runnable) this::arreglo});
            b.add(new Object[]{"✏\nAbrir pieza", 0xFF1E88E5, (Runnable) this::abrirPiezaDeMontaje});
            b.add(new Object[]{"📏\nReferencias", 0xFF1565C0, (Runnable) this::referencias});
            b.add(new Object[]{"🗑\nBorrar", 0xFFB71C1C, (Runnable) this::borrar3D});
            b.add(new Object[]{"↶\nAtrás", 0xFF455A64, (Runnable) this::deshacer});
            b.add(new Object[]{"↷\nAdelante", 0xFF455A64, (Runnable) this::rehacer});
        } else {
            b.add(new Object[]{"✏\nBoceto", 0xFF1565C0, (Runnable) this::arreglarBoceto});
            b.add(new Object[]{"🟩\nPieza", 0xFF2E7D32, (Runnable) this::arreglarExtrusion});
            if (LAMINA.equals(modo)) {
                b.add(new Object[]{"↪\nDoblez", 0xFF546E7A, (Runnable) () -> conLamina(this::pedirBorde)});
                b.add(new Object[]{"📄\nDesarrollo", 0xFF546E7A, (Runnable) this::desarrollo});
            }
            if (CASA.equals(modo)) b.add(new Object[]{"🧱\nFaroles", 0xFF6D4C41, (Runnable) this::faroles});
            if (PIEZA.equals(modo) || LAMINA.equals(modo)) b.add(new Object[]{"🔩\nAgujero", 0xFF546E7A, (Runnable) this::agujero});
            if (PIEZA.equals(modo)) b.add(new Object[]{"✂\nCortar", 0xFFC62828, (Runnable) this::cortar3D});
            b.add(new Object[]{"💾\nGuardar", 0xFF2E7D32, (Runnable) () -> guardarDoc(false)});
            b.add(new Object[]{"↶\nAtrás", 0xFF455A64, (Runnable) this::deshacer});
            b.add(new Object[]{"↷\nAdelante", 0xFF455A64, (Runnable) this::rehacer});
            if (!volverA.isEmpty()) b.add(new Object[]{"⬅\nAl montaje", 0xFF00897B, (Runnable) this::volverAlMontaje});
        }
        // filas de 3 o 4, sin huecos
        int n = b.size(), filas = (n + 3) / 4, i = 0;
        for (int f = 0; f < filas; f++) {
            int enEsta = (n - i) / (filas - f) + ((n - i) % (filas - f) > 0 ? 1 : 0);
            LinearLayout fila = new LinearLayout(this);
            for (int k = 0; k < enEsta && i < n; k++, i++) {
                Object[] o = b.get(i);
                Runnable r = (Runnable) o[2];
                fila.addView(boton((String) o[0], (Integer) o[1], r), peso());
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
            lp.topMargin = dp(4);
            cajaAcciones.addView(fila, lp);
        }
        pintarCabeza();
        vista.invalidate();
    }

    /** La pieza principal del documento (la primera que salió del boceto). */
    private Pieza piezaPrincipal() {
        for (Pieza p : piezas) if (p.tipo == Pieza.PLACA && p.hoja >= 0) return p;
        return piezas.isEmpty() ? null : piezas.get(0);
    }

    private void arreglarBoceto() {
        Pieza p = piezaPrincipal();
        Hoja h = p != null ? porHoja(p.hoja) : null;
        if (h == null) h = hoja;
        abrirHoja(h);
        aviso("✏ Arregle el boceto y toque ✓ Listo: la pieza cambia sola");
    }

    /** Cambiar el largo de la extrusión (o el calibre de la lámina, o la altura de la casa) y hacia qué lado sale. */
    private void arreglarExtrusion() {
        Pieza p = piezaPrincipal();
        if (p == null) { aviso("Primero haga el boceto y toque ✓ Listo"); return; }
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] cal = {Math.max(0, Arrays.asList(Lamina.CALIBRES).indexOf(p.cal))};
        final int[] lado = {p.alReves ? 1 : 0};
        EditText g = campoTexto(p.f.containsKey("largo") ? p.f.get("largo") : Pieza.n(p.largo), "mm o fórmula");
        if (p.lamina) {
            l.addView(etiqueta("Calibre"));
            grupoBotones(l, Lamina.CALIBRES, cal, 3, null);
        } else {
            l.addView(etiqueta(CASA.equals(modo) ? "Altura de las paredes (mm o fórmula)" : "Largo de la extrusión (mm o fórmula)"));
            l.addView(g);
        }
        l.addView(etiqueta("Hacia dónde sale del boceto"));
        grupoBotones(l, new String[]{"⬆ Para arriba", "⬇ Para abajo"}, lado, 2, null);
        new AlertDialog.Builder(this).setTitle("⬆ Extrusión de " + p.nombre()).setView(l)
                .setPositiveButton("Cambiar", (d, w) -> {
                    antes();
                    if (p.lamina) { p.cal = Lamina.CALIBRES[cal[0]]; p.largo = Lamina.GRUESOS[cal[0]]; }
                    else { leerCampo(p, "largo", Teclado.tx(g)); if (p.largo <= 0) p.largo = 6; }
                    p.alReves = lado[0] == 1;
                    vista.encuadrar();
                    recalcular();
                    guardarDoc(true);
                    aviso("✔ " + p.nombre() + ": " + Pieza.n(p.largo) + " mm. Los montajes que la usan cambian al abrirlos");
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- 📚 Librería ----------------

    private void libreria() {
        guardarDoc(true);
        List<String> ns = nombresLib();
        if (ns.isEmpty()) { aviso("La librería está vacía: haga una pieza en ☰ → 🟩 Pieza de acero nueva"); return; }
        String[] it = new String[ns.size()];
        for (int i = 0; i < it.length; i++) it[i] = icono(modoDe(ns.get(i))) + " " + ns.get(i) + (ns.get(i).equals(nombreProyecto) ? "  (abierto)" : "");
        new AlertDialog.Builder(this).setTitle("📚 Librería · Descargas/MiBarra/MiInventor/Libreria").setItems(it, (d, w) -> {
            String n = ns.get(w);
            new AlertDialog.Builder(this).setTitle(icono(modoDe(n)) + " " + n)
                    .setItems(new String[]{"📂 Abrir", "⧉ Copiar (con otro nombre)", "✎ Cambiar el nombre", "🗑 Borrar"}, (d2, w2) -> {
                        if (w2 == 0) { volverA = ""; abrirDoc(n, false); }
                        else if (w2 == 1 || w2 == 2) {
                            EditText e = campoTexto(w2 == 1 ? siguienteNombre(n) : n, "nombre");
                            new AlertDialog.Builder(this).setTitle(w2 == 1 ? "⧉ Nombre de la copia" : "✎ Nombre nuevo").setView(e)
                                    .setPositiveButton("Listo", (d3, w3) -> copiarDoc(n, limpio(Teclado.tx(e)), w2 == 2))
                                    .setNegativeButton("Cancelar", null).show();
                        } else new AlertDialog.Builder(this).setMessage("¿Borrar «" + n + "» de la librería para siempre?\n\nLos montajes que la usan se quedan con la forma que tiene ahora.")
                                .setPositiveButton("🗑 Borrar", (d3, w3) -> {
                                    if (n.equals(nombreProyecto)) { aviso("Está abierto: abra otro primero"); return; }
                                    new File(carpetaLib(), n + ".json").delete();
                                    aviso("Borrado «" + n + "»");
                                }).setNegativeButton("Cancelar", null).show();
                    }).show();
        }).setNegativeButton("Cerrar", null).show();
    }

    /** T1 → T2, «Base» → «Base 2»… el primero que no exista. */
    private String siguienteNombre(String n) {
        List<String> ya = nombresLib();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(.*?)(\\d+)$").matcher(n);
        String base = m.matches() ? m.group(1) : n + " ";
        int k = m.matches() ? Integer.parseInt(m.group(2)) + 1 : 2;
        while (ya.contains(base + k)) k++;
        return base + k;
    }

    private void copiarDoc(String de, String a, boolean mover) {
        if (a.isEmpty() || a.startsWith("_")) { aviso("Escriba un nombre"); return; }
        if (a.equals(de)) return;
        if (nombresLib().contains(a)) { aviso("Ya existe «" + a + "»"); return; }
        try {
            JSONObject o = leerDoc(de);
            if (o == null) return;
            o.put("nombre", a);
            JSONArray ps = o.optJSONArray("piezas");
            if (ps != null) for (int i = 0; i < ps.length(); i++) {
                JSONObject x = ps.optJSONObject(i);
                if (x != null && de.equals(x.optString("tit", ""))) x.put("tit", a);
            }
            try (FileWriter w = new FileWriter(new File(carpetaLib(), a + ".json"))) { w.write(o.toString()); }
            if (mover) {
                new File(carpetaLib(), de + ".json").delete();
                if (de.equals(nombreProyecto)) { nombreProyecto = a; Pieza p = piezaPrincipal(); if (p != null && de.equals(p.titulo)) p.titulo = a; guardarDoc(true); aplicarModo(); }
                aviso("✔ Ahora se llama «" + a + "». Ojo: los montajes que la usaban la buscan con el nombre viejo");
            } else aviso("✔ Copia «" + a + "» en la librería. Ábrala y cámbiele lo que necesite");
        } catch (Exception e) { aviso("No se pudo"); }
    }

    // ---------------- 🧩 Montaje: piezas que vienen de la librería ----------------

    /** La forma (no el sitio) de la pieza de la librería. */
    private static void copiarForma(Pieza src, Pieza dst) {
        dst.tipo = src.tipo; dst.medida = src.medida; dst.a = src.a; dst.b = src.b; dst.t = src.t; dst.calibre = src.calibre;
        dst.largo = src.largo; dst.contorno = src.contorno; dst.alReves = src.alReves;
        dst.agujeros.clear(); dst.agujeros.addAll(src.agujeros);
        dst.huecos.clear();
        for (Pieza.Hueco h : src.huecos) { h.hoja = -1; h.ents = new ArrayList<>(); dst.huecos.add(h); }
        dst.cortes.clear();
        for (Pieza.Corte c : src.cortes) { c.hoja = -1; c.ents = new ArrayList<>(); dst.cortes.add(c); }
        dst.lamina = src.lamina; dst.cal = src.cal; dst.radio = src.radio; dst.kFactor = src.kFactor;
        dst.dobleces = src.dobleces;
        dst.corteIni = src.corteIni; dst.corteFin = src.corteFin; dst.ciS = src.ciS; dst.ciU = src.ciU; dst.cfS = src.cfS; dst.cfU = src.cfU;
        dst.hoja = -1;
        dst.entsContorno = new ArrayList<>();
        dst.entsAgujeros.clear();
        dst.f.remove("largo");
    }

    private Pieza principalDe(JSONObject o) {
        JSONArray a = o == null ? null : o.optJSONArray("piezas");
        if (a == null || a.length() == 0) return null;
        Pieza mejor = null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            Pieza p = Pieza.deJson(x);
            if (mejor == null || (p.tipo == Pieza.PLACA && p.hoja >= 0 && !(mejor.tipo == Pieza.PLACA && mejor.hoja >= 0))) mejor = p;
        }
        return mejor;
    }

    /** Al abrir un montaje, cada pieza toma la forma que tiene hoy en la librería. */
    private void refrescarInstancias() {
        Map<String, Pieza> cache = new HashMap<>();
        List<String> faltan = new ArrayList<>();
        for (Pieza p : piezas) {
            if (p.lib == null || p.lib.isEmpty()) continue;
            if (!cache.containsKey(p.lib)) cache.put(p.lib, principalDe(leerDoc(p.lib)));
            Pieza src = cache.get(p.lib);
            if (src == null) { if (!faltan.contains(p.lib)) faltan.add(p.lib); continue; }
            copiarForma(src, p);
        }
        if (!faltan.isEmpty()) aviso("⚠ No están en la librería: " + String.join(", ", faltan) + " (se quedan como estaban)");
    }

    private void insertar() {
        new AlertDialog.Builder(this).setTitle("📥 Insertar en el montaje")
                .setItems(new String[]{"📚 Una pieza de la librería", "🟩 Un tubo del catálogo"}, (d, w) -> {
                    if (w == 1) { editar(null); return; }
                    guardarDoc(true);
                    List<String> ns = new ArrayList<>();
                    for (String n : nombresLib()) { String m = modoDe(n); if (!MONTAJE.equals(m)) ns.add(n); }
                    if (ns.isEmpty()) { aviso("La librería no tiene piezas: haga una en ☰ → 🟩 Pieza de acero nueva"); return; }
                    String[] it = new String[ns.size()];
                    for (int i = 0; i < it.length; i++) it[i] = icono(modoDe(ns.get(i))) + " " + ns.get(i);
                    new AlertDialog.Builder(this).setTitle("📚 ¿Cuál pieza?").setItems(it, (d2, w2) -> insertarDeLib(ns.get(w2))).show();
                }).show();
    }

    private int instancias(String lib) {
        int k = 0;
        for (Pieza p : piezas) if (lib.equals(p.lib)) k++;
        return k;
    }

    private void insertarDeLib(String lib) {
        Pieza src = principalDe(leerDoc(lib));
        if (src == null) { aviso("«" + lib + "» todavía no tiene pieza: ábrala y toque ✓ Listo en su boceto"); return; }
        antes();
        Pieza p = src.copia(nuevoId());
        if (p == null) return;
        copiarForma(src, p);
        p.lib = lib;
        p.titulo = lib + ":" + (instancias(lib) + 1);
        p.padre = -1; p.fija = piezas.isEmpty();
        p.oculta = false;
        piezas.add(p);
        escogida = p.id;
        vista.encuadrar();
        recalcular();
        aviso("✔ " + p.titulo + " en el montaje" + (p.fija ? " (la primera queda 📌 fija, como en Inventor)" : ": muévala o amárrela"));
    }

    /** ✏ Abrir la pieza de la librería para cambiarla; luego ⬅ vuelve al montaje. */
    private void abrirPiezaDeMontaje() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere abrir"); return; }
        if (p.lib == null || p.lib.isEmpty()) { editar(p); return; }
        String m = nombreProyecto;
        guardarDoc(true);
        abrirDoc(p.lib, true);
        volverA = m;
        aplicarModo();
        aviso("✏ " + p.lib + " abierta. Lo que cambie aquí cambia en todos los montajes. ☰ → ⬅ para volver");
    }

    private void volverAlMontaje() {
        if (volverA.isEmpty()) return;
        String m = volverA;
        guardarDoc(true);
        volverA = "";
        abrirDoc(m, false);
    }

    /** Versión 6: el proyecto viejo (todo junto) se vuelve un montaje; cada pieza de boceto pasa a la librería. */
    private void migrar() {
        modoFalta = false;
        if (piezas.isEmpty() && hojas.size() <= 1 && (hoja == null || hoja.b.vacio())) { modo = PIEZA; return; }
        modo = MONTAJE;
        List<String> ya = nombresLib();
        if ("Sin nombre".equals(nombreProyecto) || nombreProyecto.isEmpty()) {
            int n = 1;
            while (ya.contains("Montaje " + n)) n++;
            nombreProyecto = "Montaje " + n;
        }
        int pasadas = 0;
        for (Pieza p : piezas) {
            if (p.tipo != Pieza.PLACA || p.hoja < 0) continue;
            Hoja h = porHoja(p.hoja);
            if (h == null) continue;
            String nom = limpio(p.nombre());
            while (nombresLib().contains(nom)) nom = siguienteNombre(nom);
            try {
                JSONObject o = new JSONObject();
                o.put("v", 6);
                o.put("modo", p.lamina ? LAMINA : PIEZA);
                o.put("nombre", nom);
                Pieza c = p.copia(1);
                c.titulo = nom; c.padre = -1; c.cara = 0; c.fija = false;
                JSONArray pa = new JSONArray();
                pa.put(c.json());
                o.put("piezas", pa);
                o.put("medidas", medidas.json());
                JSONArray hs = new JSONArray();
                hs.put(h.json());
                o.put("bocetos", hs);
                o.put("hojaAct", h.id);
                try (FileWriter w = new FileWriter(new File(carpetaLib(), nom + ".json"))) { w.write(o.toString()); }
                p.lib = nom;
                p.titulo = nom + ":1";
                p.hoja = -1;
                p.entsContorno = new ArrayList<>();
                p.entsAgujeros.clear();
                pasadas++;
            } catch (Exception ignored) { }
        }
        hojas.clear();
        hojas.add(Hoja.nueva(1, 0));
        hoja = hojas.get(0);
        boceto.b = hoja.b;
        guardarDoc(true);
        if (pasadas > 0) aviso("✔ Su trabajo quedó como «" + nombreProyecto + "»; " + pasadas + (pasadas == 1 ? " pieza pasó" : " piezas pasaron") + " a la librería");
    }

    // =====================================================================
    //                         VERSIÓN 6.1
    // =====================================================================

    /** Tocar una cara (sin comando): la barrita de la cara, como en Inventor. */
    private void menuCara(int pieza, float[] nrm, float[] q, float[][] pts) {
        Pieza p = porId(pieza);
        if (p == null || barra3D.getVisibility() == View.VISIBLE) return;   // v6.2: si hay otra cosa abierta (doblez, amarre), la cara no estorba
        if (vista.pideToque != null || vista.pideCara != null) return;
        panel("Cara de " + p.nombre());
        LinearLayout f = filaPanel();
        // v6.5: un toque = boceto en esta cara o color (el boceto inicial y el largo van con doble toque)
        if (agujeroDiam > 0 && !esMontaje()) { double dd = agujeroDiam; agujeroDiam = 0; cerrarPanel(); agujeroEnCara(p, nrm, q, pts, dd); return; }
        if (!esMontaje()) {
            f.addView(boton("➕ Boceto en esta cara", 0xFF00897B, () -> { cerrarPanel(); bocetoEnCara(p, nrm, q, pts); }), peso());
        } else {
            f.addView(boton("🔗 Amarrar", 0xFF00897B, () -> { cerrarPanel(); amarrar3D(); }), peso());
            if (p.lib != null && !p.lib.isEmpty()) f.addView(boton("✏ Abrir pieza", 0xFF1E88E5, () -> { cerrarPanel(); abrirPiezaDeMontaje(); }), peso());
        }
        f.addView(boton("🎨 Color", 0xFF6A1B9A, () -> colorCara(p, nrm)), peso());
        LinearLayout f2 = filaPanel();
        f2.addView(boton("✖ Cerrar", 0xFF455A64, this::cerrarPanel), peso());
    }

    /** v6.5: doble toque en la pieza. */
    private void menuDoble(int pieza) {
        Pieza p = porId(pieza);
        if (p == null) return;
        if (toquePanel || barra3D.getVisibility() == View.VISIBLE) cerrarPanel();
        if (esMontaje()) {
            if (p.lib != null && !p.lib.isEmpty()) new AlertDialog.Builder(this).setTitle(p.nombre())
                    .setItems(new String[]{"✏ Abrir la pieza para cambiarla", "🔗 Amarrar"}, (d, w) -> { if (w == 0) abrirPiezaDeMontaje(); else amarrar3D(); }).show();
            return;
        }
        String largo = LAMINA.equals(modo) ? "📏 Cambiar el calibre" : "⬆ Cambiar el largo (altura del sólido)";
        new AlertDialog.Builder(this).setTitle(p.nombre())
                .setItems(new String[]{largo, "✏ Ir al boceto original"}, (d, w) -> { if (w == 0) arreglarExtrusion(); else arreglarBoceto(); }).show();
    }

    // ---------------- v6.5: 🔩 Agujero (taladro) ----------------

    private double agujeroDiam;

    private void agujero() {
        String[] brocas = {"1/4\" (6,35 mm)", "5/16\" (7,94 mm)", "3/8\" (9,53 mm)", "1/2\" (12,7 mm)", "5/8\" (15,88 mm)", "3/4\" (19,05 mm)", "1\" (25,4 mm)", "Otra medida…"};
        double[] mm = {6.35, 7.94, 9.53, 12.7, 15.88, 19.05, 25.4, 0};
        new AlertDialog.Builder(this).setTitle("🔩 ¿Qué broca?").setItems(brocas, (d, w) -> {
            if (mm[w] > 0) { agujeroDiam = mm[w]; aviso("🔩 Toque la cara donde va el agujero de " + brocas[w]); }
            else Teclado.pedir(this, "Diámetro del agujero", Double.NaN, v -> { agujeroDiam = v; aviso("🔩 Toque la cara donde va el agujero de " + Pieza.n((float) v) + " mm"); });
        }).show();
    }

    private void agujeroEnCara(Pieza p, float[] nrm, float[] q, float[][] pts, double diam) {
        bocetoEnCara(p, nrm, q, pts);
        Boceto.Punto c = hoja.b.punto(0, 0);
        Boceto.Ent e = hoja.b.ent(Boceto.CIRCULO);
        e.a = c.id;
        e.r = diam / 2;
        hoja.b.restriccion(Boceto.C_DIAM, e.id, -1, -1, -1, Pieza.n((float) diam));
        recalcular();
        grupo2D(G_AMARRAR);
        aviso("🔩 Ubique el agujero: toque su centro, luego un borde punteado y ⟂ Punto-línea (haga lo mismo con el otro borde). Después ✓ Listo → Perforar");
    }

    /** ✏ Boceto sobre la cara tocada: el 0,0 queda donde tocó. Al terminar sale Cortar (pasante, a una profundidad) o Extruir. */
    private void bocetoEnCara(Pieza pz, float[] nrm, float[] q) { bocetoEnCara(pz, nrm, q, null); }

    private void bocetoEnCara(Pieza pz, float[] nrm, float[] q, float[][] pts) {
        Hoja h = new Hoja();
        h.id = nuevoIdHoja();
        h.nombre = "Boceto " + h.id;
        h.plano = "Cara de " + pz.nombre();
        float[] n = {nrm[0], nrm[1], nrm[2]};
        float[] ey = Math.abs(n[2]) < 0.9f ? new float[]{-n[0] * n[2], -n[1] * n[2], 1 - n[2] * n[2]} : new float[]{0, 1, 0};
        ey = Geo.unit(ey);
        h.ey = ey;
        h.ex = new float[]{ey[1] * n[2] - ey[2] * n[1], ey[2] * n[0] - ey[0] * n[2], ey[0] * n[1] - ey[1] * n[0]};
        h.o = new float[]{Math.round(q[0]), Math.round(q[1]), Math.round(q[2])};
        h.pieza = pz.id;
        h.rel = relativo(pz, h);
        // v6.3: las aristas de la cara quedan en el boceto (punteadas y fijas) para amarrar y acotar desde los bordes
        if (pts != null && pts.length >= 3) {
            int[] ids = new int[pts.length];
            for (int i = 0; i < pts.length; i++) {
                float[] d = Geo.sub(pts[i], h.o);
                Boceto.Punto bp = h.b.punto(Math.round(Geo.dot(d, h.ex) * 10) / 10.0, Math.round(Geo.dot(d, h.ey) * 10) / 10.0);
                bp.fijo = true;
                ids[i] = bp.id;
            }
            for (int i = 0; i < pts.length; i++) {
                Boceto.Ent e = h.b.linea(h.b.puntos.get(ids[i]), h.b.puntos.get(ids[(i + 1) % pts.length]));
                e.punteada = true;
            }
        }
        antes();
        hojas.add(h);
        abrirHoja(h);
        grupo2D(G_DIBUJAR);
        boceto.encuadrar();
        aviso("✏ Trabajo sobre " + pz.nombre() + ": las líneas punteadas son los bordes de la cara. Dibuje, amarre y acote desde ellos, y toque ✓ Listo → ✂ Cortar o ⬆ Elevación");
    }

    private void colorCara(Pieza p, float[] nrm) {
        String[] nom = {"🟥 Rojo", "🟧 Naranja", "🟨 Amarillo", "🟩 Verde", "🟦 Azul", "🟪 Morado", "⬜ Blanco", "⬛ Negro", "↺ Quitar el color"};
        int[] col = {0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFF5F5F5, 0xFF212121, 0};
        new AlertDialog.Builder(this).setTitle("🎨 Color de la cara").setItems(nom, (d, w) -> {
            antes();
            float[][] e = Vista3D.ejes(p);
            double[] l = {Geo.dot(nrm, e[0]), Geo.dot(nrm, e[1]), Geo.dot(nrm, e[2])};
            p.colores.removeIf(c -> l[0] * c[0] + l[1] * c[1] + l[2] * c[2] > 0.995);
            if (col[w] != 0) p.colores.add(new double[]{l[0], l[1], l[2], col[w]});
            cerrarPanel();
            recalcular();
            guardarDoc(true);
        }).show();
    }

    private void medirCara(float[][] pts) {
        if (pts == null || pts.length < 3) return;
        StringBuilder sb = new StringBuilder("📏 Lados: ");
        double area = 0;
        float[] n = Geo.unit(Geo.cross(Geo.sub(pts[1], pts[0]), Geo.sub(pts[2], pts[0])));
        float[] acc = {0, 0, 0};
        for (int i = 0; i < pts.length; i++) {
            float[] a = pts[i], b = pts[(i + 1) % pts.length];
            if (pts.length <= 6) sb.append(i == 0 ? "" : " · ").append(Pieza.n(Geo.dist(a, b)));
            acc = Geo.add(acc, Geo.cross(a, b));
        }
        area = Math.abs(Geo.dot(acc, n)) / 2;
        if (pts.length > 6) sb.append(pts.length).append(" lados");
        sb.append(" mm\nÁrea: ").append(Pieza.n((float) area)).append(" mm² = ").append(String.format(Locale.US, "%.4f", area / 1e6)).append(" m²");
        new AlertDialog.Builder(this).setTitle("📏 Medida de la cara").setMessage(sb.toString()).setPositiveButton("Listo", null).show();
    }

    /** Las líneas de doblez de las láminas, punteadas en el 3D. */
    private void lineasDoblez() {
        List<float[][]> l = new ArrayList<>();
        for (Pieza p : piezas) {
            if (!p.lamina || p.dobleces.isEmpty() || p.marco == null || p.oculta) continue;
            try {
                Lamina.Borde[][] a = Lamina.armar(p, null);
                for (Lamina.Borde b : a[0]) if (b != null) l.add(new float[][]{b.a, b.b});
            } catch (Exception ignored) { }
        }
        vista.punteadas = l.isEmpty() ? null : l;
    }

    /** Terminar revisa que todo quede amarrado (paramétrico) antes de extruir. */
    private void revisarParametrico() {
        if (false && !esMontaje() && boceto.libres != null && hoja.b.gradosLibres > 0 && placasDe(hoja).isEmpty()) {
            new AlertDialog.Builder(this).setTitle("🩺 Revisión del boceto")
                    .setMessage("Faltan " + hoja.b.gradosLibres + " medidas o amarres (lo azul). Así se puede extruir, pero si cambia una medida, la figura se puede deformar.\n\nLo ideal: que todo quede negro.")
                    .setPositiveButton("⬆ Extruir igual", (d, w) -> irAlMontaje())
                    .setNegativeButton("✏ Lo arreglo", (d, w) -> grupo2D(G_AMARRAR)).show();
            return;
        }
        irAlMontaje();
    }

    // ---------------- ⇋ Espejo y ▦ Arreglo (montaje) ----------------

    /** ⇋ Espejo: una copia de la pieza al otro lado de un plano de referencia. */
    private void espejo() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza"); return; }
        if (planosRef().isEmpty()) { aviso("Primero haga un plano: 📏 Referencias"); return; }
        escogerPlano("⇋ ¿Con qué plano hago el espejo de " + p.nombre() + "?", r -> {
            antes();
            Map<Integer, Pieza> m = mapaPiezas();
            float[] ini = p.inicio(m, 0);
            float[][] e = Vista3D.ejes(p);
            Pieza c = p.copia(nuevoId());
            if (c == null) return;
            float[] n = r.v;
            java.util.function.Function<float[], float[]> refl = v -> Geo.sub(v, Geo.mul(n, 2 * Geo.dot(v, n)));
            float[] d = refl.apply(e[0]), s = Geo.neg(refl.apply(e[1])), u = refl.apply(e[2]);
            float[] st = Geo.add(r.o, refl.apply(Geo.sub(ini, r.o)));
            // la forma también se voltea (para que quede de verdad al espejo)
            if (c.contorno != null) for (float[] q : c.contorno) q[0] = -q[0];
            for (float[][] ag : c.agujeros) for (float[] q : ag) q[0] = -q[0];
            for (Pieza.Hueco h : c.huecos) { h.s = -h.s; if (h.forma != null && c.tipo == Pieza.PLACA) for (float[] q : h.forma) q[0] = -q[0]; }
            c.padre = -1; c.cara = 0; c.sep = 0; c.cx = c.cy = c.cz = 0; c.fija = false; c.amarres.clear();
            for (String k : new String[]{"cx", "cy", "cz", "sep", "aMm"}) c.f.remove(k);
            float[] o = c.alReves ? Geo.addk(st, d, c.largo) : st;
            c.marco = new float[]{o[0], o[1], o[2], s[0], s[1], s[2], u[0], u[1], u[2], d[0], d[1], d[2]};
            if (c.lib != null && !c.lib.isEmpty()) c.titulo = c.lib + ":" + (instancias(c.lib) + 1);
            else c.titulo = p.nombre() + " espejo";
            c.dobleces = new ArrayList<>();   // los dobleces de lámina no se voltean todavía
            for (Pieza.Doblez db : p.dobleces) { Pieza.Doblez x = new Pieza.Doblez(); x.padre = db.padre; x.borde = db.borde; x.angulo = db.angulo; x.largo = db.largo; x.abajo = db.abajo; x.porDentro = db.porDentro; c.dobleces.add(x); }
            piezas.add(c);
            escogida = c.id;
            anotarAmarre(c, "⇋ espejo de " + p.nombre() + " con " + r.nombre);
            vista.encuadrar();
            recalcular();
            aviso("✔ " + c.nombre() + ": espejo de " + p.nombre());
        });
    }

    /** ▦ Arreglo: repetir la pieza escogida en fila (X, Y, Z) o en círculo (alrededor de un eje). */
    private void arreglo() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere repetir"); return; }
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] tipo = {0};
        l.addView(etiqueta("Cómo se repite"));
        grupoBotones(l, new String[]{"→ En X", "↗ En Y", "↑ En Z", "◯ En círculo (Z)"}, tipo, 2, null);
        l.addView(etiqueta("Cuántas en total (contando la que hay)"));
        EditText cu = campoTexto("4", "");
        l.addView(cu);
        l.addView(etiqueta("Cada cuánto: mm en fila, o grados en círculo (0 = repartidas en 360°)"));
        EditText ca = campoTexto("500", "");
        l.addView(ca);
        new AlertDialog.Builder(this).setTitle("▦ Arreglo de " + p.nombre()).setView(l)
                .setPositiveButton("Repetir", (d, w) -> {
                    Double vn = valorDe(Teclado.tx(cu)), vc = valorDe(Teclado.tx(ca));
                    if (vn == null || vn < 2) { aviso("Ponga 2 o más"); return; }
                    int n = (int) Math.min(200, Math.round(vn));
                    float paso = vc == null ? 0 : vc.floatValue();
                    if (tipo[0] == 3 && Math.abs(paso) < 0.01f) paso = 360f / n;
                    antes();
                    float[] centro = p.inicio(mapaPiezas(), 0);
                    float[][] dirs = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
                    for (int i = 1; i < n; i++) {
                        Pieza c = p.copia(nuevoId());
                        if (c == null) continue;
                        c.fija = false; c.amarres.clear();
                        if (c.lib != null && !c.lib.isEmpty()) c.titulo = c.lib + ":" + (instancias(c.lib) + 1);
                        else c.titulo = p.nombre() + "." + (i + 1);
                        piezas.add(c);
                        if (tipo[0] < 3) trasladar(c, Geo.mul(dirs[tipo[0]], paso * i));
                        else girarPieza(c, new float[]{0, 0, 0}, new float[]{0, 0, 1}, paso * i, true);
                        anotarAmarre(c, "▦ arreglo de " + p.nombre());
                    }
                    if (tipo[0] == 3) aviso("◯ Giradas alrededor del eje Z que pasa por el punto 0,0");
                    vista.encuadrar();
                    recalcular();
                    aviso("✔ " + n + " en total");
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- 🧱 Casa: cantidad de faroles sin dibujarlos uno por uno ----------------

    private void faroles() {
        Pieza p = piezaPrincipal();
        if (p == null || p.contorno == null) { aviso("Primero haga el levantamiento (boceto → ✓ Listo)"); return; }
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        l.addView(etiqueta("Grueso del muro (mm)"));
        EditText gr = campoTexto("120", "");
        l.addView(gr);
        l.addView(etiqueta("Farol: largo × alto (mm)"));
        EditText fl = campoTexto("300", ""), fa = campoTexto("200", "");
        l.addView(fl); l.addView(fa);
        l.addView(etiqueta("Junta de pega (mm)"));
        EditText ju = campoTexto("10", "");
        l.addView(ju);
        l.addView(etiqueta("Desperdicio (%)"));
        EditText de = campoTexto("5", "");
        l.addView(de);
        l.addView(etiqueta("Puertas y ventanas: ancho x alto en mm, separadas por coma (ej. 900x2100, 1200x1000)"));
        EditText hu = campoTexto("", "900x2100, 1200x1000");
        l.addView(hu);
        new AlertDialog.Builder(this).setTitle("🧱 Cantidad de faroles").setView(l)
                .setPositiveButton("Calcular", (d, w) -> {
                    Double g = valorDe(Teclado.tx(gr)), L = valorDe(Teclado.tx(fl)), A = valorDe(Teclado.tx(fa)),
                            J = valorDe(Teclado.tx(ju)), D = valorDe(Teclado.tx(de));
                    if (g == null || L == null || A == null || g <= 0 || L <= 0 || A <= 0) { aviso("Revise las medidas"); return; }
                    double j = J == null ? 0 : J, des = D == null ? 0 : D;
                    double areaPlanta = Math.abs(Vista3D.area(p.contorno));
                    for (float[][] ag : p.agujeros) areaPlanta -= Math.abs(Vista3D.area(ag));
                    double largoMuros = areaPlanta / g;            // largo de muro por el centro
                    double alto = p.largo;
                    double huecos = 0;
                    int nh = 0;
                    for (String par : Teclado.tx(hu).split("[,;]")) {
                        String[] xy = par.trim().toLowerCase().split("[x×*]");
                        if (xy.length != 2) continue;
                        Double an = valorDe(xy[0].trim()), al = valorDe(xy[1].trim());
                        if (an != null && al != null && an > 0 && al > 0) { huecos += an * al; nh++; }
                    }
                    double areaMuro = largoMuros * alto - huecos;
                    double unidad = (L + j) * (A + j);
                    double n = areaMuro / unidad;
                    double total = Math.ceil(n * (1 + des / 100));
                    String m = "Largo de muros (por el centro): " + String.format(Locale.US, "%.2f", largoMuros / 1000) + " m\n"
                            + "Alto: " + String.format(Locale.US, "%.2f", alto / 1000) + " m\n"
                            + "Huecos de puertas y ventanas: " + nh + " (" + String.format(Locale.US, "%.2f", huecos / 1e6) + " m²)\n"
                            + "Muro neto: " + String.format(Locale.US, "%.2f", areaMuro / 1e6) + " m²\n\n"
                            + "Faroles: " + Math.round(Math.ceil(n)) + " + " + Pieza.n((float) des) + " % = " + Math.round(total) + " faroles";
                    new AlertDialog.Builder(this).setTitle("🧱 " + nombreProyecto).setMessage(m)
                            .setPositiveButton("Listo", null)
                            .setNeutralButton("📤 Enviar", (d2, w2) -> compartirTexto("🧱 " + nombreProyecto + "\n" + m)).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** ☰ → Pieza nueva desde DXF: se crea la pieza y el DXF queda como su boceto. */
    private boolean dxfNuevo;

    // ---------------- 🔩 Perforar tocando la cara ----------------

    private void perforar() {
        mostrar(1);
        panel("🔩 Perforar: toque la cara donde va el hueco");
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            Pieza p = porId(pieza);
            if (p == null || tipo == 9) return;
            boolean placa = p.tipo == Pieza.PLACA;
            if (placa && tipo != 5 && tipo != 6) { aviso("En una placa, toque la cara de encima o la de abajo"); return; }
            if (!placa && (tipo == 5 || tipo == 6)) { aviso("Toque una cara a lo largo del tubo, no la punta"); return; }
            Map<Integer, Pieza> m = mapaPiezas();
            float[] s0 = p.inicio(m, 0), d = p.direccion();
            float[][] e = Vista3D.ejes(p);
            vista.pideCara = null;
            vista.resA = pieza; vista.resNrmA = nrm; vista.resPtoA = vista.caraP0;
            vista.invalidate();
            if (placa) {
                float[] org = tipo == 5 ? new float[]{s0[0] + d[0] * p.largo, s0[1] + d[1] * p.largo, s0[2] + d[2] * p.largo} : s0;
                panelPerforar(p, -1, 0, r5(punto3(menos(q, org), e[1])), r5(punto3(menos(q, org), e[2])));
            } else {
                float ks = punto3(nrm, e[1]), ku = punto3(nrm, e[2]);
                int cara = Math.abs(ku) >= Math.abs(ks) ? (ku > 0 ? 0 : 1) : (ks > 0 ? 2 : 3);
                panelPerforar(p, cara, Math.max(0, Math.min(p.largo, r5(punto3(menos(q, s0), d)))), 0, 0);
            }
        };
    }

    private void panelPerforar(Pieza p, int cara, float pos, float s, float u) {
        boolean placa = cara < 0;
        panel("🔩 Perforar " + p.nombre() + (placa ? "" : " · cara " + Pieza.CARAS[cara].toLowerCase()));
        final int[] tipo = {0};
        final boolean[] pasante = {true};
        LinearLayout f0 = filaPanel();
        List<TextView> bt = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            final int k = i;
            TextView t = boton(Pieza.HUECOS[i], i == 0 ? 0xFFFF8F00 : 0xFF455A64, null);
            t.setTextSize(12);
            t.setOnClickListener(x -> { tipo[0] = k; for (int j = 0; j < bt.size(); j++) colorear(bt.get(j), j == k ? 0xFFFF8F00 : 0xFF455A64); });
            bt.add(t);
            f0.addView(t, peso());
        }
        LinearLayout f1 = filaPanel();
        EditText d1 = campoPanel(f1, "Ø / largo", "10");
        EditText d2 = campoPanel(f1, "Ancho ranura", "8");
        LinearLayout f2 = filaPanel();
        EditText ps = placa ? campoPanel(f2, "X", Pieza.n(s)) : campoPanel(f2, "Desde la punta", Pieza.n(pos));
        EditText pu = placa ? campoPanel(f2, "Y", Pieza.n(u)) : null;
        LinearLayout f3 = filaPanel();
        EditText cuantos = campoPanel(f3, "Cuántos", "1");
        EditText cada = campoPanel(f3, "Cada (mm)", "80");
        LinearLayout f4 = filaPanel();
        if (!placa) {
            TextView tp = boton("Pasante ✓", 0xFF00897B, null);
            tp.setOnClickListener(x -> { pasante[0] = !pasante[0]; tp.setText(pasante[0] ? "Pasante ✓" : "Solo esta cara"); colorear(tp, pasante[0] ? 0xFF00897B : 0xFF455A64); });
            f4.addView(tp, peso());
        }
        f4.addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        f4.addView(boton("✓ Perforar", 0xFF2E7D32, () -> {
            Double v1 = valorDe(Teclado.tx(d1)), v2 = valorDe(Teclado.tx(d2));
            Double vp = valorDe(Teclado.tx(ps)), vu = pu == null ? Double.valueOf(0) : valorDe(Teclado.tx(pu));
            Double vn = valorDe(Teclado.tx(cuantos)), vc = valorDe(Teclado.tx(cada));
            if (v1 == null || v1 <= 0 || vp == null || vu == null || vn == null || vc == null) { aviso("Revise las medidas"); return; }
            int n = Math.max(1, Math.min(200, (int) Math.round(vn)));
            antes();
            for (int i = 0; i < n; i++) {
                Pieza.Hueco h = new Pieza.Hueco();
                h.tipo = tipo[0];
                h.d1 = v1.floatValue();
                h.d2 = v2 == null ? 8 : v2.floatValue();
                if (placa) { h.s = (float) (vp + i * vc); h.u = vu.floatValue(); }
                else { h.cara = cara; h.pos = (float) (vp + i * vc); h.pasante = pasante[0]; }
                p.huecos.add(h);
            }
            cerrarPanel();
            recalcular();
            aviso("✔ " + n + (n == 1 ? " hueco" : " huecos") + " en " + p.nombre());
        }), peso());
    }

    // ---------------- ✂ Cortar ----------------

    private void cortar3D() {
        mostrar(1);
        new AlertDialog.Builder(this).setTitle("✂ Cortar")
                .setItems(new String[]{"◸ Inglete entre dos tubos (esquina)", "▮ Tope: un tubo llega recto a la cara de otro",
                        "∠ Punta a un ángulo (la pieza escogida)", "📏 Cambiar el largo (la pieza escogida)", "↺ Quitar los cortes inclinados (la escogida)"}, (d, w) -> {
                    if (w == 0) inglete();
                    else if (w == 1) tope();
                    else {
                        Pieza p = porId(escogida);
                        if (p == null) { aviso("Toque primero una pieza"); return; }
                        if (w == 2) cortarAngulo(p);
                        else if (w == 3) {
                            EditText e = campoTexto(p.f.containsKey("largo") ? p.f.get("largo") : Pieza.n(p.largo), "mm o fórmula");
                            dialogo("📏 Largo de " + p.nombre() + " (por el eje)", e, "Cambiar", () -> { antes(); leerCampo(p, "largo", Teclado.tx(e)); recalcular(); });
                        } else { antes(); p.corteIni = p.corteFin = 0; recalcular(); }
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Mueve el inicio de la pieza delta mm hacia adentro (el final queda quieto). */
    private void moverInicio(Pieza a, float delta) {
        if (a.padre >= 0) { a.sep += delta; a.f.remove("sep"); }
        else {
            float[] d = a.direccion();
            a.cx += d[0] * delta; a.cy += d[1] * delta; a.cz += d[2] * delta;
            for (String k : new String[]{"cx", "cy", "cz"}) a.f.remove(k);
        }
        a.largo -= delta;
        a.f.remove("largo");
    }

    private void inglete() {
        panel("◸ Inglete: toque el primer tubo de la esquina");
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        final int[] primero = {-1};
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (primero[0] < 0) {
                primero[0] = pieza;
                vista.resA = pieza; vista.resNrmA = nrm; vista.resPtoA = vista.caraP0;
                vista.invalidate();
                panelTitulo.setText("◸ Inglete: ahora toque el otro tubo de la esquina");
                return;
            }
            if (pieza == primero[0]) return;
            Pieza a = porId(primero[0]), b = porId(pieza);
            if (a == null || b == null) return;
            String err = hacerInglete(a, b);
            cerrarPanel();
            if (err != null) aviso(err); else { recalcular(); aviso("✔ Inglete hecho en " + a.nombre() + " y " + b.nombre()); }
        };
    }

    private String hacerInglete(Pieza a, Pieza b) {
        Map<Integer, Pieza> m = mapaPiezas();
        float[] sa = a.inicio(m, 0), da = a.direccion(), sb = b.inicio(m, 0), db = b.direccion();
        // puntos más cercanos de los dos ejes
        float[] w0 = menos(sa, sb);
        float aa = punto3(da, da), bb = punto3(da, db), cc = punto3(db, db), dd = punto3(da, w0), ee = punto3(db, w0);
        float den = aa * cc - bb * bb;
        if (Math.abs(den) < 1e-4f) return "Esos dos tubos van paralelos: no hacen esquina";
        float ta = (bb * ee - cc * dd) / den, tb = (aa * ee - bb * dd) / den;
        float[] ca = {sa[0] + da[0] * ta, sa[1] + da[1] * ta, sa[2] + da[2] * ta}, cb = {sb[0] + db[0] * tb, sb[1] + db[1] * tb, sb[2] + db[2] * tb};
        float sepEjes = (float) Math.sqrt(punto3(menos(ca, cb), menos(ca, cb)));
        if (sepEjes > Math.max(Math.max(a.a, a.b), Math.max(b.a, b.b))) return "Esos tubos no se juntan en una esquina (están separados " + Pieza.n(sepEjes) + " mm)";
        antes();
        boolean finA = ta > a.largo / 2, finB = tb > b.largo / 2;
        // hacia dónde sigue cada tubo desde la esquina
        float[] va = finA ? new float[]{-da[0], -da[1], -da[2]} : da, vb = finB ? new float[]{-db[0], -db[1], -db[2]} : db;
        float th = (float) Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, punto3(va, vb)))));
        float phi = (180 - th) / 2;
        if (b.padre == a.id && b.cara == 5) { b.cara = 0; b.en1 = b.en2 = 0; }
        if (a.padre == b.id && a.cara == 5) { a.cara = 0; a.en1 = a.en2 = 0; }
        ponerInglete(a, finA, ta, vb, phi);
        ponerInglete(b, finB, tb, va, phi);
        return null;
    }

    private void ponerInglete(Pieza p, boolean fin, float t, float[] otro, float phi) {
        float[][] e = Vista3D.ejes(p);
        float ds = punto3(otro, e[1]), du = punto3(otro, e[2]);
        float l = (float) Math.hypot(ds, du);
        if (l < 1e-4f) { ds = 1; du = 0; } else { ds /= l; du /= l; }
        if (fin) { p.largo = t; p.f.remove("largo"); p.corteFin = phi; p.cfS = ds; p.cfU = du; }
        else { moverInicio(p, t); p.corteIni = phi; p.ciS = ds; p.ciU = du; }
    }

    private void tope() {
        panel("▮ Tope: toque el tubo que se va a cortar");
        filaPanel().addView(boton("Cancelar", 0xFF455A64, this::cerrarPanel), peso());
        final int[] primero = {-1};
        vista.pideCara = (pieza, tipo, nrm, q) -> {
            if (primero[0] < 0) {
                primero[0] = pieza;
                vista.resA = pieza; vista.resNrmA = nrm; vista.resPtoA = vista.caraP0;
                vista.invalidate();
                panelTitulo.setText("▮ Tope: ahora toque la cara contra la que llega");
                return;
            }
            if (pieza == primero[0]) return;
            Pieza a = porId(primero[0]);
            if (a == null) return;
            Map<Integer, Pieza> m = mapaPiezas();
            float[] sa = a.inicio(m, 0), da = a.direccion();
            float k = punto3(da, nrm);
            cerrarPanel();
            if (Math.abs(k) < 0.1f) { aviso("Ese tubo no llega de frente a esa cara"); return; }
            float t = punto3(menos(q, sa), nrm) / k;
            antes();
            if (t > a.largo / 2) { if (t <= 1) { revertir(); return; } a.largo = t; a.f.remove("largo"); a.corteFin = 0; }
            else { if (a.largo - t <= 1) { revertir(); return; } moverInicio(a, t); a.corteIni = 0; }
            recalcular();
            aviso("✔ " + a.nombre() + " llega recto a la cara · largo " + Pieza.n(a.largo) + " mm");
        };
    }

    private void cortarAngulo(Pieza p) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] punta = {1}, hacia = {0};
        l.addView(etiqueta("Qué punta"));
        grupoBotones(l, new String[]{"Inicio", "Final"}, punta, 2, null);
        l.addView(etiqueta("El corte se inclina hacia"));
        grupoBotones(l, new String[]{"Lo ancho", "Lo alto"}, hacia, 2, null);
        l.addView(etiqueta("Grados (0 = recto; negativo = al otro lado)"));
        EditText g = campoTexto(Pieza.n(punta[0] == 1 ? p.corteFin : p.corteIni), "");
        l.addView(g);
        new AlertDialog.Builder(this).setTitle("∠ Cortar la punta de " + p.nombre()).setView(l)
                .setPositiveButton("Cortar", (d, w) -> {
                    Double v = valorDe(Teclado.tx(g));
                    if (v == null || Math.abs(v) > 75) { aviso("Entre −75° y 75°"); return; }
                    antes();
                    float ds = hacia[0] == 0 ? 1 : 0, du = hacia[0] == 0 ? 0 : 1;
                    if (punta[0] == 1) { p.corteFin = v.floatValue(); p.cfS = ds; p.cfU = du; }
                    else { p.corteIni = v.floatValue(); p.ciS = ds; p.ciU = du; }
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- ⬆ Extruir el boceto ----------------

    private void extruir() {
        if (boceto.b.vacio()) { aviso("Primero dibuje una figura cerrada (rectángulo, polígono, círculo…)"); return; }
        VistaBoceto.Pedido p = pedido("Extruir", t -> {
            Editar2D.Figura f = Editar2D.figuraEn(boceto.b, t.get(0).x, t.get(0).y);
            if (f == null) { aviso("Toque adentro de una figura cerrada"); return; }
            dialogoExtruir(hoja, f, false);
        }, "Extruir: toque adentro de la figura cerrada (lo que tenga adentro queda como hueco)");
        p.linea = false;
        p.crudo = true;
        boceto.pedir(p);
    }

    private static float[][] aPlaca(double[][] pol) {
        // en la placa acostada: s va hacia −X y u hacia Y (así queda igual que en el boceto)
        float[][] r = new float[pol.length][2];
        for (int i = 0; i < pol.length; i++) { r[i][0] = (float) -pol[i][0]; r[i][1] = (float) pol[i][1]; }
        return r;
    }

    private List<Pieza> placas() {
        List<Pieza> l = new ArrayList<>();
        for (Pieza x : piezas) if (x.tipo == Pieza.PLACA) l.add(x);
        return l;
    }

    private void dialogoExtruir(Hoja h, Editar2D.Figura f, boolean lam) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        l.addView(etiqueta("Nombre de la pieza"));
        int nl = 0;
        for (Pieza x : piezas) if (x.lamina) nl++;
        String nomDef = !esMontaje() && placas().isEmpty() ? nombreProyecto : lam ? "Lámina " + (nl + 1) : "Pieza " + (placas().size() - nl + 1);
        EditText nom = campoTexto(nomDef, "");
        l.addView(nom);
        final int[] modo = {0}, lado = {0}, cal = {3};
        EditText g = campoTexto(CASA.equals(modo) ? "2500" : "1000", "");
        if (lam) {
            l.addView(etiqueta("Calibre"));
            grupoBotones(l, Lamina.CALIBRES, cal, 3, null);
        } else {
            l.addView(etiqueta(CASA.equals(modo) ? "Altura de las paredes (mm o fórmula)" : "Largo de la extrusión (mm o fórmula)"));
            l.addView(g);
        }
        List<Pieza> ps = lam ? new ArrayList<>() : placasDe(h);
        Pieza sobre = lam ? null : porId(h.pieza);
        final int[] maq = {0};
        EditText hondo = campoTexto("10", "");
        if (sobre != null) {
            // versión 4.5: el boceto está sobre una pieza → maquinar
            modo[0] = 2;
            l.addView(etiqueta("Qué hacer"));
            final int[] sel = {pedirElevacion ? 0 : 1};
            if (pedirElevacion) modo[0] = 0;
            pedirElevacion = false;
            grupoBotones(l, new String[]{"⬆ Elevación (pieza nueva)", "✂ Perforar / cortar en " + sobre.nombre()}, sel, 2, () -> modo[0] = sel[0] == 1 ? 2 : 0);
            l.addView(etiqueta("Cómo se corta"));
            grupoBotones(l, new String[]{"Pasante", "Solo esta cara", "Hondo (mm)"}, maq, 3, null);
            l.addView(etiqueta("Hondo en mm (si escogió Hondo)"));
            l.addView(hondo);
        } else if (!ps.isEmpty()) {
            l.addView(etiqueta("Qué hacer"));
            grupoBotones(l, new String[]{"➕ Pieza nueva", "➖ Cortar en una pieza"}, modo, 2, null);
        }
        l.addView(etiqueta("Hacia dónde sale del plano"));
        grupoBotones(l, new String[]{"⬆ Para arriba", "⬇ Para abajo"}, lado, 2, null);
        l.addView(etiqueta("Figura con " + f.huecos.size() + (f.huecos.size() == 1 ? " hueco" : " huecos") + " adentro · " + h.nombre + " · " + h.plano));
        new AlertDialog.Builder(this).setTitle(lam ? "📐 Lámina" : "⬆ Extruir").setView(l)
                .setPositiveButton("✓ Listo", (d, w) -> {
                    vista.hojaResaltada = -1;
                    if (modo[0] == 1) { cortarEnPlaca(f, ps); return; }
                    if (modo[0] == 2 && sobre != null) {
                        Double vh = valorDe(Teclado.tx(hondo));
                        maquinar(h, f, sobre, maq[0], vh == null ? 0 : (float) (double) vh);
                        return;
                    }
                    antes();
                    Pieza p = new Pieza();
                    p.id = nuevoId();
                    p.tipo = Pieza.PLACA;
                    p.titulo = Teclado.tx(nom).trim();
                    p.medida = "";
                    p.calibre = "";
                    p.dir = 2;
                    p.hoja = h.id;
                    float[] n = h.normal();
                    p.marco = new float[]{h.o[0], h.o[1], h.o[2], h.ex[0], h.ex[1], h.ex[2], h.ey[0], h.ey[1], h.ey[2], n[0], n[1], n[2]};
                    p.contorno = aF(f.pol);
                    p.entsContorno = new ArrayList<>(f.borde);
                    for (int i = 0; i < f.huecos.size(); i++) { p.agujeros.add(aF(f.polHuecos.get(i))); p.entsAgujeros.add(new ArrayList<>(f.huecos.get(i))); }
                    p.largo = 6;
                    if (lam) {
                        p.lamina = true;
                        p.cal = Lamina.CALIBRES[cal[0]];
                        p.largo = Lamina.GRUESOS[cal[0]];
                    } else leerCampo(p, "largo", Teclado.tx(g));
                    if (p.largo <= 0) p.largo = 6;
                    p.alReves = lado[0] == 1;
                    piezas.add(p);
                    escogida = p.id;
                    boceto.ponerModo(VistaBoceto.VER);
                    herrActiva = "Ver";
                    mostrar(1);
                    vista.encuadrar();
                    recalcular();
                    guardarDoc(true);
                    aviso(lam ? "✔ " + p.nombre() + " (" + p.cal + "). Ahora toque ↪ Doblez para doblarla"
                            : "✔ " + p.nombre() + ": " + Pieza.n(p.largo) + " mm. Si cambia las cotas de " + h.nombre + ", la pieza cambia también");
                }).setNegativeButton("Cancelar", (d, w) -> { vista.hojaResaltada = -1; vista.invalidate(); }).show();
    }

    private static float[][] aF(double[][] pol) {
        float[][] r = new float[pol.length][2];
        for (int i = 0; i < pol.length; i++) { r[i][0] = (float) pol[i][0]; r[i][1] = (float) pol[i][1]; }
        return r;
    }

    /** La forma tal como se guarda en esa placa (las viejas, acostadas, van al revés en X). */
    private static float[][] enPlaca(Pieza p, double[][] pol) { return p.marco != null ? aF(pol) : aPlaca(pol); }

    private void cortarEnPlaca(Editar2D.Figura f, List<Pieza> ps) {
        String[] nom = new String[ps.size()];
        for (int i = 0; i < nom.length; i++) nom[i] = ps.get(i).nombre() + " · " + ps.get(i).referencia();
        new AlertDialog.Builder(this).setTitle("➖ Cortar en qué pieza")
                .setItems(nom, (d, w) -> {
                    antes();
                    Pieza p = ps.get(w);
                    p.agujeros.add(enPlaca(p, f.pol));
                    p.entsAgujeros.add(new ArrayList<>(f.borde));
                    mostrar(1);
                    recalcular();
                    aviso("✔ Se cortó esa figura en " + p.nombre());
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Las piezas siguen a su boceto: si cambian las cotas, cambia su forma. */
    private void actualizarPlacas() {
        for (Pieza p : piezas) {
            if (p.tipo != Pieza.PLACA || p.entsContorno.isEmpty()) continue;
            Hoja h = porHoja(p.hoja);
            if (h == null) continue;
            double[][] pol = Editar2D.poligono(h.b, p.entsContorno);
            if (pol == null || pol.length < 3) continue;
            p.contorno = enPlaca(p, pol);
            p.agujeros.clear();
            for (List<Integer> hu : p.entsAgujeros) {
                double[][] ph = Editar2D.poligono(h.b, hu);
                if (ph != null && ph.length >= 3) p.agujeros.add(enPlaca(p, ph));
            }
        }
    }

    // ---------------- Versión 4.3: bocetos, montaje y árbol ----------------

    private Hoja porHoja(int id) {
        for (Hoja h : hojas) if (h.id == id) return h;
        return null;
    }

    private List<Pieza> placasDe(Hoja h) {
        List<Pieza> l = new ArrayList<>();
        if (h != null) for (Pieza x : piezas) if (x.tipo == Pieza.PLACA && x.hoja == h.id) l.add(x);
        return l;
    }

    private String usadoEn(Hoja h) {
        StringBuilder sb = new StringBuilder();
        for (Pieza p : placasDe(h)) sb.append(sb.length() == 0 ? "" : ", ").append(p.nombre());
        return sb.length() == 0 ? "" : " · usado en " + sb;
    }

    private int figurasDe(Hoja h) {
        try { return Editar2D.figuras(h.b, new ArrayList<>()).size(); } catch (Exception e) { return 0; }
    }

    /** v6.3: el desarrollo es solo un plano para cortar: no se extruye. */
    private boolean esDesarrollo(Hoja h) { return h != null && "plano para cortar".equals(h.plano); }

    /** v6.3: Terminar solo cuando el boceto todavía no es pieza; si ya es pieza (o es el desarrollo) el botón dice 🟩 Pieza. */
    private void ponerBotonTerminar() {
        if (btnTerminar == null) return;
        btnTerminar.setText("✓\nListo");
    }

    private void pintarCabeza() {
        ponerBotonTerminar();
        if (cabeza2D == null || hoja == null) return;
        String estado;
        int nf = figurasDe(hoja);
        if (hoja.b.vacio()) estado = "Dibuje una figura cerrada";
        else if (boceto.libres == null) estado = nf + (nf == 1 ? " figura cerrada" : " figuras cerradas");
        else if (hoja.b.gradosLibres == 0) estado = "✔ Completo (todo negro) · " + nf + (nf == 1 ? " figura cerrada" : " figuras cerradas");
        else estado = "🔵 Faltan " + hoja.b.gradosLibres + " medidas o amarres (lo azul) · " + nf + (nf == 1 ? " figura cerrada" : " figuras cerradas");
        cabeza2D.setText(VERSION + " · " + etiquetaModo() + "\n✏ " + hoja.nombre + " · " + hoja.plano + usadoEn(hoja) + "  ▼\n" + estado);
    }

    private void menuBocetos() {
        List<String> op = new ArrayList<>();
        for (Hoja h : hojas) op.add((h == hoja ? "▶ " : "✏ ") + h.nombre + " · " + h.plano + usadoEn(h));
        op.add("➕ Boceto nuevo");
        op.add("✎ Cambiar el nombre de " + hoja.nombre);
        new AlertDialog.Builder(this).setTitle("Bocetos").setItems(op.toArray(new String[0]), (d, w) -> {
            if (w < hojas.size()) abrirHoja(hojas.get(w));
            else if (w == hojas.size()) nuevoBoceto();
            else {
                EditText t = campoTexto(hoja.nombre, "");
                new AlertDialog.Builder(this).setTitle("Nombre del boceto").setView(t)
                        .setPositiveButton("Guardar", (d2, w2) -> { antes(); hoja.nombre = Teclado.tx(t).trim().isEmpty() ? hoja.nombre : Teclado.tx(t).trim(); recalcular(); })
                        .setNegativeButton("Cancelar", null).show();
            }
        }).show();
    }

    /** Abrir un boceto: se pasa al 2D con ese boceto. */
    private void abrirHoja(Hoja h) {
        if (h == null) return;
        if (boceto.modo != VistaBoceto.VER) listo2D();
        hoja = h;
        boceto.b = h.b;
        boceto.anclarAuto = h.pieza < 0;
        boceto.limpiarSeleccion();
        grupo2D(esDesarrollo(h) ? G_DIBUJAR : grupo2D);
        mostrar(0);
        boceto.post(boceto::encuadrar);
        recalcular();
    }

    private int nuevoIdHoja() {
        int m = 0;
        for (Hoja h : hojas) m = Math.max(m, h.id);
        return m + 1;
    }

    /** ✏ Boceto nuevo: en el piso, el frente, el lado o sobre la cara de una pieza. */
    private void nuevoBoceto() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        final int[] plano = {0};
        l.addView(etiqueta("En qué plano"));
        grupoBotones(l, new String[]{"Piso (XY)", "Frente (XZ)", "Lado (YZ)", "🧱 Cara de una pieza", "▱ Plano de referencia"}, plano, 2, null);
        l.addView(etiqueta("Corrido desde el punto 0 (mm), hacia afuera del plano"));
        EditText cor = campoTexto("0", "");
        l.addView(cor);
        new AlertDialog.Builder(this).setTitle("✏ Boceto nuevo").setView(l)
                .setPositiveButton("Crear", (d, w) -> {
                    if (plano[0] == 4) {
                        escogerPlano("✏ ¿Sobre qué plano?", r -> {
                            antes();
                            Hoja h = new Hoja();
                            h.id = nuevoIdHoja();
                            h.nombre = "Boceto " + h.id;
                            h.plano = "Sobre " + r.nombre;
                            h.o = r.o.clone();
                            h.ex = r.ex.clone();
                            h.ey = r.ey();
                            hojas.add(h);
                            abrirHoja(h);
                            aviso("✏ " + h.nombre + " sobre " + r.nombre + ". El 0,0 es el centro del plano");
                        });
                        return;
                    }
                    if (plano[0] == 3) {
                        mostrar(1);
                        aviso("Toque la cara de la pieza donde va el boceto");
                        vista.pideCara = (pieza, tipo, nrm, q) -> {
                            vista.pideCara = null;
                            Pieza pz = porId(pieza);
                            Hoja h = new Hoja();
                            h.id = nuevoIdHoja();
                            h.nombre = "Boceto " + h.id;
                            h.plano = "Cara de " + (pz == null ? "pieza" : pz.nombre());
                            float[] n = {nrm[0], nrm[1], nrm[2]};
                            float[] ey = Math.abs(n[2]) < 0.9f ? new float[]{-n[0] * n[2], -n[1] * n[2], 1 - n[2] * n[2]} : new float[]{0, 1, 0};
                            float ly = (float) Math.sqrt(ey[0] * ey[0] + ey[1] * ey[1] + ey[2] * ey[2]);
                            ey = new float[]{ey[0] / ly, ey[1] / ly, ey[2] / ly};
                            h.ey = ey;
                            h.ex = new float[]{ey[1] * n[2] - ey[2] * n[1], ey[2] * n[0] - ey[0] * n[2], ey[0] * n[1] - ey[1] * n[0]};
                            h.o = new float[]{Math.round(q[0]), Math.round(q[1]), Math.round(q[2])};
                            if (pz != null) { h.pieza = pz.id; h.rel = relativo(pz, h); }
                            antes();
                            hojas.add(h);
                            abrirHoja(h);
                            aviso("✏ " + h.nombre + " sobre " + h.plano + ". El 0,0 quedó donde tocó");
                        };
                        return;
                    }
                    antes();
                    Hoja h = Hoja.nueva(nuevoIdHoja(), plano[0]);
                    Double c = valorDe(Teclado.tx(cor));
                    if (c != null && c != 0) {
                        float[] n = h.normal();
                        h.o = new float[]{(float) (n[0] * c), (float) (n[1] * c), (float) (n[2] * c)};
                        h.plano += " a " + Formula.n(c) + " mm";
                    }
                    hojas.add(h);
                    abrirHoja(h);
                }).setNegativeButton("Cancelar", null).show();
    }

    /** ✓ Listo boceto: se pasa al montaje para extruir. */
    private void terminarBoceto() {
        if (boceto.modo != VistaBoceto.VER) listo2D();
        if (esDesarrollo(hoja)) {   // v6.2.1: del desarrollo se vuelve a la pieza, sin hacer otra lámina
            vista.hojaResaltada = -1;
            mostrar(1);
            recalcular();
            aviso("🟩 De vuelta a la pieza. El desarrollo queda en el árbol para imprimirlo cuando quiera");
            return;
        }
        // versión 4.4: el doctor revisa si hay puntas abiertas
        List<Integer> sueltas = Editar2D.puntasSueltas(hoja.b);
        boceto.sueltas = sueltas.isEmpty() ? null : sueltas;
        boceto.invalidate();
        if (!sueltas.isEmpty()) {   // v6.6: no extruye; marca en rojo y el 🩺 Doctor lo arregla
            pintarOps();
            aviso("🩺 La figura está abierta (" + sueltas.size() + (sueltas.size() == 1 ? " punta roja" : " puntas rojas") + "). Toque 🩺 Doctor");
            return;
        }
        revisarParametrico();
    }

    /** v6.6: 🩺 Doctor: busca dónde está abierta la figura, líneas repetidas o encimadas, y las arregla o deja que usted las arregle. */
    private void doctor() {
        if (boceto.modo != VistaBoceto.VER) listo2D();
        Boceto bb = hoja.b;
        List<Integer> sueltas = Editar2D.puntasSueltas(bb);
        boceto.sueltas = sueltas.isEmpty() ? null : sueltas;
        // líneas repetidas: las dos puntas en el mismo sitio
        List<Boceto.Ent> repetidas = new ArrayList<>();
        List<Boceto.Ent> ls = new ArrayList<>();
        for (Boceto.Ent e : bb.ents) if (e.tipo == Boceto.LINEA && !e.punteada) ls.add(e);
        for (int i = 0; i < ls.size(); i++) for (int j = i + 1; j < ls.size(); j++) {
            Boceto.Punto a1 = bb.puntos.get(ls.get(i).a), b1 = bb.puntos.get(ls.get(i).b), a2 = bb.puntos.get(ls.get(j).a), b2 = bb.puntos.get(ls.get(j).b);
            if (a1 == null || b1 == null || a2 == null || b2 == null) continue;
            boolean igual = Math.hypot(a1.x - a2.x, a1.y - a2.y) < 0.5 && Math.hypot(b1.x - b2.x, b1.y - b2.y) < 0.5
                    || Math.hypot(a1.x - b2.x, a1.y - b2.y) < 0.5 && Math.hypot(b1.x - a2.x, b1.y - a2.y) < 0.5;
            if (igual && !repetidas.contains(ls.get(j))) repetidas.add(ls.get(j));
        }
        boceto.invalidate();
        pintarOps();
        if (sueltas.isEmpty() && repetidas.isEmpty()) {
            aviso(figurasDe(hoja) > 0 ? "🩺 Todo bien: la figura está cerrada. Toque ✓ Listo para extruir" : "🩺 No hay figuras cerradas todavía");
            return;
        }
        List<double[]> par = Editar2D.parejasSueltas(bb, sueltas);
        StringBuilder sb = new StringBuilder();
        if (!sueltas.isEmpty()) {
            sb.append("• ").append(sueltas.size()).append(sueltas.size() == 1 ? " punta suelta" : " puntas sueltas").append(" (en rojo en el dibujo y en la lista)");
            for (double[] q : par) sb.append("\n   abierta ").append(Formula.n(Math.round(q[2] * 10) / 10.0)).append(" mm");
        }
        if (!repetidas.isEmpty()) sb.append(sb.length() > 0 ? "\n" : "").append("• ").append(repetidas.size()).append(repetidas.size() == 1 ? " línea repetida (una encima de otra)" : " líneas repetidas");
        AlertDialog.Builder bd = new AlertDialog.Builder(this).setTitle("🩺 Doctor del boceto").setMessage(sb.toString())
                .setNegativeButton("✏ La arreglo yo", (d, w) -> aviso("Lo rojo es lo que falta. En la lista de abajo está marcado con ⚠"));
        if (!par.isEmpty() || !repetidas.isEmpty()) bd.setPositiveButton("🩺 Arreglarla sola", (d, w) -> {
            antes();
            for (Boceto.Ent e : repetidas) bb.borrar(e);
            for (double[] q : par) if (bb.puntos.get((int) q[0]) != null && bb.puntos.get((int) q[1]) != null) bb.unirPuntos((int) q[0], (int) q[1]);
            bb.limpiarPuntos();
            boceto.sueltas = null;
            recalcular();
            List<Integer> quedan = Editar2D.puntasSueltas(bb);
            boceto.sueltas = quedan.isEmpty() ? null : quedan;
            pintarOps();
            aviso(quedan.isEmpty() ? "🩺 Listo: la figura quedó cerrada. Toque ✓ Listo para extruir" : "🩺 Quedan puntas que no tienen pareja: termínelas o bórrelas");
        });
        bd.show();
    }

    private void irAlMontaje() {
        int nf = figurasDe(hoja);
        if (!esMontaje()) {
            if (nf == 0) { aviso("🩺 El boceto no tiene ninguna figura cerrada: ciérrela para poder extruir"); return; }
            if (placasDe(hoja).isEmpty()) {
                extruirDe(hoja, LAMINA.equals(modo) && hoja.pieza < 0);   // como Inventor: al terminar sale Extruir (o Cortar si está sobre una cara)
                return;
            }
            mostrar(1);
            vista.encuadrar();
            recalcular();
            guardarDoc(true);
            aviso("🏁 " + usadoEn(hoja).replace(" · usado en ", "") + " ya se actualizó y quedó guardada en la librería");
            return;
        }
        vista.hojaResaltada = nf > 0 ? hoja.id : -1;
        mostrar(1);
        vista.encuadrar();
        recalcular();
        if (nf == 0) aviso("🏁 " + hoja.nombre + " terminado, pero no tiene figuras cerradas para extruir");
        else if (!placasDe(hoja).isEmpty()) aviso("🏁 " + hoja.nombre + " terminado: " + usadoEn(hoja).replace(" · usado en ", "") + " ya se actualizó");
        else {
            final Hoja h = hoja;
            new AlertDialog.Builder(this).setTitle("🏁 " + h.nombre + " terminado").setMessage("¿Qué hacemos con la figura?")
                    .setPositiveButton("⬆ Extruir", (d, w) -> extruirDe(h, false))
                    .setNeutralButton("📐 Lámina", (d, w) -> extruirDe(h, true))
                    .setNegativeButton("Después", (d, w) -> aviso("Cuando quiera: en el árbol toque ✏ del boceto y luego ✓ Listo"))
                    .show();
        }
    }

    /** ⬆ Extruir en el montaje: se escoge el boceto y se toca la figura sombreada. */
    private void extruir3D(boolean lam) {
        List<Hoja> c = new ArrayList<>();
        if (hoja != null && figurasDe(hoja) > 0 && !esDesarrollo(hoja)) c.add(hoja);
        for (Hoja h : hojas) if (h != hoja && figurasDe(h) > 0 && !esDesarrollo(h)) c.add(h);
        if (c.isEmpty()) { aviso("Primero haga un boceto con una figura cerrada (✏ Boceto)"); return; }
        if (c.size() == 1) { extruirDe(c.get(0), lam); return; }
        String[] nom = new String[c.size()];
        for (int i = 0; i < nom.length; i++) nom[i] = c.get(i).nombre + " · " + c.get(i).plano + usadoEn(c.get(i));
        new AlertDialog.Builder(this).setTitle("⬆ Extruir: ¿de qué boceto?").setItems(nom, (d, w) -> extruirDe(c.get(w), lam)).show();
    }

    private void extruirDe(Hoja h, boolean lam) {
        List<double[][]> pols = new ArrayList<>();
        List<List<Integer>> ls = Editar2D.figuras(h.b, pols);
        if (ls.size() == 1 && pols.get(0) != null) {
            Editar2D.Figura f = new Editar2D.Figura();
            f.borde = ls.get(0);
            f.pol = pols.get(0);
            dialogoExtruir(h, f, lam);
            return;
        }
        mostrar(1);
        vista.hojaResaltada = h.id;
        vista.invalidate();
        aviso("Toque adentro de la figura sombreada " + (lam ? "que va a ser la lámina" : "que quiere extruir") + " (atrás = cancelar)");
        vista.pideToque = (x, y) -> {
            float[] w = vista.enPlano(x, y, h.o, h.normal());
            double[] q = h.local(w);
            Editar2D.Figura f = Editar2D.figuraEn(h.b, q[0], q[1]);
            if (f == null) { aviso("Ahí no hay figura cerrada de " + h.nombre + ". Toque adentro de lo sombreado"); return; }
            vista.pideToque = null;
            dialogoExtruir(h, f, lam);
        };
    }

    private void borrar3D() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere borrar (o use 🗑 en el árbol de abajo)"); return; }
        eliminar(p);
    }

    private void borrarHoja(Hoja h) {
        List<Pieza> us = placasDe(h);
        String msg = "¿Borrar " + h.nombre + "?" + (us.isEmpty() ? "" : "\n\nLas piezas " + usadoEn(h).replace(" · usado en ", "") + " se quedan con la forma que tienen, pero ya no se pueden cambiar desde el boceto.");
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("🗑 Borrar", (d, w) -> {
            antes();
            for (Pieza p : us) { p.entsContorno.clear(); p.entsAgujeros.clear(); p.hoja = -1; }
            hojas.remove(h);
            if (hojas.isEmpty()) hojas.add(Hoja.nueva(1, 0));
            if (hoja == h) { hoja = hojas.get(hojas.size() - 1); boceto.b = hoja.b; boceto.limpiarSeleccion(); }
            recalcular();
        }).setNegativeButton("Cancelar", null).show();
    }

    /** Una fila del árbol: el nombre y los botones 👁 ✏ 🗑. */
    private void filaArbol(String txt, int fondo, boolean escogido, boolean visible, Runnable tocar, Runnable ojo, Runnable lapiz, Runnable basura) {
        LinearLayout f = new LinearLayout(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(escogido ? Color.BLACK : visible ? Color.WHITE : 0xFF90A4AE);
        t.setTextSize(14);
        t.setPadding(dp(10), dp(7), dp(8), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(escogido ? 0xFFFFB300 : fondo);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(v -> tocar.run());
        f.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView[] bs = {boton(visible ? "👁" : "◌", 0xFF37474F, ojo), boton("✏", 0xFF1E88E5, lapiz), boton("🗑", 0xFFC62828, basura)};
        for (TextView b : bs) {
            b.setTextSize(15);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(42), -1);
            bp.leftMargin = dp(3);
            f.addView(b, bp);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        lista.addView(f, lp);
    }

    private boolean hayPegada(Pieza p) {
        for (String x : p.amarres) if (x.startsWith("🔗 pegada a")) return true;
        return false;
    }

    /** Una fila de amarre en el árbol: el texto y 🗑 para quitarlo. */
    private void filaAmarre(Pieza p, String t) {
        LinearLayout f = new LinearLayout(this);
        TextView tx = new TextView(this);
        tx.setText("   " + t);
        tx.setTextColor(0xFFB2DFDB);
        tx.setTextSize(13);
        tx.setPadding(dp(10), dp(5), dp(8), dp(5));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF16302C);
        g.setCornerRadius(dp(8));
        tx.setBackground(g);
        tx.setOnClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); });
        f.addView(tx, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView b = boton("🗑", 0xFFC62828, () -> {
            if (t.equals("📌 fija")) { antes(); p.fija = false; recalcular(); aviso("🔓 " + p.nombre() + " ya se puede mover"); }
            else quitarAmarre(p, t);
        });
        b.setTextSize(15);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(42), -1);
        bp.leftMargin = dp(3);
        f.addView(b, bp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(3);
        lista.addView(f, lp);
    }

    private void tituloArbol(String txt) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(0xFFB0BEC5);
        t.setTextSize(13);
        t.setPadding(dp(6), dp(8), dp(6), dp(2));
        lista.addView(t);
    }

    /** Editar una placa: grueso, sitio, borrar. */
    private void editarPlaca(Pieza p) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        l.addView(etiqueta("Nombre de la pieza"));
        EditText tn = campoTexto(p.nombre(), "");
        l.addView(tn);
        l.addView(etiqueta("Grueso (mm o fórmula)"));
        EditText g = campoTexto(p.f.containsKey("largo") ? p.f.get("largo") : Pieza.n(p.largo), "");
        l.addView(g);
        final int[] lado = {p.alReves ? 1 : 0};
        if (p.marco != null) {
            l.addView(etiqueta("Hacia dónde sale del plano"));
            grupoBotones(l, new String[]{"⬆ Para arriba", "⬇ Para abajo"}, lado, 2, null);
        }
        l.addView(etiqueta("Corrida en X, Y, Z (mm)"));
        EditText x = campoTexto(Pieza.n(p.cx), ""), y = campoTexto(Pieza.n(p.cy), ""), z = campoTexto(Pieza.n(p.cz), "");
        l.addView(x); l.addView(y); l.addView(z);
        l.addView(etiqueta(p.huecos.size() + " huecos perforados · " + p.agujeros.size() + " huecos del boceto"));
        new AlertDialog.Builder(this).setTitle("✏ " + p.nombre() + " (placa)").setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    antes();
                    String tt = Teclado.tx(tn).trim();
                    if (!tt.equals(p.nombre())) p.titulo = tt;
                    p.alReves = lado[0] == 1;
                    leerCampo(p, "largo", Teclado.tx(g));
                    leerCampo(p, "cx", Teclado.tx(x));
                    leerCampo(p, "cy", Teclado.tx(y));
                    leerCampo(p, "cz", Teclado.tx(z));
                    recalcular();
                })
                .setNeutralButton(porHoja(p.hoja) != null ? "✏ Su boceto" : "🗑 Eliminar", (d, w) -> { Hoja h = porHoja(p.hoja); if (h != null) abrirHoja(h); else eliminar(p); })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Versión 3: en una sola ventana: el punto, la cara donde se pega y la separación, con un dibujito de muestra. */
    private void dialogoAmarre(Pieza p, Pieza padre) {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), dp(4));
        sv.addView(l);
        final int[] punto = {p.padre == padre.id ? p.punto : 1};
        final int[] cara = {p.padre == padre.id ? p.cara : 0};
        View[] muestra = new View[1];
        l.addView(etiqueta("1. En qué punto de " + padre.nombre()));
        grupoBotones(l, new String[]{"Inicio", "Final", "A medida"}, punto, 3, () -> muestra[0].invalidate());
        EditText am = campoTexto(p.padre == padre.id ? (p.f.containsKey("aMm") ? p.f.get("aMm") : Pieza.n(p.aMm)) : "0", "");
        l.addView(etiqueta("Medida desde el inicio (mm o fórmula), si escogió «A medida»"));
        l.addView(am);
        l.addView(etiqueta("2. En qué cara de " + padre.nombre() + " se pega"));
        grupoBotones(l, new String[]{"Arriba", "Abajo", "Punta", "Izquierda", "Derecha", "Centrado"}, cara, 3, () -> muestra[0].invalidate());
        l.addView(etiqueta("3. Separación (luz libre, mm o fórmula)"));
        EditText se = campoTexto(p.padre == padre.id ? (p.f.containsKey("sep") ? p.f.get("sep") : Pieza.n(p.sep)) : "0", "");
        l.addView(se);
        muestra[0] = new View(this) {
            private final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight();
                c.drawColor(0xFF0D1117);
                float y0 = h * 0.55f, alto = h * 0.2f, x0 = w * 0.08f, x1 = w * 0.92f;
                pp.setColor(0xFF26A69A);
                c.drawRect(x0, y0, x1, y0 + alto, pp);
                pp.setTextSize(dp(12));
                pp.setColor(Color.WHITE);
                c.drawText(padre.nombre(), (x0 + x1) / 2 - dp(8), y0 + alto / 2 + dp(4), pp);
                int k = cara[0];
                float cw = alto * 0.9f, ch = h * 0.34f;
                float px = punto[0] == 0 ? x0 : punto[0] == 1 ? x1 : (x0 + x1) / 2;
                float cx = px - cw / 2, cy;
                String nota = "";
                switch (k) {
                    case 1: cy = y0 - ch; break;
                    case 2: cy = y0 + alto; break;
                    case 3: cy = y0 + alto / 2 - ch / 2; nota = " (al lado izquierdo)"; break;
                    case 4: cy = y0 + alto / 2 - ch / 2; nota = " (al lado derecho)"; break;
                    case 5: cy = y0 + alto / 2 - ch / 2; cx = punto[0] == 0 ? x0 - cw : x1; break;
                    default: cy = y0 + alto / 2 - ch / 2; nota = " (en el eje)";
                }
                pp.setColor(k == 3 || k == 4 ? 0x99FFB300 : 0xFFFFB300);
                c.drawRect(cx, cy, cx + cw, cy + ch, pp);
                pp.setColor(Color.WHITE);
                c.drawText(p.nombre() + " " + Pieza.CARAS_UNION[k].toLowerCase() + nota, dp(6), dp(16), pp);
            }
        };
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(110));
        mp.topMargin = dp(8);
        l.addView(muestra[0], mp);
        new AlertDialog.Builder(this).setTitle("🔗 Amarrar " + p.nombre() + " a " + padre.nombre()).setView(sv)
                .setPositiveButton("Amarrar", (d2, w2) -> {
                    antes();
                    p.padre = padre.id;
                    p.punto = punto[0];
                    p.cara = cara[0];
                    p.cx = p.cy = p.cz = 0;
                    p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                    leerCampo(p, "aMm", Teclado.tx(am));
                    leerCampo(p, "sep", Teclado.tx(se));
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Botones para escoger una opción (la escogida queda en naranja). Las opciones van en el orden de los valores: "Arriba" = 1… */
    private void grupoBotones(LinearLayout l, String[] ops, int[] valor, int columnas, Runnable alCambiar) {
        // la cara: los textos están en orden de pantalla; el valor real sale de CARAS_UNION
        List<TextView> bs = new ArrayList<>();
        LinearLayout fila = null;
        for (int i = 0; i < ops.length; i++) {
            if (i % columnas == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(42));
                fp.topMargin = dp(4);
                l.addView(fila, fp);
            }
            int v = Arrays.asList(Pieza.CARAS_UNION).indexOf(ops[i]);
            if (v < 0) v = i;
            final int val = v;
            TextView t = boton(ops[i], 0xFF455A64, null);
            t.setTag(val);
            t.setOnClickListener(x -> {
                valor[0] = val;
                for (TextView o : bs) colorear(o, ((Integer) o.getTag()) == valor[0] ? 0xFFFF8F00 : 0xFF455A64);
                if (alCambiar != null) alCambiar.run();
            });
            bs.add(t);
            fila.addView(t, peso());
        }
        for (TextView o : bs) colorear(o, ((Integer) o.getTag()) == valor[0] ? 0xFFFF8F00 : 0xFF455A64);
    }

    /** Un campo de la pieza: número fijo o fórmula de la tablita. */
    private void leerCampo(Pieza p, String k, String texto) {
        String t = texto == null ? "" : texto.trim();
        if (t.isEmpty()) return;
        Double n = Formula.numero(t);
        if (n != null) { p.ponerCampo(k, n.floatValue()); p.f.remove(k); return; }
        fijos();
        medidas.calcular();
        try {
            double v = medidas.evaluar(t);
            p.ponerCampo(k, (float) v);
            p.f.put(k, t);
        } catch (Exception e) {
            aviso("⚠ " + p.nombre() + ": la fórmula «" + t + "» no sirve: " + e.getMessage());
        }
    }

    // ---------------- Formulario de una pieza ----------------

    private EditText numero(LinearLayout l, String etiqueta, float valor, boolean signo) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        e.setTextSize(17);
        Teclado.numero(this, e, etiqueta, Pieza.n(valor));   // v6.6
        l.addView(e);
        return e;
    }

    /** Casilla que acepta número o fórmula (el teclado normal, para poder escribir nombres). */
    private EditText numeroOFormula(LinearLayout l, String etiqueta, Pieza p, String k) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        String f = p.f.get(k);
        e.setTextSize(17);
        e.setSingleLine(true);
        Teclado.numero(this, e, etiqueta, f != null ? f : Pieza.n(p.campo(k)));   // v6.6
        l.addView(e);
        return e;
    }

    private EditText[] filaNumeros(LinearLayout l, String[] etiquetas, float[] valores, boolean signo) {
        LinearLayout fila = new LinearLayout(this);
        EditText[] r = new EditText[etiquetas.length];
        for (int i = 0; i < etiquetas.length; i++) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            r[i] = numero(c, etiquetas[i], valores[i], signo);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.setMargins(0, 0, dp(6), 0);
            fila.addView(c, p);
        }
        l.addView(fila);
        return r;
    }

    private Spinner lista(LinearLayout l, String etiqueta, String[] items, int sel) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(Math.max(0, Math.min(items.length - 1, sel)));
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
        return s;
    }

    private static float leer(EditText e, float porDefecto) {
        try { return Float.parseFloat(Teclado.tx(e).trim().replace(',', '.')); } catch (Exception x) { return porDefecto; }
    }

    private static String[] nombresMedidas(int tipo) {
        Object[][] m = Pieza.MEDIDAS[tipo];
        String[] r = new String[m.length + 1];
        for (int i = 0; i < m.length; i++) r[i] = (String) m[i][0];
        r[m.length] = "Otra medida (escríbala abajo)";
        return r;
    }

    private void titulo(LinearLayout l, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(2));
        l.addView(t);
    }

    private void editar(Pieza original) {
        if (original != null && original.tipo == Pieza.PLACA) { editarPlaca(original); return; }
        final boolean nueva = original == null;
        final Pieza p;
        if (nueva) {
            p = new Pieza();
            p.id = nuevoId();
            Pieza ult = piezas.isEmpty() ? null : piezas.get(piezas.size() - 1);
            if (ult != null && ult.tipo != Pieza.PLACA) {   // por comodidad: la nueva sale igual a la anterior y pegada a su final (versión 6: no si la anterior es placa)
                p.tipo = ult.tipo; p.medida = ult.medida; p.a = ult.a; p.b = ult.b; p.t = ult.t; p.calibre = ult.calibre;
                p.padre = ult.id; p.punto = 1;
            }
        } else p = original;

        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), dp(10));
        sv.addView(l);
        if (!nueva) {
            // versión 4.2: dónde queda la pieza (se calcula sola)
            float[] ini = p.inicio(mapaPiezas(), 0), d = p.direccion();
            TextView co = etiqueta("Inicio X, Y, Z: " + Pieza.n(r1(ini[0])) + ", " + Pieza.n(r1(ini[1])) + ", " + Pieza.n(r1(ini[2]))
                    + "\nFinal X, Y, Z: " + Pieza.n(r1(ini[0] + d[0] * p.largo)) + ", " + Pieza.n(r1(ini[1] + d[1] * p.largo)) + ", " + Pieza.n(r1(ini[2] + d[2] * p.largo))
                    + "\nLargo de corte (punta larga): " + Pieza.n(r1(p.largoCorte())) + " mm");
            co.setTextColor(0xFF90A4AE);
            l.addView(co);
        }

        titulo(l, "1. El perfil");
        Spinner sTipo = lista(l, "Perfil", Pieza.TIPOS, p.tipo);
        int iMed = Arrays.asList(nombresMedidas(p.tipo)).indexOf(p.medida);
        Spinner sMed = lista(l, "Medida", nombresMedidas(p.tipo), iMed < 0 ? Pieza.MEDIDAS[p.tipo].length : iMed);
        EditText[] dims = filaNumeros(l, new String[]{"Ancho mm", "Alto mm", "Espesor mm"}, new float[]{p.a, p.b, p.t}, false);
        TextView tc = new TextView(this);
        tc.setText("Calibre (para pedirlo en la ferretería)");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setPadding(0, dp(8), 0, 0);
        l.addView(tc);
        EditText eCal = new EditText(this);
        eCal.setText(p.calibre);
        Teclado.letras(this, eCal);
        l.addView(eCal);
        final int[] tipoAntes = {p.tipo};
        sTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                if (pos == tipoAntes[0]) return;
                tipoAntes[0] = pos;
                sMed.setAdapter(new ArrayAdapter<>(InventorActivity.this, android.R.layout.simple_spinner_dropdown_item, nombresMedidas(pos)));
                sMed.setSelection(Math.min(2, Pieza.MEDIDAS[pos].length - 1));
                eCal.setText(pos <= 2 ? "Cal 18" : "");
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });
        sMed.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                Object[][] m = Pieza.MEDIDAS[sTipo.getSelectedItemPosition()];
                if (pos >= m.length) return;
                dims[0].setText(Pieza.n((Float) m[pos][1]));
                dims[1].setText(Pieza.n((Float) m[pos][2]));
                dims[2].setText(Pieza.n((Float) m[pos][3]));
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });

        titulo(l, "2. Largo y hacia dónde va");
        EditText eLargo = numeroOFormula(l, "Largo de corte (mm o fórmula, ej. ancho - 2*tubo)", p, "largo");
        if (!nueva && p.marco != null) {
            TextView gl = etiqueta("⟳ Esta pieza está girada libre. Si cambia la dirección, la inclinación o el giro, se endereza.");
            gl.setTextColor(0xFFFFD54A);
            l.addView(gl);
        }
        Spinner sDir = lista(l, "Dirección", Pieza.DIRS, p.dir);
        EditText eIncl = numero(l, "Inclinación (grados, 0 = derecho)", p.incl, true);
        Spinner sGiro = lista(l, "Girar la sección (para ángulo o platina)", new String[]{"0°", "90°", "180°", "270°"}, p.giro);

        titulo(l, "3. Dónde se une");
        Set<Integer> no = nueva ? new HashSet<>() : descendientes(p.id);
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (x != p && !no.contains(x.id)) posibles.add(x);
        String[] nomPadres = new String[posibles.size() + 1];
        nomPadres[0] = "En el punto 0 (suelta)";
        int selPadre = 0;
        for (int i = 0; i < posibles.size(); i++) {
            nomPadres[i + 1] = posibles.get(i).nombre() + " · " + posibles.get(i).referencia();
            if (posibles.get(i).id == p.padre) selPadre = i + 1;
        }
        Spinner sPadre = lista(l, "Va pegada a", nomPadres, selPadre);
        Spinner sPunto = lista(l, "En qué punto de esa pieza", new String[]{"Al inicio", "Al final", "A una medida del inicio"}, p.punto);
        Spinner sCara = lista(l, "En qué cara de esa pieza se pega", Pieza.CARAS_UNION, p.cara);
        EditText eAmm = numeroOFormula(l, "Medida desde el inicio (mm o fórmula), si escogió «a una medida»", p, "aMm");
        EditText eSep = numeroOFormula(l, "Separación (mm o fórmula) — luz entre las dos piezas", p, "sep");
        EditText eCx = numeroOFormula(l, "Correr X (mm o fórmula)", p, "cx");
        EditText eCy = numeroOFormula(l, "Correr Y (mm o fórmula)", p, "cy");
        EditText eCz = numeroOFormula(l, "Correr Z (mm o fórmula)", p, "cz");

        titulo(l, "4. Cortes de las puntas");
        EditText[] cortes = filaNumeros(l, new String[]{"Inicio (°)", "Final (°)"}, new float[]{p.corteIni, p.corteFin}, true);

        titulo(l, "5. Huecos y ranuras");
        LinearLayout cajaHuecos = new LinearLayout(this);
        cajaHuecos.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHuecos);
        List<Object[]> filasHueco = new ArrayList<>();
        for (Pieza.Hueco h : p.huecos) agregarFilaHueco(cajaHuecos, filasHueco, h);
        TextView masH = boton("➕ Agregar hueco", 0xFF37474F, () -> agregarFilaHueco(cajaHuecos, filasHueco, new Pieza.Hueco()));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(44));
        mp.topMargin = dp(6);
        l.addView(masH, mp);

        new AlertDialog.Builder(this).setTitle(nueva ? "➕ Pieza nueva " + p.nombre() : "✏ " + p.nombre()).setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    antes();
                    p.tipo = sTipo.getSelectedItemPosition();
                    int im = sMed.getSelectedItemPosition();
                    p.a = Math.max(1, leer(dims[0], p.a));
                    p.b = Math.max(1, leer(dims[1], p.b));
                    p.t = Math.max(0.3f, leer(dims[2], p.t));
                    p.medida = im < Pieza.MEDIDAS[p.tipo].length ? (String) Pieza.MEDIDAS[p.tipo][im][0]
                            : Pieza.n(p.a) + "x" + Pieza.n(p.b) + " mm";
                    p.calibre = Teclado.tx(eCal);
                    leerCampo(p, "largo", Teclado.tx(eLargo));
                    if (p.largo <= 0) p.largo = 1000;
                    boolean cambioDir = sDir.getSelectedItemPosition() != p.dir || Math.abs(leer(eIncl, 0) - p.incl) > 0.01f || sGiro.getSelectedItemPosition() != p.giro;
                    p.dir = sDir.getSelectedItemPosition();
                    p.incl = leer(eIncl, 0);
                    p.giro = sGiro.getSelectedItemPosition();
                    if (cambioDir) p.marco = null;
                    int ip = sPadre.getSelectedItemPosition();
                    p.padre = ip == 0 ? -1 : posibles.get(ip - 1).id;
                    p.punto = sPunto.getSelectedItemPosition();
                    p.cara = p.padre < 0 ? 0 : sCara.getSelectedItemPosition();
                    leerCampo(p, "aMm", Teclado.tx(eAmm));
                    leerCampo(p, "sep", Teclado.tx(eSep));
                    leerCampo(p, "cx", Teclado.tx(eCx));
                    leerCampo(p, "cy", Teclado.tx(eCy));
                    leerCampo(p, "cz", Teclado.tx(eCz));
                    p.corteIni = leer(cortes[0], 0); p.corteFin = leer(cortes[1], 0);
                    p.huecos.clear();
                    for (Object[] f : filasHueco) {
                        Pieza.Hueco h = new Pieza.Hueco();
                        h.tipo = ((Spinner) f[0]).getSelectedItemPosition();
                        h.d1 = Math.max(1, leer((EditText) f[1], 10));
                        h.d2 = Math.max(1, leer((EditText) f[2], 8));
                        h.pos = leer((EditText) f[3], 50);
                        h.cara = ((Spinner) f[4]).getSelectedItemPosition();
                        p.huecos.add(h);
                    }
                    if (nueva) piezas.add(p);
                    escogida = p.id;
                    vista.encuadrar();
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Una fila de hueco: tipo, medidas, posición y cara. */
    private void agregarFilaHueco(LinearLayout caja, List<Object[]> filas, Pieza.Hueco h) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(8), dp(4), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        f.setBackground(g);
        Spinner sT = lista(f, "Hueco " + (filas.size() + 1), Pieza.HUECOS, h.tipo);
        EditText[] m = filaNumeros(f, new String[]{"Ø / lado / largo", "Ancho ranura", "A mm del inicio"}, new float[]{h.d1, h.d2, h.pos}, false);
        Spinner sC = lista(f, "En qué cara", Pieza.CARAS, h.cara);
        Object[] reg = {sT, m[0], m[1], m[2], sC, f};
        TextView quitar = boton("✕ Quitar este hueco", 0xFFC62828, () -> { caja.removeView(f); filas.remove(reg); });
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, dp(38));
        qp.topMargin = dp(6);
        f.addView(quitar, qp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        caja.addView(f, lp);
        filas.add(reg);
    }

    // ---------------- Lista de corte ----------------

    private String textoCorte() {
        Map<String, List<Pieza>> grupos = new LinkedHashMap<>();
        for (Pieza p : piezas) {
            if (p.tipo == Pieza.PLACA) continue;
            List<Pieza> g = grupos.get(p.referencia());
            if (g == null) { g = new ArrayList<>(); grupos.put(p.referencia(), g); }
            g.add(p);
        }
        StringBuilder s = new StringBuilder();
        s.append("CHEPE CAD - LISTA DE CORTE\n");
        s.append("Proyecto: ").append(nombreProyecto).append("\n");
        s.append(new SimpleDateFormat("dd/MM/yyyy h:mm a", new Locale("es", "CO")).format(new Date())).append("\n");
        s.append("Barras de 6 m · se descuentan 3 mm por cada corte\n");
        int totalBarras = 0;
        for (Map.Entry<String, List<Pieza>> en : grupos.entrySet()) {
            s.append("\n========================================\n");
            s.append(en.getKey().toUpperCase(new Locale("es", "CO"))).append("\n");
            s.append("========================================\n");
            float metros = 0;
            List<Float> largos = new ArrayList<>();
            List<String> largas = new ArrayList<>();
            int extra = 0;
            for (Pieza p : en.getValue()) {
                float lc = p.largoCorte();
                metros += lc;
                s.append(String.format(Locale.US, "%-4s %6s mm", p.nombre(), Pieza.n(lc)));
                if (Math.abs(p.corteIni) > 0.01f || Math.abs(p.corteFin) > 0.01f)
                    s.append("  (punta larga) cortes ").append(Pieza.n(Math.abs(p.corteIni))).append("° / ").append(Pieza.n(Math.abs(p.corteFin))).append("°")
                            .append(" · eje ").append(Pieza.n(p.largo));
                else s.append("  cortes rectos (90°)");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(h.texto()).append("\n");
                if (lc > BARRA) { largas.add(p.nombre() + " (" + Pieza.n(lc) + " mm)"); extra += (int) Math.ceil(lc / BARRA); }
                else largos.add(lc);
            }
            // acomodar los cortes en barras: primero los más largos
            largos.sort((x, y) -> Float.compare(y, x));
            List<List<Float>> barras = new ArrayList<>();
            List<Float> libre = new ArrayList<>();
            for (float L : largos) {
                int k = -1;
                for (int i = 0; i < barras.size(); i++) if (libre.get(i) >= L + (barras.get(i).isEmpty() ? 0 : DISCO)) { k = i; break; }
                if (k < 0) { barras.add(new ArrayList<>()); libre.add(BARRA); k = barras.size() - 1; }
                libre.set(k, libre.get(k) - L - (barras.get(k).isEmpty() ? 0 : DISCO));
                barras.get(k).add(L);
            }
            s.append("\nMetros lineales: ").append(String.format(Locale.US, "%.2f", metros / 1000f)).append(" m\n");
            for (int i = 0; i < barras.size(); i++) {
                s.append("Barra ").append(i + 1).append(": ");
                List<Float> b = barras.get(i);
                for (int j = 0; j < b.size(); j++) s.append(j == 0 ? "" : " + ").append(Pieza.n(b.get(j)));
                s.append("  (sobran ").append(Pieza.n(Math.max(0, libre.get(i)))).append(" mm)\n");
            }
            if (!largas.isEmpty()) s.append("Más largas que 6 m (van empatadas): ").append(String.join(", ", largas)).append("\n");
            int comprar = barras.size() + extra;
            totalBarras += comprar;
            s.append(">> COMPRAR: ").append(comprar).append(comprar == 1 ? " barra de 6 m\n" : " barras de 6 m\n");
        }
        // versión 4: las placas sacadas del boceto
        List<Pieza> pl = placas();
        if (!pl.isEmpty()) {
            s.append("\n========================================\nPLACAS (del boceto)\n========================================\n");
            for (Pieza p : pl) {
                float s0 = Float.MAX_VALUE, s1 = -Float.MAX_VALUE, u0 = Float.MAX_VALUE, u1 = -Float.MAX_VALUE;
                if (p.contorno != null) for (float[] q : p.contorno) { s0 = Math.min(s0, q[0]); s1 = Math.max(s1, q[0]); u0 = Math.min(u0, q[1]); u1 = Math.max(u1, q[1]); }
                float ar = p.contorno == null ? 0 : Math.abs(Vista3D.area(p.contorno));
                for (float[][] h : p.agujeros) ar -= Math.abs(Vista3D.area(h));
                s.append(p.nombre()).append("  ").append(Pieza.n(s1 - s0)).append(" x ").append(Pieza.n(u1 - u0)).append(" mm · grueso ")
                        .append(Pieza.n(p.largo)).append(" mm · área ").append(String.format(Locale.US, "%.3f", ar / 1e6f)).append(" m²");
                int nh = p.agujeros.size() + p.huecos.size();
                if (nh > 0) s.append(" · ").append(nh).append(nh == 1 ? " hueco" : " huecos");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(Pieza.HUECOS[h.tipo].toLowerCase()).append(" Ø").append(Pieza.n(h.d1))
                        .append(" en X ").append(Pieza.n(-h.s)).append(" Y ").append(Pieza.n(h.u)).append("\n");
            }
        }
        s.append("\n----------------------------------------\n");
        s.append("TOTAL: ").append(totalBarras).append(" barras de 6 m\n");
        return s.toString();
    }

    private void listaCorte() {
        if (piezas.isEmpty()) { aviso("Todavía no hay piezas en el 3D"); return; }
        String txt = textoCorte();
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(Color.WHITE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("📋 Lista de corte").setView(sv)
                .setPositiveButton("📄 PDF carta", (d, w) -> pdf(txt))
                .setNeutralButton("📲 WhatsApp", (d, w) -> compartirTexto(txt))
                .setNegativeButton("Cerrar", null).show();
    }

    private void compartirTexto(String txt) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) { try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {} }
    }

    /** La lista en PDF tamaño carta, letras negras nítidas. */
    private void pdf(String txt) {
        try {
            PdfDocument doc = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(10.5f);
            String[] lineas = txt.split("\n");
            float alto = 14, arriba = 50, abajo = 792 - 45;
            int num = 1, i = 0;
            while (i < lineas.length) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                float y = arriba;
                while (i < lineas.length && y < abajo) {
                    String ln = lineas[i++];
                    p.setFakeBoldText(ln.startsWith(">>") || ln.startsWith("TOTAL") || ln.startsWith("CHEPE CAD") || (i > 1 && ln.equals(ln.toUpperCase()) && !ln.startsWith("=")));
                    c.drawText(ln, 45, y, p);
                    y += alto;
                }
                p.setFakeBoldText(false);
                c.drawText("Página " + num, 520, 775, p);
                doc.finishPage(pg);
                num++;
            }
            guardarPdf(doc, "MiInventor_Corte_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Proyectos (archivos livianos) ----------------

    private File carpeta() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private JSONObject proyecto() throws Exception { return proyecto(true); }

    /** conCalco = false: para deshacer (sin los DXF de referencia, para que no pese). */
    private JSONObject proyecto(boolean conCalco) throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 6);
        o.put("modo", modo);
        JSONArray rf = new JSONArray();
        for (Ref r : refs) rf.put(r.json());
        o.put("refs", rf);
        o.put("nombre", nombreProyecto);
        JSONArray a = new JSONArray();
        for (Pieza p : piezas) a.put(p.json());
        o.put("piezas", a);
        o.put("medidas", medidas.json());
        JSONArray hs = new JSONArray();
        for (Hoja h : hojas) hs.put(h.json(conCalco));
        o.put("bocetos", hs);
        o.put("hojaAct", hoja == null ? 1 : hoja.id);
        return o;
    }

    /** Deshacer no guarda los DXF de referencia: se le vuelven a poner a cada boceto. */
    private void cargarSinPerderCalcos(JSONObject o) throws Exception {
        Map<Integer, Boceto> cal = new HashMap<>();
        for (Hoja h : hojas) if (h.calco != null) cal.put(h.id, h.calco);
        cargar(o);
        for (Hoja h : hojas) if (h.calco == null && cal.containsKey(h.id)) h.calco = cal.get(h.id);
    }

    private void cargar(JSONObject o) throws Exception {
        JSONArray a = o.optJSONArray("piezas");
        piezas.clear();
        if (a != null) for (int i = 0; i < a.length(); i++) piezas.add(Pieza.deJson(a.getJSONObject(i)));
        medidas.deJson(o.optJSONArray("medidas"));
        hojas.clear();
        JSONArray hs = o.optJSONArray("bocetos");
        if (hs != null) for (int i = 0; i < hs.length(); i++) hojas.add(Hoja.deJson(hs.getJSONObject(i)));
        else {
            // proyectos viejos: un solo boceto, en el piso
            Hoja h = Hoja.nueva(1, 0);
            h.b = Boceto.deJson(o.optJSONObject("boceto"));
            hojas.add(h);
            for (Pieza p : piezas) if (p.tipo == Pieza.PLACA && p.hoja < 0) p.hoja = 1;
        }
        if (hojas.isEmpty()) hojas.add(Hoja.nueva(1, 0));
        hoja = porHoja(o.optInt("hojaAct", hojas.get(0).id));
        if (hoja == null) hoja = hojas.get(0);
        boceto.b = hoja.b;
        boceto.limpiarSeleccion();
        nombreProyecto = o.optString("nombre", nombreProyecto);
        modoFalta = !o.has("modo");
        modo = o.optString("modo", MONTAJE);
        if (porId(escogida) == null) escogida = -1;
        refs.clear();
        JSONArray rf = o.optJSONArray("refs");
        if (rf != null) for (int i = 0; i < rf.length(); i++) { JSONObject x = rf.optJSONObject(i); if (x != null) refs.add(Ref.deJson(x)); }
    }

    private void menuProyecto() {
        new AlertDialog.Builder(this).setTitle("📂 Archivo · " + nombreProyecto)
                .setItems(new String[]{"📤 Enviar este archivo (liviano)", "📥 Abrir un archivo recibido",
                        "📄 PDF carta del plano 2D", "📐 Abrir un plano DXF (de AutoCAD)", "💾 Guardar el plano 2D en DXF", "🧹 Hoja 2D nueva (borra solo el 2D)"}, (d, w0) -> {
                    int w = new int[]{2, 3, 5, 6, 7, 8}[w0];
                    if (w == 0) pedirNombre();
                    else if (w == 1) listaProyectos();
                    else if (w == 2) enviarProyecto();
                    else if (w == 3) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_ARCHIVO); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else if (w == 4) new AlertDialog.Builder(this).setMessage("¿Empezar vacío? Lo que no haya guardado con nombre se pierde (se puede deshacer con ↶).")
                                .setPositiveButton("Empezar", (d2, w2) -> {
                                    antes();
                                    piezas.clear(); medidas.filas.clear();
                                    hojas.clear(); hojas.add(Hoja.nueva(1, 0)); hoja = hojas.get(0); boceto.b = hoja.b;
                                    escogida = -1; nombreProyecto = "Sin nombre";
                                    vista.encuadrar(); boceto.encuadrar(); recalcular();
                                })
                                .setNegativeButton("Cancelar", null).show();
                    else if (w == 5) pdf2D();
                    else if (w == 6) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_DXF); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else if (w == 7) exportarDxf();
                    else new AlertDialog.Builder(this).setMessage("¿Borrar todo el boceto 2D? (se puede deshacer con ↶)")
                                .setPositiveButton("Borrar", (d2, w2) -> { antes(); hoja.b = new Boceto(); boceto.b = hoja.b; boceto.limpiarSeleccion(); recalcular(); })
                                .setNegativeButton("Cancelar", null).show();
                }).show();
    }

    /** Versión 3: el plano 2D en DXF (se abre en AutoCAD y en cualquier programa de dibujo). */
    private void exportarDxf() {
        if (boceto.b.vacio()) { aviso("El boceto 2D está vacío"); return; }
        try {
            byte[] datos = Dxf.exportar(boceto.b, boceto).getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                    + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".dxf";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/dxf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            new AlertDialog.Builder(this).setTitle("✔ DXF guardado")
                    .setMessage(nom + "\n\nQuedó en Descargas/MiBarra/MiInventor (" + Math.max(1, datos.length / 1024) + " KB).\nMedidas en milímetros.")
                    .setPositiveButton("📤 Enviar", (d, w) -> {
                        Intent i = new Intent(Intent.ACTION_SEND).setType("application/dxf").putExtra(Intent.EXTRA_STREAM, u)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { startActivity(Intent.createChooser(i, "Enviar el DXF")); } catch (Exception ignored) {}
                    })
                    .setNegativeButton("Listo", null).show();
        } catch (Exception e) {
            aviso("No se pudo guardar el DXF");
        }
    }

    /** Lee el DXF escogido y pregunta si reemplaza el boceto o se agrega. */
    private void abrirDxf(Uri u) {
        String texto;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) {
                bo.write(b, 0, n);
                if (bo.size() > 40 * 1024 * 1024) { aviso("Ese plano es muy grande (más de 40 MB)"); return; }
            }
            byte[] datos = bo.toByteArray();
            String inicio = new String(datos, 0, Math.min(datos.length, 32), StandardCharsets.ISO_8859_1);
            if (inicio.startsWith("AC10") || inicio.startsWith("AC1.")) {
                new AlertDialog.Builder(this).setTitle("Ese archivo es DWG")
                        .setMessage("Chepe CAD abre DXF. Pídale el plano en DXF a quien se lo mandó (en AutoCAD: Guardar como → DXF), "
                                + "o conviértalo gratis con ODA File Converter en un computador.")
                        .setPositiveButton("Entendido", null).show();
                return;
            }
            if (inicio.startsWith("AutoCAD Binary DXF")) { aviso("Ese DXF está en binario: guárdelo como DXF de texto (ASCII)"); return; }
            texto = new String(datos, StandardCharsets.UTF_8);
            if (!texto.contains("SECTION")) { aviso("Ese archivo no es un plano DXF"); return; }
        } catch (Exception e) {
            aviso("No se pudo leer el archivo");
            return;
        }
        final String t = texto;
        if (dxfNuevo) {
            dxfNuevo = false;
            antes();
            Dxf.Resultado r = Dxf.importar(t, hoja.b);
            mostrar(0);
            boceto.encuadrar();
            recalcular();
            aviso("✔ DXF abierto como boceto de " + nombreProyecto + " (" + r.lineas + " líneas, " + r.circulos + " círculos, " + r.arcos + " arcos). Revíselo y toque ✓ Listo");
            return;
        }
        new AlertDialog.Builder(this).setTitle("📐 Abrir DXF")
                .setItems(new String[]{"📐 Como calco (de referencia, para dibujar encima)", "Reemplazar el boceto 2D", "Agregarlo al boceto 2D que hay"}, (d, w0) -> {
                    if (w0 == 0) { ponerCalco(t); return; }
                    int w = w0 - 1;
                    antes();
                    if (w == 0) { hoja.b = new Boceto(); boceto.b = hoja.b; }
                    Dxf.Resultado r = Dxf.importar(t, boceto.b);
                    if (r.total() == 0) { revertir(); aviso("No se encontraron líneas, círculos, arcos ni textos"); return; }
                    boceto.limpiarSeleccion();
                    mostrar(0);
                    boceto.encuadrar();
                    recalcular();
                    String m = "✔ " + r.lineas + " líneas, " + r.circulos + " círculos, " + r.arcos + " arcos, " + r.textos + " textos";
                    if (!r.unidades.equals("mm")) m += " (venía en " + r.unidades + ", pasado a mm)";
                    if (r.omitidos > 0) m += ". " + r.omitidos + " cosas no se pudieron traer (bloques, sombreados o cotas)";
                    new AlertDialog.Builder(this).setTitle("Plano abierto").setMessage(m).setPositiveButton("Listo", null).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Versión 5.1: 📐 Calco DXF (plano de referencia en el boceto) ----------------

    private void pedirDxf() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        try { startActivityForResult(i, ABRIR_DXF); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
    }

    private void menuCalco() {
        if (hoja == null) return;
        if (hoja.calco == null) {
            new AlertDialog.Builder(this).setTitle("📐 Calco DXF")
                    .setMessage("Abra un plano DXF de referencia: se ve en gris punteado y sus puntas y mitades son imanes, para dibujar el perfil encima. El calco no se extruye ni sale en la lista de corte.")
                    .setPositiveButton("📂 Abrir DXF", (d, w) -> pedirDxf())
                    .setNegativeButton("Cancelar", null).show();
            return;
        }
        String[] op = {hoja.verCalco ? "🙈 Ocultar el calco" : "👁 Ver el calco", "⌖ Llevar el calco al 0,0 (su esquina de abajo a la izquierda)",
                "↔ Correr el calco (X, Y)", "📂 Cambiar por otro DXF", "🗑 Quitar el calco"};
        new AlertDialog.Builder(this).setTitle("📐 Calco DXF de " + hoja.nombre).setItems(op, (d, w) -> {
            if (w == 0) { hoja.verCalco = !hoja.verCalco; recalcular(); grupo2D(G_DIBUJAR); }
            else if (w == 1) { double[] c = hoja.calco.caja(); correrCalco(-c[0], -c[1]); }
            else if (w == 2) {
                LinearLayout l = new LinearLayout(this);
                l.setOrientation(LinearLayout.VERTICAL);
                l.setPadding(dp(16), dp(4), dp(16), 0);
                l.addView(etiqueta("Correr en X (mm, + o −)"));
                EditText ex = campoTexto("0", "mm");
                l.addView(ex);
                l.addView(etiqueta("Correr en Y (mm, + o −)"));
                EditText ey = campoTexto("0", "mm");
                l.addView(ey);
                new AlertDialog.Builder(this).setTitle("↔ Correr el calco").setView(l)
                        .setPositiveButton("Correr", (d2, w2) -> {
                            Double vx = valorDe(Teclado.tx(ex)), vy = valorDe(Teclado.tx(ey));
                            correrCalco(vx == null ? 0 : vx, vy == null ? 0 : vy);
                        }).setNegativeButton("Cancelar", null).show();
            } else if (w == 3) pedirDxf();
            else new AlertDialog.Builder(this).setMessage("¿Quitar el calco de " + hoja.nombre + "? Lo que usted dibujó encima se queda.")
                        .setPositiveButton("🗑 Quitar", (d2, w2) -> { hoja.calco = null; recalcular(); grupo2D(G_DIBUJAR); aviso("Calco quitado"); })
                        .setNegativeButton("Cancelar", null).show();
        }).show();
    }

    private void correrCalco(double dx, double dy) {
        if (hoja == null || hoja.calco == null) return;
        for (Boceto.Punto p : hoja.calco.puntos.values()) { p.x += dx; p.y += dy; }
        recalcular();
        boceto.encuadrar();
    }

    /** El DXF queda de calco en el boceto activo (no se mezcla con el dibujo). */
    private void ponerCalco(String texto) {
        Boceto k = new Boceto();
        Dxf.Resultado r = Dxf.importar(texto, k);
        if (r.total() == 0) { aviso("No se encontraron líneas, círculos ni arcos"); return; }
        hoja.calco = k;
        hoja.verCalco = true;
        mostrar(0);
        recalcular();
        boceto.encuadrar();
        grupo2D(G_DIBUJAR);
        String m = "✔ Calco puesto: " + r.lineas + " líneas, " + r.circulos + " círculos, " + r.arcos + " arcos (en gris punteado).";
        if (!r.unidades.equals("mm")) m += " Venía en " + r.unidades + ", pasado a mm.";
        m += "\n\nDibuje encima con ╱ Línea, ▭ Rectáng. o ◯ Círculo: las puntas del calco jalan como imán (cuadrito con X).";
        new AlertDialog.Builder(this).setTitle("📐 Calco DXF").setMessage(m).setPositiveButton("Listo", null).show();
    }

    /** El proyecto es solo números y fórmulas: unos pocos KB. Se guarda en Descargas/MiBarra/MiInventor y se manda. */
    private void enviarProyecto() {
        try {
            byte[] datos = proyecto().toString().getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + ".miv.json";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            aviso("✔ Archivo de " + Math.max(1, datos.length / 1024) + " KB en Descargas/MiBarra/MiInventor");
            Intent i = new Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_STREAM, u)
                    .putExtra(Intent.EXTRA_TEXT, "Proyecto de Chepe CAD: " + nombreProyecto).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Enviar el proyecto"));
        } catch (Exception e) {
            aviso("No se pudo preparar el archivo");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == GRABAR) {   // v6.6: el usuario dejó grabar la pantalla
            if (res != RESULT_OK || data == null) { aviso("No se empezó a grabar"); return; }
            Grabadora.codigo = res;
            Grabadora.permiso = data;
            Grabadora.alTerminar = (u, nom, bytes) -> runOnUiThread(() -> { pintarRec(); listoArchivo(u, nom, bytes, true); });
            startForegroundService(new Intent(this, Grabadora.class));
            relojRec();
            return;
        }
        if (res != RESULT_OK || data == null || data.getData() == null) { dxfNuevo = false; return; }
        if (req == ABRIR_DXF) { abrirDxf(data.getData()); return; }
        if (req != ABRIR_ARCHIVO) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            byte[] b = new byte[8192];
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONObject o = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            if (PLANTA.equals(o.optString("modo"))) {   // v6.5: archivo de casa (por ejemplo el que manda Claude)
                String nom = limpio(o.optString("nombre", "Casa recibida"));
                if (nom.isEmpty()) nom = "Casa recibida";
                if (casa != null) cerrarCasa();
                if (nombresLib().contains(nom)) nom = siguienteNombre(nom);
                o.put("nombre", nom);
                try (FileWriter w = new FileWriter(new File(carpetaLib(), nom + ".json"))) { w.write(o.toString()); }
                abrirCasa(nom, CasaPlano.deJson(o.getJSONObject("plano")));
                aviso("✔ Casa «" + nom + "» abierta y guardada en la librería");
                return;
            }
            antes();
            cargar(o);
            if (modoFalta) migrar();
            aplicarModo();
            guardarDoc(true);
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            aviso("Ese archivo no es un proyecto de Chepe CAD");
        }
    }

    private void pedirNombre() {
        EditText e = new EditText(this);
        e.setText("Sin nombre".equals(nombreProyecto) ? "" : nombreProyecto);
        e.setHint("Por ejemplo: escalera");
        Teclado.letras(this, e);
        new AlertDialog.Builder(this).setTitle("Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = Teclado.tx(e).trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty() || n.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    nombreProyecto = n;
                    guardar(n, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void guardar(String nombre, boolean callado) {
        try {
            try (FileWriter w = new FileWriter(new File(carpeta(), nombre + ".json"))) { w.write(proyecto().toString()); }
            if (!callado) aviso("✔ Guardado «" + nombre + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo guardar");
        }
    }

    private void abrir(String nombre, boolean callado) {
        try {
            File f = new File(carpeta(), nombre + ".json");
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            cargar(o);
            escogida = -1;
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            if (!callado) aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo abrir");
        }
    }

    private void listaProyectos() {
        File[] fs = carpeta().listFiles(x -> x.getName().endsWith(".json") && !x.getName().startsWith("_"));
        if (fs == null || fs.length == 0) { aviso("Todavía no hay proyectos guardados con nombre"); return; }
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] nom = new String[fs.length];
        for (int i = 0; i < fs.length; i++) nom[i] = fs[i].getName().replace(".json", "") + "  (" + Math.max(1, fs[i].length() / 1024) + " KB)";
        new AlertDialog.Builder(this).setTitle("📂 Proyectos").setItems(nom, (d, w) -> {
            String n = fs[w].getName().replace(".json", "");
            new AlertDialog.Builder(this).setTitle(n).setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                if (w2 == 0) { antes(); abrir(n, false); }
                else new AlertDialog.Builder(this).setMessage("¿Borrar «" + n + "» para siempre?")
                        .setPositiveButton("Borrar", (d3, w3) -> { fs[w].delete(); aviso("Borrado"); })
                        .setNegativeButton("Cancelar", null).show();
            }).show();
        }).show();
    }

    // ---------------- Versión 4.4: insertar, lámina doblada y desarrollo ----------------

    /** 📥 Insertar en el montaje: un tubo o perfil del catálogo, o una copia de una pieza que ya está. */
    private Pieza laminaEscogida() {
        Pieza p = porId(escogida);
        return p != null && p.lamina ? p : null;
    }

    private void conLamina(java.util.function.Consumer<Pieza> hacer) {
        Pieza p = laminaEscogida();
        if (p != null) { hacer.accept(p); return; }
        List<Pieza> ls = new ArrayList<>();
        for (Pieza x : piezas) if (x.lamina) ls.add(x);
        if (ls.isEmpty()) { aviso("Primero haga una lámina: ✏ Boceto, luego 📐 Lámina"); return; }
        if (ls.size() == 1) { escogida = ls.get(0).id; vista.escogida = escogida; hacer.accept(ls.get(0)); return; }
        String[] nom = new String[ls.size()];
        for (int i = 0; i < nom.length; i++) nom[i] = ls.get(i).nombre() + " · " + ls.get(i).referencia();
        new AlertDialog.Builder(this).setTitle("¿Cuál lámina?").setItems(nom, (d, w) -> { escogida = ls.get(w).id; vista.escogida = escogida; hacer.accept(ls.get(w)); }).show();
    }

    /** Una fila de doblez en el árbol: tocar = cambiar · ⇅ = al otro lado · 🗑 = quitar. */
    private void filaDoblez(Pieza p, Pieza.Doblez db, int k) {
        LinearLayout f = new LinearLayout(this);
        TextView tx = new TextView(this);
        tx.setText("↪ " + textoDoblez(db, k));
        tx.setTextColor(Color.WHITE);
        tx.setTextSize(13);
        tx.setPadding(dp(10), dp(6), dp(8), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263C45);
        g.setCornerRadius(dp(8));
        tx.setBackground(g);
        tx.setOnClickListener(v -> dialogoDoblez(p, null, db));
        f.addView(tx, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView[] bs = {boton("⇅", 0xFF5E35B1, () -> { antes(); db.abajo = !db.abajo; recalcular(); guardarDoc(true); aviso("⇅ Doblez " + (k + 1) + " ahora va " + (db.abajo ? "⬇ abajo" : "⬆ arriba")); }),
                boton("🗑", 0xFFC62828, () -> quitarDoblez(p, k))};
        for (TextView b : bs) {
            b.setTextSize(15);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(42), -1);
            bp.leftMargin = dp(3);
            f.addView(b, bp);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(3);
        lista.addView(f, lp);
    }

    /** Quitar un doblez (y los que salen de su punta). */
    private void quitarDoblez(Pieza p, int k) {
        if (k < 0 || k >= p.dobleces.size()) return;
        antes();
        java.util.Set<Integer> fuera = new java.util.HashSet<>();
        fuera.add(k);
        boolean cambio = true;
        while (cambio) {
            cambio = false;
            for (int i = 0; i < p.dobleces.size(); i++) if (!fuera.contains(i) && fuera.contains(p.dobleces.get(i).padre)) { fuera.add(i); cambio = true; }
        }
        // los que quedan: se arreglan los números de padre
        List<Pieza.Doblez> quedan = new ArrayList<>();
        int[] nuevo = new int[p.dobleces.size()];
        for (int i = 0; i < p.dobleces.size(); i++) { if (fuera.contains(i)) nuevo[i] = -1; else { nuevo[i] = quedan.size(); quedan.add(p.dobleces.get(i)); } }
        for (Pieza.Doblez d : quedan) if (d.padre >= 0) d.padre = nuevo[d.padre];
        p.dobleces = quedan;
        recalcular();
        guardarDoc(true);
        aviso("🗑 Doblez " + (k + 1) + " quitado" + (fuera.size() > 1 ? " (y " + (fuera.size() - 1) + " que salían de él)" : ""));
    }

    private String textoDoblez(Pieza.Doblez d, int i) {
        return "Doblez " + (i + 1) + ": " + Pieza.n(d.angulo) + "° " + (d.abajo ? "⬇" : "⬆") + " · " + Pieza.n(d.largo) + " mm " + (d.porDentro ? "por dentro" : "por fuera")
                + (d.padre >= 0 ? " (sobre el doblez " + (d.padre + 1) + ")" : "");
    }

    /** ↪ Doblez: se toca un borde naranja de la lámina y se llena el cajetín. */
    private void doblez() {
        conLamina(p -> {
            if (p.dobleces.isEmpty()) { pedirBorde(p); return; }
            List<String> op = new ArrayList<>();
            op.add("➕ Doblez nuevo (tocar el borde)");
            for (int i = 0; i < p.dobleces.size(); i++) op.add("✏ " + textoDoblez(p.dobleces.get(i), i));
            op.add("🗑 Quitar el último doblez");
            new AlertDialog.Builder(this).setTitle("↪ Dobleces de " + p.nombre()).setItems(op.toArray(new String[0]), (d, w) -> {
                if (w == 0) pedirBorde(p);
                else if (w <= p.dobleces.size()) dialogoDoblez(p, null, p.dobleces.get(w - 1));
                else {
                    antes();
                    int ult = p.dobleces.size() - 1;
                    // también se van los que salen de ese doblez
                    p.dobleces.remove(ult);
                    for (int i = p.dobleces.size() - 1; i >= 0; i--) if (p.dobleces.get(i).padre >= ult) p.dobleces.remove(i);
                    recalcular();
                    aviso("Se quitó el doblez " + (ult + 1));
                }
            }).show();
        });
    }

    private void pedirBorde(Pieza p) {
        List<Lamina.Borde> bs = Lamina.bordesLibres(p);
        if (bs.isEmpty()) { aviso("Esta lámina ya no tiene bordes libres para doblar"); return; }
        List<float[][]> nar = new ArrayList<>();
        for (Lamina.Borde b : bs) nar.add(new float[][]{b.a, b.b});
        vista.bordesNaranja = nar;
        mostrar(1);
        vista.invalidate();
        aviso("Toque el borde naranja donde va el doblez (atrás = cancelar)");
        vista.pideToque = (x, y) -> {
            int i = vista.bordeCerca(x, y);
            if (i < 0) { aviso("Toque más cerca de una línea naranja"); return; }
            vista.pideToque = null;
            List<float[][]> uno = new ArrayList<>();
            uno.add(nar.get(i));
            vista.bordesNaranja = uno;
            vista.invalidate();
            dialogoDoblez(p, bs.get(i), null);
        };
    }

    /** El cajetín del doblez: ángulo, largo, hacia dónde y cómo se mide. b = borde nuevo, o d = doblez que se cambia. */
    private void dialogoDoblez(Pieza p, Lamina.Borde b, Pieza.Doblez viejo) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), 0);
        if (b != null) l.addView(etiqueta(b.nombre));
        float ang0 = viejo == null ? 90 : viejo.angulo;
        final int[] an = {ang0 == 90 ? 0 : ang0 == 45 ? 1 : ang0 == 135 ? 2 : 3};
        l.addView(etiqueta("Ángulo del doblez"));
        EditText otro = campoTexto(Pieza.n(ang0), "");
        grupoBotones(l, new String[]{"90°", "45°", "135°", "Otro"}, an, 4, null);
        l.addView(etiqueta("Grados (si escogió Otro)"));
        l.addView(otro);
        l.addView(etiqueta("Largo del doblez (mm)"));
        EditText la = campoTexto(viejo == null ? "50" : Pieza.n(viejo.largo), "");
        l.addView(la);
        final int[] ha = {viejo != null && viejo.abajo ? 1 : 0}, me = {viejo != null && viejo.porDentro ? 1 : 0};
        l.addView(etiqueta("Hacia dónde"));
        grupoBotones(l, new String[]{"⬆ Arriba", "⬇ Abajo"}, ha, 2, null);
        l.addView(etiqueta("La medida es"));
        grupoBotones(l, new String[]{"Por fuera", "Por dentro"}, me, 2, null);
        l.addView(etiqueta("Radio por dentro (mm) · lámina " + Pieza.n(Lamina.grueso(p)) + " mm"));
        EditText ra = campoTexto(Pieza.n(Lamina.radio(p)), "");
        l.addView(ra);
        new AlertDialog.Builder(this).setTitle(viejo == null ? "↪ Doblez nuevo" : "✏ Cambiar doblez").setView(l)
                .setPositiveButton("Doblar", (d, w) -> {
                    vista.bordesNaranja = null;
                    Double vl = valorDe(Teclado.tx(la)), vo = valorDe(Teclado.tx(otro)), vr = valorDe(Teclado.tx(ra));
                    if (vl == null || vl <= 0) { aviso("El largo del doblez no es válido"); vista.invalidate(); return; }
                    antes();
                    Pieza.Doblez q = viejo != null ? viejo : new Pieza.Doblez();
                    q.angulo = an[0] == 0 ? 90 : an[0] == 1 ? 45 : an[0] == 2 ? 135 : (float) Math.max(1, Math.min(179, vo == null ? 90 : vo));
                    q.largo = (float) (double) vl;
                    q.abajo = ha[0] == 1;
                    q.porDentro = me[0] == 1;
                    if (vr != null && vr > 0) p.radio = (float) (double) vr;
                    if (viejo == null) { q.padre = b.padre; q.borde = b.borde; p.dobleces.add(q); }
                    escogida = p.id;
                    recalcular();
                    aviso("✔ " + textoDoblez(q, p.dobleces.indexOf(q)) + ". Para el plano de corte: 📄 Desarrollo");
                })
                .setNegativeButton("Cancelar", (d, w) -> { vista.bordesNaranja = null; vista.invalidate(); }).show();
    }

    /** 📄 Desarrollo: la lámina estirada en un boceto nuevo, con los dobleces punteados. */
    private void desarrollo() {
        conLamina(p -> {
            if (p.contorno == null || p.contorno.length < 3) { aviso("Esa lámina no tiene forma"); return; }
            antes();
            Hoja h = Hoja.nueva(nuevoIdHoja(), 0);
            h.nombre = "Desarrollo de " + p.nombre();
            h.plano = "plano para cortar";
            double[] t = Lamina.desarrollo(p, h.b);
            hojas.add(h);
            abrirHoja(h);
            new AlertDialog.Builder(this).setTitle("📄 Desarrollo de " + p.nombre())
                    .setMessage(p.cal + " estirada: " + Formula.n(t[0]) + " × " + Formula.n(t[1]) + " mm.\nLas líneas punteadas son los dobleces (con su radio ya descontado).")
                    .setPositiveButton("Ver", null).show();
        });
    }

    // ---------------- Versión 4.5: maquinado sobre una pieza ----------------

    private static float pp3(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    /** El boceto en los ejes de la pieza, para que se mueva con ella. */
    private float[] relativo(Pieza p, Hoja h) {
        float[] ini = p.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(p);
        float[] d = {h.o[0] - ini[0], h.o[1] - ini[1], h.o[2] - ini[2]};
        return new float[]{pp3(d, e[0]), pp3(d, e[1]), pp3(d, e[2]), pp3(h.ex, e[0]), pp3(h.ex, e[1]), pp3(h.ex, e[2]), pp3(h.ey, e[0]), pp3(h.ey, e[1]), pp3(h.ey, e[2])};
    }

    /** Los bocetos hechos sobre una pieza se van con ella si la pieza se mueve o se gira. */
    private void seguirPiezas() {
        for (Hoja h : hojas) {
            if (h.pieza < 0 || h.rel == null) continue;
            Pieza p = porId(h.pieza);
            if (p == null) { h.pieza = -1; continue; }
            float[] ini = p.inicio(mapaPiezas(), 0);
            float[][] e = Vista3D.ejes(p);
            float[] r = h.rel;
            for (int k = 0; k < 3; k++) {
                h.o[k] = ini[k] + e[0][k] * r[0] + e[1][k] * r[1] + e[2][k] * r[2];
                h.ex[k] = e[0][k] * r[3] + e[1][k] * r[4] + e[2][k] * r[5];
                h.ey[k] = e[0][k] * r[6] + e[1][k] * r[7] + e[2][k] * r[8];
            }
        }
    }

    /** La forma del boceto medida sobre la pieza. cara = cara del tubo (0..3) o -1 en placas. */
    private float[][] formaEn(Pieza p, Hoja h, double[][] pol, int cara) {
        float[] ini = p.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(p);
        float[] ax1 = p.tipo == Pieza.PLACA ? e[1] : e[0];
        float[] ax2 = p.tipo == Pieza.PLACA ? e[2] : (cara <= 1 ? e[1] : e[2]);
        float[][] r = new float[pol.length][2];
        for (int i = 0; i < pol.length; i++) {
            float[] w = h.mundo(pol[i][0], pol[i][1]);
            float[] d = {w[0] - ini[0], w[1] - ini[1], w[2] - ini[2]};
            r[i][0] = pp3(d, ax1);
            r[i][1] = pp3(d, ax2);
        }
        return r;
    }

    /** v6.3: los puntos del boceto en medidas de la pieza (d, s, u desde su inicio). */
    private float[][] formaEn3(Pieza p, Hoja h, double[][] pol) {
        float[] ini = p.inicio(mapaPiezas(), 0);
        float[][] e = Vista3D.ejes(p);
        float[][] r = new float[pol.length][3];
        for (int i = 0; i < pol.length; i++) {
            float[] w = h.mundo(pol[i][0], pol[i][1]);
            float[] d = {w[0] - ini[0], w[1] - ini[1], w[2] - ini[2]};
            r[i][0] = pp3(d, e[0]); r[i][1] = pp3(d, e[1]); r[i][2] = pp3(d, e[2]);
        }
        return r;
    }

    private void medirForma(Pieza.Hueco hu) {
        float a0 = Float.MAX_VALUE, a1 = -Float.MAX_VALUE, b0 = Float.MAX_VALUE, b1 = -Float.MAX_VALUE;
        for (float[] q : hu.forma) { a0 = Math.min(a0, q[0]); a1 = Math.max(a1, q[0]); b0 = Math.min(b0, q[1]); b1 = Math.max(b1, q[1]); }
        hu.d1 = a1 - a0; hu.d2 = b1 - b0; hu.pos = (a0 + a1) / 2; hu.s = (a0 + a1) / 2; hu.u = (b0 + b1) / 2;
    }

    private void maquinar(Hoja h, Editar2D.Figura f, Pieza p, int como, float hondo) {
        int cara = -1;
        if (p.tipo == Pieza.PLACA) {
            boolean deLado = Math.abs(pp3(h.normal(), Vista3D.ejes(p)[0])) < 0.9f;
            if (deLado || como == 2 && !p.lamina) {   // v6.3: corte en cualquier cara (lados y puntas) = resta de sólidos
                if (p.lamina && !p.dobleces.isEmpty()) { aviso("En una lámina doblada el corte se hace en la cara grande; los lados se trabajan en el desarrollo"); return; }
                antes();
                Pieza.Corte c = new Pieza.Corte();
                c.forma = formaEn3(p, h, f.pol);
                float[][] e = Vista3D.ejes(p);
                float[] n = h.normal();
                c.n = new float[]{pp3(n, e[0]), pp3(n, e[1]), pp3(n, e[2])};
                c.pasante = como != 2;
                c.hondo = como == 2 ? Math.max(0.1f, hondo) : 0;
                c.hoja = h.id;
                c.ents = new ArrayList<>(f.borde);
                p.cortes.add(c);
                escogida = p.id;
                vista.hojaResaltada = -1;
                mostrar(1);
                recalcular();
                aviso("✂ Corte hecho en " + p.nombre() + (c.pasante ? " (pasante)" : " (" + Pieza.n(c.hondo) + " mm de hondo)") + ". Si cambia " + h.nombre + ", el corte cambia solo");
                return;
            }
        }
        if (p.tipo != Pieza.PLACA) {
            float[][] e = Vista3D.ejes(p);
            float[] n = h.normal();
            float ku = pp3(n, e[2]), ks = pp3(n, e[1]);
            if (ku > 0.7f) cara = 0; else if (ku < -0.7f) cara = 1; else if (ks > 0.7f) cara = 2; else if (ks < -0.7f) cara = 3;
            else { aviso("Ese boceto no está sobre una cara plana de " + p.nombre() + " (las puntas no se maquinan aquí)"); return; }
        }
        antes();
        Pieza.Hueco hu = new Pieza.Hueco();
        hu.tipo = 4;
        hu.cara = Math.max(0, cara);
        hu.pasante = como == 0;
        hu.hondo = como == 2 ? Math.max(0.1f, hondo) : 0;
        hu.hoja = h.id;
        hu.ents = new ArrayList<>(f.borde);
        hu.forma = formaEn(p, h, f.pol, cara);
        medirForma(hu);
        p.huecos.add(hu);
        escogida = p.id;
        vista.hojaResaltada = -1;
        mostrar(1);
        recalcular();
        aviso("✔ " + p.nombre() + ": " + hu.texto() + ". Si cambia " + h.nombre + ", el maquinado cambia solo");
    }

    /** Si cambian las cotas del boceto, el maquinado cambia. */
    private void actualizarMaquinados() {
        for (Pieza p : piezas) for (Pieza.Corte c : p.cortes) {   // v6.3
            if (c.hoja < 0 || c.ents.isEmpty()) continue;
            Hoja h = porHoja(c.hoja);
            if (h == null) continue;
            double[][] pol = Editar2D.poligono(h.b, c.ents);
            if (pol == null || pol.length < 3) continue;
            c.forma = formaEn3(p, h, pol);
        }
        for (Pieza p : piezas) for (Pieza.Hueco hu : p.huecos) {
            if (hu.tipo != 4 || hu.hoja < 0 || hu.ents.isEmpty()) continue;
            Hoja h = porHoja(hu.hoja);
            if (h == null) continue;
            double[][] pol = Editar2D.poligono(h.b, hu.ents);
            if (pol == null || pol.length < 3) continue;
            hu.forma = formaEn(p, h, pol, p.tipo == Pieza.PLACA ? -1 : hu.cara);
            medirForma(hu);
        }
    }
}
