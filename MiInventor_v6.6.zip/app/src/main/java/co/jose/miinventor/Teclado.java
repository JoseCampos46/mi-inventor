package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * v6.4 Chepe CAD: el teclado propio, como el de Floor Plan (números, punto, borrar, + − × ÷ y OK).
 * No sale el teclado del celular. Se puede poner el cursor donde quiera y cambiar solo ese número.
 */
final class Teclado {

    interface Listo { void valor(double v); }
    interface ListoTexto { void texto(String t); }

    // ---------------- v6.6: casillas limpias en toda la app ----------------

    /** Lo que dice la casilla; si está vacía, lo que traía antes (guardado aparte, sin mostrarlo). */
    static String tx(android.widget.TextView e) {
        String t = e.getText() == null ? "" : e.getText().toString();
        if (t.trim().isEmpty() && e instanceof EditText && e.getTag() instanceof String) return (String) e.getTag();
        return t;
    }

    /** Casilla de número: sale VACÍA, no abre el teclado del celular y al tocarla abre el teclado de Chepe CAD. */
    static void numero(Activity act, EditText e, String titulo, String antes) {
        e.setText("");
        e.setHint("");
        e.setTag(antes == null ? "" : antes);
        e.setShowSoftInputOnFocus(false);
        e.setFocusable(false);
        e.setOnClickListener(v -> pedirFormula(act, titulo, tx(e), t -> e.setText(t)));
    }

    /** Casilla de letras (nombres): el teclado del celular sale solo cuando se toca la casilla. */
    static void letras(Activity act, EditText e) {
        e.setShowSoftInputOnFocus(false);
        e.setFocusable(false);
        e.setOnClickListener(v -> llamarTeclado(act, e));
    }

    static void llamarTeclado(Activity act, EditText e) {
        e.setShowSoftInputOnFocus(true);
        e.setFocusableInTouchMode(true);
        e.setFocusable(true);
        e.requestFocus();
        Object o = act.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if (o instanceof android.view.inputmethod.InputMethodManager)
            ((android.view.inputmethod.InputMethodManager) o).showSoftInput(e, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
    }

    static boolean esNumero(String v) {
        if (v == null) return false;
        String t = v.trim().replace(',', '.');
        return t.matches("-?[0-9]*\\.?[0-9]+");
    }

    /** El teclado que devuelve lo escrito (número o fórmula con nombres de la tablita). */
    static void pedirFormula(Activity act, String titulo, String antes, ListoTexto lt) {
        armar(act, titulo, antes, null, lt);
    }

    static void pedir(Activity act, String titulo, double valor, Listo listo) {
        armar(act, titulo, Double.isNaN(valor) || valor == 0 ? "" : Pieza.n((float) valor), listo, null);
    }

    private static void armar(Activity act, String titulo, String antes, Listo listo, ListoTexto lt) {
        if (antes != null && !antes.trim().isEmpty()) titulo = titulo + "  (ahora " + antes.trim() + ")";
        float d = act.getResources().getDisplayMetrics().density;
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding((int) (12 * d), (int) (6 * d), (int) (12 * d), (int) (6 * d));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        EditText pantalla = new EditText(act);
        pantalla.setShowSoftInputOnFocus(false);
        // v6.6: arranca vacío y sin letras grises; lo que había sale en el título
        String ini = "";
        pantalla.setText(ini);
        pantalla.setTextSize(24);
        pantalla.setSingleLine(true);
        pantalla.setSelection(ini.length());
        arriba.addView(pantalla, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mm = new TextView(act);
        mm.setText(" mm ");
        mm.setTextSize(16);
        arriba.addView(mm);
        l.addView(arriba);
        TextView error = new TextView(act);
        error.setTextColor(0xFFE53935);
        error.setTextSize(13);
        l.addView(error);
        AlertDialog[] dlg = new AlertDialog[1];
        Runnable ok = () -> {
            try {
                String tx = pantalla.getText().toString().trim();
                if (tx.isEmpty() && antes != null) tx = antes.trim();   // OK sin escribir = deja el que estaba
                if (lt != null) {   // fórmula: puede llevar nombres de la tablita
                    if (tx.isEmpty()) { error.setText("Escriba la medida"); return; }
                    if (!tx.matches(".*[A-Za-zÁÉÍÓÚáéíóúñÑ].*")) Formula.calcular(tx, k -> null);
                    dlg[0].dismiss();
                    lt.texto(tx);
                    return;
                }
                double v = Formula.calcular(tx, k -> null);
                dlg[0].dismiss();
                listo.valor(v);
            } catch (Throwable t) {
                error.setText("Revise el número");
            }
        };
        String[][] teclas = {
                {"7", "8", "9", "⌫", "OK"},
                {"4", "5", "6", "(", ")"},
                {"1", "2", "3", "÷", "×"},
                {"✕", "0", ".", "−", "+"}};
        for (String[] f : teclas) {
            LinearLayout fila = new LinearLayout(act);
            for (String k : f) {
                TextView t = new TextView(act);
                t.setText(k);
                t.setTextSize(22);
                t.setGravity(Gravity.CENTER);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                boolean num = k.matches("[0-9.]");
                t.setTextColor(k.equals("OK") ? Color.WHITE : 0xFF212121);
                GradientDrawable g = new GradientDrawable();
                g.setColor(k.equals("OK") ? 0xFF2E7D32 : num ? 0xFFE0E0E0 : 0xFFCFD8DC);
                g.setCornerRadius(8 * d);
                t.setBackground(g);
                t.setPadding(0, (int) (12 * d), 0, (int) (12 * d));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
                p.setMargins((int) (3 * d), (int) (3 * d), (int) (3 * d), (int) (3 * d));
                fila.addView(t, p);
                t.setOnClickListener(v -> {
                    error.setText("");
                    String s = pantalla.getText().toString();
                    int c = Math.max(0, Math.min(s.length(), pantalla.getSelectionStart()));
                    switch (k) {
                        case "OK": ok.run(); return;
                        case "✕": dlg[0].dismiss(); return;
                        case "⌫":
                            if (c > 0) { pantalla.setText(s.substring(0, c - 1) + s.substring(c)); pantalla.setSelection(c - 1); }
                            return;
                        default: {
                            String ins = k.equals("−") ? "-" : k;
                            pantalla.setText(s.substring(0, c) + ins + s.substring(c));
                            pantalla.setSelection(c + ins.length());
                        }
                    }
                });
            }
            l.addView(fila);
        }
        // v6.6: el teclado del celular solo si usted lo llama (para fórmulas con nombres)
        TextView kb = new TextView(act);
        kb.setText("⌨ Teclado del celular (para letras)");
        kb.setTextSize(14);
        kb.setGravity(Gravity.CENTER);
        kb.setTextColor(0xFF455A64);
        kb.setPadding(0, (int) (10 * d), 0, (int) (6 * d));
        kb.setOnClickListener(v -> llamarTeclado(act, pantalla));
        l.addView(kb);
        dlg[0] = new AlertDialog.Builder(act).setTitle(titulo).setView(l).create();
        dlg[0].show();
    }
}
