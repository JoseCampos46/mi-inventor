package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * v6.4 ChpWork: el teclado propio, como el de Floor Plan (números, punto, borrar, + − × ÷ y OK).
 * No sale el teclado del celular. Se puede poner el cursor donde quiera y cambiar solo ese número.
 */
final class Teclado {

    interface Listo { void valor(double v); }
    interface ListoTexto { void texto(String t); }

    // ---------------- v6.6: casillas limpias en toda la app ----------------

    /** Lo que dice la casilla; si está vacía, lo que traía antes (guardado aparte, sin mostrarlo). */
    static String tx(android.widget.TextView e) {
        String t = e.getText() == null ? "" : e.getText().toString();
        if (t.trim().isEmpty() && e instanceof EditText && e.getTag() instanceof String) return (String) e.getTag();
        return t;
    }

    /** Casilla de número: sale VACÍA, no abre el teclado del celular y al tocarla abre el teclado de ChpWork. */
    static void numero(Activity act, EditText e, String titulo, String antes) {
        e.setText("");
        e.setHint("");
        e.setTag(antes == null ? "" : antes);
        e.setShowSoftInputOnFocus(false);
        e.setFocusable(false);
        e.setOnClickListener(v -> pedirFormula(act, titulo, tx(e), t -> e.setText(t)));
    }

    /** Casilla de letras (nombres): el teclado del celular sale solo cuando se toca la casilla. */
    static void letras(Activity act, EditText e) {
        e.setShowSoftInputOnFocus(false);
        e.setFocusable(false);
        e.setOnClickListener(v -> llamarTeclado(act, e));
    }

    static void llamarTeclado(Activity act, EditText e) {
        e.setShowSoftInputOnFocus(true);
        e.setFocusableInTouchMode(true);
        e.setFocusable(true);
        e.requestFocus();
        Object o = act.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if (o instanceof android.view.inputmethod.InputMethodManager)
            ((android.view.inputmethod.InputMethodManager) o).showSoftInput(e, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
    }

    static boolean esNumero(String v) {
        if (v == null) return false;
        String t = v.trim().replace(',', '.');
        return t.matches("-?[0-9]*\\.?[0-9]+");
    }

    /** El teclado que devuelve lo escrito (número o fórmula con nombres de la tablita). */
    static void pedirFormula(Activity act, String titulo, String antes, ListoTexto lt) {
        armar(act, titulo, antes, null, lt);
    }

    static void pedir(Activity act, String titulo, double valor, Listo listo) {
        armar(act, titulo, Double.isNaN(valor) || valor == 0 ? "" : Pieza.n((float) valor), listo, null);
    }

    /** v6.9: 1/4 → pulgadas. Una fracción sola (o con entero: 1 1/2) se vuelve pulg(…) = mm. Para dividir se usa ÷. */
    static String pulgadas(String t) {
        if (t == null) return "";
        String x = t.trim();
        // v7.3: «″» = pulgadas enteras (2″ = 50.8 mm) · pulgada y media: 1+1/2 (entero de 1 o 2 cifras + fracción)
        x = x.replaceAll("(\\d+(?:\\.\\d+)?)\\s*[\u2033\"]", "pulg($1)");
        x = x.replaceAll("(?<![\\w.)])(\\d{1,2})\\s*\\+\\s*(\\d+)\\s*/\\s*(\\d+)(?![\\w.(])", "pulg($1+$2/$3)");
        // la fracción sola: se guarda de una en milímetros
        java.util.regex.Matcher m1 = java.util.regex.Pattern.compile("^(\\d+)\\s+(\\d+)\\s*/\\s*(\\d+)$").matcher(x);
        java.util.regex.Matcher m2 = java.util.regex.Pattern.compile("^(\\d+(?:\\.\\d+)?)\\s*/\\s*(\\d+)$").matcher(x);
        if (m1.matches() || m2.matches()) {
            double ent = 0, num, den;
            if (m1.matches()) { ent = Double.parseDouble(m1.group(1)); num = Double.parseDouble(m1.group(2)); den = Double.parseDouble(m1.group(3)); }
            else { num = Double.parseDouble(m2.group(1)); den = Double.parseDouble(m2.group(2)); }
            if (den == 0) return x;
            return Formula.n(Math.round((ent + num / den) * 25.4 * 100) / 100.0);
        }
        // dentro de una fórmula: cada fracción va como pulg(…)
        return x.replaceAll("(?<![\\w.)])(\\d+)\\s+(\\d+)\\s*/\\s*(\\d+)(?![\\w.(])", "pulg($1+$2/$3)")
                .replaceAll("(?<![\\w.)+])(\\d+(?:\\.\\d+)?)\\s*/\\s*(\\d+)(?![\\w.(])", "pulg($1/$2)");
    }

    private static TextView tecla(Activity act, String k, float d, int fondo, int letra) {
        TextView t = new TextView(act);
        t.setText(k);
        t.setTextSize(k.length() > 2 ? 17 : 22);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(letra);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(8 * d);
        t.setBackground(g);
        t.setPadding(0, (int) (12 * d), 0, (int) (12 * d));
        return t;
    }

    private static void armar(Activity act, String titulo, String antes, Listo listo, ListoTexto lt) {
        if (antes != null && !antes.trim().isEmpty()) titulo = titulo + "  (ahora " + antes.trim() + ")";
        float d = act.getResources().getDisplayMetrics().density;
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding((int) (12 * d), (int) (6 * d), (int) (12 * d), (int) (6 * d));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        EditText pantalla = new EditText(act);
        pantalla.setShowSoftInputOnFocus(false);
        String ini = "";
        pantalla.setText(ini);
        pantalla.setTextSize(24);
        pantalla.setSingleLine(true);
        pantalla.setSelection(ini.length());
        arriba.addView(pantalla, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mm = new TextView(act);
        mm.setText(" mm ");
        mm.setTextSize(16);
        arriba.addView(mm);
        l.addView(arriba);
        // v6.9: el resultado en vivo (1/4 = 6.35 mm · L1 + 20 = fórmula)
        TextView vivo = new TextView(act);
        vivo.setTextColor(0xFF1B5E20);
        vivo.setTextSize(17);
        vivo.setTypeface(Typeface.DEFAULT_BOLD);
        l.addView(vivo);
        TextView error = new TextView(act);
        error.setTextColor(0xFFE53935);
        error.setTextSize(13);
        l.addView(error);
        pantalla.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int e) { }
            public void onTextChanged(CharSequence a, int b, int c, int e) { }
            public void afterTextChanged(android.text.Editable e) {
                String tx = e.toString().trim();
                if (tx.isEmpty()) { vivo.setText(""); return; }
                try {
                    String f = pulgadas(tx);
                    if (f.replace("pulg", "").matches(".*[A-Za-zÁÉÍÓÚáéíóúñÑ].*")) { vivo.setText("= fórmula: " + f); return; }
                    vivo.setText("= " + Formula.n(Math.round(Formula.calcular(f, k -> null) * 100) / 100.0) + " mm");
                } catch (Throwable t) { vivo.setText(""); }
            }
        });
        AlertDialog[] dlg = new AlertDialog[1];
        Runnable ok = () -> {
            try {
                String tx = pantalla.getText().toString().trim();
                if (tx.isEmpty() && antes != null) tx = antes.trim();   // OK sin escribir = deja el que estaba
                tx = pulgadas(tx);
                if (lt != null) {   // fórmula: puede llevar nombres de la tablita (L1, H2…)
                    if (tx.isEmpty()) { error.setText("Escriba la medida"); return; }
                    if (!tx.replace("pulg", "").matches(".*[A-Za-zÁÉÍÓÚáéíóúñÑ].*")) Formula.calcular(tx, k -> null);
                    dlg[0].dismiss();
                    lt.texto(tx);
                    return;
                }
                double v = Formula.calcular(tx, k -> null);
                dlg[0].dismiss();
                listo.valor(v);
            } catch (Throwable t) {
                error.setText("Revise el número");
            }
        };
        // v6.9: «/» = pulgadas (1/4 = 6.35 mm) · «÷» = dividir · ◀ ▶ mueven el cursor · ABC = letras
        String[][] teclas = {
                {"7", "8", "9", "/", "⌫"},
                {"4", "5", "6", "×", "("},
                {"1", "2", "3", "−", ")"},
                {"0", ".", "÷", "+", "\u2033"},
                {"ABC", "◀", "▶", "✕", "OK"}};
        for (String[] f : teclas) {
            LinearLayout fila = new LinearLayout(act);
            for (String k : f) {
                boolean num = k.matches("[0-9.]");
                int fondo = k.equals("OK") ? 0xFF2E7D32 : k.equals("ABC") ? 0xFF1565C0 : k.equals("⌫") || k.equals("✕") ? 0xFFC62828 : num ? 0xFFE0E0E0 : 0xFFCFD8DC;
                int letra = k.equals("OK") || k.equals("ABC") || k.equals("⌫") || k.equals("✕") ? Color.WHITE : k.equals("/") ? 0xFFE65100 : 0xFF212121;
                TextView t = tecla(act, k, d, fondo, letra);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
                p.setMargins((int) (3 * d), (int) (3 * d), (int) (3 * d), (int) (3 * d));
                fila.addView(t, p);
                t.setOnClickListener(v -> {
                    error.setText("");
                    String s = pantalla.getText().toString();
                    int c = Math.max(0, Math.min(s.length(), pantalla.getSelectionStart()));
                    switch (k) {
                        case "OK": ok.run(); return;
                        case "✕": dlg[0].dismiss(); return;
                        case "ABC": llamarTeclado(act, pantalla); return;
                        case "◀": if (c > 0) pantalla.setSelection(c - 1); return;
                        case "▶": if (c < s.length()) pantalla.setSelection(c + 1); return;
                        case "⌫":
                            if (c > 0) { pantalla.setText(s.substring(0, c - 1) + s.substring(c)); pantalla.setSelection(c - 1); }
                            return;
                        default: {
                            String ins = k.equals("−") ? "-" : k;
                            pantalla.setText(s.substring(0, c) + ins + s.substring(c));
                            pantalla.setSelection(c + ins.length());
                        }
                    }
                });
            }
            l.addView(fila);
        }
        TextView kb = new TextView(act);
        kb.setText("/ = pulgadas (1/4 → 6.35 mm) · ″ = pulgadas enteras (2″ → 50.8) · ÷ = dividir · ABC = letras");
        kb.setTextSize(12);
        kb.setGravity(Gravity.CENTER);
        kb.setTextColor(0xFF455A64);
        kb.setPadding(0, (int) (6 * d), 0, (int) (4 * d));
        l.addView(kb);
        dlg[0] = new AlertDialog.Builder(act).setTitle(titulo).setView(l).create();
        dlg[0].show();
    }
}
