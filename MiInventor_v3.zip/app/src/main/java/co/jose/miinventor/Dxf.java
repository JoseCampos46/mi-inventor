package co.jose.miinventor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Versión 3: abrir y guardar planos DXF (el formato abierto de AutoCAD), en milímetros.
 * Se guarda en DXF R12 (el que abre cualquier programa). Se leen líneas, polilíneas, círculos, arcos y textos.
 */
public final class Dxf {

    private Dxf() {}

    // ---------------- Guardar ----------------

    private static String n(double v) {
        String s = String.format(Locale.US, "%.4f", v);
        if (s.contains(".")) { s = s.replaceAll("0+$", ""); if (s.endsWith(".")) s = s.substring(0, s.length() - 1); }
        return s.equals("-0") ? "0" : s;
    }

    private static void g(StringBuilder sb, int codigo, String valor) { sb.append(codigo).append('\n').append(valor).append('\n'); }

    private static void linea(StringBuilder sb, String capa, double x1, double y1, double x2, double y2) {
        g(sb, 0, "LINE"); g(sb, 8, capa);
        g(sb, 10, n(x1)); g(sb, 20, n(y1)); g(sb, 30, "0");
        g(sb, 11, n(x2)); g(sb, 21, n(y2)); g(sb, 31, "0");
    }

    private static void texto(StringBuilder sb, String capa, double x, double y, double alto, double ang, String t) {
        g(sb, 0, "TEXT"); g(sb, 8, capa);
        g(sb, 10, n(x)); g(sb, 20, n(y)); g(sb, 30, "0");
        g(sb, 40, n(alto)); g(sb, 1, t.replace('\n', ' '));
        if (Math.abs(ang) > 1e-6) g(sb, 50, n(ang));
    }

    /** El boceto en texto DXF. Capas: PIEZAS (el dibujo), COTAS y TEXTOS. */
    public static String exportar(Boceto b, VistaBoceto vista) {
        StringBuilder sb = new StringBuilder();
        double[] caja = b.caja();
        double tam = Math.max(caja[2] - caja[0], caja[3] - caja[1]);
        double altoCota = Math.max(20, Math.round(tam / 60 / 5) * 5.0), sep = altoCota * 2.2;
        g(sb, 0, "SECTION"); g(sb, 2, "HEADER");
        g(sb, 9, "$ACADVER"); g(sb, 1, "AC1009");
        g(sb, 9, "$EXTMIN"); g(sb, 10, n(caja[0])); g(sb, 20, n(caja[1])); g(sb, 30, "0");
        g(sb, 9, "$EXTMAX"); g(sb, 10, n(caja[2])); g(sb, 20, n(caja[3])); g(sb, 30, "0");
        g(sb, 0, "ENDSEC");
        g(sb, 0, "SECTION"); g(sb, 2, "ENTITIES");
        for (Boceto.Ent e : b.ents) {
            Boceto.Punto a = b.puntos.get(e.a);
            if (a == null) continue;
            switch (e.tipo) {
                case Boceto.LINEA: {
                    Boceto.Punto q = b.puntos.get(e.b);
                    if (q != null) linea(sb, "PIEZAS", a.x, a.y, q.x, q.y);
                    break;
                }
                case Boceto.CIRCULO:
                    g(sb, 0, "CIRCLE"); g(sb, 8, "PIEZAS");
                    g(sb, 10, n(a.x)); g(sb, 20, n(a.y)); g(sb, 30, "0"); g(sb, 40, n(e.r));
                    break;
                case Boceto.ARCO: {
                    Boceto.Punto p1 = b.puntos.get(e.b), p2 = b.puntos.get(e.c);
                    if (p1 == null || p2 == null) break;
                    g(sb, 0, "ARC"); g(sb, 8, "PIEZAS");
                    g(sb, 10, n(a.x)); g(sb, 20, n(a.y)); g(sb, 30, "0"); g(sb, 40, n(e.r));
                    g(sb, 50, n(Math.toDegrees(Editar2D.ang(a.x, a.y, p1.x, p1.y))));
                    g(sb, 51, n(Math.toDegrees(Editar2D.ang(a.x, a.y, p2.x, p2.y))));
                    break;
                }
                case Boceto.TEXTO:
                    texto(sb, "TEXTOS", a.x, a.y, e.r <= 0 ? 150 : e.r, 0, e.texto);
                    break;
            }
        }
        // las cotas: líneas y el número, en la capa COTAS
        for (Boceto.Restr r : b.restr) {
            if (!r.esCota()) continue;
            String t = vista != null ? vista.textoCota(r) : Formula.n(b.medir(r));
            switch (r.tipo) {
                case Boceto.C_LARGO: case Boceto.C_DIST: case Boceto.C_HORIZ: case Boceto.C_VERT: {
                    Boceto.Punto p, q;
                    if (r.tipo == Boceto.C_LARGO) {
                        Boceto.Ent e = b.entPorId(r.e1);
                        if (e == null) continue;
                        p = b.puntos.get(e.a); q = b.puntos.get(e.b);
                    } else { p = b.puntos.get(r.p1); q = b.puntos.get(r.p2); }
                    if (p == null || q == null) continue;
                    double l1x, l1y, l2x, l2y;
                    if (r.tipo == Boceto.C_HORIZ) { double y = Math.max(p.y, q.y) + sep; l1x = p.x; l1y = y; l2x = q.x; l2y = y; }
                    else if (r.tipo == Boceto.C_VERT) { double x = Math.max(p.x, q.x) + sep; l1x = x; l1y = p.y; l2x = x; l2y = q.y; }
                    else {
                        double vx = q.x - p.x, vy = q.y - p.y, l = Math.hypot(vx, vy);
                        if (l < 1e-9) continue;
                        double dx = -vy / l, dy = vx / l;
                        if (dy < 0 || (Math.abs(dy) < 1e-6 && dx < 0)) { dx = -dx; dy = -dy; }
                        l1x = p.x + dx * sep; l1y = p.y + dy * sep; l2x = q.x + dx * sep; l2y = q.y + dy * sep;
                    }
                    linea(sb, "COTAS", p.x, p.y, l1x, l1y);
                    linea(sb, "COTAS", q.x, q.y, l2x, l2y);
                    linea(sb, "COTAS", l1x, l1y, l2x, l2y);
                    double ang = Math.toDegrees(Math.atan2(l2y - l1y, l2x - l1x));
                    if (ang > 90) ang -= 180;
                    if (ang <= -90) ang += 180;
                    double mx = (l1x + l2x) / 2, my = (l1y + l2y) / 2;
                    double ra = Math.toRadians(ang);
                    double ancho = t.length() * altoCota * 0.8;
                    texto(sb, "COTAS", mx - Math.cos(ra) * ancho / 2 - Math.sin(ra) * altoCota * 0.4,
                            my - Math.sin(ra) * ancho / 2 + Math.cos(ra) * altoCota * 0.4, altoCota, ang, t);
                    break;
                }
                case Boceto.C_RADIO: case Boceto.C_DIAM: {
                    Boceto.Ent e = b.entPorId(r.e1);
                    if (e == null) continue;
                    Boceto.Punto c = b.puntos.get(e.a);
                    if (c == null) continue;
                    double k = 0.7071, ex = c.x + k * e.r, ey = c.y + k * e.r;
                    linea(sb, "COTAS", r.tipo == Boceto.C_DIAM ? c.x - k * e.r : c.x, r.tipo == Boceto.C_DIAM ? c.y - k * e.r : c.y, ex, ey);
                    texto(sb, "COTAS", ex + altoCota * 0.3, ey + altoCota * 0.3, altoCota, 0, t);
                    break;
                }
                case Boceto.C_ANG: {
                    Boceto.Ent e = b.entPorId(r.e1), f = b.entPorId(r.e2);
                    if (e == null || f == null) continue;
                    Boceto.Punto a = b.puntos.get(e.a), q = b.puntos.get(f.a);
                    if (a == null || q == null) continue;
                    texto(sb, "COTAS", (a.x + q.x) / 2, (a.y + q.y) / 2, altoCota, 0, t);
                    break;
                }
            }
        }
        g(sb, 0, "ENDSEC");
        g(sb, 0, "EOF");
        return sb.toString();
    }

    // ---------------- Abrir ----------------

    /** Lo que trajo el DXF (para avisar). */
    public static class Resultado {
        public int lineas, circulos, arcos, textos, omitidos;
        public String unidades = "mm";
        public int total() { return lineas + circulos + arcos + textos; }
    }

    /** Lee el texto DXF y agrega el dibujo al boceto (en mm). Los puntos que coinciden quedan unidos. */
    public static Resultado importar(String texto, Boceto b) {
        Resultado res = new Resultado();
        String[] ln = texto.replace("\r", "").split("\n");
        List<String[]> pares = new ArrayList<>();
        for (int i = 0; i + 1 < ln.length; i += 2) pares.add(new String[]{ln[i].trim(), ln[i + 1].trim()});
        // unidades del encabezado ($INSUNITS)
        double f = 1;
        for (int i = 0; i + 1 < pares.size(); i++) {
            if (pares.get(i)[0].equals("9") && pares.get(i)[1].equals("$INSUNITS") && pares.get(i + 1)[0].equals("70")) {
                int u = entero(pares.get(i + 1)[1]);
                if (u == 1) { f = 25.4; res.unidades = "pulgadas"; }
                else if (u == 2) { f = 304.8; res.unidades = "pies"; }
                else if (u == 5) { f = 10; res.unidades = "cm"; }
                else if (u == 6) { f = 1000; res.unidades = "metros"; }
            }
        }
        // solo la sección ENTITIES
        int ini = -1, fin = pares.size();
        for (int i = 0; i + 1 < pares.size(); i++) {
            if (pares.get(i)[0].equals("0") && pares.get(i)[1].equals("SECTION") && pares.get(i + 1)[0].equals("2") && pares.get(i + 1)[1].equals("ENTITIES")) { ini = i + 2; }
            if (ini >= 0 && i >= ini && pares.get(i)[0].equals("0") && pares.get(i)[1].equals("ENDSEC")) { fin = i; break; }
        }
        if (ini < 0) return res;
        Map<String, Integer> unidos = new HashMap<>();
        int i = ini;
        List<double[]> poli = null;   // POLYLINE vieja (R12): se juntan sus VERTEX
        boolean poliCerrada = false;
        while (i < fin) {
            if (!pares.get(i)[0].equals("0")) { i++; continue; }
            String tipo = pares.get(i)[1];
            int j = i + 1;
            while (j < fin && !pares.get(j)[0].equals("0")) j++;
            List<String[]> d = pares.subList(i + 1, j);
            switch (tipo) {
                case "LINE": {
                    double x1 = num(d, "10") * f, y1 = num(d, "20") * f, x2 = num(d, "11") * f, y2 = num(d, "21") * f;
                    if (Math.hypot(x2 - x1, y2 - y1) > 1e-6) {
                        Boceto.Ent e = b.ent(Boceto.LINEA);
                        e.a = punto(b, unidos, x1, y1); e.b = punto(b, unidos, x2, y2);
                        res.lineas++;
                    }
                    break;
                }
                case "CIRCLE": {
                    Boceto.Ent e = b.ent(Boceto.CIRCULO);
                    e.a = punto(b, unidos, num(d, "10") * f, num(d, "20") * f);
                    e.r = num(d, "40") * f;
                    res.circulos++;
                    break;
                }
                case "ARC": {
                    double cx = num(d, "10") * f, cy = num(d, "20") * f, r = num(d, "40") * f;
                    double a1 = Math.toRadians(num(d, "50")), a2 = Math.toRadians(num(d, "51"));
                    Boceto.Ent e = b.ent(Boceto.ARCO);
                    e.a = punto(b, unidos, cx, cy);
                    e.b = punto(b, unidos, cx + r * Math.cos(a1), cy + r * Math.sin(a1));
                    e.c = punto(b, unidos, cx + r * Math.cos(a2), cy + r * Math.sin(a2));
                    e.r = r;
                    res.arcos++;
                    break;
                }
                case "LWPOLYLINE": {
                    List<double[]> pts = new ArrayList<>();
                    double xx = Double.NaN;
                    for (String[] p : d) {
                        if (p[0].equals("10")) xx = dbl(p[1]) * f;
                        else if (p[0].equals("20") && !Double.isNaN(xx)) { pts.add(new double[]{xx, dbl(p[1]) * f}); xx = Double.NaN; }
                    }
                    boolean cerrada = (entero(valor(d, "70", "0")) & 1) == 1;
                    res.lineas += poligonal(b, unidos, pts, cerrada);
                    break;
                }
                case "POLYLINE":
                    poli = new ArrayList<>();
                    poliCerrada = (entero(valor(d, "70", "0")) & 1) == 1;
                    break;
                case "VERTEX":
                    if (poli != null) poli.add(new double[]{num(d, "10") * f, num(d, "20") * f});
                    break;
                case "SEQEND":
                    if (poli != null) res.lineas += poligonal(b, unidos, poli, poliCerrada);
                    poli = null;
                    break;
                case "TEXT": case "MTEXT": {
                    String t = valor(d, "1", "").replaceAll("\\\\P", " ").replaceAll("\\\\[A-Za-z][^;]*;", "").replaceAll("[{}]", "");
                    if (t.isEmpty()) break;
                    Boceto.Punto p = b.punto(num(d, "10") * f, num(d, "20") * f);
                    Boceto.Ent e = b.ent(Boceto.TEXTO);
                    e.a = p.id; e.texto = t; e.r = Math.max(1, num(d, "40") * f);
                    res.textos++;
                    break;
                }
                default:
                    if (!tipo.equals("ENDSEC") && !tipo.equals("EOF")) res.omitidos++;
            }
            i = j;
        }
        return res;
    }

    private static int poligonal(Boceto b, Map<String, Integer> unidos, List<double[]> pts, boolean cerrada) {
        int k = 0;
        for (int i = 0; i + 1 < pts.size() + (cerrada ? 1 : 0); i++) {
            double[] p = pts.get(i), q = pts.get((i + 1) % pts.size());
            if (Math.hypot(q[0] - p[0], q[1] - p[1]) < 1e-6) continue;
            Boceto.Ent e = b.ent(Boceto.LINEA);
            e.a = punto(b, unidos, p[0], p[1]); e.b = punto(b, unidos, q[0], q[1]);
            k++;
        }
        return k;
    }

    /** Un punto en (x, y): si ya hay uno ahí (a 0.01 mm), se usa ese. */
    private static int punto(Boceto b, Map<String, Integer> unidos, double x, double y) {
        String k = Math.round(x * 100) + "," + Math.round(y * 100);
        Integer id = unidos.get(k);
        if (id != null && b.puntos.containsKey(id)) return id;
        int nuevo = b.punto(x, y).id;
        unidos.put(k, nuevo);
        return nuevo;
    }

    private static String valor(List<String[]> d, String codigo, String def) {
        for (String[] p : d) if (p[0].equals(codigo)) return p[1];
        return def;
    }

    private static double num(List<String[]> d, String codigo) { return dbl(valor(d, codigo, "0")); }

    private static double dbl(String s) { try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; } }

    private static int entero(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }
}
