package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Mi Inventor 3: boceto 2D paramétrico (en mm) con lupa, imanes, herramientas de modificar, medir y DXF;
 * estructuras 3D en tubo, ángulo y platina (amarradas por cara),
 * y un mini Excel de medidas que manda en los dos. Lista de corte para comprar barras de 6 m.
 */
public class InventorActivity extends Activity {

    private static final String ULTIMO = "_ultimo";
    private static final float BARRA = 6000f, DISCO = 3f;   // barra de 6 m y lo que se come el disco al cortar
    private static final int ABRIR_ARCHIVO = 41, ABRIR_DXF = 42;
    private static final int FONDO = 0xFF151A26;

    private final List<Pieza> piezas = new ArrayList<>();
    private final Medidas medidas = new Medidas();
    private Vista3D vista;
    private VistaBoceto boceto;
    private LinearLayout lista, listaMedidas;
    private FrameLayout contenedor;
    private View panel2D, panel3D, panelMedidas;
    private final TextView[] pestanas = new TextView[3];
    private final List<TextView> botonesModo3D = new ArrayList<>();
    private String nombreProyecto = "Sin nombre";
    private int escogida = -1;
    private int pestana = 0;

    // deshacer / rehacer: copias livianas del proyecto
    private final List<String> atras = new ArrayList<>(), adelante = new ArrayList<>();

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(FONDO);
        getWindow().setNavigationBarColor(FONDO);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(FONDO);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));

        // pestañas de arriba
        LinearLayout tabs = new LinearLayout(this);
        String[] nt = {"✏ 2D", "🧊 3D", "📊 Medidas"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            pestanas[i] = boton(nt[i], 0xFF37474F, () -> mostrar(k));
            pestanas[i].setTextSize(13);
            tabs.addView(pestanas[i], peso());
        }
        TextView tCorte = boton("📋 Corte", 0xFF43A047, this::listaCorte);
        tCorte.setTextSize(13);
        tabs.addView(tCorte, peso());
        TextView tArch = boton("📂 Archivo", 0xFF6D4C41, this::menuProyecto);
        tArch.setTextSize(13);
        tabs.addView(tArch, peso());
        raiz.addView(tabs, new LinearLayout.LayoutParams(-1, dp(44)));

        contenedor = new FrameLayout(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1f);
        cp.topMargin = dp(4);
        raiz.addView(contenedor, cp);
        panel2D = armar2D();
        panel3D = armar3D();
        panelMedidas = armarMedidas();
        contenedor.addView(panel2D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panel3D, new FrameLayout.LayoutParams(-1, -1));
        contenedor.addView(panelMedidas, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);

        abrir(ULTIMO, true);
        pestana = getPreferences(MODE_PRIVATE).getInt("pestana", 0);
        mostrar(pestana);
        recalcular();
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardar(ULTIMO, true);
        getPreferences(MODE_PRIVATE).edit().putInt("pestana", pestana).apply();
    }

    @Override
    public void onBackPressed() {
        if (pestana == 0 && boceto.modo != VistaBoceto.VER) { listo2D(); return; }
        if (pestana == 0 && (!boceto.sel.isEmpty() || !boceto.selPts.isEmpty())) { boceto.limpiarSeleccion(); return; }
        super.onBackPressed();
    }

    private void mostrar(int k) {
        pestana = k;
        panel2D.setVisibility(k == 0 ? View.VISIBLE : View.GONE);
        panel3D.setVisibility(k == 1 ? View.VISIBLE : View.GONE);
        panelMedidas.setVisibility(k == 2 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) colorear(pestanas[i], i == k ? 0xFF1E88E5 : 0xFF37474F);
        if (k == 2) pintarMedidas();
    }

    // ---------------- Ayudas ----------------

    private LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        colorear(t, color);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private void colorear(TextView t, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
    }

    private LinearLayout fila(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, peso());
        return l;
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private Pieza porId(int id) {
        for (Pieza p : piezas) if (p.id == id) return p;
        return null;
    }

    private Map<Integer, Pieza> mapa() {
        Map<Integer, Pieza> m = new HashMap<>();
        for (Pieza p : piezas) m.put(p.id, p);
        return m;
    }

    private int nuevoId() {
        int m = 0;
        for (Pieza p : piezas) m = Math.max(m, p.id);
        return m + 1;
    }

    // ---------------- Deshacer ----------------

    /** Guarda una copia antes de cambiar algo. */
    private void antes() {
        try {
            atras.add(proyecto().toString());
            if (atras.size() > 60) atras.remove(0);
            adelante.clear();
        } catch (Exception ignored) {}
    }

    private void deshacer() {
        if (atras.isEmpty()) { aviso("No hay nada para deshacer"); return; }
        try {
            adelante.add(proyecto().toString());
            cargar(new JSONObject(atras.remove(atras.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo deshacer"); }
    }

    private void rehacer() {
        if (adelante.isEmpty()) { aviso("No hay nada para rehacer"); return; }
        try {
            atras.add(proyecto().toString());
            cargar(new JSONObject(adelante.remove(adelante.size() - 1)));
            recalcular();
        } catch (Exception e) { aviso("No se pudo rehacer"); }
    }

    /** Volver a la copia que se acaba de guardar (cuando algo no cuadró). */
    private void revertir() {
        if (atras.isEmpty()) return;
        try { cargar(new JSONObject(atras.remove(atras.size() - 1))); } catch (Exception ignored) {}
    }

    // ---------------- Todo se recalcula desde la tablita ----------------

    private void fijos() {
        medidas.fijos.clear();
        float total = 0;
        for (Pieza p : piezas) { medidas.fijos.put("T" + p.id, (double) p.largo); total += p.largo; }
        medidas.fijos.put("total", (double) total);
        medidas.fijos.put("piezas", (double) piezas.size());
    }

    /** Tablita → piezas 3D → boceto 2D. Devuelve true si el boceto cuadró. */
    private boolean recalcular() {
        fijos();
        medidas.calcular();
        String err = null;
        for (Pieza p : piezas) { String e = p.aplicarFormulas(medidas); if (err == null) err = e; }
        fijos();
        medidas.calcular();
        boolean ok = boceto.b.resolver(medidas, -1);
        boceto.invalidate();
        vista.escogida = escogida;
        vista.invalidate();
        pintarLista();
        if (pestana == 2) pintarMedidas();
        if (err != null) aviso("⚠ " + err);
        return ok;
    }

    // =====================================================================
    //                              BOCETO 2D
    // =====================================================================

    // Versión 3: abajo van 4 grupos (Dibujar, Modificar, Amarrar, Medir); cada uno muestra sus herramientas.
    private static final int G_DIBUJAR = 0, G_MODIFICAR = 1, G_AMARRAR = 2, G_MEDIR = 3;
    private int grupo2D = G_DIBUJAR;
    private final TextView[] botonesGrupo = new TextView[4];
    private LinearLayout cajaHerr, casilla;
    private EditText casilla1, casilla2;
    private TextView casillaEt1, casillaEt2;
    private String herrActiva = "Ver";
    private final Map<String, TextView> botonesHerr = new HashMap<>();
    private double ultDesfase = 50, ultRadio = 20, ultChaflan = 20;

    private View armar2D() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        boceto = new VistaBoceto(this);
        boceto.medidas = medidas;
        boceto.orto = getPreferences(MODE_PRIVATE).getBoolean("orto", false);
        boceto.oyente = new VistaBoceto.Oyente() {
            @Override public void antes() { InventorActivity.this.antes(); }
            @Override public void cambio() { boceto.b.resolver(medidas, -1); boceto.invalidate(); }
            @Override public void pedirCota(Boceto.Restr nueva) { InventorActivity.this.pedirCota(nueva, null); }
            @Override public void pedirDistancia(int p1, int p2) { InventorActivity.this.pedirDistancia(p1, p2); }
            @Override public void editarCota(Boceto.Restr r) { InventorActivity.this.editarCota(r); }
            @Override public void pedirTexto(double x, double y) { InventorActivity.this.pedirTexto(x, y); }
            @Override public void seleccion() { }
            @Override public void aviso(String s) { InventorActivity.this.aviso(s); }
        };
        l.addView(boceto, new LinearLayout.LayoutParams(-1, 0, 1f));

        // la casilla para escribir medidas (línea, rectángulo, círculo, polígono)
        casilla = new LinearLayout(this);
        casilla.setGravity(Gravity.CENTER_VERTICAL);
        casillaEt1 = etiquetaCasilla();
        casilla1 = campoCasilla();
        casillaEt2 = etiquetaCasilla();
        casilla2 = campoCasilla();
        casilla.addView(casillaEt1, new LinearLayout.LayoutParams(-2, -1));
        casilla.addView(casilla1, new LinearLayout.LayoutParams(0, -1, 1f));
        casilla.addView(casillaEt2, new LinearLayout.LayoutParams(-2, -1));
        casilla.addView(casilla2, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView ok = boton("OK", 0xFF2E7D32, this::okCasilla);
        LinearLayout.LayoutParams okp = new LinearLayout.LayoutParams(dp(56), -1);
        okp.leftMargin = dp(4);
        casilla.addView(ok, okp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(46));
        cp.topMargin = dp(4);
        l.addView(casilla, cp);
        casilla.setVisibility(View.GONE);

        // los 4 grupos
        LinearLayout grupos = new LinearLayout(this);
        String[] ng = {"✏ Dibujar", "🛠 Modificar", "🔗 Amarrar", "📐 Medir"};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            botonesGrupo[i] = boton(ng[i], 0xFF37474F, () -> grupo2D(k));
            botonesGrupo[i].setTextSize(13);
            grupos.addView(botonesGrupo[i], peso());
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(40));
        gp.topMargin = dp(4);
        l.addView(grupos, gp);

        cajaHerr = new LinearLayout(this);
        cajaHerr.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHerr, new LinearLayout.LayoutParams(-1, -2));

        // fila fija
        LinearLayout f = new LinearLayout(this);
        f.addView(boton("↶\nAtrás", 0xFF5E35B1, this::deshacer), peso());
        f.addView(boton("↷\nAdelante", 0xFF5E35B1, this::rehacer), peso());
        f.addView(boton("⛶\nVer todo", 0xFF455A64, boceto::encuadrar), peso());
        f.addView(boton("🗑\nBorrar", 0xFFC62828, this::borrar2D), peso());
        f.addView(boton("✓\nListo", 0xFF2E7D32, this::listo2D), peso());
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(46));
        fp.topMargin = dp(4);
        l.addView(f, fp);
        grupo2D(G_DIBUJAR);
        return l;
    }

    private TextView etiquetaCasilla() {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    private EditText campoCasilla() {
        EditText e = new EditText(this);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.BLACK);
        e.setHintTextColor(0xFF90A4AE);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(7));
        e.setBackground(g);
        return e;
    }

    /** Muestra el grupo de herramientas (Dibujar, Modificar, Amarrar o Medir). */
    private void grupo2D(int k) {
        grupo2D = k;
        for (int i = 0; i < 4; i++) colorear(botonesGrupo[i], i == k ? (i == G_AMARRAR ? 0xFF00897B : 0xFFFF8F00) : 0xFF37474F);
        cajaHerr.removeAllViews();
        botonesHerr.clear();
        List<Object[]> h = new ArrayList<>();   // {texto, color, acción}
        int gris = 0xFF455A64, verde = 0xFF00897B;
        switch (k) {
            case G_DIBUJAR:
                h.add(new Object[]{"✋\nVer", gris, (Runnable) () -> herr("Ver", VistaBoceto.VER)});
                h.add(new Object[]{"╱\nLínea", gris, (Runnable) () -> herr("Línea", VistaBoceto.LINEA)});
                h.add(new Object[]{"▭\nRectáng.", gris, (Runnable) () -> herr("Rectáng.", VistaBoceto.RECT)});
                h.add(new Object[]{"◯\nCírculo", gris, (Runnable) () -> herr("Círculo", VistaBoceto.CIRCULO)});
                h.add(new Object[]{"◠\nArco", gris, (Runnable) () -> herr("Arco", VistaBoceto.ARCO)});
                h.add(new Object[]{"⬡\nPolígono", gris, (Runnable) () -> herr("Polígono", VistaBoceto.POLIGONO)});
                h.add(new Object[]{"A\nTexto", gris, (Runnable) () -> herr("Texto", VistaBoceto.TEXTO)});
                h.add(new Object[]{"┼\nOrto", boceto.orto ? 0xFF1E88E5 : gris, (Runnable) this::orto});
                break;
            case G_MODIFICAR:
                h.add(new Object[]{"✥\nMover", gris, (Runnable) this::moverSel});
                h.add(new Object[]{"⧉\nCopiar", gris, (Runnable) this::copiarSel});
                h.add(new Object[]{"⟳\nRotar", gris, (Runnable) this::rotarSel});
                h.add(new Object[]{"⇋\nEspejo", gris, (Runnable) this::espejoSel});
                h.add(new Object[]{"⤢\nEscalar", gris, (Runnable) this::escalarSel});
                h.add(new Object[]{"⫽\nDesfase", gris, (Runnable) this::desfase});
                h.add(new Object[]{"✂\nRecortar", gris, (Runnable) this::recortar});
                h.add(new Object[]{"⟷\nExtender", gris, (Runnable) this::extender});
                h.add(new Object[]{"◜\nEmpalme", gris, (Runnable) () -> esquina(true)});
                h.add(new Object[]{"◸\nChaflán", gris, (Runnable) () -> esquina(false)});
                h.add(new Object[]{"⫶\nPartir", gris, (Runnable) this::partir});
                h.add(new Object[]{"▦\nMatriz", gris, (Runnable) this::matriz});
                break;
            case G_AMARRAR:
                h.add(new Object[]{"═\nHorizontal", verde, (Runnable) () -> amarrar(Boceto.HORIZ)});
                h.add(new Object[]{"║\nVertical", verde, (Runnable) () -> amarrar(Boceto.VERT)});
                h.add(new Object[]{"⊥\n90°", verde, (Runnable) () -> amarrar(Boceto.PERP)});
                h.add(new Object[]{"∥\nParalela", verde, (Runnable) () -> amarrar(Boceto.PARAL)});
                h.add(new Object[]{"=\nIgual", verde, (Runnable) () -> amarrar(Boceto.IGUAL)});
                h.add(new Object[]{"⊙\nUnir punto", verde, (Runnable) () -> amarrar(Boceto.COINC)});
                h.add(new Object[]{"◡\nTangente", verde, (Runnable) () -> amarrar(Boceto.TANG)});
                h.add(new Object[]{"📌\nFijo", verde, (Runnable) () -> amarrar(Boceto.FIJO)});
                h.add(new Object[]{"📏\nCota", 0xFF1565C0, (Runnable) () -> herr("Cota", VistaBoceto.COTA)});
                h.add(new Object[]{"∠\nÁngulo", 0xFF1565C0, (Runnable) this::cotaAngulo});
                h.add(new Object[]{"🗑\nQuitar", 0xFFC62828, (Runnable) this::amarrar2D});
                h.add(new Object[]{"👁\nMarcas", boceto.marcas ? 0xFF1E88E5 : gris, (Runnable) () -> { boceto.marcas = !boceto.marcas; boceto.invalidate(); grupo2D(G_AMARRAR); }});
                break;
            default:
                h.add(new Object[]{"✋\nEscoger", gris, (Runnable) () -> herr("Ver", VistaBoceto.VER)});
                h.add(new Object[]{"↔\nDistancia", gris, (Runnable) this::medirDistancia});
                h.add(new Object[]{"▨\nÁrea", gris, (Runnable) this::medirArea});
                h.add(new Object[]{"∠\nÁngulo", gris, (Runnable) this::medirAngulo});
        }
        LinearLayout fila = null;
        for (int i = 0; i < h.size(); i++) {
            if (i % 4 == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
                p.topMargin = dp(4);
                cajaHerr.addView(fila, p);
            }
            Object[] o = h.get(i);
            String txt = (String) o[0];
            TextView t = boton(txt, (Integer) o[1], (Runnable) o[2]);
            t.setTag(o[1]);
            botonesHerr.put(txt.substring(txt.indexOf('\n') + 1), t);
            fila.addView(t, peso());
        }
        if (k == G_AMARRAR || k == G_MEDIR || k == G_MODIFICAR) {
            if (boceto.modo != VistaBoceto.VER) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; }
        }
        boceto.medicion = null;
        boceto.lineaMedida = null;
        marcarHerr();
        mostrarCasilla();
    }

    /** Pone la herramienta de dibujo y la marca en naranja. */
    private void herr(String nombre, int modo) {
        herrActiva = nombre;
        boceto.ponerModo(modo);
        boceto.medicion = null;
        boceto.lineaMedida = null;
        marcarHerr();
        mostrarCasilla();
    }

    private void marcarHerr() {
        for (Map.Entry<String, TextView> e : botonesHerr.entrySet()) {
            TextView t = e.getValue();
            int base = t.getTag() instanceof Integer ? (Integer) t.getTag() : 0xFF455A64;
            colorear(t, e.getKey().equals(herrActiva) ? 0xFFFF8F00 : base);
        }
    }

    private void listo2D() {
        boceto.terminar();
        boceto.ponerModo(VistaBoceto.VER);
        herrActiva = "Ver";
        marcarHerr();
        mostrarCasilla();
        recalcular();
    }

    private void orto() {
        boceto.orto = !boceto.orto;
        getPreferences(MODE_PRIVATE).edit().putBoolean("orto", boceto.orto).apply();
        aviso(boceto.orto ? "Orto prendido: las líneas salen derechas o paradas" : "Orto apagado");
        grupo2D(G_DIBUJAR);
        boceto.invalidate();
    }

    // ---------------- La casilla de medidas ----------------

    private void mostrarCasilla() {
        int m = boceto.modo;
        boolean ver = m == VistaBoceto.LINEA || m == VistaBoceto.RECT || m == VistaBoceto.CIRCULO || m == VistaBoceto.POLIGONO;
        casilla.setVisibility(ver ? View.VISIBLE : View.GONE);
        if (!ver) return;
        casilla2.setVisibility(m == VistaBoceto.CIRCULO ? View.GONE : View.VISIBLE);
        casillaEt2.setVisibility(m == VistaBoceto.CIRCULO ? View.GONE : View.VISIBLE);
        if (m == VistaBoceto.LINEA) { casillaEt1.setText("Largo"); casillaEt2.setText("Ángulo"); casilla1.setHint("mm"); casilla2.setHint("0°"); }
        else if (m == VistaBoceto.RECT) { casillaEt1.setText("Ancho"); casillaEt2.setText("Alto"); casilla1.setHint("mm"); casilla2.setHint("mm"); }
        else if (m == VistaBoceto.CIRCULO) { casillaEt1.setText("Diámetro"); casilla1.setHint("mm o fórmula"); }
        else { casillaEt1.setText("Lados"); casillaEt2.setText("Radio"); casilla1.setText(String.valueOf(boceto.lados)); casilla2.setHint("mm"); }
    }

    /** Evalúa lo escrito: un número o una fórmula de la tablita. */
    private Double valorDe(String txt) {
        String t = txt == null ? "" : txt.trim();
        if (t.isEmpty()) return null;
        Double n = Formula.numero(t);
        if (n != null) return n;
        try { return medidas.evaluar(t); } catch (Exception e) { aviso("⚠ " + e.getMessage()); return null; }
    }

    private void okCasilla() {
        int m = boceto.modo;
        String t1 = casilla1.getText().toString().trim(), t2 = casilla2.getText().toString().trim();
        Double v1 = valorDe(t1);
        if (v1 == null) { if (t1.isEmpty()) aviso("Escriba la medida"); return; }
        String err;
        antes();
        if (m == VistaBoceto.LINEA) {
            Double ang = t2.isEmpty() ? Double.valueOf(0) : valorDe(t2);
            if (ang == null) { atras.remove(atras.size() - 1); return; }
            err = boceto.lineaPorMedida(t1, v1, ang);
        } else if (m == VistaBoceto.RECT) {
            Double v2 = valorDe(t2);
            if (v2 == null) { atras.remove(atras.size() - 1); aviso("Escriba el alto"); return; }
            err = boceto.rectPorMedida(t1, v1, t2, v2);
        } else if (m == VistaBoceto.CIRCULO) {
            err = boceto.circuloPorMedida(t1, v1);
        } else {
            int n = (int) Math.round(v1);
            if (n < 3 || n > 60) { atras.remove(atras.size() - 1); aviso("Los lados van de 3 a 60"); return; }
            boceto.lados = n;
            Double v2 = valorDe(t2);
            if (v2 == null) { atras.remove(atras.size() - 1); aviso("Lados: " + n + ". Ahora toque el centro y una punta, o escriba el radio"); return; }
            err = boceto.poligonoPorMedida(n, v2);
        }
        if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
        if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se puso: choca con otra medida o amarre"); return; }
        if (m == VistaBoceto.LINEA) { casilla1.setText(""); casilla2.setText(""); casilla1.requestFocus(); }
    }

    // ---------------- Modificar ----------------

    private List<Integer> escogidas() {
        List<Integer> l = new ArrayList<>();
        for (Integer id : boceto.sel) if (boceto.b.entPorId(id) != null) l.add(id);
        return l;
    }

    /** Si no hay nada escogido: avisa y deja la hoja en «escoger». */
    private boolean faltaEscoger(String que) {
        if (!escogidas().isEmpty()) return false;
        boceto.ponerModo(VistaBoceto.VER);
        herrActiva = "Ver";
        marcarHerr();
        aviso("Primero toque lo que quiere " + que + " (queda en naranja) y vuelva a tocar el botón");
        return true;
    }

    private VistaBoceto.Pedido pedido(String nombre, VistaBoceto.AlTerminar fin, String... ayudas) {
        herrActiva = nombre;
        marcarHerr();
        VistaBoceto.Pedido p = new VistaBoceto.Pedido(fin, ayudas);
        return p;
    }

    private void moverSel() {
        if (escogidas().isEmpty()) {
            herr("Mover", VistaBoceto.MOVER);
            aviso("Arrastre un punto. Para mover piezas enteras: escójalas primero y toque ✥ Mover");
            return;
        }
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Mover", t -> {
            antes();
            Editar2D.transformar(boceto.b, s, Editar2D.traslado(t.get(1).x - t.get(0).x, t.get(1).y - t.get(0).y), true, 1, false);
            despuesDeModificar("Movido");
        }, "Mover: toque el punto de agarre (por ejemplo una esquina)", "Ahora toque a dónde va ese punto");
        p.fantasma = 1;
        boceto.pedir(p);
    }

    private void copiarSel() {
        if (faltaEscoger("copiar")) return;
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Copiar", t -> {
            antes();
            List<Integer> nuevas = Editar2D.copiar(boceto.b, s, Editar2D.traslado(t.get(1).x - t.get(0).x, t.get(1).y - t.get(0).y), true, 1, false);
            boceto.sel.clear();
            boceto.sel.addAll(nuevas);
            despuesDeModificar("Copiado (la copia quedó escogida)");
        }, "Copiar: toque el punto de agarre", "Ahora toque dónde va la copia");
        p.fantasma = 1;
        boceto.pedir(p);
    }

    private void rotarSel() {
        if (faltaEscoger("rotar")) return;
        List<Integer> s = escogidas();
        boceto.pedir(pedido("Rotar", t -> {
            VistaBoceto.Toque c = t.get(0);
            EditText e = campoTexto("90", "grados");
            e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            dialogo("⟳ Rotar (grados contra el reloj; negativo = con el reloj)", e, "Rotar", () -> {
                Double g = valorDe(e.getText().toString());
                if (g == null) return;
                antes();
                int d = Editar2D.giroDerecho(g);
                Editar2D.transformar(boceto.b, s, Editar2D.giro(c.x, c.y, g), d >= 0, 1, d == 1);
                despuesDeModificar("Rotado " + Formula.n(g) + "°");
            });
        }, "Rotar: toque el punto alrededor del cual gira"));
    }

    private void espejoSel() {
        if (faltaEscoger("voltear en espejo")) return;
        List<Integer> s = escogidas();
        VistaBoceto.Pedido p = pedido("Espejo", t -> {
            double ax = t.get(0).x, ay = t.get(0).y, bx = t.get(1).x, by = t.get(1).y;
            if (Math.hypot(bx - ax, by - ay) < 0.5) { aviso("Los dos puntos del espejo deben ser distintos"); return; }
            boolean derecho = Math.abs(bx - ax) < 1e-6 || Math.abs(by - ay) < 1e-6;
            new AlertDialog.Builder(this).setTitle("⇋ Espejo")
                    .setItems(new String[]{"Dejar el original y la copia", "Quitar el original"}, (d, w) -> {
                        antes();
                        List<Integer> nuevas = Editar2D.copiar(boceto.b, s, Editar2D.espejo(ax, ay, bx, by), derecho, 1, false);
                        if (w == 1) for (Integer id : s) { Boceto.Ent e = boceto.b.entPorId(id); if (e != null) boceto.b.borrar(e); }
                        boceto.sel.clear();
                        boceto.sel.addAll(nuevas);
                        despuesDeModificar("Espejo hecho");
                    }).setNegativeButton("Cancelar", null).show();
        }, "Espejo: toque el primer punto de la línea del espejo", "Ahora toque el segundo punto de la línea del espejo");
        p.fantasma = 2;
        boceto.pedir(p);
    }

    private void escalarSel() {
        if (faltaEscoger("agrandar o achicar")) return;
        List<Integer> s = escogidas();
        boceto.pedir(pedido("Escalar", t -> {
            VistaBoceto.Toque c = t.get(0);
            EditText e = campoTexto("2", "");
            dialogo("⤢ Escalar: cuántas veces (2 = el doble, 0.5 = la mitad)", e, "Escalar", () -> {
                Double f = valorDe(e.getText().toString());
                if (f == null || f <= 0) { aviso("Escriba un número mayor que cero"); return; }
                antes();
                Editar2D.transformar(boceto.b, s, Editar2D.escala(c.x, c.y, f), true, f, false);
                despuesDeModificar("Escalado ×" + Formula.n(f));
            });
        }, "Escalar: toque el punto que se queda quieto"));
    }

    private void desfase() {
        EditText e = campoTexto(Formula.n(ultDesfase), "mm");
        dialogo("⫽ Desfase: a cuántos mm (o fórmula, ej. tubo)", e, "Seguir", () -> {
            Double d = valorDe(e.getText().toString());
            if (d == null || d <= 0) { aviso("Escriba una distancia mayor que cero"); return; }
            ultDesfase = d;
            VistaBoceto.Pedido p = pedido("Desfase", t -> {
                antes();
                String err = Editar2D.desfase(boceto.b, t.get(0).ent, d, t.get(1).x, t.get(1).y);
                if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
                despuesDeModificar(null);
            }, "Desfase " + Formula.n(d) + " mm: toque la línea, el círculo o el arco (una línea de un rectángulo desfasa todo el rectángulo)",
                    "Ahora toque hacia qué lado (adentro o afuera)");
            p.quiereEnt[0] = true;
            p.repetir = true;
            p.linea = false;
            boceto.pedir(p);
        });
    }

    private void recortar() {
        VistaBoceto.Pedido p = pedido("Recortar", t -> {
            antes();
            String err = Editar2D.recortar(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Recortar: toque el pedazo que sobra (se corta hasta donde cruza con otra cosa). Siga tocando; termine con ✓ Listo");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void extender() {
        VistaBoceto.Pedido p = pedido("Extender", t -> {
            antes();
            String err = Editar2D.extender(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Extender: toque la línea cerca de la punta que quiere alargar (llega hasta lo primero que encuentre)");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void partir() {
        VistaBoceto.Pedido p = pedido("Partir", t -> {
            antes();
            String err = Editar2D.partir(boceto.b, t.get(0).ent, t.get(0).x, t.get(0).y);
            if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
            despuesDeModificar(null);
        }, "Partir: toque la línea donde la quiere partir (sirve el imán de la mitad)");
        p.quiereEnt[0] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void esquina(boolean redondo) {
        EditText e = campoTexto(Formula.n(redondo ? ultRadio : ultChaflan), "mm");
        dialogo(redondo ? "◜ Empalme: radio (mm o fórmula)" : "◸ Chaflán: cuánto se corta en cada lado (mm)", e, "Seguir", () -> {
            Double v = valorDe(e.getText().toString());
            if (v == null || v <= 0) { aviso("Escriba una medida mayor que cero"); return; }
            if (redondo) ultRadio = v; else ultChaflan = v;
            VistaBoceto.Pedido p = pedido(redondo ? "Empalme" : "Chaflán", t -> {
                antes();
                String err = Editar2D.esquina(boceto.b, t.get(0).punto, v, redondo);
                if (err != null) { atras.remove(atras.size() - 1); aviso(err); return; }
                despuesDeModificar(null);
            }, (redondo ? "Empalme R" : "Chaflán ") + Formula.n(v) + ": toque la esquina (el punto donde se juntan dos líneas)");
            p.quierePunto[0] = true;
            p.repetir = true;
            p.linea = false;
            boceto.pedir(p);
        });
    }

    private void matriz() {
        if (faltaEscoger("repetir")) return;
        List<Integer> s = escogidas();
        new AlertDialog.Builder(this).setTitle("▦ Matriz: repetir lo escogido")
                .setItems(new String[]{"▦ En filas y columnas", "◎ En círculo"}, (d, w) -> {
                    if (w == 0) matrizFilas(s); else matrizCirculo(s);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void matrizFilas(List<Integer> s) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Columnas (cuántas a lo ancho, contando la original)"));
        EditText col = campoTexto("4", ""); l.addView(col);
        l.addView(etiqueta("Distancia entre columnas (mm, negativo = a la izquierda)"));
        EditText dx = campoTexto("100", ""); l.addView(dx);
        l.addView(etiqueta("Filas (cuántas hacia arriba, contando la original)"));
        EditText fil = campoTexto("1", ""); l.addView(fil);
        l.addView(etiqueta("Distancia entre filas (mm, negativo = hacia abajo)"));
        EditText dy = campoTexto("100", ""); l.addView(dy);
        new AlertDialog.Builder(this).setTitle("▦ Matriz en filas y columnas").setView(l)
                .setPositiveButton("Hacer", (d, w) -> {
                    Double c = valorDe(col.getText().toString()), f = valorDe(fil.getText().toString());
                    Double x = valorDe(dx.getText().toString()), y = valorDe(dy.getText().toString());
                    if (c == null || f == null || x == null || y == null) return;
                    int nc = (int) Math.round(c), nf = (int) Math.round(f);
                    if (nc < 1 || nf < 1 || nc * nf > 400) { aviso("Entre 1 y 400 copias en total"); return; }
                    antes();
                    for (int i = 0; i < nc; i++) for (int j = 0; j < nf; j++) {
                        if (i == 0 && j == 0) continue;
                        Editar2D.copiar(boceto.b, s, Editar2D.traslado(i * x, j * y), true, 1, false);
                    }
                    despuesDeModificar((nc * nf - 1) + " copias");
                }).setNegativeButton("Cancelar", null).show();
    }

    private void matrizCirculo(List<Integer> s) {
        boceto.pedir(pedido("Matriz", t -> {
            VistaBoceto.Toque c = t.get(0);
            LinearLayout l = new LinearLayout(this);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setPadding(dp(18), dp(4), dp(18), 0);
            l.addView(etiqueta("Cuántas en total (contando la original)"));
            EditText n = campoTexto("6", ""); l.addView(n);
            l.addView(etiqueta("Ángulo que ocupan (360 = la vuelta completa)"));
            EditText g = campoTexto("360", ""); l.addView(g);
            new AlertDialog.Builder(this).setTitle("◎ Matriz en círculo").setView(l)
                    .setPositiveButton("Hacer", (d, w) -> {
                        Double nn = valorDe(n.getText().toString()), gg = valorDe(g.getText().toString());
                        if (nn == null || gg == null) return;
                        int k = (int) Math.round(nn);
                        if (k < 2 || k > 360) { aviso("Entre 2 y 360"); return; }
                        double paso = Math.abs(gg - 360) < 1e-6 ? 360.0 / k : gg / (k - 1);
                        antes();
                        for (int i = 1; i < k; i++) {
                            int dd = Editar2D.giroDerecho(paso * i);
                            Editar2D.copiar(boceto.b, s, Editar2D.giro(c.x, c.y, paso * i), dd >= 0, 1, dd == 1);
                        }
                        despuesDeModificar((k - 1) + " copias en círculo");
                    }).setNegativeButton("Cancelar", null).show();
        }, "Matriz en círculo: toque el centro"));
    }

    /** Después de modificar: se resuelve; si algo no cuadró se avisa (se puede deshacer). */
    private void despuesDeModificar(String ok) {
        boolean bien = recalcular();
        if (!bien) aviso("⚠ Quedó algo que no cuadra con las medidas o amarres. Toque ↶ Atrás si no le gusta");
        else if (ok != null) aviso("✔ " + ok);
        if (boceto.pedido == null) { herrActiva = "Ver"; marcarHerr(); }
    }

    private void dialogo(String titulo, View v, String si, Runnable r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(v);
        new AlertDialog.Builder(this).setTitle(titulo).setView(l)
                .setPositiveButton(si, (d, w) -> r.run())
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------- Amarrar (botones directos) ----------------

    private void amarrar(int tipo) {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null) s.add(e); }
        List<Integer> pts = new ArrayList<>();
        for (Integer id : boceto.selPts) if (bb.puntos.containsKey(id)) pts.add(id);
        if (boceto.modo != VistaBoceto.VER) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; marcarHerr(); mostrarCasilla(); }
        String falta = null;
        switch (tipo) {
            case Boceto.HORIZ: case Boceto.VERT: {
                List<Boceto.Ent> ls = new ArrayList<>();
                for (Boceto.Ent e : s) if (e.tipo == Boceto.LINEA) ls.add(e);
                if (ls.isEmpty()) { falta = "Toque una o varias líneas"; break; }
                antes();
                for (Boceto.Ent e : ls) {
                    bb.restr.removeIf(r -> (r.tipo == Boceto.HORIZ || r.tipo == Boceto.VERT) && r.e1 == e.id);
                    bb.restriccion(tipo, e.id, -1, -1, -1, null);
                }
                terminarAmarre();
                return;
            }
            case Boceto.PERP: case Boceto.PARAL:
                if (s.size() != 2 || s.get(0).tipo != Boceto.LINEA || s.get(1).tipo != Boceto.LINEA) { falta = "Toque exactamente dos líneas"; break; }
                poner(tipo, s.get(0).id, s.get(1).id, -1, -1);
                boceto.limpiarSeleccion();
                return;
            case Boceto.IGUAL:
                if (s.size() < 2) { falta = "Toque dos o más líneas (o círculos)"; break; }
                {
                    boolean lineas = s.get(0).tipo == Boceto.LINEA;
                    for (Boceto.Ent e : s) if ((e.tipo == Boceto.LINEA) != lineas || e.tipo == Boceto.TEXTO) { falta = "Todas deben ser líneas, o todas círculos y arcos"; break; }
                    if (falta != null) break;
                    antes();
                    for (int i = 1; i < s.size(); i++) bb.restriccion(Boceto.IGUAL, s.get(0).id, s.get(i).id, -1, -1, null);
                    terminarAmarre();
                    return;
                }
            case Boceto.COINC:
                if (pts.size() == 2) { poner(Boceto.COINC, -1, -1, pts.get(0), pts.get(1)); boceto.limpiarSeleccion(); return; }
                if (pts.size() == 1 && s.size() == 1 && s.get(0).tipo != Boceto.TEXTO) { poner(Boceto.SOBRE, s.get(0).id, -1, pts.get(0), -1); boceto.limpiarSeleccion(); return; }
                falta = "Toque dos puntos (quedan unidos), o un punto y una línea (el punto queda sobre la línea)";
                break;
            case Boceto.TANG: {
                Boceto.Ent ln = null, ci = null;
                for (Boceto.Ent e : s) { if (e.tipo == Boceto.LINEA) ln = e; else if (e.tipo == Boceto.CIRCULO || e.tipo == Boceto.ARCO) ci = e; }
                if (s.size() != 2 || ln == null || ci == null) { falta = "Toque una línea y un círculo (o arco)"; break; }
                poner(Boceto.TANG, ln.id, ci.id, -1, -1);
                boceto.limpiarSeleccion();
                return;
            }
            case Boceto.FIJO:
                if (pts.isEmpty()) { falta = "Toque uno o dos puntos para dejarlos fijos (o sueltos si ya estaban fijos)"; break; }
                antes();
                for (Integer p : pts) {
                    boolean ya = false;
                    for (Boceto.Restr r : bb.restr) if (r.tipo == Boceto.FIJO && r.p1 == p) ya = true;
                    if (ya) bb.restr.removeIf(r -> r.tipo == Boceto.FIJO && r.p1 == p);
                    else bb.restriccion(Boceto.FIJO, -1, -1, p, -1, null);
                }
                terminarAmarre();
                return;
        }
        if (falta != null) aviso(falta);
    }

    private void terminarAmarre() {
        if (!recalcular()) { revertir(); recalcular(); aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)"); return; }
        boceto.limpiarSeleccion();
    }

    private void cotaAngulo() {
        Boceto bb = boceto.b;
        List<Boceto.Ent> s = new ArrayList<>();
        for (Integer id : boceto.sel) { Boceto.Ent e = bb.entPorId(id); if (e != null && e.tipo == Boceto.LINEA) s.add(e); }
        if (s.size() != 2) { boceto.ponerModo(VistaBoceto.VER); herrActiva = "Ver"; marcarHerr(); aviso("Toque dos líneas y luego ∠ Ángulo"); return; }
        Boceto.Restr r = new Boceto.Restr();
        r.tipo = Boceto.C_ANG; r.e1 = s.get(0).id; r.e2 = s.get(1).id;
        pedirCota(r, null);
        boceto.limpiarSeleccion();
    }

    // ---------------- Medir ----------------

    private void mostrarMedida(String txt, double[] linea) {
        boceto.medicion = txt;
        boceto.lineaMedida = linea;
        boceto.invalidate();
    }

    private void medirDistancia() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Distancia", t -> {
            double ax = t.get(0).x, ay = t.get(0).y, bx = t.get(1).x, by = t.get(1).y;
            double d = Math.hypot(bx - ax, by - ay), g = Math.toDegrees(Math.atan2(by - ay, bx - ax));
            mostrarMedida("Distancia " + Formula.n(Math.round(d * 10) / 10.0) + " mm · ↔ " + Formula.n(Math.round(Math.abs(bx - ax) * 10) / 10.0)
                    + " · ↕ " + Formula.n(Math.round(Math.abs(by - ay) * 10) / 10.0) + " · " + Formula.n(Math.round(g * 10) / 10.0) + "°", new double[]{ax, ay, bx, by});
        }, "Distancia: toque el primer punto", "Ahora toque el segundo punto");
        p.repetir = true;
        boceto.pedir(p);
    }

    private void medirArea() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Área", t -> {
            double[] a = Editar2D.area(boceto.b, t.get(0).x, t.get(0).y);
            if (a == null) { mostrarMedida(null, null); aviso("Toque adentro de una figura cerrada (rectángulo, polígono o círculo)"); return; }
            mostrarMedida("Área " + String.format(Locale.US, "%.3f", a[0] / 1e6) + " m² (" + Formula.n(Math.round(a[0])) + " mm²) · Perímetro "
                    + Formula.n(Math.round(a[1] * 10) / 10.0) + " mm", null);
        }, "Área: toque adentro de una figura cerrada");
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private void medirAngulo() {
        boceto.medicion = null;
        boceto.lineaMedida = null;
        VistaBoceto.Pedido p = pedido("Ángulo", t -> {
            Boceto.Ent e = boceto.b.entPorId(t.get(0).ent), f = boceto.b.entPorId(t.get(1).ent);
            if (e == null || f == null || e.tipo != Boceto.LINEA || f.tipo != Boceto.LINEA) { aviso("Toque dos líneas"); return; }
            double g = Editar2D.anguloEntre(boceto.b, e, f);
            mostrarMedida("Ángulo " + Formula.n(Math.round(g * 10) / 10.0) + "° (el otro lado " + Formula.n(Math.round((180 - g) * 10) / 10.0) + "°)", null);
        }, "Ángulo: toque la primera línea", "Ahora toque la segunda línea");
        p.quiereEnt[0] = true;
        p.quiereEnt[1] = true;
        p.repetir = true;
        p.linea = false;
        boceto.pedir(p);
    }

    private EditText campoTexto(String valor, String pista) {
        EditText e = new EditText(this);
        e.setText(valor);
        e.setHint(pista);
        e.setTextSize(18);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setSelection(e.getText().length());
        return e;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(0xFF90A4AE);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    /** Escribir el valor de una cota nueva: un número (mm) o una fórmula de la tablita; y si quiere, ponerle nombre. */
    private void pedirCota(Boceto.Restr nueva, String sugerido) {
        Boceto bb = boceto.b;
        double actual = bb.medir(nueva);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Medida en mm, o fórmula (ej. ancho - 2*tubo)"));
        EditText val = campoTexto(sugerido != null ? sugerido : Formula.n(actual), "");
        l.addView(val);
        l.addView(etiqueta("Nombre para la tablita (opcional, ej. ancho)"));
        EditText nom = campoTexto("", "sin nombre");
        l.addView(nom);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[nueva.tipo]).setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String v = val.getText().toString().trim();
                    if (v.isEmpty()) return;
                    String n = nom.getText().toString().trim();
                    antes();
                    if (!n.isEmpty()) {
                        String ok = Medidas.nombreValido(n);
                        if (ok == null) { aviso("Ese nombre no sirve: use letras y números, sin espacios"); atras.remove(atras.size() - 1); return; }
                        Medidas.Fila f = medidas.buscar(ok);
                        if (f == null) { f = new Medidas.Fila(ok, v); medidas.filas.add(f); } else f.formula = v;
                        nueva.formula = ok;
                    } else nueva.formula = v;
                    bb.restr.add(nueva);
                    if (!recalcular() || nueva.error != null) {
                        String por = nueva.error != null ? nueva.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se puso: " + por);
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirDistancia(int p1, int p2) {
        new AlertDialog.Builder(this).setTitle("📏 Distancia entre los dos puntos")
                .setItems(new String[]{"↔ Horizontal", "↕ Vertical", "⤢ Alineada (en línea recta)"}, (d, w) -> {
                    Boceto.Restr r = new Boceto.Restr();
                    r.tipo = w == 0 ? Boceto.C_HORIZ : w == 1 ? Boceto.C_VERT : Boceto.C_DIST;
                    r.p1 = p1; r.p2 = p2;
                    pedirCota(r, null);
                }).setNegativeButton("Cancelar", null).show();
    }

    private void editarCota(Boceto.Restr r) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Hoy mide " + boceto.textoCota(r) + (r.error != null ? "\n⚠ " + r.error : "")));
        l.addView(etiqueta("Nuevo valor (mm) o fórmula"));
        EditText val = campoTexto(r.formula, "");
        l.addView(val);
        new AlertDialog.Builder(this).setTitle("📏 " + Boceto.NOMBRES[r.tipo]).setView(l)
                .setPositiveButton("Cambiar", (d, w) -> {
                    String v = val.getText().toString().trim();
                    if (v.isEmpty() || v.equals(r.formula)) return;
                    antes();
                    int i = boceto.b.restr.indexOf(r);
                    // si la cota es solo el nombre de una fila, se cambia la fila (así se mueve todo lo que la usa)
                    Medidas.Fila f = medidas.buscar(r.formula);
                    if (f != null && Formula.numero(v) != null) f.formula = v; else r.formula = v;
                    boolean ok = recalcular();
                    Boceto.Restr rr = i >= 0 && i < boceto.b.restr.size() ? boceto.b.restr.get(i) : r;
                    if (!ok || rr.error != null) {
                        String por = rr.error != null ? rr.error : "choca con otra medida o amarre";
                        revertir();
                        recalcular();
                        aviso("⚠ No se cambió: " + por);
                    }
                })
                .setNeutralButton("🗑 Quitar cota", (d, w) -> { antes(); boceto.b.restr.remove(r); recalcular(); })
                .setNegativeButton("Cancelar", null).show();
    }

    private void pedirTexto(double x, double y) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        EditText t = campoTexto("", "Ej. COCINA");
        l.addView(t);
        l.addView(etiqueta("Alto de la letra (mm)"));
        EditText al = campoTexto("150", "");
        al.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(al);
        new AlertDialog.Builder(this).setTitle("A Texto").setView(l)
                .setPositiveButton("Poner", (d, w) -> {
                    String s = t.getText().toString().trim();
                    if (s.isEmpty()) return;
                    antes();
                    Boceto.Punto p = boceto.b.punto(x, y);
                    Boceto.Ent e = boceto.b.ent(Boceto.TEXTO);
                    e.a = p.id;
                    e.texto = s;
                    Double h = Formula.numero(al.getText().toString());
                    e.r = h == null || h <= 0 ? 150 : h;
                    boceto.invalidate();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🗑 Quitar: los amarres y cotas de lo escogido, para quitar el que sobre. */
    private void amarrar2D() {
        Boceto bb = boceto.b;
        Set<Integer> s = new HashSet<>(boceto.sel), pts = new HashSet<>(boceto.selPts);
        List<Boceto.Restr> suyas = new ArrayList<>();
        for (Boceto.Restr r : bb.restr) {
            boolean es = s.contains(r.e1) || s.contains(r.e2) || pts.contains(r.p1) || pts.contains(r.p2);
            if (s.isEmpty() && pts.isEmpty()) es = true;
            if (es) suyas.add(r);
        }
        if (suyas.isEmpty()) {
            aviso(s.isEmpty() && pts.isEmpty() ? "No hay amarres ni cotas" : "Eso que escogió no tiene amarres ni cotas");
            return;
        }
        String[] nom = new String[suyas.size()];
        for (int i = 0; i < nom.length; i++) {
            Boceto.Restr r = suyas.get(i);
            nom[i] = "🗑 " + Boceto.NOMBRES[r.tipo] + (r.esCota() ? " (" + boceto.textoCota(r) + ")" : "");
        }
        new AlertDialog.Builder(this).setTitle(s.isEmpty() && pts.isEmpty() ? "🗑 Quitar (todos los amarres)" : "🗑 Quitar amarre de lo escogido")
                .setItems(nom, (d, w) -> { antes(); bb.restr.remove(suyas.get(w)); recalcular(); })
                .setNegativeButton("Cerrar", null).show();
    }

    private void poner(int tipo, int e1, int e2, int p1, int p2) {
        antes();
        boceto.b.restriccion(tipo, e1, e2, p1, p2, null);
        if (!recalcular()) {
            revertir();
            recalcular();
            aviso("⚠ No se puso: choca con otra medida o amarre (sobraría)");
        }
    }

    private void borrar2D() {
        Boceto bb = boceto.b;
        if (boceto.sel.isEmpty() && boceto.selPts.isEmpty()) { aviso("Con ✋ Ver toque lo que quiere borrar"); return; }
        antes();
        for (Integer id : new ArrayList<>(boceto.sel)) { Boceto.Ent e = bb.entPorId(id); if (e != null) bb.borrar(e); }
        for (Integer p : new ArrayList<>(boceto.selPts)) {
            for (Boceto.Ent e : new ArrayList<>(bb.ents)) if (e.a == p || e.b == p || e.c == p) bb.borrar(e);
            bb.puntos.remove(p);
            bb.limpiarPuntos();
        }
        boceto.limpiarSeleccion();
        recalcular();
    }

    /** El boceto en PDF tamaño carta, todo en negro nítido, con su escala. */
    private void pdf2D() {
        if (boceto.b.vacio()) { aviso("El boceto está vacío"); return; }
        try {
            PdfDocument doc = new PdfDocument();
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create());
            Canvas c = pg.getCanvas();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTextSize(13);
            p.setFakeBoldText(true);
            c.drawText("MI INVENTOR · " + nombreProyecto, 40, 45, p);
            p.setFakeBoldText(false);
            p.setTextSize(9.5f);
            boceto.imprimir(c, 36, 60, 540, 640);
            double esc = boceto.escalaImpresa;   // puntos de papel por mm
            long e = Math.max(1, Math.round(1 / (esc / 72.0 * 25.4)));
            c.drawText("Medidas en milímetros · Escala aprox. 1:" + e + " · " + new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "CO")).format(new Date()), 40, 735, p);
            // las medidas con nombre de la tablita, abajo
            StringBuilder sb = new StringBuilder();
            for (Medidas.Fila f : medidas.filas) {
                Double v = medidas.valorDe(f.nombre);
                if (sb.length() > 0) sb.append("   ");
                sb.append(f.nombre).append(" = ").append(v == null ? "⚠" : Formula.n(v));
            }
            if (sb.length() > 0) c.drawText(sb.length() > 110 ? sb.substring(0, 110) + "…" : sb.toString(), 40, 752, p);
            Paint marco = new Paint();
            marco.setStyle(Paint.Style.STROKE);
            marco.setColor(Color.BLACK);
            marco.setStrokeWidth(1);
            c.drawRect(30, 55, 582, 720, marco);
            doc.finishPage(pg);
            guardarPdf(doc, "MiInventor_Plano_");
        } catch (Exception ex) {
            aviso("No se pudo hacer el PDF");
        }
    }

    private void guardarPdf(PdfDocument doc, String prefijo) throws Exception {
        ContentValues cv = new ContentValues();
        String nom = prefijo + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".pdf";
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        try (OutputStream o = getContentResolver().openOutputStream(u)) { doc.writeTo(o); }
        doc.close();
        aviso("✔ PDF guardado en Descargas/MiBarra/MiInventor");
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception ignored) {}
    }

    // =====================================================================
    //                              MEDIDAS (mini Excel)
    // =====================================================================

    private View armarMedidas() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView ay = new TextView(this);
        ay.setText("Cada medida tiene nombre y fórmula. Las cotas del 2D y las piezas del 3D pueden usar estos nombres: "
                + "cambia un número y se rehace todo. Funciones: redondear( ), arriba( ), abajo( ), min( ; ), max( ; ), si(cond; sí; no).");
        ay.setTextColor(0xFFB0BEC5);
        ay.setTextSize(13);
        ay.setPadding(dp(6), dp(4), dp(6), dp(6));
        l.addView(ay);
        ScrollView sv = new ScrollView(this);
        listaMedidas = new LinearLayout(this);
        listaMedidas.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listaMedidas);
        l.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout acc = fila(
                boton("➕ Agregar medida", 0xFF00897B, () -> editarFila(null)),
                boton("💬 WhatsApp", 0xFF25A244, () -> compartirTexto(textoMedidas())),
                boton("↶ Atrás", 0xFF5E35B1, this::deshacer));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(46));
        ap.topMargin = dp(4);
        l.addView(acc, ap);
        return l;
    }

    private void pintarMedidas() {
        listaMedidas.removeAllViews();
        if (medidas.filas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay medidas. Toque ➕ Agregar medida, o en el 2D ponga una cota y escríbale un nombre.\n\n"
                    + "Ejemplo:\n  ancho = 4000\n  tubo = 40\n  travesano = ancho - 2*tubo\n  tubos_6m = arriba(total / 6000)");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            listaMedidas.addView(t);
        }
        int n = 1;
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            String err = medidas.errorDe(f.nombre);
            boolean soloNumero = Formula.numero(f.formula) != null;
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(err != null ? 0xFF4A1C1C : 0xFF1E2A3A);
            g.setCornerRadius(dp(8));
            r.setBackground(g);
            TextView num = new TextView(this);
            num.setText(String.valueOf(n++));
            num.setTextColor(0xFF78909C);
            num.setTextSize(12);
            r.addView(num, new LinearLayout.LayoutParams(dp(22), -2));
            TextView t = new TextView(this);
            t.setText(f.nombre + (soloNumero ? "" : "\n= " + f.formula));
            t.setTextColor(Color.WHITE);
            t.setTextSize(15);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView val = new TextView(this);
            val.setText(err != null ? "⚠ " + err : Formula.n(v == null ? 0 : v));
            val.setTextColor(err != null ? 0xFFFF8A80 : 0xFFFFD54A);
            val.setTextSize(err != null ? 12 : 17);
            val.setTypeface(Typeface.DEFAULT_BOLD);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(err != null ? dp(150) : -2, -2));
            r.setOnClickListener(x -> editarFila(f));
            r.setOnLongClickListener(x -> {
                new AlertDialog.Builder(this).setMessage("¿Borrar la medida «" + f.nombre + "»? Lo que la use quedará con error.")
                        .setPositiveButton("Borrar", (d, w) -> { antes(); medidas.filas.remove(f); recalcular(); })
                        .setNegativeButton("Cancelar", null).show();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            listaMedidas.addView(r, lp);
        }
        // los valores que pone la app
        TextView sub = new TextView(this);
        StringBuilder s = new StringBuilder("Valores de la app (solo leer):\n");
        for (Map.Entry<String, Double> e : medidas.fijos.entrySet()) s.append(e.getKey()).append(" = ").append(Formula.n(e.getValue())).append("   ");
        sub.setText(s.toString().trim());
        sub.setTextColor(0xFF90A4AE);
        sub.setTextSize(13);
        sub.setPadding(dp(8), dp(12), dp(8), dp(8));
        listaMedidas.addView(sub);
    }

    private void editarFila(Medidas.Fila f) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), 0);
        l.addView(etiqueta("Nombre (sin espacios, ej. ancho)"));
        EditText nom = campoTexto(f == null ? "" : f.nombre, "ancho");
        l.addView(nom);
        l.addView(etiqueta("Valor o fórmula (ej. 4000  ·  ancho - 2*tubo)"));
        EditText fo = campoTexto(f == null ? "" : f.formula, "4000");
        l.addView(fo);
        new AlertDialog.Builder(this).setTitle(f == null ? "➕ Medida nueva" : "✏ " + f.nombre).setView(l)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = Medidas.nombreValido(nom.getText().toString());
                    String v = fo.getText().toString().trim();
                    if (n == null) { aviso("El nombre debe empezar con letra, sin espacios ni signos (y no puede ser T1, total…)"); return; }
                    if (v.isEmpty()) { aviso("Escriba el valor o la fórmula"); return; }
                    Medidas.Fila otra = medidas.buscar(n);
                    if (otra != null && otra != f) { aviso("Ya hay una medida «" + n + "»"); return; }
                    antes();
                    String viejo = f == null ? null : f.nombre;
                    Medidas.Fila x = f == null ? new Medidas.Fila() : f;
                    x.nombre = n;
                    x.formula = v;
                    if (f == null) medidas.filas.add(x);
                    // si cambió el nombre, se cambia también donde se usaba
                    if (viejo != null && !Formula.plano(viejo).equals(Formula.plano(n))) renombrar(viejo, n);
                    if (!recalcular()) {
                        revertir();
                        recalcular();
                        aviso("⚠ Con ese valor el dibujo no cuadra: no se cambió");
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Cambia un nombre dentro de todas las fórmulas. */
    private void renombrar(String viejo, String nuevo) {
        String re = "(?i)(?<![\\p{L}\\p{N}_])" + java.util.regex.Pattern.quote(viejo) + "(?![\\p{L}\\p{N}_])";
        for (Medidas.Fila f : medidas.filas) f.formula = f.formula.replaceAll(re, nuevo);
        for (Boceto.Restr r : boceto.b.restr) r.formula = r.formula.replaceAll(re, nuevo);
        for (Pieza p : piezas) for (Map.Entry<String, String> e : p.f.entrySet()) e.setValue(e.getValue().replaceAll(re, nuevo));
    }

    private String textoMedidas() {
        StringBuilder s = new StringBuilder("MI INVENTOR · MEDIDAS · ").append(nombreProyecto).append("\n\n");
        for (Medidas.Fila f : medidas.filas) {
            Double v = medidas.valorDe(f.nombre);
            s.append(f.nombre).append(" = ");
            if (Formula.numero(f.formula) == null) s.append(f.formula).append(" = ");
            s.append(v == null ? "⚠ error" : Formula.n(v)).append(" mm\n");
        }
        return s.toString();
    }

    // =====================================================================
    //                              3D
    // =====================================================================

    private boolean movioPieza;

    private View armar3D() {
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        vista = new Vista3D(this);
        vista.piezas = piezas;
        vista.alEscoger = id -> { escogida = id; pintarLista(); };
        vista.alMover = new Vista3D.AlMover() {
            @Override public void mover(int id, float dx, float dy, float dz) {
                Pieza p = porId(id);
                if (p == null) return;
                if (!movioPieza) { antes(); movioPieza = true; }
                p.cx += dx; p.cy += dy; p.cz += dz;
                p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                vista.invalidate();
            }
            @Override public void soltar() { movioPieza = false; pintarLista(); }
        };
        raiz.addView(vista, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        LinearLayout vistas = new LinearLayout(this);
        vistas.addView(boton("🧊 3D", 0xFF37474F, () -> vista.vista(-35, 25)), peso());
        vistas.addView(boton("Frente", 0xFF37474F, () -> vista.vista(0, 0)), peso());
        vistas.addView(boton("Lado", 0xFF37474F, () -> vista.vista(-90, 0)), peso());
        vistas.addView(boton("Arriba", 0xFF37474F, () -> vista.vista(0, 89)), peso());
        vistas.addView(boton("⛶ Todo", 0xFF37474F, () -> vista.encuadrar()), peso());
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(36));
        vp.topMargin = dp(4);
        raiz.addView(vistas, vp);

        // Versión 2: qué hace un dedo
        LinearLayout modos = new LinearLayout(this);
        String[][] md = {{"✋ Correr vista", "" + Vista3D.CORRER}, {"🔄 Girar", "" + Vista3D.GIRAR}, {"✥ Mover pieza", "" + Vista3D.MOVER}};
        for (String[] m : md) {
            final int k = Integer.parseInt(m[1]);
            TextView t = boton(m[0], 0xFF37474F, () -> modo3D(k));
            t.setTag(k);
            botonesModo3D.add(t);
            modos.addView(t, peso());
        }
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(36));
        mp.topMargin = dp(4);
        raiz.addView(modos, mp);

        LinearLayout acciones = new LinearLayout(this);
        acciones.addView(boton("➕\nPieza", 0xFF00897B, () -> editar(null)), peso());
        acciones.addView(boton("✏\nEditar", 0xFF1E88E5, () -> { Pieza p = porId(escogida); if (p == null) aviso("Toque primero una pieza"); else editar(p); }), peso());
        acciones.addView(boton("⧉\nCopiar", 0xFF5E35B1, this::copiarEscogida), peso());
        acciones.addView(boton("⟳\nRotar", 0xFF6A1B9A, this::rotar), peso());
        acciones.addView(boton("🔗\nAmarrar", 0xFF00897B, this::amarrar3D), peso());
        acciones.addView(boton("↶\nAtrás", 0xFF455A64, this::deshacer), peso());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(50));
        ap.topMargin = dp(4);
        raiz.addView(acciones, ap);

        ScrollView sv = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        sv.addView(lista);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 0.7f);
        lp.topMargin = dp(4);
        raiz.addView(sv, lp);
        modo3D(Vista3D.CORRER);
        return raiz;
    }

    private void modo3D(int m) {
        vista.modo = m;
        for (TextView t : botonesModo3D) colorear(t, ((Integer) t.getTag()) == m ? 0xFFFF8F00 : 0xFF37474F);
        if (m == Vista3D.MOVER) aviso("Arrastre la pieza con el dedo (se mueve de 5 en 5 mm)");
    }

    private String resumen(Pieza p) {
        StringBuilder s = new StringBuilder();
        s.append(p.nombre()).append(" · ").append(p.referencia()).append("\n")
                .append(Pieza.n(p.largo)).append(" mm");
        if (p.f.containsKey("largo")) s.append(" (= ").append(p.f.get("largo")).append(")");
        s.append(" · ").append(Pieza.DIRS[p.dir].substring(0, 1));
        if (Math.abs(p.incl) > 0.01f) s.append(" inclinado ").append(Pieza.n(p.incl)).append("°");
        Pieza pp = porId(p.padre);
        if (pp != null) {
            s.append(" · unido a ").append(pp.nombre()).append(p.punto == 0 ? " (inicio" : p.punto == 1 ? " (final" : " (a " + Pieza.n(p.aMm) + " mm");
            s.append(p.cara > 0 ? ", " + Pieza.CARAS_UNION[p.cara].toLowerCase() : "").append(")");
            String cor = p.textoUnion();
            int k = cor.indexOf(" · corrido");
            if (k >= 0) s.append(cor.substring(k));
            if (Math.abs(p.sep) > 0.01f) s.append(" · separ. ").append(Pieza.n(p.sep)).append(" mm");
        }
        if (!p.huecos.isEmpty()) s.append(" · ").append(p.huecos.size()).append(p.huecos.size() == 1 ? " hueco" : " huecos");
        return s.toString();
    }

    private void pintarLista() {
        if (lista == null) return;
        lista.removeAllViews();
        if (piezas.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Toque ➕ Pieza para empezar.\n\nCada pieza arranca en el punto 0 o pegada a otra pieza (al inicio, al final o a una medida), "
                    + "y puede quedar separada los milímetros que usted diga.\n\nUn dedo corre la vista (o gira con 🔄, o arrastra la pieza con ✥), dos dedos acercan. "
                    + "En el largo puede escribir una fórmula de la tablita, por ejemplo: ancho - 2*tubo.");
            t.setTextColor(0xFFCFD8DC);
            t.setTextSize(15);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            lista.addView(t);
            return;
        }
        for (Pieza p : piezas) {
            TextView t = new TextView(this);
            t.setText(resumen(p));
            t.setTextColor(p.id == escogida ? Color.BLACK : Color.WHITE);
            t.setTextSize(14);
            t.setPadding(dp(10), dp(7), dp(8), dp(7));
            GradientDrawable g = new GradientDrawable();
            g.setColor(p.id == escogida ? 0xFFFFB300 : p.tipo == 3 ? 0xFF4E3B1A : p.tipo == 4 ? 0xFF37474F : 0xFF1E3A34);
            g.setCornerRadius(dp(8));
            t.setBackground(g);
            t.setOnClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); });
            t.setOnLongClickListener(v -> { escogida = p.id; vista.escogida = escogida; vista.invalidate(); pintarLista(); opcionesPieza(p); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(4);
            lista.addView(t, lp);
        }
    }

    private void opcionesPieza(Pieza p) {
        new AlertDialog.Builder(this).setTitle(p.nombre())
                .setItems(new String[]{"✏ Editar", "⧉ Copiar (queda pegada al final de esta)", "⟳ Rotar", "🔗 Amarrar a otra pieza", "🗑 Eliminar"}, (d, w) -> {
                    if (w == 0) editar(p);
                    else if (w == 1) copiarEscogida();
                    else if (w == 2) rotar();
                    else if (w == 3) amarrar3D();
                    else eliminar(p);
                }).show();
    }

    private void copiarEscogida() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        antes();
        Pieza c = p.copia(nuevoId());
        if (c == null) return;
        c.padre = p.id;
        c.punto = 1;
        c.sep = 0;
        c.cx = c.cy = c.cz = 0;
        c.f.remove("sep"); c.f.remove("cx"); c.f.remove("cy"); c.f.remove("cz"); c.f.remove("aMm");
        piezas.add(c);
        escogida = c.id;
        vista.encuadrar();
        recalcular();
        aviso("Copia " + c.nombre() + " pegada al final de " + p.nombre());
    }

    /** Las piezas que cuelgan de esta (para no amarrar en círculo y para rotar todo junto). */
    private Set<Integer> descendientes(int id) {
        Set<Integer> r = new HashSet<>();
        boolean cambio = true;
        r.add(id);
        while (cambio) {
            cambio = false;
            for (Pieza p : piezas) if (!r.contains(p.id) && r.contains(p.padre)) { r.add(p.id); cambio = true; }
        }
        return r;
    }

    /** Al eliminar o soltar, lo que estaba unido se queda en su puesto. */
    private void soltarEnSuPuesto(Pieza h) {
        Map<Integer, Pieza> m = mapa();
        float[] ini = h.inicio(m, 0), dir = h.direccion();
        h.padre = -1;
        h.cara = 0;
        h.cx = ini[0] - dir[0] * h.sep;
        h.cy = ini[1] - dir[1] * h.sep;
        h.cz = ini[2] - dir[2] * h.sep;
        h.f.remove("cx"); h.f.remove("cy"); h.f.remove("cz");
    }

    private void eliminar(Pieza p) {
        new AlertDialog.Builder(this).setMessage("¿Eliminar " + p.nombre() + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    antes();
                    for (Pieza h : piezas) if (h.padre == p.id) soltarEnSuPuesto(h);
                    piezas.remove(p);
                    escogida = -1;
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** ⟳ Rotar 90°: la pieza y todo lo que tiene pegado giran juntos. */
    private void rotar() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero una pieza"); return; }
        new AlertDialog.Builder(this).setTitle("⟳ Rotar " + p.nombre() + " (y lo que tiene pegado)")
                .setItems(new String[]{"↻ 90° en el piso (alrededor de Z)", "↻ 90° parándola (alrededor de X)", "↻ 90° de lado (alrededor de Y)",
                        "↕ Cambiar la inclinación…", "🔁 Girar la sección 90° (ángulo o platina)"}, (d, w) -> {
                    if (w == 3) { inclinacion(p); return; }
                    antes();
                    if (w == 4) { p.giro = (p.giro + 1) & 3; recalcular(); return; }
                    for (Integer id : descendientes(p.id)) {
                        Pieza x = porId(id);
                        if (x == null) continue;
                        x.dir = Pieza.girarDir(x.dir, w);
                        if (x != p) {
                            float[] v = Pieza.girarVec(new float[]{x.cx, x.cy, x.cz}, w);
                            x.cx = v[0]; x.cy = v[1]; x.cz = v[2];
                        }
                    }
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cerrar", null).show();
    }

    private void inclinacion(Pieza p) {
        EditText e = campoTexto(Pieza.n(p.incl), "grados");
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        new AlertDialog.Builder(this).setTitle("Inclinación de " + p.nombre() + " (0 = derecho)").setView(e)
                .setPositiveButton("Listo", (d, w) -> {
                    Double v = Formula.numero(e.getText().toString());
                    if (v == null) return;
                    antes();
                    p.incl = v.floatValue();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** 🔗 Amarrar la pieza escogida a otra (o soltarla dejándola en su puesto). */
    private void amarrar3D() {
        Pieza p = porId(escogida);
        if (p == null) { aviso("Toque primero la pieza que quiere amarrar"); return; }
        Set<Integer> no = descendientes(p.id);
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (!no.contains(x.id)) posibles.add(x);
        List<String> nom = new ArrayList<>();
        if (p.padre >= 0) nom.add("🔓 Soltarla (se queda donde está)");
        for (Pieza x : posibles) nom.add("🔗 A " + x.nombre() + " · " + x.referencia());
        if (nom.isEmpty()) { aviso("No hay otra pieza para amarrarla"); return; }
        final int corre = p.padre >= 0 ? 1 : 0;
        new AlertDialog.Builder(this).setTitle("🔗 Amarrar " + p.nombre()).setItems(nom.toArray(new String[0]), (d, w) -> {
            if (corre == 1 && w == 0) { antes(); soltarEnSuPuesto(p); recalcular(); return; }
            Pieza padre = posibles.get(w - corre);
            dialogoAmarre(p, padre);
        }).setNegativeButton("Cerrar", null).show();
    }

    /** Versión 3: en una sola ventana: el punto, la cara donde se pega y la separación, con un dibujito de muestra. */
    private void dialogoAmarre(Pieza p, Pieza padre) {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), dp(4));
        sv.addView(l);
        final int[] punto = {p.padre == padre.id ? p.punto : 1};
        final int[] cara = {p.padre == padre.id ? p.cara : 0};
        View[] muestra = new View[1];
        l.addView(etiqueta("1. En qué punto de " + padre.nombre()));
        grupoBotones(l, new String[]{"Inicio", "Final", "A medida"}, punto, 3, () -> muestra[0].invalidate());
        EditText am = campoTexto(p.padre == padre.id ? (p.f.containsKey("aMm") ? p.f.get("aMm") : Pieza.n(p.aMm)) : "0", "");
        l.addView(etiqueta("Medida desde el inicio (mm o fórmula), si escogió «A medida»"));
        l.addView(am);
        l.addView(etiqueta("2. En qué cara de " + padre.nombre() + " se pega"));
        grupoBotones(l, new String[]{"Arriba", "Abajo", "Punta", "Izquierda", "Derecha", "Centrado"}, cara, 3, () -> muestra[0].invalidate());
        l.addView(etiqueta("3. Separación (luz libre, mm o fórmula)"));
        EditText se = campoTexto(p.padre == padre.id ? (p.f.containsKey("sep") ? p.f.get("sep") : Pieza.n(p.sep)) : "0", "");
        l.addView(se);
        muestra[0] = new View(this) {
            private final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight();
                c.drawColor(0xFF0D1117);
                float y0 = h * 0.55f, alto = h * 0.2f, x0 = w * 0.08f, x1 = w * 0.92f;
                pp.setColor(0xFF26A69A);
                c.drawRect(x0, y0, x1, y0 + alto, pp);
                pp.setTextSize(dp(12));
                pp.setColor(Color.WHITE);
                c.drawText(padre.nombre(), (x0 + x1) / 2 - dp(8), y0 + alto / 2 + dp(4), pp);
                int k = cara[0];
                float cw = alto * 0.9f, ch = h * 0.34f;
                float px = punto[0] == 0 ? x0 : punto[0] == 1 ? x1 : (x0 + x1) / 2;
                float cx = px - cw / 2, cy;
                String nota = "";
                switch (k) {
                    case 1: cy = y0 - ch; break;
                    case 2: cy = y0 + alto; break;
                    case 3: cy = y0 + alto / 2 - ch / 2; nota = " (al lado izquierdo)"; break;
                    case 4: cy = y0 + alto / 2 - ch / 2; nota = " (al lado derecho)"; break;
                    case 5: cy = y0 + alto / 2 - ch / 2; cx = punto[0] == 0 ? x0 - cw : x1; break;
                    default: cy = y0 + alto / 2 - ch / 2; nota = " (en el eje)";
                }
                pp.setColor(k == 3 || k == 4 ? 0x99FFB300 : 0xFFFFB300);
                c.drawRect(cx, cy, cx + cw, cy + ch, pp);
                pp.setColor(Color.WHITE);
                c.drawText(p.nombre() + " " + Pieza.CARAS_UNION[k].toLowerCase() + nota, dp(6), dp(16), pp);
            }
        };
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(110));
        mp.topMargin = dp(8);
        l.addView(muestra[0], mp);
        new AlertDialog.Builder(this).setTitle("🔗 Amarrar " + p.nombre() + " a " + padre.nombre()).setView(sv)
                .setPositiveButton("Amarrar", (d2, w2) -> {
                    antes();
                    p.padre = padre.id;
                    p.punto = punto[0];
                    p.cara = cara[0];
                    p.cx = p.cy = p.cz = 0;
                    p.f.remove("cx"); p.f.remove("cy"); p.f.remove("cz");
                    leerCampo(p, "aMm", am.getText().toString());
                    leerCampo(p, "sep", se.getText().toString());
                    vista.encuadrar();
                    recalcular();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Botones para escoger una opción (la escogida queda en naranja). Las opciones van en el orden de los valores: "Arriba" = 1… */
    private void grupoBotones(LinearLayout l, String[] ops, int[] valor, int columnas, Runnable alCambiar) {
        // la cara: los textos están en orden de pantalla; el valor real sale de CARAS_UNION
        List<TextView> bs = new ArrayList<>();
        LinearLayout fila = null;
        for (int i = 0; i < ops.length; i++) {
            if (i % columnas == 0) {
                fila = new LinearLayout(this);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(42));
                fp.topMargin = dp(4);
                l.addView(fila, fp);
            }
            int v = Arrays.asList(Pieza.CARAS_UNION).indexOf(ops[i]);
            if (v < 0) v = i;
            final int val = v;
            TextView t = boton(ops[i], 0xFF455A64, null);
            t.setTag(val);
            t.setOnClickListener(x -> {
                valor[0] = val;
                for (TextView o : bs) colorear(o, ((Integer) o.getTag()) == valor[0] ? 0xFFFF8F00 : 0xFF455A64);
                if (alCambiar != null) alCambiar.run();
            });
            bs.add(t);
            fila.addView(t, peso());
        }
        for (TextView o : bs) colorear(o, ((Integer) o.getTag()) == valor[0] ? 0xFFFF8F00 : 0xFF455A64);
    }

    /** Un campo de la pieza: número fijo o fórmula de la tablita. */
    private void leerCampo(Pieza p, String k, String texto) {
        String t = texto == null ? "" : texto.trim();
        if (t.isEmpty()) return;
        Double n = Formula.numero(t);
        if (n != null) { p.ponerCampo(k, n.floatValue()); p.f.remove(k); return; }
        fijos();
        medidas.calcular();
        try {
            double v = medidas.evaluar(t);
            p.ponerCampo(k, (float) v);
            p.f.put(k, t);
        } catch (Exception e) {
            aviso("⚠ " + p.nombre() + ": la fórmula «" + t + "» no sirve: " + e.getMessage());
        }
    }

    // ---------------- Formulario de una pieza ----------------

    private EditText numero(LinearLayout l, String etiqueta, float valor, boolean signo) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        e.setText(Pieza.n(valor));
        e.setTextSize(17);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | (signo ? InputType.TYPE_NUMBER_FLAG_SIGNED : 0));
        l.addView(e);
        return e;
    }

    /** Casilla que acepta número o fórmula (el teclado normal, para poder escribir nombres). */
    private EditText numeroOFormula(LinearLayout l, String etiqueta, Pieza p, String k) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        EditText e = new EditText(this);
        String f = p.f.get(k);
        e.setText(f != null ? f : Pieza.n(p.campo(k)));
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        l.addView(e);
        return e;
    }

    private EditText[] filaNumeros(LinearLayout l, String[] etiquetas, float[] valores, boolean signo) {
        LinearLayout fila = new LinearLayout(this);
        EditText[] r = new EditText[etiquetas.length];
        for (int i = 0; i < etiquetas.length; i++) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            r[i] = numero(c, etiquetas[i], valores[i], signo);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.setMargins(0, 0, dp(6), 0);
            fila.addView(c, p);
        }
        l.addView(fila);
        return r;
    }

    private Spinner lista(LinearLayout l, String etiqueta, String[] items, int sel) {
        TextView t = new TextView(this);
        t.setText(etiqueta);
        t.setTextColor(0xFFFFD54A);
        t.setTextSize(13);
        t.setPadding(0, dp(8), 0, 0);
        l.addView(t);
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        s.setSelection(Math.max(0, Math.min(items.length - 1, sel)));
        l.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
        return s;
    }

    private static float leer(EditText e, float porDefecto) {
        try { return Float.parseFloat(e.getText().toString().trim().replace(',', '.')); } catch (Exception x) { return porDefecto; }
    }

    private static String[] nombresMedidas(int tipo) {
        Object[][] m = Pieza.MEDIDAS[tipo];
        String[] r = new String[m.length + 1];
        for (int i = 0; i < m.length; i++) r[i] = (String) m[i][0];
        r[m.length] = "Otra medida (escríbala abajo)";
        return r;
    }

    private void titulo(LinearLayout l, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(2));
        l.addView(t);
    }

    private void editar(Pieza original) {
        final boolean nueva = original == null;
        final Pieza p;
        if (nueva) {
            p = new Pieza();
            p.id = nuevoId();
            Pieza ult = piezas.isEmpty() ? null : piezas.get(piezas.size() - 1);
            if (ult != null) {   // por comodidad: la nueva sale igual a la anterior y pegada a su final
                p.tipo = ult.tipo; p.medida = ult.medida; p.a = ult.a; p.b = ult.b; p.t = ult.t; p.calibre = ult.calibre;
                p.padre = ult.id; p.punto = 1;
            }
        } else p = original;

        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(4), dp(18), dp(10));
        sv.addView(l);

        titulo(l, "1. El perfil");
        Spinner sTipo = lista(l, "Perfil", Pieza.TIPOS, p.tipo);
        int iMed = Arrays.asList(nombresMedidas(p.tipo)).indexOf(p.medida);
        Spinner sMed = lista(l, "Medida", nombresMedidas(p.tipo), iMed < 0 ? Pieza.MEDIDAS[p.tipo].length : iMed);
        EditText[] dims = filaNumeros(l, new String[]{"Ancho mm", "Alto mm", "Espesor mm"}, new float[]{p.a, p.b, p.t}, false);
        TextView tc = new TextView(this);
        tc.setText("Calibre (para pedirlo en la ferretería)");
        tc.setTextColor(0xFFFFD54A);
        tc.setTextSize(13);
        tc.setPadding(0, dp(8), 0, 0);
        l.addView(tc);
        EditText eCal = new EditText(this);
        eCal.setText(p.calibre);
        l.addView(eCal);
        final int[] tipoAntes = {p.tipo};
        sTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                if (pos == tipoAntes[0]) return;
                tipoAntes[0] = pos;
                sMed.setAdapter(new ArrayAdapter<>(InventorActivity.this, android.R.layout.simple_spinner_dropdown_item, nombresMedidas(pos)));
                sMed.setSelection(Math.min(2, Pieza.MEDIDAS[pos].length - 1));
                eCal.setText(pos <= 2 ? "Cal 18" : "");
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });
        sMed.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                Object[][] m = Pieza.MEDIDAS[sTipo.getSelectedItemPosition()];
                if (pos >= m.length) return;
                dims[0].setText(Pieza.n((Float) m[pos][1]));
                dims[1].setText(Pieza.n((Float) m[pos][2]));
                dims[2].setText(Pieza.n((Float) m[pos][3]));
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        });

        titulo(l, "2. Largo y hacia dónde va");
        EditText eLargo = numeroOFormula(l, "Largo de corte (mm o fórmula, ej. ancho - 2*tubo)", p, "largo");
        Spinner sDir = lista(l, "Dirección", Pieza.DIRS, p.dir);
        EditText eIncl = numero(l, "Inclinación (grados, 0 = derecho)", p.incl, true);
        Spinner sGiro = lista(l, "Girar la sección (para ángulo o platina)", new String[]{"0°", "90°", "180°", "270°"}, p.giro);

        titulo(l, "3. Dónde se une");
        Set<Integer> no = nueva ? new HashSet<>() : descendientes(p.id);
        List<Pieza> posibles = new ArrayList<>();
        for (Pieza x : piezas) if (x != p && !no.contains(x.id)) posibles.add(x);
        String[] nomPadres = new String[posibles.size() + 1];
        nomPadres[0] = "En el punto 0 (suelta)";
        int selPadre = 0;
        for (int i = 0; i < posibles.size(); i++) {
            nomPadres[i + 1] = posibles.get(i).nombre() + " · " + posibles.get(i).referencia();
            if (posibles.get(i).id == p.padre) selPadre = i + 1;
        }
        Spinner sPadre = lista(l, "Va pegada a", nomPadres, selPadre);
        Spinner sPunto = lista(l, "En qué punto de esa pieza", new String[]{"Al inicio", "Al final", "A una medida del inicio"}, p.punto);
        Spinner sCara = lista(l, "En qué cara de esa pieza se pega", Pieza.CARAS_UNION, p.cara);
        EditText eAmm = numeroOFormula(l, "Medida desde el inicio (mm o fórmula), si escogió «a una medida»", p, "aMm");
        EditText eSep = numeroOFormula(l, "Separación (mm o fórmula) — luz entre las dos piezas", p, "sep");
        EditText eCx = numeroOFormula(l, "Correr X (mm o fórmula)", p, "cx");
        EditText eCy = numeroOFormula(l, "Correr Y (mm o fórmula)", p, "cy");
        EditText eCz = numeroOFormula(l, "Correr Z (mm o fórmula)", p, "cz");

        titulo(l, "4. Cortes de las puntas");
        EditText[] cortes = filaNumeros(l, new String[]{"Inicio (°)", "Final (°)"}, new float[]{p.corteIni, p.corteFin}, true);

        titulo(l, "5. Huecos y ranuras");
        LinearLayout cajaHuecos = new LinearLayout(this);
        cajaHuecos.setOrientation(LinearLayout.VERTICAL);
        l.addView(cajaHuecos);
        List<Object[]> filasHueco = new ArrayList<>();
        for (Pieza.Hueco h : p.huecos) agregarFilaHueco(cajaHuecos, filasHueco, h);
        TextView masH = boton("➕ Agregar hueco", 0xFF37474F, () -> agregarFilaHueco(cajaHuecos, filasHueco, new Pieza.Hueco()));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(44));
        mp.topMargin = dp(6);
        l.addView(masH, mp);

        new AlertDialog.Builder(this).setTitle(nueva ? "➕ Pieza nueva " + p.nombre() : "✏ " + p.nombre()).setView(sv)
                .setPositiveButton("Listo", (d, w) -> {
                    antes();
                    p.tipo = sTipo.getSelectedItemPosition();
                    int im = sMed.getSelectedItemPosition();
                    p.a = Math.max(1, leer(dims[0], p.a));
                    p.b = Math.max(1, leer(dims[1], p.b));
                    p.t = Math.max(0.3f, leer(dims[2], p.t));
                    p.medida = im < Pieza.MEDIDAS[p.tipo].length ? (String) Pieza.MEDIDAS[p.tipo][im][0]
                            : Pieza.n(p.a) + "x" + Pieza.n(p.b) + " mm";
                    p.calibre = eCal.getText().toString();
                    leerCampo(p, "largo", eLargo.getText().toString());
                    if (p.largo <= 0) p.largo = 1000;
                    p.dir = sDir.getSelectedItemPosition();
                    p.incl = leer(eIncl, 0);
                    p.giro = sGiro.getSelectedItemPosition();
                    int ip = sPadre.getSelectedItemPosition();
                    p.padre = ip == 0 ? -1 : posibles.get(ip - 1).id;
                    p.punto = sPunto.getSelectedItemPosition();
                    p.cara = p.padre < 0 ? 0 : sCara.getSelectedItemPosition();
                    leerCampo(p, "aMm", eAmm.getText().toString());
                    leerCampo(p, "sep", eSep.getText().toString());
                    leerCampo(p, "cx", eCx.getText().toString());
                    leerCampo(p, "cy", eCy.getText().toString());
                    leerCampo(p, "cz", eCz.getText().toString());
                    p.corteIni = leer(cortes[0], 0); p.corteFin = leer(cortes[1], 0);
                    p.huecos.clear();
                    for (Object[] f : filasHueco) {
                        Pieza.Hueco h = new Pieza.Hueco();
                        h.tipo = ((Spinner) f[0]).getSelectedItemPosition();
                        h.d1 = Math.max(1, leer((EditText) f[1], 10));
                        h.d2 = Math.max(1, leer((EditText) f[2], 8));
                        h.pos = leer((EditText) f[3], 50);
                        h.cara = ((Spinner) f[4]).getSelectedItemPosition();
                        p.huecos.add(h);
                    }
                    if (nueva) piezas.add(p);
                    escogida = p.id;
                    vista.encuadrar();
                    recalcular();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Una fila de hueco: tipo, medidas, posición y cara. */
    private void agregarFilaHueco(LinearLayout caja, List<Object[]> filas, Pieza.Hueco h) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(8), dp(4), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF263238);
        g.setCornerRadius(dp(8));
        f.setBackground(g);
        Spinner sT = lista(f, "Hueco " + (filas.size() + 1), Pieza.HUECOS, h.tipo);
        EditText[] m = filaNumeros(f, new String[]{"Ø / lado / largo", "Ancho ranura", "A mm del inicio"}, new float[]{h.d1, h.d2, h.pos}, false);
        Spinner sC = lista(f, "En qué cara", Pieza.CARAS, h.cara);
        Object[] reg = {sT, m[0], m[1], m[2], sC, f};
        TextView quitar = boton("✕ Quitar este hueco", 0xFFC62828, () -> { caja.removeView(f); filas.remove(reg); });
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, dp(38));
        qp.topMargin = dp(6);
        f.addView(quitar, qp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        caja.addView(f, lp);
        filas.add(reg);
    }

    // ---------------- Lista de corte ----------------

    private String textoCorte() {
        Map<String, List<Pieza>> grupos = new LinkedHashMap<>();
        for (Pieza p : piezas) {
            List<Pieza> g = grupos.get(p.referencia());
            if (g == null) { g = new ArrayList<>(); grupos.put(p.referencia(), g); }
            g.add(p);
        }
        StringBuilder s = new StringBuilder();
        s.append("MI INVENTOR - LISTA DE CORTE\n");
        s.append("Proyecto: ").append(nombreProyecto).append("\n");
        s.append(new SimpleDateFormat("dd/MM/yyyy h:mm a", new Locale("es", "CO")).format(new Date())).append("\n");
        s.append("Barras de 6 m · se descuentan 3 mm por cada corte\n");
        int totalBarras = 0;
        for (Map.Entry<String, List<Pieza>> en : grupos.entrySet()) {
            s.append("\n========================================\n");
            s.append(en.getKey().toUpperCase(new Locale("es", "CO"))).append("\n");
            s.append("========================================\n");
            float metros = 0;
            List<Float> largos = new ArrayList<>();
            List<String> largas = new ArrayList<>();
            int extra = 0;
            for (Pieza p : en.getValue()) {
                metros += p.largo;
                s.append(String.format(Locale.US, "%-4s %6s mm", p.nombre(), Pieza.n(p.largo)));
                if (Math.abs(p.corteIni) > 0.01f || Math.abs(p.corteFin) > 0.01f)
                    s.append("  cortes ").append(Pieza.n(p.corteIni)).append("° / ").append(Pieza.n(p.corteFin)).append("°");
                else s.append("  cortes rectos (90°)");
                s.append("\n");
                for (Pieza.Hueco h : p.huecos) s.append("        · ").append(h.texto()).append("\n");
                if (p.largo > BARRA) { largas.add(p.nombre() + " (" + Pieza.n(p.largo) + " mm)"); extra += (int) Math.ceil(p.largo / BARRA); }
                else largos.add(p.largo);
            }
            // acomodar los cortes en barras: primero los más largos
            largos.sort((x, y) -> Float.compare(y, x));
            List<List<Float>> barras = new ArrayList<>();
            List<Float> libre = new ArrayList<>();
            for (float L : largos) {
                int k = -1;
                for (int i = 0; i < barras.size(); i++) if (libre.get(i) >= L + (barras.get(i).isEmpty() ? 0 : DISCO)) { k = i; break; }
                if (k < 0) { barras.add(new ArrayList<>()); libre.add(BARRA); k = barras.size() - 1; }
                libre.set(k, libre.get(k) - L - (barras.get(k).isEmpty() ? 0 : DISCO));
                barras.get(k).add(L);
            }
            s.append("\nMetros lineales: ").append(String.format(Locale.US, "%.2f", metros / 1000f)).append(" m\n");
            for (int i = 0; i < barras.size(); i++) {
                s.append("Barra ").append(i + 1).append(": ");
                List<Float> b = barras.get(i);
                for (int j = 0; j < b.size(); j++) s.append(j == 0 ? "" : " + ").append(Pieza.n(b.get(j)));
                s.append("  (sobran ").append(Pieza.n(Math.max(0, libre.get(i)))).append(" mm)\n");
            }
            if (!largas.isEmpty()) s.append("Más largas que 6 m (van empatadas): ").append(String.join(", ", largas)).append("\n");
            int comprar = barras.size() + extra;
            totalBarras += comprar;
            s.append(">> COMPRAR: ").append(comprar).append(comprar == 1 ? " barra de 6 m\n" : " barras de 6 m\n");
        }
        s.append("\n----------------------------------------\n");
        s.append("TOTAL: ").append(totalBarras).append(" barras de 6 m\n");
        return s.toString();
    }

    private void listaCorte() {
        if (piezas.isEmpty()) { aviso("Todavía no hay piezas en el 3D"); return; }
        String txt = textoCorte();
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(Color.WHITE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("📋 Lista de corte").setView(sv)
                .setPositiveButton("📄 PDF carta", (d, w) -> pdf(txt))
                .setNeutralButton("📲 WhatsApp", (d, w) -> compartirTexto(txt))
                .setNegativeButton("Cerrar", null).show();
    }

    private void compartirTexto(String txt) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt);
        try { startActivity(new Intent(i).setPackage("com.whatsapp")); }
        catch (Exception e) { try { startActivity(Intent.createChooser(i, "Compartir")); } catch (Exception ignored) {} }
    }

    /** La lista en PDF tamaño carta, letras negras nítidas. */
    private void pdf(String txt) {
        try {
            PdfDocument doc = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(10.5f);
            String[] lineas = txt.split("\n");
            float alto = 14, arriba = 50, abajo = 792 - 45;
            int num = 1, i = 0;
            while (i < lineas.length) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                float y = arriba;
                while (i < lineas.length && y < abajo) {
                    String ln = lineas[i++];
                    p.setFakeBoldText(ln.startsWith(">>") || ln.startsWith("TOTAL") || ln.startsWith("MI INVENTOR") || (i > 1 && ln.equals(ln.toUpperCase()) && !ln.startsWith("=")));
                    c.drawText(ln, 45, y, p);
                    y += alto;
                }
                p.setFakeBoldText(false);
                c.drawText("Página " + num, 520, 775, p);
                doc.finishPage(pg);
                num++;
            }
            guardarPdf(doc, "MiInventor_Corte_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Proyectos (archivos livianos) ----------------

    private File carpeta() {
        File f = new File(getFilesDir(), "proyectos");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private JSONObject proyecto() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 3);
        o.put("nombre", nombreProyecto);
        JSONArray a = new JSONArray();
        for (Pieza p : piezas) a.put(p.json());
        o.put("piezas", a);
        o.put("medidas", medidas.json());
        o.put("boceto", boceto.b.json());
        return o;
    }

    private void cargar(JSONObject o) throws Exception {
        JSONArray a = o.optJSONArray("piezas");
        piezas.clear();
        if (a != null) for (int i = 0; i < a.length(); i++) piezas.add(Pieza.deJson(a.getJSONObject(i)));
        medidas.deJson(o.optJSONArray("medidas"));
        boceto.b = Boceto.deJson(o.optJSONObject("boceto"));
        boceto.limpiarSeleccion();
        nombreProyecto = o.optString("nombre", nombreProyecto);
        if (porId(escogida) == null) escogida = -1;
    }

    private void menuProyecto() {
        new AlertDialog.Builder(this).setTitle("📂 Archivo · " + nombreProyecto)
                .setItems(new String[]{"💾 Guardar con nombre", "📂 Abrir uno guardado", "📤 Enviar el proyecto (archivo liviano)",
                        "📥 Abrir un proyecto recibido", "📄 Empezar uno nuevo (vacío)",
                        "📄 PDF carta del plano 2D", "📐 Abrir un plano DXF (de AutoCAD)", "💾 Guardar el plano 2D en DXF", "🧹 Hoja 2D nueva (borra solo el 2D)"}, (d, w) -> {
                    if (w == 0) pedirNombre();
                    else if (w == 1) listaProyectos();
                    else if (w == 2) enviarProyecto();
                    else if (w == 3) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_ARCHIVO); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else if (w == 4) new AlertDialog.Builder(this).setMessage("¿Empezar vacío? Lo que no haya guardado con nombre se pierde (se puede deshacer con ↶).")
                                .setPositiveButton("Empezar", (d2, w2) -> {
                                    antes();
                                    piezas.clear(); medidas.filas.clear(); boceto.b = new Boceto();
                                    escogida = -1; nombreProyecto = "Sin nombre";
                                    vista.encuadrar(); boceto.encuadrar(); recalcular();
                                })
                                .setNegativeButton("Cancelar", null).show();
                    else if (w == 5) pdf2D();
                    else if (w == 6) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                        try { startActivityForResult(i, ABRIR_DXF); } catch (Exception e) { aviso("No se pudo abrir el buscador de archivos"); }
                    } else if (w == 7) exportarDxf();
                    else new AlertDialog.Builder(this).setMessage("¿Borrar todo el boceto 2D? (se puede deshacer con ↶)")
                                .setPositiveButton("Borrar", (d2, w2) -> { antes(); boceto.b = new Boceto(); boceto.limpiarSeleccion(); recalcular(); })
                                .setNegativeButton("Cancelar", null).show();
                }).show();
    }

    /** Versión 3: el plano 2D en DXF (se abre en AutoCAD y en cualquier programa de dibujo). */
    private void exportarDxf() {
        if (boceto.b.vacio()) { aviso("El boceto 2D está vacío"); return; }
        try {
            byte[] datos = Dxf.exportar(boceto.b, boceto).getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + "_"
                    + new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date()) + ".dxf";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/dxf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            new AlertDialog.Builder(this).setTitle("✔ DXF guardado")
                    .setMessage(nom + "\n\nQuedó en Descargas/MiBarra/MiInventor (" + Math.max(1, datos.length / 1024) + " KB).\nMedidas en milímetros.")
                    .setPositiveButton("📤 Enviar", (d, w) -> {
                        Intent i = new Intent(Intent.ACTION_SEND).setType("application/dxf").putExtra(Intent.EXTRA_STREAM, u)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { startActivity(Intent.createChooser(i, "Enviar el DXF")); } catch (Exception ignored) {}
                    })
                    .setNegativeButton("Listo", null).show();
        } catch (Exception e) {
            aviso("No se pudo guardar el DXF");
        }
    }

    /** Lee el DXF escogido y pregunta si reemplaza el boceto o se agrega. */
    private void abrirDxf(Uri u) {
        String texto;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) {
                bo.write(b, 0, n);
                if (bo.size() > 40 * 1024 * 1024) { aviso("Ese plano es muy grande (más de 40 MB)"); return; }
            }
            byte[] datos = bo.toByteArray();
            String inicio = new String(datos, 0, Math.min(datos.length, 32), StandardCharsets.ISO_8859_1);
            if (inicio.startsWith("AC10") || inicio.startsWith("AC1.")) {
                new AlertDialog.Builder(this).setTitle("Ese archivo es DWG")
                        .setMessage("Mi Inventor abre DXF. Pídale el plano en DXF a quien se lo mandó (en AutoCAD: Guardar como → DXF), "
                                + "o conviértalo gratis con ODA File Converter en un computador.")
                        .setPositiveButton("Entendido", null).show();
                return;
            }
            if (inicio.startsWith("AutoCAD Binary DXF")) { aviso("Ese DXF está en binario: guárdelo como DXF de texto (ASCII)"); return; }
            texto = new String(datos, StandardCharsets.UTF_8);
            if (!texto.contains("SECTION")) { aviso("Ese archivo no es un plano DXF"); return; }
        } catch (Exception e) {
            aviso("No se pudo leer el archivo");
            return;
        }
        final String t = texto;
        new AlertDialog.Builder(this).setTitle("📐 Abrir DXF")
                .setItems(new String[]{"Reemplazar el boceto 2D", "Agregarlo al boceto 2D que hay"}, (d, w) -> {
                    antes();
                    if (w == 0) boceto.b = new Boceto();
                    Dxf.Resultado r = Dxf.importar(t, boceto.b);
                    if (r.total() == 0) { revertir(); aviso("No se encontraron líneas, círculos, arcos ni textos"); return; }
                    boceto.limpiarSeleccion();
                    mostrar(0);
                    boceto.encuadrar();
                    recalcular();
                    String m = "✔ " + r.lineas + " líneas, " + r.circulos + " círculos, " + r.arcos + " arcos, " + r.textos + " textos";
                    if (!r.unidades.equals("mm")) m += " (venía en " + r.unidades + ", pasado a mm)";
                    if (r.omitidos > 0) m += ". " + r.omitidos + " cosas no se pudieron traer (bloques, sombreados o cotas)";
                    new AlertDialog.Builder(this).setTitle("Plano abierto").setMessage(m).setPositiveButton("Listo", null).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** El proyecto es solo números y fórmulas: unos pocos KB. Se guarda en Descargas/MiBarra/MiInventor y se manda. */
    private void enviarProyecto() {
        try {
            byte[] datos = proyecto().toString().getBytes(StandardCharsets.UTF_8);
            ContentValues cv = new ContentValues();
            String nom = "MiInventor_" + nombreProyecto.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ]", "") + ".miv.json";
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nom);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/MiInventor");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(datos); }
            aviso("✔ Archivo de " + Math.max(1, datos.length / 1024) + " KB en Descargas/MiBarra/MiInventor");
            Intent i = new Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_STREAM, u)
                    .putExtra(Intent.EXTRA_TEXT, "Proyecto de Mi Inventor: " + nombreProyecto).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Enviar el proyecto"));
        } catch (Exception e) {
            aviso("No se pudo preparar el archivo");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == ABRIR_DXF) { abrirDxf(data.getData()); return; }
        if (req != ABRIR_ARCHIVO) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            byte[] b = new byte[8192];
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONObject o = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            antes();
            cargar(o);
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            aviso("Ese archivo no es un proyecto de Mi Inventor");
        }
    }

    private void pedirNombre() {
        EditText e = new EditText(this);
        e.setText("Sin nombre".equals(nombreProyecto) ? "" : nombreProyecto);
        e.setHint("Por ejemplo: escalera 55-21");
        new AlertDialog.Builder(this).setTitle("Nombre del proyecto").setView(e)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim().replaceAll("[/\\\\:*?\"<>|]", "-");
                    if (n.isEmpty() || n.startsWith("_")) { aviso("Escriba un nombre"); return; }
                    nombreProyecto = n;
                    guardar(n, false);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void guardar(String nombre, boolean callado) {
        try {
            try (FileWriter w = new FileWriter(new File(carpeta(), nombre + ".json"))) { w.write(proyecto().toString()); }
            if (!callado) aviso("✔ Guardado «" + nombre + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo guardar");
        }
    }

    private void abrir(String nombre, boolean callado) {
        try {
            File f = new File(carpeta(), nombre + ".json");
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            cargar(o);
            escogida = -1;
            vista.encuadrar();
            boceto.encuadrar();
            recalcular();
            if (!callado) aviso("✔ Abierto «" + nombreProyecto + "»");
        } catch (Exception e) {
            if (!callado) aviso("No se pudo abrir");
        }
    }

    private void listaProyectos() {
        File[] fs = carpeta().listFiles(x -> x.getName().endsWith(".json") && !x.getName().startsWith("_"));
        if (fs == null || fs.length == 0) { aviso("Todavía no hay proyectos guardados con nombre"); return; }
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] nom = new String[fs.length];
        for (int i = 0; i < fs.length; i++) nom[i] = fs[i].getName().replace(".json", "") + "  (" + Math.max(1, fs[i].length() / 1024) + " KB)";
        new AlertDialog.Builder(this).setTitle("📂 Proyectos").setItems(nom, (d, w) -> {
            String n = fs[w].getName().replace(".json", "");
            new AlertDialog.Builder(this).setTitle(n).setItems(new String[]{"Abrir", "🗑 Borrar"}, (d2, w2) -> {
                if (w2 == 0) { antes(); abrir(n, false); }
                else new AlertDialog.Builder(this).setMessage("¿Borrar «" + n + "» para siempre?")
                        .setPositiveButton("Borrar", (d3, w3) -> { fs[w].delete(); aviso("Borrado"); })
                        .setNegativeButton("Cancelar", null).show();
            }).show();
        }).show();
    }
}
