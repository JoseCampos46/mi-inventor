package co.jose.miinventor;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * v6.4 Chepe CAD: el teclado propio, como el de Floor Plan (números, punto, borrar, + − × ÷ y OK).
 * No sale el teclado del celular. Se puede poner el cursor donde quiera y cambiar solo ese número.
 */
final class Teclado {

    interface Listo { void valor(double v); }

    static void pedir(Activity act, String titulo, double valor, Listo listo) {
        float d = act.getResources().getDisplayMetrics().density;
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding((int) (12 * d), (int) (6 * d), (int) (12 * d), (int) (6 * d));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        EditText pantalla = new EditText(act);
        pantalla.setShowSoftInputOnFocus(false);
        String ini = Pieza.n((float) valor);
        pantalla.setText(ini);
        pantalla.setTextSize(24);
        pantalla.setSingleLine(true);
        pantalla.setSelection(ini.length());
        arriba.addView(pantalla, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mm = new TextView(act);
        mm.setText(" mm ");
        mm.setTextSize(16);
        arriba.addView(mm);
        l.addView(arriba);
        TextView error = new TextView(act);
        error.setTextColor(0xFFE53935);
        error.setTextSize(13);
        l.addView(error);
        AlertDialog[] dlg = new AlertDialog[1];
        Runnable ok = () -> {
            try {
                double v = Formula.calcular(pantalla.getText().toString(), k -> null);
                dlg[0].dismiss();
                listo.valor(v);
            } catch (Throwable t) {
                error.setText("Revise el número");
            }
        };
        String[][] teclas = {
                {"7", "8", "9", "⌫", "OK"},
                {"4", "5", "6", "(", ")"},
                {"1", "2", "3", "÷", "×"},
                {"✕", "0", ".", "−", "+"}};
        for (String[] f : teclas) {
            LinearLayout fila = new LinearLayout(act);
            for (String k : f) {
                TextView t = new TextView(act);
                t.setText(k);
                t.setTextSize(22);
                t.setGravity(Gravity.CENTER);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                boolean num = k.matches("[0-9.]");
                t.setTextColor(k.equals("OK") ? Color.WHITE : 0xFF212121);
                GradientDrawable g = new GradientDrawable();
                g.setColor(k.equals("OK") ? 0xFF2E7D32 : num ? 0xFFE0E0E0 : 0xFFCFD8DC);
                g.setCornerRadius(8 * d);
                t.setBackground(g);
                t.setPadding(0, (int) (12 * d), 0, (int) (12 * d));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
                p.setMargins((int) (3 * d), (int) (3 * d), (int) (3 * d), (int) (3 * d));
                fila.addView(t, p);
                t.setOnClickListener(v -> {
                    error.setText("");
                    String s = pantalla.getText().toString();
                    int c = Math.max(0, Math.min(s.length(), pantalla.getSelectionStart()));
                    switch (k) {
                        case "OK": ok.run(); return;
                        case "✕": dlg[0].dismiss(); return;
                        case "⌫":
                            if (c > 0) { pantalla.setText(s.substring(0, c - 1) + s.substring(c)); pantalla.setSelection(c - 1); }
                            return;
                        default: {
                            String ins = k.equals("−") ? "-" : k;
                            pantalla.setText(s.substring(0, c) + ins + s.substring(c));
                            pantalla.setSelection(c + ins.length());
                        }
                    }
                });
            }
            l.addView(fila);
        }
        dlg[0] = new AlertDialog.Builder(act).setTitle(titulo).setView(l).create();
        dlg[0].show();
    }
}
