package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

/**
 * v6.4 Chepe CAD: la casa como en Floor Plan, pero con medidas que mandan.
 * La casa es un rectángulo con su muro de afuera; adentro van cuartos (rectángulos con nombre y medida por dentro).
 * Dos cuartos que quedan a un grueso de muro comparten ese muro. Los cuartos entran y salen con todo lo que tienen.
 * Todo en milímetros; X a la derecha, Y hacia arriba; el 0,0 es la esquina de afuera, abajo a la izquierda, de la casa.
 */
final class CasaPlano {

    // ---------------- Datos ----------------

    float ancho = 10900, fondo = 6360;   // por fuera
    float gExt = 120, gInt = 120;        // gruesos de muro
    float alto = 2500;                   // altura de las paredes desde el sobrepiso
    boolean verSobrepiso = true;
    int sigId = 1;

    static final class Cuarto {
        int id;
        String nombre = "Cuarto";
        float x, y, w = 3000, h = 3000;   // por dentro (luz libre), esquina de abajo a la izquierda
        Cuarto copia() { Cuarto c = new Cuarto(); c.id = id; c.nombre = nombre; c.x = x; c.y = y; c.w = w; c.h = h; return c; }
    }

    /** Puerta, ventana o paso sobre un lado de un cuarto (o de la casa, cuarto = -1). */
    static final class Abertura {
        int id, cuarto = -1, lado;        // lado: 0 abajo, 1 derecha, 2 arriba, 3 izquierda
        int tipo;                         // 0 puerta, 1 ventana, 2 paso, 3 puerta doble, 4 corrediza
        float pos = 500;                  // del arranque del lado al borde del hueco (mm)
        float ancho = 800, alto = 2100, ante = 0;   // ante = altura desde el sobrepiso
        boolean abreOtroLado;
    }

    /** Un mueble de la librería, dentro de un cuarto (se mueve con él). */
    static final class Mueble {
        int id, cuarto = -1;
        String clave, nombre;
        float x, y, w, h, z = 800;        // x, y desde la esquina de adentro del cuarto (o absolutos si cuarto = -1)
        int giro;                         // 0, 90, 180, 270
    }

    final List<Cuarto> cuartos = new ArrayList<>();
    final List<Abertura> aberturas = new ArrayList<>();
    final List<Mueble> muebles = new ArrayList<>();

    static final String[] TIPOS = {"Puerta", "Ventana", "Paso", "Puerta doble", "Corrediza"};

    // ---------------- Geometría ----------------

    float inX0() { return gExt; }
    float inY0() { return gExt; }
    float inX1() { return ancho - gExt; }
    float inY1() { return fondo - gExt; }

    Cuarto cuarto(int id) { for (Cuarto c : cuartos) if (c.id == id) return c; return null; }

    /** El cuarto está entero dentro de la casa. */
    boolean adentro(Cuarto c) {
        return c.x >= inX0() - 0.5f && c.y >= inY0() - 0.5f && c.x + c.w <= inX1() + 0.5f && c.y + c.h <= inY1() + 0.5f;
    }

    /** Está montado a medias en la casa (no cabe): se pinta en rojo. */
    boolean noCabe(Cuarto c) {
        boolean toca = c.x < ancho && c.x + c.w > 0 && c.y < fondo && c.y + c.h > 0;
        if (!toca) return false;
        if (!adentro(c)) return true;
        for (Cuarto o : cuartos) {
            if (o == c) continue;
            if (c.x < o.x + o.w + gInt - 0.5f && c.x + c.w > o.x - gInt + 0.5f && c.y < o.y + o.h + gInt - 0.5f && c.y + c.h > o.y - gInt + 0.5f) return true;
        }
        return false;
    }

    /** Grueso del muro de ese lado del cuarto: el de afuera si el lado va pegado a la cara de adentro de la casa. */
    float grueso(Cuarto c, int lado) {
        if (c == null) return gExt;
        if (!adentro(c)) return gInt;
        switch (lado) {
            case 0: return Math.abs(c.y - inY0()) < 1 ? gExt : gInt;
            case 1: return Math.abs(c.x + c.w - inX1()) < 1 ? gExt : gInt;
            case 2: return Math.abs(c.y + c.h - inY1()) < 1 ? gExt : gInt;
            default: return Math.abs(c.x - inX0()) < 1 ? gExt : gInt;
        }
    }

    /** Dónde queda un hueco en el piso: {x0, y0, x1, y1} (atraviesa todo el muro) y si el muro va en X (true) o en Y. */
    float[] huella(Abertura a) {
        float x0, y0, x1, y1;
        Cuarto c = cuarto(a.cuarto);
        float bx0, by0, bx1, by1;   // la cara de adentro del lado
        if (c == null) { bx0 = inX0(); by0 = inY0(); bx1 = inX1(); by1 = inY1(); }
        else { bx0 = c.x; by0 = c.y; bx1 = c.x + c.w; by1 = c.y + c.h; }
        float g = grueso(c, a.lado) + 2;
        switch (a.lado) {
            case 0: x0 = bx0 + a.pos; x1 = x0 + a.ancho; y1 = by0 + 1; y0 = by0 - g; break;
            case 2: x0 = bx0 + a.pos; x1 = x0 + a.ancho; y0 = by1 - 1; y1 = by1 + g; break;
            case 1: y0 = by0 + a.pos; y1 = y0 + a.ancho; x0 = bx1 - 1; x1 = bx1 + g; break;
            default: y0 = by0 + a.pos; y1 = y0 + a.ancho; x1 = bx0 + 1; x0 = bx0 - g; break;
        }
        return new float[]{x0, y0, x1, y1, (a.lado == 0 || a.lado == 2) ? 1 : 0};
    }

    /** Largo del lado donde va la abertura. */
    float largoLado(Abertura a) {
        Cuarto c = cuarto(a.cuarto);
        if (c == null) return (a.lado == 0 || a.lado == 2) ? inX1() - inX0() : inY1() - inY0();
        return (a.lado == 0 || a.lado == 2) ? c.w : c.h;
    }

    /** Las celdas de muro: rectángulos {x0, y0, x1, y1} que juntos son todos los muros (el de la casa más el anillo de cada cuarto). */
    List<float[]> celdasMuro(List<float[]> extras) {
        TreeSet<Float> xs = new TreeSet<>(), ys = new TreeSet<>();
        xs.add(0f); xs.add(ancho); xs.add(inX0()); xs.add(inX1());
        ys.add(0f); ys.add(fondo); ys.add(inY0()); ys.add(inY1());
        for (Cuarto c : cuartos) {
            xs.add(c.x); xs.add(c.x + c.w); xs.add(c.x - gInt); xs.add(c.x + c.w + gInt);
            ys.add(c.y); ys.add(c.y + c.h); ys.add(c.y - gInt); ys.add(c.y + c.h + gInt);
        }
        if (extras != null) for (float[] e : extras) { xs.add(e[0]); xs.add(e[2]); ys.add(e[1]); ys.add(e[3]); }
        List<Float> X = new ArrayList<>(xs), Y = new ArrayList<>(ys);
        int nx = X.size() - 1, ny = Y.size() - 1;
        boolean[][] m = new boolean[nx][ny];
        for (int i = 0; i < nx; i++) for (int j = 0; j < ny; j++) {
            float cx = (X.get(i) + X.get(i + 1)) / 2, cy = (Y.get(j) + Y.get(j + 1)) / 2;
            if (X.get(i + 1) - X.get(i) < 0.01f || Y.get(j + 1) - Y.get(j) < 0.01f) continue;
            boolean muro = cx > 0 && cx < ancho && cy > 0 && cy < fondo && !(cx > inX0() && cx < inX1() && cy > inY0() && cy < inY1());
            if (!muro) for (Cuarto c : cuartos) if (cx > c.x - gInt && cx < c.x + c.w + gInt && cy > c.y - gInt && cy < c.y + c.h + gInt) { muro = true; break; }
            if (muro) for (Cuarto c : cuartos) if (cx > c.x && cx < c.x + c.w && cy > c.y && cy < c.y + c.h) { muro = false; break; }
            m[i][j] = muro;
        }
        // juntar celdas en rectángulos grandes (menos piezas, el 3D va más liviano)
        List<float[]> r = new ArrayList<>();
        boolean[][] usado = new boolean[nx][ny];
        for (int j = 0; j < ny; j++) for (int i = 0; i < nx; i++) {
            if (!m[i][j] || usado[i][j]) continue;
            int i2 = i;
            while (i2 + 1 < nx && m[i2 + 1][j] && !usado[i2 + 1][j]) i2++;
            int j2 = j;
            boolean sigue = true;
            while (sigue && j2 + 1 < ny) {
                for (int k = i; k <= i2; k++) if (!m[k][j2 + 1] || usado[k][j2 + 1]) { sigue = false; break; }
                if (sigue) j2++;
            }
            for (int a = i; a <= i2; a++) for (int b = j; b <= j2; b++) usado[a][b] = true;
            r.add(new float[]{X.get(i), Y.get(j), X.get(i2 + 1), Y.get(j2 + 1)});
        }
        return r;
    }

    /** Área por dentro de un cuarto en m². */
    static double m2(Cuarto c) { return c.w * (double) c.h / 1e6; }

    // ---------------- Imanes ----------------

    /** Las líneas donde se pega un cuarto que se mueve: caras de adentro de la casa y caras de los otros cuartos más un muro. */
    void imanes(Cuarto yo, List<Float> vx, List<Float> vy) {
        vx.add(inX0()); vx.add(inX1()); vy.add(inY0()); vy.add(inY1());
        for (Cuarto c : cuartos) {
            if (c == yo) continue;
            vx.add(c.x - gInt); vx.add(c.x + c.w + gInt); vx.add(c.x); vx.add(c.x + c.w);
            vy.add(c.y - gInt); vy.add(c.y + c.h + gInt); vy.add(c.y); vy.add(c.y + c.h);
        }
    }

    // ---------------- Guardar ----------------

    JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("ancho", ancho); o.put("fondo", fondo); o.put("gExt", gExt); o.put("gInt", gInt); o.put("alto", alto);
        o.put("sobrepiso", verSobrepiso); o.put("sig", sigId);
        JSONArray a = new JSONArray();
        for (Cuarto c : cuartos) {
            JSONObject x = new JSONObject();
            x.put("id", c.id); x.put("n", c.nombre); x.put("x", c.x); x.put("y", c.y); x.put("w", c.w); x.put("h", c.h);
            a.put(x);
        }
        o.put("cuartos", a);
        JSONArray b = new JSONArray();
        for (Abertura v : aberturas) {
            JSONObject x = new JSONObject();
            x.put("id", v.id); x.put("c", v.cuarto); x.put("l", v.lado); x.put("t", v.tipo); x.put("p", v.pos);
            x.put("a", v.ancho); x.put("al", v.alto); x.put("an", v.ante); x.put("o", v.abreOtroLado);
            b.put(x);
        }
        o.put("aberturas", b);
        JSONArray d = new JSONArray();
        for (Mueble mu : muebles) {
            JSONObject x = new JSONObject();
            x.put("id", mu.id); x.put("c", mu.cuarto); x.put("k", mu.clave); x.put("n", mu.nombre);
            x.put("x", mu.x); x.put("y", mu.y); x.put("w", mu.w); x.put("h", mu.h); x.put("z", mu.z); x.put("g", mu.giro);
            d.put(x);
        }
        o.put("muebles", d);
        return o;
    }

    static CasaPlano deJson(JSONObject o) {
        CasaPlano p = new CasaPlano();
        if (o == null) return p;
        p.ancho = (float) o.optDouble("ancho", 10900); p.fondo = (float) o.optDouble("fondo", 6360);
        p.gExt = (float) o.optDouble("gExt", 120); p.gInt = (float) o.optDouble("gInt", 120); p.alto = (float) o.optDouble("alto", 2500);
        p.verSobrepiso = o.optBoolean("sobrepiso", true); p.sigId = o.optInt("sig", 1);
        JSONArray a = o.optJSONArray("cuartos");
        if (a != null) for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            Cuarto c = new Cuarto();
            c.id = x.optInt("id"); c.nombre = x.optString("n", "Cuarto");
            c.x = (float) x.optDouble("x"); c.y = (float) x.optDouble("y"); c.w = (float) x.optDouble("w", 3000); c.h = (float) x.optDouble("h", 3000);
            p.cuartos.add(c);
        }
        JSONArray b = o.optJSONArray("aberturas");
        if (b != null) for (int i = 0; i < b.length(); i++) {
            JSONObject x = b.optJSONObject(i);
            if (x == null) continue;
            Abertura v = new Abertura();
            v.id = x.optInt("id"); v.cuarto = x.optInt("c", -1); v.lado = x.optInt("l"); v.tipo = x.optInt("t");
            v.pos = (float) x.optDouble("p", 500); v.ancho = (float) x.optDouble("a", 800); v.alto = (float) x.optDouble("al", 2100);
            v.ante = (float) x.optDouble("an", 0); v.abreOtroLado = x.optBoolean("o", false);
            p.aberturas.add(v);
        }
        JSONArray d = o.optJSONArray("muebles");
        if (d != null) for (int i = 0; i < d.length(); i++) {
            JSONObject x = d.optJSONObject(i);
            if (x == null) continue;
            Mueble mu = new Mueble();
            mu.id = x.optInt("id"); mu.cuarto = x.optInt("c", -1); mu.clave = x.optString("k", "caja"); mu.nombre = x.optString("n", "Mueble");
            mu.x = (float) x.optDouble("x"); mu.y = (float) x.optDouble("y"); mu.w = (float) x.optDouble("w", 500); mu.h = (float) x.optDouble("h", 500);
            mu.z = (float) x.optDouble("z", 800); mu.giro = x.optInt("g", 0);
            p.muebles.add(mu);
        }
        int mx = 0;
        for (Cuarto c : p.cuartos) mx = Math.max(mx, c.id);
        for (Abertura v : p.aberturas) mx = Math.max(mx, v.id);
        for (Mueble mu : p.muebles) mx = Math.max(mx, mu.id);
        p.sigId = Math.max(p.sigId, mx + 1);
        return p;
    }

    // ---------------- La casa 111026 (la del video de Floor Plan) ----------------

    static CasaPlano casa111026() {
        CasaPlano p = new CasaPlano();
        p.ancho = 10900; p.fondo = 6360; p.gExt = 120; p.gInt = 120; p.alto = 2500;
        float g = 120;
        Cuarto pieza2 = p.nuevoCuarto("Pieza 2", g, g, 3000, 4000);
        Cuarto patio = p.nuevoCuarto("Patio de ropas", g, g + 4000 + g, 3000, 2000);
        Cuarto pieza1 = p.nuevoCuarto("Pieza 1", g + 3000 + g, g, 3000, 4000);
        float bx = g + 3000 + g + 3000 + g;
        float hb = (4000 - g) / 2;
        Cuarto bano1 = p.nuevoCuarto("Baño", bx, g, 1300, hb);
        Cuarto bano2 = p.nuevoCuarto("Baño", bx, g + hb + g, 1300, hb);
        Cuarto cocina = p.nuevoCuarto("Cocina", g + 3000 + g, g + 4000 + g, 4420, 2000);
        Cuarto sala = p.nuevoCuarto("Sala-comedor", bx + 1300 + g, g, 3000, 6120);
        // puertas
        p.abertura(pieza2.id, 2, 0, 2100, 800, 2100, 0);
        p.abertura(pieza1.id, 2, 0, 150, 800, 2100, 0);
        p.abertura(bano1.id, 3, 0, 1000, 650, 2100, 0);   // el de abajo entra por la Pieza 1
        p.abertura(bano2.id, 2, 0, 500, 650, 2100, 0);    // el de arriba entra por la cocina
        p.abertura(cocina.id, 1, 2, 300, 900, 2100, 0);
        p.abertura(sala.id, 1, 3, 2800, 1400, 2100, 0);
        p.abertura(patio.id, 1, 2, 300, 800, 2100, 0);
        // ventanas
        p.abertura(pieza2.id, 0, 1, 1100, 1200, 1100, 1000);
        p.abertura(pieza2.id, 3, 1, 1500, 1200, 1100, 1000);
        p.abertura(pieza1.id, 0, 1, 1100, 1200, 1100, 1000);
        p.abertura(cocina.id, 2, 1, 800, 1500, 1000, 1100);
        p.abertura(sala.id, 2, 1, 900, 1200, 1100, 1000);
        p.abertura(sala.id, 0, 1, 900, 1200, 1100, 1000);
        p.abertura(patio.id, 2, 1, 900, 1200, 1000, 1100);
        // muebles principales
        p.mueble(pieza2.id, "cama2", 400, 1700);
        p.mueble(pieza1.id, "cama2", 800, 1700);
        p.mueble(cocina.id, "meson", 60, 1400);
        p.mueble(cocina.id, "estufa", 1300, 1400);
        p.mueble(cocina.id, "nevera", 3600, 1250);
        p.mueble(bano1.id, "sanitario", 100, 900);
        p.mueble(bano1.id, "lavamanos", 100, 200);
        p.mueble(bano2.id, "sanitario", 100, 900);
        p.mueble(bano2.id, "lavamanos", 100, 200);
        p.mueble(sala.id, "sofa", 100, 600);
        p.mueble(sala.id, "comedor4", 900, 4200);
        p.mueble(patio.id, "lavadero", 100, 1300);
        p.mueble(patio.id, "lavadora", 900, 1350);
        return p;
    }

    Cuarto nuevoCuarto(String n, float x, float y, float w, float h) {
        Cuarto c = new Cuarto();
        c.id = sigId++; c.nombre = n; c.x = x; c.y = y; c.w = w; c.h = h;
        cuartos.add(c);
        return c;
    }

    Abertura abertura(int cuarto, int lado, int tipo, float pos, float ancho, float alto, float ante) {
        Abertura a = new Abertura();
        a.id = sigId++; a.cuarto = cuarto; a.lado = lado; a.tipo = tipo; a.pos = pos; a.ancho = ancho; a.alto = alto; a.ante = ante;
        aberturas.add(a);
        return a;
    }

    Mueble mueble(int cuarto, String clave, float x, float y) {
        Libreria.Item it = Libreria.item(clave);
        Mueble m = new Mueble();
        m.id = sigId++; m.cuarto = cuarto; m.clave = clave;
        m.nombre = it == null ? clave : it.nombre;
        m.w = it == null ? 500 : it.w; m.h = it == null ? 500 : it.h; m.z = it == null ? 800 : it.z;
        m.x = x; m.y = y;
        Cuarto c = cuarto(cuarto);
        if (c != null) { m.x = Math.max(0, Math.min(m.x, c.w - m.w)); m.y = Math.max(0, Math.min(m.y, c.h - m.h)); }
        muebles.add(m);
        return m;
    }

    /** Dónde queda el mueble en la planta: {x0, y0, x1, y1}. */
    float[] cajaMueble(Mueble m) {
        Cuarto c = cuarto(m.cuarto);
        float ox = c == null ? 0 : c.x, oy = c == null ? 0 : c.y;
        boolean vuelto = m.giro == 90 || m.giro == 270;
        float w = vuelto ? m.h : m.w, h = vuelto ? m.w : m.h;
        return new float[]{ox + m.x, oy + m.y, ox + m.x + w, oy + m.y + h};
    }

    /** El baño de siempre: 1,20 × 1,70 con ducha recta de 1,20 × 0,80, sanitario y lavamanos. */
    Cuarto banoDeSiempre(float x, float y) {
        Cuarto c = nuevoCuarto("Baño", x, y, 1200, 1700);
        mueble(c.id, "ducha120", 0, 900);
        mueble(c.id, "sanitario", 50, 100);
        mueble(c.id, "lavamanos", 650, 100);
        return c;
    }

    static List<Float> ordenar(List<Float> l) { Collections.sort(l); return l; }
}
