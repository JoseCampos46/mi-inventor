package co.jose.miinventor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * v6.4 Chepe CAD: la planta de la casa. Un dedo corre la hoja o arrastra lo escogido, dos dedos acercan.
 * Tocar un cuarto lo escoge: salen agarres en la mitad de cada lado para estirarlo y se arrastra desde adentro.
 * Los cuartos se pegan solos a la cara de la casa y a un muro de distancia de los otros cuartos.
 */
public class VistaPlano extends View {

    interface Oyente { void escogio(); void cambio(); void antes(); void tocoParaPoner(float x, float y); void tocoCota(); void muroNuevo(float x0, float y0, float x1, float y1); }

    CasaPlano p = new CasaPlano();
    Oyente oyente;
    /** 0 nada · 1 cuarto · 2 abertura · 3 mueble · 4 muro suelto. */
    int tipoSel;
    int idSel = -1;
    /** Si es true, el próximo toque en la hoja es para poner algo (puerta, ventana, mueble). */
    boolean poniendo;
    /** v6.5: trazando un muro suelto (se arrastra del arranque a la llegada). */
    boolean trazando;
    private float[] tr;          // {x0, y0, x1, y1} del muro que se está trazando
    private float[] guia;        // línea punteada de rastreo {x0, y0, x1, y1}
    private float[] zonaCota;    // dónde quedó escrita la cota que se puede tocar (pantalla)
    String aviso = "";

    float esc = 0.05f, offX = 40, offY = 600;
    private final Paint pMuro = new Paint(Paint.ANTI_ALIAS_FLAG), pPiso = new Paint(Paint.ANTI_ALIAS_FLAG), pLinea = new Paint(Paint.ANTI_ALIAS_FLAG),
            pTxt = new Paint(Paint.ANTI_ALIAS_FLAG), pCota = new Paint(Paint.ANTI_ALIAS_FLAG), pSel = new Paint(Paint.ANTI_ALIAS_FLAG);

    public VistaPlano(Context c) {
        super(c);
        pMuro.setColor(0xFF4E4E4E);
        pPiso.setColor(0xFFE9DFC4);
        pLinea.setStyle(Paint.Style.STROKE);
        pLinea.setColor(Color.BLACK);
        pLinea.setStrokeWidth(dp(1));
        pTxt.setColor(Color.BLACK);
        pTxt.setTextSize(dp(12));
        pTxt.setFakeBoldText(true);
        pCota.setColor(Color.BLACK);
        pCota.setTextSize(dp(10));
        pCota.setStrokeWidth(dp(0.8f));
        pSel.setStyle(Paint.Style.STROKE);
        pSel.setColor(0xFF2E7D32);
        pSel.setStrokeWidth(dp(3));
    }

    float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    float sx(float x) { return offX + x * esc; }
    float sy(float y) { return offY - y * esc; }
    float mx(float X) { return (X - offX) / esc; }
    float my(float Y) { return (offY - Y) / esc; }

    /** Ver todo: la casa y lo que haya afuera llenan la pantalla. */
    void encuadrar() {
        float x0 = -900, y0 = -900, x1 = p.ancho + 900, y1 = p.fondo + 900;
        for (CasaPlano.Cuarto c : p.cuartos) {
            x0 = Math.min(x0, c.x - 900); y0 = Math.min(y0, c.y - 900);
            x1 = Math.max(x1, c.x + c.w + 900); y1 = Math.max(y1, c.y + c.h + 900);
        }
        float w = getWidth() > 0 ? getWidth() : dp(360), h = getHeight() > 0 ? getHeight() : dp(500);
        esc = Math.min(w / (x1 - x0), h / (y1 - y0));
        offX = (w - (x1 - x0) * esc) / 2 - x0 * esc;
        offY = h - (h - (y1 - y0) * esc) / 2 + y0 * esc;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) { encuadrar(); }

    // =====================================================================
    //                                Dibujo
    // =====================================================================

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFFF5F7F8);
        pintar(c, false);
        if (!aviso.isEmpty()) {
            Paint a = new Paint(Paint.ANTI_ALIAS_FLAG);
            a.setTextSize(dp(13));
            a.setColor(0xFF263238);
            c.drawText(aviso, dp(8), dp(18), a);
        }
    }

    /** papel = true: para el PDF (todo en negro nítido, sin agarres). */
    void pintar(Canvas c, boolean papel) {
        float g = p.gExt;
        // sobrepiso: una franja suave bajo la casa
        if (p.verSobrepiso && !papel) {
            Paint sp = new Paint();
            sp.setColor(0xFFDCE3E6);
            c.drawRect(sx(-150), sy(p.fondo + 150), sx(p.ancho + 150), sy(-150), sp);
        }
        // espacio de adentro sin cuarto (patio, pasillo): blanco
        Paint blanco = new Paint();
        blanco.setColor(Color.WHITE);
        c.drawRect(sx(0), sy(p.fondo), sx(p.ancho), sy(0), blanco);
        // los muros
        for (float[] r : p.celdasMuro(null)) c.drawRect(sx(r[0]), sy(r[3]), sx(r[2]), sy(r[1]), pMuro);
        // los pisos de los cuartos
        for (CasaPlano.Cuarto k : p.cuartos) {
            Paint pp = p.noCabe(k) ? rojo() : pPiso;
            c.drawRect(sx(k.x), sy(k.y + k.h), sx(k.x + k.w), sy(k.y), pp);
        }
        // puertas y ventanas (se borra el muro donde van y se dibuja su símbolo)
        for (CasaPlano.Abertura a : p.aberturas) dibujarAbertura(c, a, papel);
        // muebles
        Paint pm = new Paint(Paint.ANTI_ALIAS_FLAG);
        pm.setColor(0xFF37474F);
        pm.setStrokeWidth(papel ? 0.7f : dp(1));
        for (CasaPlano.Mueble m : p.muebles) {
            float[] b = p.cajaMueble(m);
            RectF r = new RectF(sx(b[0]), sy(b[3]), sx(b[2]), sy(b[1]));
            if (!papel) {
                Paint f = new Paint();
                Libreria.Item it = Libreria.item(m.clave);
                f.setColor(((it == null ? 0xFFB0BEC5 : it.color) & 0x00FFFFFF) | 0x55000000);
                c.drawRect(r, f);
            }
            c.save();
            if (m.giro != 0) {
                // el dibujo se gira dentro de su caja
                c.rotate(-m.giro, r.centerX(), r.centerY());
                boolean v = m.giro == 90 || m.giro == 270;
                if (v) r = new RectF(r.centerX() - r.height() / 2, r.centerY() - r.width() / 2, r.centerX() + r.height() / 2, r.centerY() + r.width() / 2);
            }
            Libreria.dibujar(c, m.clave, r, pm);
            c.restore();
        }
        // nombres y medidas de los cuartos
        for (CasaPlano.Cuarto k : p.cuartos) {
            float cx = sx(k.x + k.w / 2), cy = sy(k.y + k.h / 2);
            pTxt.setTextSize(papel ? 9 : dp(12));
            pTxt.setFakeBoldText(true);
            texto(c, k.nombre, cx, cy - (papel ? 4 : dp(6)), pTxt);
            pTxt.setFakeBoldText(false);
            pTxt.setTextSize(papel ? 7 : dp(10));
            texto(c, Pieza.n(k.w) + " x " + Pieza.n(k.h) + " · " + String.format(java.util.Locale.US, "%.1f m²", CasaPlano.m2(k)), cx, cy + (papel ? 6 : dp(9)), pTxt);
        }
        // cotas de afuera, encadenadas, en los cuatro lados
        cotasAfuera(c, papel);
        // lo escogido
        if (!papel) seleccion(c);
        if (!papel && tr != null) dibujarTrazo(c);
    }

    private void dibujarTrazo(Canvas c) {
        Paint m = new Paint(Paint.ANTI_ALIAS_FLAG);
        m.setColor(0xAA1565C0);
        m.setStrokeWidth(Math.max(dp(3), p.gInt * esc));
        c.drawLine(sx(tr[0]), sy(tr[1]), sx(tr[2]), sy(tr[3]), m);
        if (guia != null) {
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setColor(0xFF00897B);
            g.setStrokeWidth(dp(1.2f));
            g.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(4)}, 0));
            c.drawLine(sx(guia[0]), sy(guia[1]), sx(guia[2]), sy(guia[3]), g);
        }
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(0xFFD84315);
        t.setTextSize(dp(14));
        t.setFakeBoldText(true);
        String s = Pieza.n((float) Math.hypot(tr[2] - tr[0], tr[3] - tr[1]));
        c.drawText(s, (sx(tr[0]) + sx(tr[2])) / 2 + dp(8), (sy(tr[1]) + sy(tr[3])) / 2 - dp(10), t);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(0xFF1565C0);
        c.drawCircle(sx(tr[0]), sy(tr[1]), dp(5), pt);
    }

    private Paint rojo() { Paint r = new Paint(); r.setColor(0xFFEF9A9A); return r; }

    private void texto(Canvas c, String t, float x, float y, Paint p) {
        c.drawText(t, x - p.measureText(t) / 2, y, p);
    }

    private void dibujarAbertura(Canvas c, CasaPlano.Abertura a, boolean papel) {
        float[] h = p.huella(a);
        float x0 = sx(h[0]), y0 = sy(h[3]), x1 = sx(h[2]), y1 = sy(h[1]);
        Paint hueco = new Paint();
        hueco.setColor(a.tipo == 1 ? 0xFFFFFFFF : 0xFFE9DFC4);
        c.drawRect(x0, y0, x1, y1, hueco);
        Paint l = new Paint(Paint.ANTI_ALIAS_FLAG);
        l.setStyle(Paint.Style.STROKE);
        l.setColor(Color.BLACK);
        l.setStrokeWidth(papel ? 0.6f : dp(1));
        boolean enX = h[4] > 0.5f;
        if (a.tipo == 1) {   // ventana: dos rayas por el centro del muro
            if (enX) { float m = (y0 + y1) / 2; c.drawLine(x0, m - dp(1.5f), x1, m - dp(1.5f), l); c.drawLine(x0, m + dp(1.5f), x1, m + dp(1.5f), l); }
            else { float m = (x0 + x1) / 2; c.drawLine(m - dp(1.5f), y0, m - dp(1.5f), y1, l); c.drawLine(m + dp(1.5f), y0, m + dp(1.5f), y1, l); }
            c.drawRect(x0, y0, x1, y1, l);
            return;
        }
        if (a.tipo == 2) { c.drawRect(x0, y0, x1, y1, l); return; }   // paso: solo el hueco
        if (a.tipo == 4) {   // corrediza: dos hojas montadas
            if (enX) { float m = (y0 + y1) / 2; c.drawLine(x0, m - dp(2), (x0 + x1) / 2 + dp(4), m - dp(2), l); c.drawLine((x0 + x1) / 2 - dp(4), m + dp(2), x1, m + dp(2), l); }
            else { float m = (x0 + x1) / 2; c.drawLine(m - dp(2), y0, m - dp(2), (y0 + y1) / 2 + dp(4), l); c.drawLine(m + dp(2), (y0 + y1) / 2 - dp(4), m + dp(2), y1, l); }
            return;
        }
        // puerta: la hoja y el arco hacia adentro del cuarto
        CasaPlano.Cuarto k = p.cuarto(a.cuarto);
        int lado = a.lado;
        boolean haciaAdentro = !a.abreOtroLado;
        int hojas = a.tipo == 3 ? 2 : 1;
        float w = a.ancho * esc / hojas;
        for (int i0 = 0; i0 < hojas; i0++) {
            int i = hojas == 1 && a.bisagraDer ? 1 : i0;   // v6.5: bisagra a la izquierda o a la derecha
            float bx, by;   // bisagra
            float sgn;      // hacia dónde abre (pantalla)
            if (lado == 0 || lado == 2) {
                float caraY = lado == 0 ? (k == null ? sy(p.inY0()) : sy(k.y)) : (k == null ? sy(p.inY1()) : sy(k.y + k.h));
                sgn = (lado == 0) == haciaAdentro ? -1 : 1;
                bx = i == 0 ? x0 : x1; by = caraY;
                float dirX = i == 0 ? 1 : -1;
                c.drawLine(bx, by, bx, by + sgn * w, l);
                RectF ov = new RectF(bx - w, by - w, bx + w, by + w);
                float start = sgn < 0 ? (dirX > 0 ? 270 : 180) : (dirX > 0 ? 0 : 90);
                l.setPathEffect(new DashPathEffect(new float[]{dp(3), dp(3)}, 0));
                c.drawArc(ov, start, 90, false, l);
                l.setPathEffect(null);
            } else {
                float caraX = lado == 3 ? (k == null ? sx(p.inX0()) : sx(k.x)) : (k == null ? sx(p.inX1()) : sx(k.x + k.w));
                sgn = (lado == 3) == haciaAdentro ? 1 : -1;
                bx = caraX; by = i == 0 ? y1 : y0;
                float dirY = i == 0 ? -1 : 1;
                c.drawLine(bx, by, bx + sgn * w, by, l);
                RectF ov = new RectF(bx - w, by - w, bx + w, by + w);
                float start = sgn > 0 ? (dirY < 0 ? 270 : 0) : (dirY < 0 ? 180 : 90);
                l.setPathEffect(new DashPathEffect(new float[]{dp(3), dp(3)}, 0));
                c.drawArc(ov, start, 90, false, l);
                l.setPathEffect(null);
            }
        }
    }

    /** Cotas encadenadas por fuera: de cara a cara de cada muro y cuarto que toca ese lado de la casa, y la total. */
    private void cotasAfuera(Canvas c, boolean papel) {
        pCota.setTextSize(papel ? 6.5f : dp(9));
        pCota.setStrokeWidth(papel ? 0.5f : dp(0.8f));
        float sep = 450, sep2 = 900;
        for (int lado = 0; lado < 4; lado++) {
            TreeSet<Float> xs = new TreeSet<>();
            boolean enX = lado == 0 || lado == 2;
            float largo = enX ? p.ancho : p.fondo;
            xs.add(0f); xs.add(largo);
            xs.add(p.gExt); xs.add(largo - p.gExt);
            for (CasaPlano.Cuarto k : p.cuartos) {
                if (!p.adentro(k)) continue;
                boolean toca = lado == 0 ? Math.abs(k.y - p.inY0()) < 1 : lado == 2 ? Math.abs(k.y + k.h - p.inY1()) < 1
                        : lado == 3 ? Math.abs(k.x - p.inX0()) < 1 : Math.abs(k.x + k.w - p.inX1()) < 1;
                if (!toca) continue;
                if (enX) { xs.add(k.x); xs.add(k.x + k.w); } else { xs.add(k.y); xs.add(k.y + k.h); }
            }
            List<Float> l = new ArrayList<>(xs);
            for (int i = 0; i + 1 < l.size(); i++) {
                float a = l.get(i), b = l.get(i + 1);
                if (b - a < 1) continue;
                cota(c, lado, a, b, sep, papel);
            }
            cota(c, lado, 0, largo, sep2, papel);
        }
    }

    private void cota(Canvas c, int lado, float a, float b, float sep, boolean papel) {
        float X0, Y0, X1, Y1;
        switch (lado) {
            case 0: X0 = sx(a); X1 = sx(b); Y0 = Y1 = sy(-sep); break;
            case 2: X0 = sx(a); X1 = sx(b); Y0 = Y1 = sy(p.fondo + sep); break;
            case 3: Y0 = sy(a); Y1 = sy(b); X0 = X1 = sx(-sep); break;
            default: Y0 = sy(a); Y1 = sy(b); X0 = X1 = sx(p.ancho + sep); break;
        }
        c.drawLine(X0, Y0, X1, Y1, pCota);
        float t = papel ? 2.5f : dp(3);
        if (lado == 0 || lado == 2) { c.drawLine(X0, Y0 - t, X0, Y0 + t, pCota); c.drawLine(X1, Y1 - t, X1, Y1 + t, pCota); }
        else { c.drawLine(X0 - t, Y0, X0 + t, Y0, pCota); c.drawLine(X1 - t, Y1, X1 + t, Y1, pCota); }
        String s = Pieza.n(b - a);
        float w = pCota.measureText(s);
        if (lado == 0 || lado == 2) {
            if (w < Math.abs(X1 - X0) - 2 || b - a > 300) c.drawText(s, (X0 + X1) / 2 - w / 2, Y0 - t - 1, pCota);
        } else {
            c.save();
            c.rotate(-90, X0 - t - 1, (Y0 + Y1) / 2);
            c.drawText(s, X0 - t - 1 - w / 2, (Y0 + Y1) / 2, pCota);
            c.restore();
        }
    }

    private void seleccion(Canvas c) {
        zonaCota = null;
        if (tipoSel == 1) {
            CasaPlano.Cuarto k = p.cuarto(idSel);
            if (k == null) return;
            c.drawRect(sx(k.x), sy(k.y + k.h), sx(k.x + k.w), sy(k.y), pSel);
            Paint ag = new Paint(Paint.ANTI_ALIAS_FLAG);
            ag.setColor(0xFF2E7D32);
            for (float[] h : agarres(k)) c.drawCircle(h[0], h[1], dp(9), ag);
            Paint bl = new Paint(Paint.ANTI_ALIAS_FLAG);
            bl.setColor(Color.WHITE);
            for (float[] h : agarres(k)) c.drawCircle(h[0], h[1], dp(4), bl);
        } else if (tipoSel == 2) {
            for (CasaPlano.Abertura a : p.aberturas) if (a.id == idSel) {
                float[] h = p.huella(a);
                c.drawRect(sx(h[0]), sy(h[3]), sx(h[2]), sy(h[1]), pSel);
                // cota del borde del hueco a la esquina del cuarto
                cotaAbertura(c, a);
            }
        } else if (tipoSel == 3) {
            for (CasaPlano.Mueble m : p.muebles) if (m.id == idSel) {
                float[] b = p.cajaMueble(m);
                c.drawRect(sx(b[0]), sy(b[3]), sx(b[2]), sy(b[1]), pSel);
            }
        } else if (tipoSel == 4) {
            for (CasaPlano.Muro m : p.muros) if (m.id == idSel) {
                float[] b = p.cajaMuro(m);
                c.drawRect(sx(b[0]), sy(b[3]), sx(b[2]), sy(b[1]), pSel);
                // cota del largo y cota a la cara de la casa (se tocan para cambiarlas)
                Paint pc = new Paint(Paint.ANTI_ALIAS_FLAG);
                pc.setColor(0xFFD84315);
                pc.setStrokeWidth(dp(1.2f));
                pc.setTextSize(dp(12));
                pc.setFakeBoldText(true);
                String t = "↔ " + Pieza.n(m.largo());
                float tx = (sx(m.x0) + sx(m.x1)) / 2 + dp(10), ty = (sy(m.y0) + sy(m.y1)) / 2 - dp(12);
                c.drawText(t, tx, ty, pc);
                zonaCota = new float[]{tx - dp(10), ty - dp(22), tx + pc.measureText(t) + dp(10), ty + dp(10)};
                float x0 = Math.min(m.x0, m.x1), y0 = Math.min(m.y0, m.y1);
                if (m.enX()) {   // distancia de la cara de adentro de la izquierda al arranque
                    float y = sy(m.y0) + dp(16);
                    c.drawLine(sx(p.inX0()), y, sx(x0), y, pc);
                    c.drawText(Pieza.n(x0 - p.inX0()), (sx(p.inX0()) + sx(x0)) / 2 - dp(12), y + dp(14), pc);
                    // v6.7: y su ubicación: de la cara de abajo de la casa al eje del muro
                    float xx = sx(x0) + dp(18);
                    c.drawLine(xx, sy(p.inY0()), xx, sy(m.y0), pc);
                    c.drawText(Pieza.n(m.y0 - p.inY0()), xx + dp(3), (sy(p.inY0()) + sy(m.y0)) / 2, pc);
                } else {
                    float x = sx(m.x0) - dp(16);
                    c.drawLine(x, sy(p.inY0()), x, sy(y0), pc);
                    c.drawText(Pieza.n(y0 - p.inY0()), x - dp(40), (sy(p.inY0()) + sy(y0)) / 2, pc);
                    // v6.7: y su ubicación: de la cara izquierda de la casa al eje del muro
                    float yy = sy(y0) + dp(18);
                    c.drawLine(sx(p.inX0()), yy, sx(m.x0), yy, pc);
                    c.drawText(Pieza.n(m.x0 - p.inX0()), (sx(p.inX0()) + sx(m.x0)) / 2 - dp(12), yy + dp(14), pc);
                }
            }
        }
    }

    private void cotaAbertura(Canvas c, CasaPlano.Abertura a) {
        Paint pc = new Paint(Paint.ANTI_ALIAS_FLAG);
        pc.setColor(0xFFD84315);
        pc.setStrokeWidth(dp(1.2f));
        pc.setTextSize(dp(11));
        pc.setFakeBoldText(true);
        float[] h = p.huella(a);
        CasaPlano.Cuarto k = p.cuarto(a.cuarto);
        float ox = k == null ? p.inX0() : k.x, oy = k == null ? p.inY0() : k.y;
        String t = Pieza.n(a.pos);
        // v6.7: también la cota del otro lado (del borde del hueco a la otra esquina)
        float L = p.largoLado(a);
        String t2 = Pieza.n(L - a.pos - a.ancho);
        if (h[4] > 0.5f) {
            float y2 = (sy(h[1]) + sy(h[3])) / 2 - dp(14);
            c.drawLine(sx(h[2]), y2, sx(ox + L), y2, pc);
            c.drawText(t2, (sx(h[2]) + sx(ox + L)) / 2 - pc.measureText(t2) / 2, y2 - dp(3), pc);
        } else {
            float x2 = (sx(h[0]) + sx(h[2])) / 2 + dp(14);
            c.drawLine(x2, sy(h[3]), x2, sy(oy + L), pc);
            c.drawText(t2, x2 + dp(3), (sy(h[3]) + sy(oy + L)) / 2, pc);
        }
        if (h[4] > 0.5f) {
            float y = (sy(h[1]) + sy(h[3])) / 2 - dp(14);
            c.drawLine(sx(ox), y, sx(h[0]), y, pc);
            float tx = (sx(ox) + sx(h[0])) / 2 - pc.measureText(t) / 2;
            c.drawText(t, tx, y - dp(3), pc);
            zonaCota = new float[]{Math.min(sx(ox), sx(h[0])) - dp(6), y - dp(26), Math.max(sx(ox), sx(h[0])) + dp(6), y + dp(10)};
        } else {
            float x = (sx(h[0]) + sx(h[2])) / 2 + dp(14);
            c.drawLine(x, sy(oy), x, sy(h[1]), pc);
            c.drawText(t, x + dp(3), (sy(oy) + sy(h[1])) / 2, pc);
            zonaCota = new float[]{x - dp(10), Math.min(sy(oy), sy(h[1])) - dp(6), x + pc.measureText(t) + dp(14), Math.max(sy(oy), sy(h[1])) + dp(6)};
        }
    }

    /** Agarres en la mitad de cada lado: abajo, derecha, arriba, izquierda. */
    List<float[]> agarres(CasaPlano.Cuarto k) {
        List<float[]> r = new ArrayList<>();
        r.add(new float[]{sx(k.x + k.w / 2), sy(k.y)});
        r.add(new float[]{sx(k.x + k.w), sy(k.y + k.h / 2)});
        r.add(new float[]{sx(k.x + k.w / 2), sy(k.y + k.h)});
        r.add(new float[]{sx(k.x), sy(k.y + k.h / 2)});
        return r;
    }

    // =====================================================================
    //                                Tocar
    // =====================================================================

    private float lx, ly, dist0, esc0, mx0, my0;
    private boolean dos, movio, arrastrando;
    private int agarre = -1;   // -1 mover todo · 0..3 estirar ese lado
    private float ax, ay;      // dónde arrancó el arrastre (mm)
    private float[] orig;      // cómo estaba lo arrastrado

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                lx = e.getX(); ly = e.getY(); movio = false; dos = false; arrastrando = false; agarre = -1;
                if (trazando) {   // v6.5: arranca el muro suelto, pegado a la punta más cercana
                    float[] q = pegarPunto(mx(lx), my(ly));
                    tr = new float[]{q[0], q[1], q[0], q[1]};
                    guia = null;
                    invalidate();
                    return true;
                }
                // ¿tocó un agarre o lo escogido?
                if (tipoSel == 1) {
                    CasaPlano.Cuarto k = p.cuarto(idSel);
                    if (k != null) {
                        List<float[]> ag = agarres(k);
                        for (int i = 0; i < 4; i++) if (Math.hypot(ag.get(i)[0] - lx, ag.get(i)[1] - ly) < dp(26)) { agarre = i; arrastrando = true; }
                        if (!arrastrando && dentro(k, mx(lx), my(ly))) arrastrando = true;
                        if (arrastrando) orig = new float[]{k.x, k.y, k.w, k.h};
                    }
                } else if (tipoSel == 2) {
                    for (CasaPlano.Abertura a : p.aberturas) if (a.id == idSel && tocaAbertura(a, mx(lx), my(ly))) { arrastrando = true; orig = new float[]{a.pos}; }
                } else if (tipoSel == 4) {
                    for (CasaPlano.Muro m : p.muros) if (m.id == idSel && tocaMuro(m, mx(lx), my(ly))) { arrastrando = true; orig = new float[]{m.x0, m.y0, m.x1, m.y1}; }
                } else if (tipoSel == 3) {
                    for (CasaPlano.Mueble m : p.muebles) if (m.id == idSel) {
                        float[] b = p.cajaMueble(m);
                        if (mx(lx) >= b[0] - 100 && mx(lx) <= b[2] + 100 && my(ly) >= b[1] - 100 && my(ly) <= b[3] + 100) { arrastrando = true; orig = new float[]{m.x, m.y}; }
                    }
                }
                ax = mx(lx); ay = my(ly);
                if (arrastrando && oyente != null) oyente.antes();
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    dos = true; arrastrando = false; tr = null; guia = null;
                    dist0 = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    esc0 = esc;
                    mx0 = mx((e.getX(0) + e.getX(1)) / 2); my0 = my((e.getY(0) + e.getY(1)) / 2);
                }
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (dos && e.getPointerCount() >= 2) {
                    float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    esc = Math.max(0.005f, Math.min(2f, esc0 * d / Math.max(1, dist0)));
                    float cx = (e.getX(0) + e.getX(1)) / 2, cy = (e.getY(0) + e.getY(1)) / 2;
                    offX = cx - mx0 * esc; offY = cy + my0 * esc;
                    movio = true;
                    invalidate();
                    return true;
                }
                float x = e.getX(), y = e.getY();
                if (trazando && tr != null) { seguirTrazo(mx(x), my(y)); movio = true; invalidate(); return true; }
                if (!movio && Math.hypot(x - lx, y - ly) < dp(8)) return true;
                movio = true;
                if (arrastrando) arrastrar(mx(x) - ax, my(y) - ay);
                else { offX += x - lx; offY += y - ly; lx = x; ly = y; }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (trazando && tr != null) {
                    float[] t = tr;
                    tr = null; guia = null; trazando = false; aviso = "";
                    if (Math.hypot(t[2] - t[0], t[3] - t[1]) >= 100 && oyente != null) oyente.muroNuevo(t[0], t[1], t[2], t[3]);
                    else aviso = "Muy corto: arrastre el dedo de donde arranca el muro hasta donde llega";
                    invalidate();
                    return true;
                }
                if (!movio && !dos && zonaCota != null && e.getX() >= zonaCota[0] && e.getX() <= zonaCota[2] && e.getY() >= zonaCota[1] && e.getY() <= zonaCota[3]) {
                    if (oyente != null) oyente.tocoCota();   // v6.5: tocar la cota la cambia
                    return true;
                }
                if (!movio && !dos) tocar(mx(e.getX()), my(e.getY()));
                else if (arrastrando && oyente != null) oyente.cambio();
                arrastrando = false;
                invalidate();
                return true;
        }
        return true;
    }

    private boolean dentro(CasaPlano.Cuarto k, float x, float y) { return x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h; }

    private boolean tocaAbertura(CasaPlano.Abertura a, float x, float y) {
        float[] h = p.huella(a);
        float t = dp(14) / esc;
        return x >= h[0] - t && x <= h[2] + t && y >= h[1] - t && y <= h[3] + t;
    }

    private boolean tocaMuro(CasaPlano.Muro m, float x, float y) {
        float[] b = p.cajaMuro(m);
        float t = dp(14) / esc;
        return x >= b[0] - t && x <= b[2] + t && y >= b[1] - t && y <= b[3] + t;
    }

    /** La punta más cercana (esquinas de casa, cuartos y muros); si no hay, redondea a 10 mm. */
    private float[] pegarPunto(float x, float y) {
        float tol = dp(22) / esc;
        float[] mejor = null;
        double d = tol;
        for (float[] q : p.puntosIman()) { double e = Math.hypot(q[0] - x, q[1] - y); if (e < d) { d = e; mejor = q; } }
        if (mejor != null) { aviso = "Pegado a una punta"; return new float[]{mejor[0], mejor[1]}; }
        return new float[]{Math.round(x / 10f) * 10f, Math.round(y / 10f) * 10f};
    }

    /** Muro derecho o parado (paralelo o perpendicular a la casa) con rastreo: línea punteada a la punta que coincide. */
    private void seguirTrazo(float x, float y) {
        float tol = dp(16) / esc;
        boolean enX = Math.abs(x - tr[0]) >= Math.abs(y - tr[1]);
        float v = enX ? x : y;
        guia = null;
        float mejor = Float.MAX_VALUE;
        for (float[] q : p.puntosIman()) {
            float c = enX ? q[0] : q[1];
            if (Math.abs(c - v) < tol && Math.abs(c - v) < mejor) {
                mejor = Math.abs(c - v);
                guia = enX ? new float[]{q[0], q[1], q[0], tr[1]} : new float[]{q[0], q[1], tr[0], q[1]};
            }
        }
        if (guia != null) v = enX ? guia[0] : guia[1];
        else v = Math.round(v / 10f) * 10f;
        if (enX) { tr[2] = v; tr[3] = tr[1]; } else { tr[2] = tr[0]; tr[3] = v; }
        aviso = "Muro " + Pieza.n((float) Math.hypot(tr[2] - tr[0], tr[3] - tr[1])) + (guia != null ? "  · ⋯ alineado con una punta" : "");
    }

    private void tocar(float x, float y) {
        if (poniendo && oyente != null) { poniendo = false; oyente.tocoParaPoner(x, y); return; }
        // primero aberturas, luego muros sueltos, luego muebles, luego cuartos
        for (CasaPlano.Abertura a : p.aberturas) if (tocaAbertura(a, x, y)) { escoger(2, a.id); return; }
        for (CasaPlano.Muro m : p.muros) if (tocaMuro(m, x, y)) { escoger(4, m.id); return; }
        for (int i = p.muebles.size() - 1; i >= 0; i--) {
            CasaPlano.Mueble m = p.muebles.get(i);
            float[] b = p.cajaMueble(m);
            if (x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3]) { escoger(3, m.id); return; }
        }
        for (int i = p.cuartos.size() - 1; i >= 0; i--) {
            CasaPlano.Cuarto k = p.cuartos.get(i);
            if (dentro(k, x, y)) { escoger(1, k.id); return; }
        }
        escoger(0, -1);
    }

    void escoger(int tipo, int id) {
        tipoSel = tipo; idSel = id;
        if (oyente != null) oyente.escogio();
        invalidate();
    }

    private float iman(float v, List<Float> cand, float tol) {
        float mejor = v, d = tol;
        for (float c : cand) if (Math.abs(c - v) < d) { d = Math.abs(c - v); mejor = c; }
        return mejor == v ? Math.round(v / 10f) * 10f : mejor;
    }

    /** Pega el borde de arranque o el de llegada (v + tam) a la línea más cercana; si no hay, redondea a 10 mm. */
    private float imanPar(float v, float tam, List<Float> cand, float tol) {
        float mejor = Math.round(v / 10f) * 10f, d = tol;
        for (float c : cand) {
            if (Math.abs(c - v) < d) { d = Math.abs(c - v); mejor = c; }
            if (Math.abs(c - (v + tam)) < d) { d = Math.abs(c - (v + tam)); mejor = c - tam; }
        }
        return mejor;
    }

    private void arrastrar(float dx, float dy) {
        float tol = dp(18) / esc;
        if (tipoSel == 1) {
            CasaPlano.Cuarto k = p.cuarto(idSel);
            if (k == null) return;
            List<Float> vx = new ArrayList<>(), vy = new ArrayList<>();
            p.imanes(k, vx, vy);
            if (agarre < 0) {
                k.x = imanPar(orig[0] + dx, k.w, vx, tol);
                k.y = imanPar(orig[1] + dy, k.h, vy, tol);
            } else {
                float x0 = orig[0], y0 = orig[1], x1 = orig[0] + orig[2], y1 = orig[1] + orig[3];
                switch (agarre) {
                    case 0: y0 = Math.min(y1 - 300, iman(orig[1] + dy, vy, tol)); break;
                    case 2: y1 = Math.max(y0 + 300, iman(orig[1] + orig[3] + dy, vy, tol)); break;
                    case 3: x0 = Math.min(x1 - 300, iman(orig[0] + dx, vx, tol)); break;
                    default: x1 = Math.max(x0 + 300, iman(orig[0] + orig[2] + dx, vx, tol)); break;
                }
                k.x = x0; k.y = y0; k.w = x1 - x0; k.h = y1 - y0;
            }
            aviso = k.nombre + "  " + Pieza.n(k.w) + " x " + Pieza.n(k.h) + (p.noCabe(k) ? "  · no cabe ahí" : "");
        } else if (tipoSel == 2) {
            for (CasaPlano.Abertura a : p.aberturas) if (a.id == idSel) {
                boolean enX = a.lado == 0 || a.lado == 2;
                float np = Math.round((orig[0] + (enX ? dx : dy)) / 10f) * 10f;
                a.pos = Math.max(0, Math.min(p.largoLado(a) - a.ancho, np));
                aviso = CasaPlano.TIPOS[a.tipo] + " a " + Pieza.n(a.pos) + " de la esquina";
            }
        } else if (tipoSel == 4) {
            for (CasaPlano.Muro m : p.muros) if (m.id == idSel) {
                float ddx = Math.round(dx / 10f) * 10f, ddy = Math.round(dy / 10f) * 10f;
                // se pega por su arranque a la punta más cercana
                float tolP = dp(16) / esc;
                for (float[] q : p.puntosIman()) {
                    if (Math.abs(q[0] - (orig[0] + dx)) < tolP && Math.abs(q[1] - (orig[1] + dy)) < tolP) { ddx = q[0] - orig[0]; ddy = q[1] - orig[1]; break; }
                }
                m.x0 = orig[0] + ddx; m.y0 = orig[1] + ddy; m.x1 = orig[2] + ddx; m.y1 = orig[3] + ddy;
                p.meterMuro(m);   // v6.7: no se sale de la casa
                aviso = "Muro " + Pieza.n(m.largo());
            }
        } else if (tipoSel == 3) {
            for (CasaPlano.Mueble m : p.muebles) if (m.id == idSel) {
                m.x = Math.round((orig[0] + dx) / 10f) * 10f;
                m.y = Math.round((orig[1] + dy) / 10f) * 10f;
                CasaPlano.Cuarto k = p.cuarto(m.cuarto);
                if (k != null) {
                    float[] b = p.cajaMueble(m);
                    float w = b[2] - b[0], h = b[3] - b[1];
                    // imán a las paredes del cuarto
                    if (Math.abs(m.x) < tol) m.x = 0;
                    if (Math.abs(m.y) < tol) m.y = 0;
                    if (Math.abs(m.x + w - k.w) < tol) m.x = k.w - w;
                    if (Math.abs(m.y + h - k.h) < tol) m.y = k.h - h;
                }
                aviso = m.nombre;
            }
        }
    }
}
