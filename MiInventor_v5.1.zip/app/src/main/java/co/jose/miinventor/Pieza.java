package co.jose.miinventor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Un tubo, ángulo o platina, con su largo de corte, hacia dónde va, a qué pieza se une y sus huecos. */
public class Pieza {

    public static final String[] TIPOS = {"Tubo cuadrado", "Tubo rectangular", "Tubo redondo", "Ángulo", "Platina"};
    public static final String[] DIRS = {"→ A lo ancho (X)", "↗ Hacia el fondo (Y)", "↑ Para arriba (Z)",
            "← A lo ancho, al revés (−X)", "↙ Hacia el frente (−Y)", "↓ Para abajo (−Z)"};
    public static final String[] CARAS = {"Arriba", "Abajo", "Lado", "Otro lado"};
    public static final String[] HUECOS = {"Redondo", "Cuadrado", "Ranura", "Avellanado"};
    /** Versión 4: tipo 5 = placa sacada del boceto 2D (extruida). */
    public static final int PLACA = 5;
    /** Versión 3: en qué cara de la otra pieza se pega. */
    public static final String[] CARAS_UNION = {"Centrado", "Arriba", "Abajo", "Izquierda", "Derecha", "Punta"};

    private static final float P = 25.4f;

    /** Medidas comunes: nombre, ancho, alto, espesor (mm). */
    public static final Object[][][] MEDIDAS = {
            {{"3/4\"", .75f * P, .75f * P, 1.2f}, {"1\"", P, P, 1.2f}, {"1 1/4\"", 1.25f * P, 1.25f * P, 1.2f},
                    {"1 1/2\"", 1.5f * P, 1.5f * P, 1.5f}, {"2\"", 2 * P, 2 * P, 1.5f}, {"2 1/2\"", 2.5f * P, 2.5f * P, 2f},
                    {"3\"", 3 * P, 3 * P, 2f}, {"4\"", 4 * P, 4 * P, 2.5f}},
            {{"1\" x 2\"", P, 2 * P, 1.2f}, {"1\" x 3\"", P, 3 * P, 1.5f}, {"1 1/2\" x 3\"", 1.5f * P, 3 * P, 1.5f},
                    {"2\" x 3\"", 2 * P, 3 * P, 1.5f}, {"2\" x 4\"", 2 * P, 4 * P, 2f}, {"3\" x 1 1/2\"", 3 * P, 1.5f * P, 1.5f}},
            {{"1/2\"", .5f * P, .5f * P, 1.2f}, {"3/4\"", .75f * P, .75f * P, 1.2f}, {"1\"", P, P, 1.2f},
                    {"1 1/4\"", 1.25f * P, 1.25f * P, 1.5f}, {"1 1/2\"", 1.5f * P, 1.5f * P, 1.5f}, {"2\"", 2 * P, 2 * P, 2f}},
            {{"1\" x 1/8\"", P, P, P / 8}, {"1 1/4\" x 1/8\"", 1.25f * P, 1.25f * P, P / 8}, {"1 1/2\" x 1/8\"", 1.5f * P, 1.5f * P, P / 8},
                    {"1 1/2\" x 3/16\"", 1.5f * P, 1.5f * P, 3 * P / 16}, {"2\" x 3/16\"", 2 * P, 2 * P, 3 * P / 16}, {"2\" x 1/4\"", 2 * P, 2 * P, P / 4}},
            {{"1\" x 1/8\"", P, P / 8, P / 8}, {"1 1/2\" x 1/8\"", 1.5f * P, P / 8, P / 8}, {"1 1/2\" x 3/16\"", 1.5f * P, 3 * P / 16, 3 * P / 16},
                    {"2\" x 3/16\"", 2 * P, 3 * P / 16, 3 * P / 16}, {"2\" x 1/4\"", 2 * P, P / 4, P / 4}, {"3\" x 1/4\"", 3 * P, P / 4, P / 4}}};

    public static class Hueco {
        public int tipo;      // 0 redondo, 1 cuadrado, 2 ranura
        public float d1 = 10; // diámetro, lado o largo de la ranura
        public float d2 = 8;  // ancho de la ranura
        public float pos = 50; // a cuántos mm del inicio de la pieza
        public int cara;
        public boolean pasante;   // versión 4: atraviesa las dos caras
        public float s, u;        // versión 4: en placas, dónde va el hueco (mm)
        // versión 4.5: maquinado dibujado en un boceto sobre la cara (tipo 4)
        public float[][] forma;   // placas: (s, u) · tubos: (a lo largo desde el inicio, de lado)
        public int hoja = -1;
        public List<Integer> ents = new ArrayList<>();
        public float hondo;       // 0 = todo

        public String texto() {
            if (tipo == 4) return "maquinado " + n(d1) + "x" + n(d2) + " a " + n(pos) + " mm (" + (cara < CARAS.length ? CARAS[cara].toLowerCase() : "cara") + (pasante ? ", pasante" : hondo > 0 ? ", " + n(hondo) + " mm de hondo" : ", solo esa cara") + ")";
            String m = tipo == 0 ? "Ø" + n(d1) : tipo == 1 ? n(d1) + "x" + n(d1) : tipo == 3 ? "avellanado Ø" + n(d1) : "ranura " + n(d1) + "x" + n(d2);
            return "hueco " + m + " a " + n(pos) + " mm (" + CARAS[cara].toLowerCase() + (pasante ? ", pasante" : "") + ")";
        }
    }

    public int id;
    public int tipo;
    public String medida = "2\"";
    public float a = 50.8f, b = 50.8f, t = 1.5f;
    public String calibre = "Cal 18";
    public float largo = 1000;
    public int dir;
    public float incl;
    public int padre = -1;    // -1: en el punto 0
    public int punto = 1;     // 0 inicio del padre, 1 fin del padre, 2 a una medida
    public float aMm;
    public float sep;
    public float cx, cy, cz;  // corrimiento
    public float corteIni, corteFin; // grados (0 = recto)
    public int giro;          // giro de la sección: 0, 1, 2, 3 (× 90°)
    public int cara;          // versión 3: 0 centrado (en el eje) · 1 arriba · 2 abajo · 3 izquierda · 4 derecha · 5 punta
    public final List<Hueco> huecos = new ArrayList<>();
    // Versión 4
    public float luz;                 // separación entre caras al amarrar (luz libre)
    public float en1, en2;            // corrimiento sobre la cara de la otra pieza (centrado = 0)
    public float ciS = 1, ciU, cfS = 1, cfU;   // hacia dónde va el corte inclinado de cada punta (en la sección)
    public float[][] contorno;        // placa: forma (s, u)
    public final List<float[][]> agujeros = new ArrayList<>();   // placa: huecos del boceto
    public List<Integer> entsContorno = new ArrayList<>();       // placa: de qué líneas del boceto salió
    public int hoja = -1;             // versión 4.3: de qué boceto salió
    public float[] marco;             // versión 4.3: origen (3), eje X (3), eje Y (3), normal (3) del plano de la placa
    public boolean oculta;            // versión 4.3: ocultar en el 3D
    public boolean alReves;           // versión 4.3: la extrusión va hacia el otro lado del plano
    public String titulo = "";        // versión 4.3: el nombre propio de la pieza
    // versión 4.4: lámina con dobleces (es una placa del calibre, con pestañas dobladas)
    public boolean lamina;
    public String cal = "";
    public float radio = -1;          // radio por dentro del doblez (-1 = el grueso)
    public float kFactor = 0.33f;
    public List<Doblez> dobleces = new ArrayList<>();
    /** Versión 5: pieza fija (📌), no se mueve al amarrar ni al arrastrar. */
    public boolean fija;

    public static class Doblez {
        public int padre = -1;        // -1: sale de un borde de la cara principal · si no: de la punta de ese doblez
        public int borde;             // qué borde de la cara principal
        public float angulo = 90, largo = 50;
        public boolean abajo, porDentro;
    }
    public final List<List<Integer>> entsAgujeros = new ArrayList<>();
    /** Versión 2: fórmulas de la tablita para largo, sep, aMm, cx, cy, cz (si no hay, el número queda fijo). */
    public final Map<String, String> f = new java.util.HashMap<>();

    public static final String[] CAMPOS = {"largo", "sep", "aMm", "cx", "cy", "cz"};

    public float campo(String k) {
        switch (k) {
            case "largo": return largo; case "sep": return sep; case "aMm": return aMm;
            case "cx": return cx; case "cy": return cy; default: return cz;
        }
    }

    public void ponerCampo(String k, float v) {
        switch (k) {
            case "largo": largo = v; break; case "sep": sep = v; break; case "aMm": aMm = v; break;
            case "cx": cx = v; break; case "cy": cy = v; break; default: cz = v;
        }
    }

    /** Recalcula los campos que tienen fórmula. Devuelve el primer error (o null). */
    public String aplicarFormulas(Medidas m) {
        String err = null;
        for (String k : CAMPOS) {
            String fo = f.get(k);
            if (fo == null || fo.trim().isEmpty()) continue;
            try {
                float v = (float) m.evaluar(fo);
                if (k.equals("largo") && v <= 0) throw new Formula.Error("el largo da " + Formula.n(v));
                ponerCampo(k, v);
            } catch (Exception e) {
                if (err == null) err = nombre() + " (" + k + "): " + e.getMessage();
            }
        }
        return err;
    }

    // ---------------- Versión 2: girar 90° (la pieza y todo lo que tiene pegado) ----------------

    /** eje 0: alrededor de Z (en el piso) · 1: alrededor de X · 2: alrededor de Y. */
    public static int girarDir(int dir, int eje) {
        int[][] ciclo = {{0, 1, 3, 4}, {1, 2, 4, 5}, {2, 0, 5, 3}};
        int[] c = ciclo[eje];
        for (int i = 0; i < 4; i++) if (c[i] == dir) return c[(i + 1) % 4];
        return dir;
    }

    public static float[] girarVec(float[] v, int eje) {
        if (eje == 0) return new float[]{-v[1], v[0], v[2]};
        if (eje == 1) return new float[]{v[0], -v[2], v[1]};
        return new float[]{v[2], v[1], -v[0]};
    }

    public String nombre() { return titulo != null && !titulo.trim().isEmpty() ? titulo.trim() : (tipo == PLACA ? (lamina ? "L" : "P") : "T") + id; }

    /** Cómo se pide en la ferretería: así se agrupan en la lista de corte. */
    public String referencia() {
        if (tipo == PLACA && lamina) return "Lámina " + (cal == null || cal.isEmpty() ? n(largo) + " mm" : cal) + (dobleces.isEmpty() ? "" : " · " + dobleces.size() + (dobleces.size() == 1 ? " doblez" : " dobleces"));
        if (tipo == PLACA) return "Placa de " + n(largo) + " mm";
        String r = TIPOS[tipo] + " " + medida;
        if (tipo <= 2 && calibre != null && !calibre.trim().isEmpty()) r += " " + calibre.trim();
        return r;
    }

    public static String n(float v) {
        if (Math.abs(v - Math.round(v)) < 0.05f) return String.valueOf(Math.round(v));
        return String.format(java.util.Locale.US, "%.1f", v);
    }

    // ---------------- Geometría ----------------

    public float[] direccion() {
        if (marco != null) return new float[]{marco[9], marco[10], marco[11]};
        float[][] base = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {-1, 0, 0}, {0, -1, 0}, {0, 0, -1}};
        float[] h = base[Math.max(0, Math.min(5, dir))];
        double r = Math.toRadians(incl);
        float c = (float) Math.cos(r), s = (float) Math.sin(r);
        if (dir == 2 || dir == 5) return new float[]{s, 0, h[2] * c};      // vertical que se inclina hacia X
        return new float[]{h[0] * c, h[1] * c, s};                        // horizontal que se inclina para arriba
    }

    /** Dónde arranca la pieza (mm), siguiendo la cadena de piezas a las que va unida. */
    public float[] inicio(Map<Integer, Pieza> todas, int profundidad) {
        float[] d = direccion();
        float[] base = marco != null ? new float[]{marco[0] - (alReves ? d[0] * largo : 0), marco[1] - (alReves ? d[1] * largo : 0), marco[2] - (alReves ? d[2] * largo : 0)} : new float[]{0, 0, 0};   // versión 4.3: la placa nace en su plano
        Pieza pp = padre >= 0 ? todas.get(padre) : null;
        if (pp != null && profundidad < 60 && pp != this) {
            float[] ps = pp.inicio(todas, profundidad + 1);
            float[] pd = pp.direccion();
            float cuanto = punto == 0 ? 0 : punto == 1 ? pp.largo : aMm;
            base = new float[]{ps[0] + pd[0] * cuanto, ps[1] + pd[1] * cuanto, ps[2] + pd[2] * cuanto};
            if (cara > 0) {
                // se pega a la cara de la otra pieza: se corre la mitad de ella más la mitad de esta
                float[][] ep = Vista3D.ejes(pp);
                float[] n, t1, t2 = null;
                float mitadPadre;
                switch (cara) {
                    case 1: n = ep[2]; t1 = ep[1]; break;
                    case 2: n = neg(ep[2]); t1 = ep[1]; break;
                    case 3: n = neg(ep[1]); t1 = ep[2]; break;
                    case 4: n = ep[1]; t1 = ep[2]; break;
                    default: n = punto == 0 ? neg(ep[0]) : ep[0]; t1 = ep[1]; t2 = ep[2];
                }
                mitadPadre = cara == 5 ? 0 : pp.alcance(n);
                float off = mitadPadre + alcance(neg(n)) + luz;
                base = new float[]{base[0] + n[0] * off + t1[0] * en1, base[1] + n[1] * off + t1[1] * en1, base[2] + n[2] * off + t1[2] * en1};
                if (t2 != null) base = new float[]{base[0] + t2[0] * en2, base[1] + t2[1] * en2, base[2] + t2[2] * en2};
            }
        }
        return new float[]{base[0] + d[0] * sep + cx, base[1] + d[1] * sep + cy, base[2] + d[2] * sep + cz};
    }

    private static float[] neg(float[] v) { return new float[]{-v[0], -v[1], -v[2]}; }

    /** Versión 4: la dirección sobre la cara de la pieza pp en la que se corre en1 (según la cara). */
    public static float[] ejeT1(Pieza pp, int cara) {
        float[][] ep = Vista3D.ejes(pp);
        return cara == 3 || cara == 4 ? ep[2] : ep[1];
    }

    /** Versión 4: hasta dónde llega la sección (desde el eje) hacia la dirección n del mundo. */
    public float alcance(float[] n) {
        float[][] e = Vista3D.ejes(this);
        float ks = e[1][0] * n[0] + e[1][1] * n[1] + e[1][2] * n[2];
        float ku = e[2][0] * n[0] + e[2][1] * n[1] + e[2][2] * n[2];
        float m = 0;
        for (float[][] pol : Vista3D.seccion(this)) for (float[] q : pol) m = Math.max(m, q[0] * ks + q[1] * ku);
        return m;
    }

    /** Lo que queda más largo una punta cortada inclinada (mm), para la lista de corte. */
    public float extraCorte(boolean fin) {
        float ang = fin ? corteFin : corteIni;
        if (Math.abs(ang) < 0.01f) return 0;
        float ds = fin ? cfS : ciS, du = fin ? cfU : ciU;
        float m = 0;
        for (float[][] pol : Vista3D.seccion(this)) for (float[] q : pol) m = Math.max(m, -(q[0] * ds + q[1] * du));
        return (float) Math.tan(Math.toRadians(Math.abs(ang))) * m;
    }

    /** Largo de punta a punta (por la punta larga). */
    public float largoCorte() { return largo + extraCorte(false) + extraCorte(true); }

    /** Media sección hacia el ancho (s) y hacia el alto (u). */
    public float mitadS() { return a / 2; }

    public float mitadU() { return tipo == 4 ? t / 2 : tipo == 2 ? a / 2 : b / 2; }

    /** Qué tanto sobresale esta pieza (su sección) hacia la dirección n. */
    public float mitadHacia(float[] n) {
        float[][] e = Vista3D.ejes(this);
        float ks = Math.abs(e[1][0] * n[0] + e[1][1] * n[1] + e[1][2] * n[2]);
        float ku = Math.abs(e[2][0] * n[0] + e[2][1] * n[1] + e[2][2] * n[2]);
        return ks * mitadS() + ku * mitadU();
    }

    /** Versión 3: cómo va unida, en palabras (para la lista). */
    public String textoUnion() {
        StringBuilder s = new StringBuilder();
        if (cara > 0) s.append(", ").append(CARAS_UNION[cara].toLowerCase());
        if (Math.abs(cx) > 0.05f || Math.abs(cy) > 0.05f || Math.abs(cz) > 0.05f) {
            s.append(" · corrido");
            if (Math.abs(cx) > 0.05f) s.append(" X").append(cx > 0 ? "+" : "").append(n(cx));
            if (Math.abs(cy) > 0.05f) s.append(" Y").append(cy > 0 ? "+" : "").append(n(cy));
            if (Math.abs(cz) > 0.05f) s.append(" Z").append(cz > 0 ? "+" : "").append(n(cz));
            s.append(" mm");
        }
        return s.toString();
    }

    // ---------------- Guardar ----------------

    public JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("tipo", tipo); o.put("medida", medida);
        o.put("a", a); o.put("b", b); o.put("t", t); o.put("calibre", calibre);
        o.put("largo", largo); o.put("dir", dir); o.put("incl", incl);
        o.put("padre", padre); o.put("punto", punto); o.put("aMm", aMm); o.put("sep", sep);
        o.put("cx", cx); o.put("cy", cy); o.put("cz", cz);
        o.put("corteIni", corteIni); o.put("corteFin", corteFin); o.put("giro", giro);
        if (cara != 0) o.put("cara", cara);
        if (hoja >= 0) o.put("hoja", hoja);
        if (oculta) o.put("oc", true);
        if (fija) o.put("fija", true);
        if (alReves) o.put("rev", true);
        if (titulo != null && !titulo.isEmpty()) o.put("tit", titulo);
        if (lamina) {
            o.put("lam", true); o.put("cal", cal); o.put("rad", (double) radio); o.put("k", (double) kFactor);
            JSONArray dd = new JSONArray();
            for (Doblez d : dobleces) {
                JSONObject x = new JSONObject();
                x.put("pa", d.padre); x.put("bo", d.borde); x.put("an", (double) d.angulo); x.put("la", (double) d.largo);
                x.put("ab", d.abajo); x.put("pd", d.porDentro);
                dd.put(x);
            }
            o.put("dob", dd);
        }
        if (marco != null) { JSONArray m = new JSONArray(); for (float v : marco) m.put((double) v); o.put("marco", m); }
        o.put("luz", luz); o.put("en1", en1); o.put("en2", en2);
        o.put("ciS", ciS); o.put("ciU", ciU); o.put("cfS", cfS); o.put("cfU", cfU);
        if (contorno != null) {
            o.put("cont", polJson(contorno));
            JSONArray ag = new JSONArray();
            for (float[][] a1 : agujeros) ag.put(polJson(a1));
            o.put("aguj", ag);
            JSONArray ec = new JSONArray();
            for (Integer k : entsContorno) ec.put(k);
            o.put("entsC", ec);
            JSONArray ea = new JSONArray();
            for (List<Integer> l : entsAgujeros) { JSONArray x = new JSONArray(); for (Integer k : l) x.put(k); ea.put(x); }
            o.put("entsA", ea);
        }
        JSONArray hs = new JSONArray();
        for (Hueco h : huecos) {
            JSONObject x = new JSONObject();
            x.put("tipo", h.tipo); x.put("d1", h.d1); x.put("d2", h.d2); x.put("pos", h.pos); x.put("cara", h.cara);
            if (h.pasante) x.put("pas", true);
            if (h.s != 0 || h.u != 0) { x.put("s", h.s); x.put("u", h.u); }
            if (h.forma != null) x.put("forma", polJson(h.forma));
            if (h.hoja >= 0) { x.put("hoja", h.hoja); JSONArray ee = new JSONArray(); for (int k : h.ents) ee.put(k); x.put("ents", ee); }
            if (h.hondo > 0) x.put("hondo", (double) h.hondo);
            hs.put(x);
        }
        o.put("huecos", hs);
        if (!f.isEmpty()) o.put("f", new JSONObject(f));
        return o;
    }

    public static Pieza deJson(JSONObject o) {
        Pieza p = new Pieza();
        p.id = o.optInt("id"); p.tipo = o.optInt("tipo"); p.medida = o.optString("medida", "");
        p.a = (float) o.optDouble("a", 50); p.b = (float) o.optDouble("b", 50); p.t = (float) o.optDouble("t", 1.5);
        p.calibre = o.optString("calibre", ""); p.largo = (float) o.optDouble("largo", 1000);
        p.dir = o.optInt("dir"); p.incl = (float) o.optDouble("incl", 0);
        p.padre = o.optInt("padre", -1); p.punto = o.optInt("punto", 1);
        p.aMm = (float) o.optDouble("aMm", 0); p.sep = (float) o.optDouble("sep", 0);
        p.cx = (float) o.optDouble("cx", 0); p.cy = (float) o.optDouble("cy", 0); p.cz = (float) o.optDouble("cz", 0);
        p.corteIni = (float) o.optDouble("corteIni", 0); p.corteFin = (float) o.optDouble("corteFin", 0);
        p.giro = o.optInt("giro");
        p.cara = o.optInt("cara", 0);
        p.hoja = o.optInt("hoja", -1);
        p.oculta = o.optBoolean("oc", false);
        p.fija = o.optBoolean("fija", false);
        p.alReves = o.optBoolean("rev", false);
        p.titulo = o.optString("tit", "");
        p.lamina = o.optBoolean("lam", false);
        p.cal = o.optString("cal", "");
        p.radio = (float) o.optDouble("rad", -1);
        p.kFactor = (float) o.optDouble("k", 0.33);
        JSONArray dd = o.optJSONArray("dob");
        if (dd != null) for (int i = 0; i < dd.length(); i++) {
            JSONObject x = dd.optJSONObject(i);
            if (x == null) continue;
            Doblez d = new Doblez();
            d.padre = x.optInt("pa", -1); d.borde = x.optInt("bo", 0); d.angulo = (float) x.optDouble("an", 90); d.largo = (float) x.optDouble("la", 50);
            d.abajo = x.optBoolean("ab", false); d.porDentro = x.optBoolean("pd", false);
            p.dobleces.add(d);
        }
        JSONArray mm = o.optJSONArray("marco");
        if (mm != null && mm.length() == 12) { p.marco = new float[12]; for (int i = 0; i < 12; i++) p.marco[i] = (float) mm.optDouble(i, 0); }
        p.luz = (float) o.optDouble("luz", 0); p.en1 = (float) o.optDouble("en1", 0); p.en2 = (float) o.optDouble("en2", 0);
        p.ciS = (float) o.optDouble("ciS", 1); p.ciU = (float) o.optDouble("ciU", 0);
        p.cfS = (float) o.optDouble("cfS", 1); p.cfU = (float) o.optDouble("cfU", 0);
        JSONArray co = o.optJSONArray("cont");
        if (co != null) {
            p.contorno = polDe(co);
            JSONArray ag = o.optJSONArray("aguj");
            if (ag != null) for (int i = 0; i < ag.length(); i++) { JSONArray x = ag.optJSONArray(i); if (x != null) p.agujeros.add(polDe(x)); }
            JSONArray ec = o.optJSONArray("entsC");
            if (ec != null) for (int i = 0; i < ec.length(); i++) p.entsContorno.add(ec.optInt(i));
            JSONArray ea = o.optJSONArray("entsA");
            if (ea != null) for (int i = 0; i < ea.length(); i++) {
                JSONArray x = ea.optJSONArray(i);
                List<Integer> l = new ArrayList<>();
                if (x != null) for (int j = 0; j < x.length(); j++) l.add(x.optInt(j));
                p.entsAgujeros.add(l);
            }
        }
        JSONArray hs = o.optJSONArray("huecos");
        if (hs != null) for (int i = 0; i < hs.length(); i++) {
            JSONObject x = hs.optJSONObject(i);
            if (x == null) continue;
            Hueco h = new Hueco();
            h.tipo = x.optInt("tipo"); h.d1 = (float) x.optDouble("d1", 10); h.d2 = (float) x.optDouble("d2", 8);
            h.pos = (float) x.optDouble("pos", 50); h.cara = x.optInt("cara");
            h.pasante = x.optBoolean("pas", false);
            h.s = (float) x.optDouble("s", 0); h.u = (float) x.optDouble("u", 0);
            JSONArray fo = x.optJSONArray("forma");
            if (fo != null) {
                h.forma = new float[fo.length()][2];
                for (int k = 0; k < fo.length(); k++) { JSONArray q = fo.optJSONArray(k); if (q != null) { h.forma[k][0] = (float) q.optDouble(0, 0); h.forma[k][1] = (float) q.optDouble(1, 0); } }
            }
            h.hoja = x.optInt("hoja", -1);
            JSONArray ee = x.optJSONArray("ents");
            if (ee != null) for (int k = 0; k < ee.length(); k++) h.ents.add(ee.optInt(k));
            h.hondo = (float) x.optDouble("hondo", 0);
            p.huecos.add(h);
        }
        JSONObject fo = o.optJSONObject("f");
        if (fo != null) for (java.util.Iterator<String> it = fo.keys(); it.hasNext(); ) { String k = it.next(); p.f.put(k, fo.optString(k)); }
        return p;
    }

    private static JSONArray polJson(float[][] pol) throws Exception {
        JSONArray a = new JSONArray();
        for (float[] q : pol) { a.put(Math.round(q[0] * 100) / 100.0); a.put(Math.round(q[1] * 100) / 100.0); }
        return a;
    }

    private static float[][] polDe(JSONArray a) {
        float[][] r = new float[a.length() / 2][2];
        for (int i = 0; i < r.length; i++) { r[i][0] = (float) a.optDouble(2 * i, 0); r[i][1] = (float) a.optDouble(2 * i + 1, 0); }
        return r;
    }

    public Pieza copia(int nuevoId) {
        try {
            Pieza p = deJson(json());
            p.id = nuevoId;
            return p;
        } catch (Exception e) { return null; }
    }
}
