package co.jose.miinventor;

import android.app.AlertDialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * v6.3: ✂ Cortes. Listado de corte de barras (perfiles P1 a P50) y de láminas (vidrio, tableros, alucobond),
 * con sierra, retales y existencias (todo arranca en 0). Dice cuánto comprar y dibuja cada corte.
 */
final class Cortes {

    // =====================================================================
    //                    El cálculo (sin pantalla, se puede probar)
    // =====================================================================

    /** Una referencia de perfil: P1, P2… */
    static final class Ref {
        String nombre = "P1";
        double barra = 6000;
        int tengo = 0;
        String retales = "";   // ej: 1200x2; 850
        String piezas = "";    // ej: 300x4; 500x2
    }

    /** Una barra (o retal) ya cortada. */
    static final class Barra {
        String origen;          // "Retal", "En existencia", "Nueva"
        double largo;
        final List<Double> piezas = new ArrayList<>();
        double usado;           // piezas + sierra
        double sobra() { return largo - usado; }
    }

    static final class ResBarras {
        String ref;
        final List<Barra> barras = new ArrayList<>();
        int retalesUsados, existUsadas, nuevas;
        double piezasMm, compradoMm;
        String error;
    }

    /** "300x4; 500x2, 750" → lista de medidas (cada una repetida). */
    static List<Double> leerLista(String t) {
        List<Double> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').replace(',', ';').split(";")) {
            String p = parte.trim().toLowerCase(Locale.US).replace('*', 'x').replace('×', 'x');
            if (p.isEmpty()) continue;
            String[] w = p.split("x");
            try {
                double m = Double.parseDouble(w[0].trim().replace(" ", ""));
                int n = w.length > 1 ? (int) Math.round(Double.parseDouble(w[1].trim())) : 1;
                for (int i = 0; i < n && i < 2000; i++) r.add(m);
            } catch (Exception ignored) { }
        }
        return r;
    }

    static ResBarras cortarBarras(Ref ref, double sierra) {
        ResBarras res = new ResBarras();
        res.ref = ref.nombre;
        List<Double> ps = leerLista(ref.piezas);
        ps.sort(Collections.reverseOrder());
        List<Double> ret = leerLista(ref.retales);
        Collections.sort(ret);   // primero los retales más pequeños que sirvan
        boolean[] retUsado = new boolean[ret.size()];
        int exist = ref.tengo;
        for (double p : ps) {
            res.piezasMm += p;
            if (p > ref.barra) { res.error = "Hay un pedazo de " + Pieza.n((float) p) + " mm más largo que la barra"; continue; }
            // 1) en la barra ya abierta donde quede más justo
            Barra mejor = null;
            for (Barra b : res.barras) {
                double nec = p + (b.piezas.isEmpty() ? 0 : sierra);
                if (b.sobra() >= nec - 1e-6 && (mejor == null || b.sobra() < mejor.sobra())) mejor = b;
            }
            if (mejor == null) {
                // 2) un retal que alcance (el más pequeño), 3) una barra en existencia, 4) una barra nueva
                Barra b = new Barra();
                int k = -1;
                for (int i = 0; i < ret.size(); i++) if (!retUsado[i] && ret.get(i) >= p) { k = i; break; }
                if (k >= 0) { retUsado[k] = true; b.origen = "Retal"; b.largo = ret.get(k); res.retalesUsados++; }
                else if (exist > 0) { exist--; b.origen = "En existencia"; b.largo = ref.barra; res.existUsadas++; }
                else { b.origen = "Nueva"; b.largo = ref.barra; res.nuevas++; res.compradoMm += ref.barra; }
                res.barras.add(b);
                mejor = b;
            }
            mejor.usado += p + (mejor.piezas.isEmpty() ? 0 : sierra);
            mejor.piezas.add(p);
        }
        return res;
    }

    /** Material en láminas: vidrio, tablero, alucobond. */
    static final class Mat {
        String nombre = "Vidrio";
        double ancho = 2440, alto = 1220;
        int tengo = 0;
        boolean girar = true;
        String retales = "";   // ej: 600x400x2
        String piezas = "";    // una por renglón: 600x300x4 canto F I
    }

    static final class Pz {
        String nombre;
        double w, h;          // como se escribió
        boolean f, a, i, d;   // canto: frente y atrás (lados de w), izquierdo y derecho (lados de h)
        double canto() { return (f ? w : 0) + (a ? w : 0) + (i ? h : 0) + (d ? h : 0); }
    }

    static final class Puesta {
        Pz pz;
        double x, y, w, h;
        boolean girada;
    }

    static final class Hoja2 {
        String origen;
        double ancho, alto;
        final List<Puesta> puestas = new ArrayList<>();
        final List<double[]> libres = new ArrayList<>();   // x, y, w, h (MaxRects)
        double usado() { double s = 0; for (Puesta p : puestas) s += p.w * p.h; return s; }
    }

    static final class ResLam {
        final List<Hoja2> hojas = new ArrayList<>();
        int retalesUsados, existUsadas, nuevas;
        double cantoMm, piezasArea;
        String error;
    }

    /** "600x300x4 canto F I" o "Lateral 600x300x2 F". */
    static List<Pz> leerPiezas(String t) {
        List<Pz> r = new ArrayList<>();
        if (t == null) return r;
        for (String reng : t.split("[\\n;]")) {
            String s = reng.trim();
            if (s.isEmpty()) continue;
            String[] w = s.replace('*', 'x').replace('×', 'x').split("\\s+");
            Pz base = null;
            int n = 1;
            StringBuilder nom = new StringBuilder();
            boolean f = false, a = false, iz = false, de = false;
            for (String tok : w) {
                String k = tok.toLowerCase(Locale.US);
                if (base == null && k.matches("[0-9.]+x[0-9.]+(x[0-9]+)?")) {
                    String[] m = k.split("x");
                    base = new Pz();
                    base.w = Double.parseDouble(m[0]); base.h = Double.parseDouble(m[1]);
                    if (m.length > 2) n = Integer.parseInt(m[2]);
                } else if (base != null && k.matches("x?[0-9]+")) n = Integer.parseInt(k.replace("x", ""));
                else if (k.equals("f")) f = true;
                else if (k.equals("a")) a = true;
                else if (k.equals("i")) iz = true;
                else if (k.equals("d")) de = true;
                else if (k.equals("todo") || k.equals("t")) { f = a = iz = de = true; }
                else if (!k.equals("canto") && base == null) nom.append(nom.length() > 0 ? " " : "").append(tok);
            }
            if (base == null || base.w <= 0 || base.h <= 0) continue;
            for (int i = 0; i < n && i < 2000; i++) {
                Pz p = new Pz();
                p.nombre = nom.length() > 0 ? nom.toString() : Pieza.n((float) base.w) + "x" + Pieza.n((float) base.h);
                p.w = base.w; p.h = base.h; p.f = f; p.a = a; p.i = iz; p.d = de;
                r.add(p);
            }
        }
        return r;
    }

    static List<double[]> leerRetales2(String t) {
        List<double[]> r = new ArrayList<>();
        if (t == null) return r;
        for (String parte : t.replace('\n', ';').replace(',', ';').split(";")) {
            String p = parte.trim().toLowerCase(Locale.US).replace('*', 'x').replace('×', 'x').replace(" ", "");
            if (p.isEmpty()) continue;
            String[] m = p.split("x");
            try {
                double w = Double.parseDouble(m[0]), h = Double.parseDouble(m[1]);
                int n = m.length > 2 ? Integer.parseInt(m[2]) : 1;
                for (int i = 0; i < n && i < 500; i++) r.add(new double[]{w, h});
            } catch (Exception ignored) { }
        }
        return r;
    }

    static ResLam cortarLaminas(Mat m, double sierra) {
        ResLam res = new ResLam();
        List<Pz> ps = leerPiezas(m.piezas);
        ps.sort((p, q) -> Double.compare(Math.max(q.w, q.h) * 1e6 + q.w * q.h, Math.max(p.w, p.h) * 1e6 + p.w * p.h));
        List<double[]> ret = leerRetales2(m.retales);
        ret.sort((p, q) -> Double.compare(p[0] * p[1], q[0] * q[1]));
        boolean[] retUsado = new boolean[ret.size()];
        int exist = m.tengo;
        for (Pz p : ps) {
            res.cantoMm += p.canto();
            res.piezasArea += p.w * p.h;
            if (!cabe(p, m.ancho, m.alto, m.girar)) { res.error = "La pieza " + p.nombre + " no cabe en la lámina de " + Pieza.n((float) m.ancho) + " x " + Pieza.n((float) m.alto); continue; }
            boolean puesta = false;
            for (Hoja2 h : res.hojas) if (poner(h, p, sierra, m.girar)) { puesta = true; break; }
            while (!puesta) {
                Hoja2 h = new Hoja2();
                int k = -1;
                for (int i = 0; i < ret.size(); i++) if (!retUsado[i] && cabe(p, ret.get(i)[0], ret.get(i)[1], m.girar)) { k = i; break; }
                if (k >= 0) { retUsado[k] = true; h.origen = "Retal"; h.ancho = ret.get(k)[0]; h.alto = ret.get(k)[1]; res.retalesUsados++; }
                else if (exist > 0) { exist--; h.origen = "En existencia"; h.ancho = m.ancho; h.alto = m.alto; res.existUsadas++; }
                else { h.origen = "Nueva"; h.ancho = m.ancho; h.alto = m.alto; res.nuevas++; }
                h.libres.add(new double[]{0, 0, h.ancho + sierra, h.alto + sierra});
                res.hojas.add(h);
                puesta = poner(h, p, sierra, m.girar);
                if (!puesta && k < 0) break;   // no debería pasar
            }
        }
        return res;
    }

    private static boolean cabe(Pz p, double w, double h, boolean girar) {
        return p.w <= w + 1e-6 && p.h <= h + 1e-6 || girar && p.h <= w + 1e-6 && p.w <= h + 1e-6;
    }

    /** MaxRects, mejor lado corto: la pieza se agranda con la sierra y se busca el hueco más justo. */
    private static boolean poner(Hoja2 hj, Pz p, double k, boolean girar) {
        double bw = p.w + k, bh = p.h + k;
        double mejor = Double.MAX_VALUE, mejor2 = Double.MAX_VALUE;
        double[] sel = null;
        boolean gir = false;
        for (double[] r : hj.libres) {
            for (int o = 0; o < (girar ? 2 : 1); o++) {
                double w = o == 0 ? bw : bh, h = o == 0 ? bh : bw;
                if (w <= r[2] + 1e-6 && h <= r[3] + 1e-6) {
                    double c = Math.min(r[2] - w, r[3] - h), l = Math.max(r[2] - w, r[3] - h);
                    if (c < mejor || c == mejor && l < mejor2) { mejor = c; mejor2 = l; sel = new double[]{r[0], r[1], w, h}; gir = o == 1; }
                }
            }
        }
        if (sel == null) return false;
        Puesta pu = new Puesta();
        pu.pz = p; pu.x = sel[0]; pu.y = sel[1]; pu.w = gir ? p.h : p.w; pu.h = gir ? p.w : p.h; pu.girada = gir;
        hj.puestas.add(pu);
        // partir los huecos libres que toca
        List<double[]> nuevos = new ArrayList<>();
        for (double[] r : hj.libres) {
            if (sel[0] >= r[0] + r[2] || sel[0] + sel[2] <= r[0] || sel[1] >= r[1] + r[3] || sel[1] + sel[3] <= r[1]) { nuevos.add(r); continue; }
            if (sel[0] > r[0]) nuevos.add(new double[]{r[0], r[1], sel[0] - r[0], r[3]});
            if (sel[0] + sel[2] < r[0] + r[2]) nuevos.add(new double[]{sel[0] + sel[2], r[1], r[0] + r[2] - sel[0] - sel[2], r[3]});
            if (sel[1] > r[1]) nuevos.add(new double[]{r[0], r[1], r[2], sel[1] - r[1]});
            if (sel[1] + sel[3] < r[1] + r[3]) nuevos.add(new double[]{r[0], sel[1] + sel[3], r[2], r[1] + r[3] - sel[1] - sel[3]});
        }
        // quitar los que quedan dentro de otro
        List<double[]> lim = new ArrayList<>();
        for (int i = 0; i < nuevos.size(); i++) {
            double[] a = nuevos.get(i);
            boolean dentro = false;
            for (int j = 0; j < nuevos.size() && !dentro; j++) {
                if (i == j) continue;
                double[] b = nuevos.get(j);
                if (a[0] >= b[0] && a[1] >= b[1] && a[0] + a[2] <= b[0] + b[2] && a[1] + a[3] <= b[1] + b[3] && (j < i || a[0] != b[0] || a[1] != b[1] || a[2] != b[2] || a[3] != b[3])) dentro = true;
            }
            if (!dentro) lim.add(a);
        }
        hj.libres.clear();
        hj.libres.addAll(lim);
        return true;
    }

    // =====================================================================
    //                              La pantalla
    // =====================================================================

    private final InventorActivity act;
    private final File carpeta;
    private final List<Ref> refs = new ArrayList<>();
    private final List<Mat> mats = new ArrayList<>();
    private double sierraB = 4, sierraL = 4;

    Cortes(InventorActivity act, File carpeta) {
        this.act = act;
        this.carpeta = carpeta;
        cargar();
    }

    private int dp(float v) { return Math.round(v * act.getResources().getDisplayMetrics().density); }

    private void aviso(String s) { Toast.makeText(act, s, Toast.LENGTH_LONG).show(); }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(act);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        t.setBackground(g);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(0xFFB0BEC5);
        t.setPadding(0, dp(8), 0, dp(2));
        return t;
    }

    private EditText campo(String v, String pista, boolean numero, boolean varias) {
        EditText e = new EditText(act);
        // v6.5: casillas limpias, sin letras grises que parecen números que no se borran (el ejemplo va en el letrero)
        e.setText("0".equals(v) ? "" : v);
        e.setTextSize(17);
        if (varias) { e.setSingleLine(false); e.setMinLines(3); e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS); }
        else { e.setSingleLine(true); e.setInputType(numero ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS); }
        return e;
    }

    private static double num(EditText e, double def) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(',', '.')); } catch (Exception x) { return def; }
    }

    private LinearLayout.LayoutParams peso() { return new LinearLayout.LayoutParams(0, -2, 1); }

    void abrir() {
        new AlertDialog.Builder(act).setTitle("✂ Cortes · " + InventorActivity.VERSION)
                .setItems(new String[]{"📏 Barras de perfil (P1 a P50)", "🪟 Láminas: vidrio, tableros, alucobond"}, (d, w) -> {
                    if (w == 0) pantallaBarras(); else pantallaLaminas();
                }).show();
    }

    // ---------------- Barras ----------------

    private void pantallaBarras() {
        if (refs.isEmpty()) refs.add(new Ref());
        ScrollView sv = new ScrollView(act);
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), dp(8));
        sv.addView(l);
        TextView ay = etiqueta("Pedazos así: 300x4; 500x2 (medida en mm × cuántos). Retales igual: 1200x2; 850. Lo que no tiene se deja en 0.");
        l.addView(ay);
        l.addView(etiqueta("Grueso de la sierra (mm)"));
        EditText sierra = campo(Pieza.n((float) sierraB), "4", true, false);
        l.addView(sierra);
        List<EditText[]> filas = new ArrayList<>();
        LinearLayout lista = new LinearLayout(act);
        lista.setOrientation(LinearLayout.VERTICAL);
        l.addView(lista);
        Runnable[] pintar = new Runnable[1];
        pintar[0] = () -> {
            lista.removeAllViews();
            filas.clear();
            for (Ref r : refs) {
                LinearLayout c = new LinearLayout(act);
                c.setOrientation(LinearLayout.VERTICAL);
                c.setPadding(dp(10), dp(6), dp(10), dp(10));
                GradientDrawable g = new GradientDrawable();
                g.setColor(0xFF263238);
                g.setCornerRadius(dp(10));
                c.setBackground(g);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
                cp.topMargin = dp(10);
                lista.addView(c, cp);
                LinearLayout f1 = new LinearLayout(act);
                EditText nom = campo(r.nombre, "P1", false, false), barra = campo(Pieza.n((float) r.barra), "6000", true, false), tengo = campo(String.valueOf(r.tengo), "0", true, false);
                LinearLayout c1 = new LinearLayout(act), c2 = new LinearLayout(act), c3 = new LinearLayout(act);
                for (LinearLayout x : new LinearLayout[]{c1, c2, c3}) x.setOrientation(LinearLayout.VERTICAL);
                c1.addView(etiqueta("Referencia")); c1.addView(nom);
                c2.addView(etiqueta("Barra mm")); c2.addView(barra);
                c3.addView(etiqueta("Tengo (vacío=0)")); c3.addView(tengo);
                f1.addView(c1, peso()); f1.addView(c2, peso()); f1.addView(c3, peso());
                c.addView(f1);
                c.addView(etiqueta("Pedazos (ej.: 300x4; 500x2)"));
                EditText pz = campo(r.piezas, "300x4; 500x2", false, true);
                c.addView(pz);
                c.addView(etiqueta("Retales que hay (ej.: 1200x2; 850) — vacío = ninguno"));
                EditText rt = campo(r.retales, "1200x2; 850", false, false);
                c.addView(rt);
                final Ref rr = r;
                TextView quitar = boton("🗑 Quitar " + r.nombre, 0xFF6D4C41, () -> { leerBarras(filas); refs.remove(rr); if (refs.isEmpty()) refs.add(new Ref()); pintar[0].run(); });
                LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
                qp.topMargin = dp(6);
                c.addView(quitar, qp);
                filas.add(new EditText[]{nom, barra, tengo, pz, rt});
            }
        };
        pintar[0].run();
        TextView mas = boton("➕ Otra referencia", 0xFF1565C0, () -> {
            leerBarras(filas);
            if (refs.size() >= 50) { aviso("Son 50 referencias como máximo"); return; }
            Ref n = new Ref();
            n.nombre = "P" + (refs.size() + 1);
            refs.add(n);
            pintar[0].run();
        });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(10);
        l.addView(mas, mp);
        new AlertDialog.Builder(act).setTitle("📏 Barras de perfil").setView(sv)
                .setPositiveButton("✂ Calcular", (d, w) -> {
                    leerBarras(filas);
                    sierraB = num(sierra, 4);
                    guardar();
                    resultadoBarras();
                })
                .setNeutralButton("💾 Guardar", (d, w) -> { leerBarras(filas); sierraB = num(sierra, 4); guardar(); aviso("✔ Guardado"); })
                .setNegativeButton("Cerrar", null).show();
    }

    private void leerBarras(List<EditText[]> filas) {
        for (int i = 0; i < filas.size() && i < refs.size(); i++) {
            EditText[] f = filas.get(i);
            Ref r = refs.get(i);
            r.nombre = f[0].getText().toString().trim().isEmpty() ? "P" + (i + 1) : f[0].getText().toString().trim();
            r.barra = Math.max(1, num(f[1], 6000));
            r.tengo = (int) Math.max(0, num(f[2], 0));
            r.piezas = f[3].getText().toString();
            r.retales = f[4].getText().toString();
        }
    }

    private void resultadoBarras() {
        List<ResBarras> rs = new ArrayList<>();
        for (Ref r : refs) { ResBarras x = cortarBarras(r, sierraB); if (!x.barras.isEmpty() || x.error != null) rs.add(x); }
        if (rs.isEmpty()) { aviso("Escriba los pedazos de alguna referencia"); return; }
        StringBuilder sb = new StringBuilder();
        for (ResBarras x : rs) {
            sb.append(x.ref).append(": usa ").append(x.barras.size()).append(x.barras.size() == 1 ? " barra" : " barras");
            if (x.retalesUsados > 0) sb.append(" · ").append(x.retalesUsados).append(" retal").append(x.retalesUsados == 1 ? "" : "es");
            if (x.existUsadas > 0) sb.append(" · ").append(x.existUsadas).append(" de las que tiene");
            sb.append(" → COMPRAR ").append(x.nuevas).append('\n');
            if (x.error != null) sb.append("   ⚠ ").append(x.error).append('\n');
        }
        dibujo(sb.toString(), new DibujoBarras(rs), () -> pdfBarras(rs));
    }

    // ---------------- Láminas ----------------

    private void pantallaLaminas() {
        if (mats.isEmpty()) mats.add(new Mat());
        Mat m = mats.get(0);
        ScrollView sv = new ScrollView(act);
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(4), dp(16), dp(8));
        sv.addView(l);
        l.addView(etiqueta("Material (vidrio 4 mm, tablero 15 mm, alucobond…)"));
        EditText nom = campo(m.nombre, "Vidrio", false, false);
        l.addView(nom);
        l.addView(etiqueta("Tamaño de la lámina"));
        LinearLayout tam = new LinearLayout(act);
        TextView t1 = boton("1220 x 2440", 0xFF455A64, null), t2 = boton("1500 x 5500", 0xFF455A64, null);
        tam.addView(t1, peso());
        tam.addView(t2, peso());
        l.addView(tam);
        LinearLayout medidas = new LinearLayout(act);
        EditText an = campo(Pieza.n((float) m.ancho), "ancho", true, false), al = campo(Pieza.n((float) m.alto), "alto", true, false), tg = campo(String.valueOf(m.tengo), "0", true, false);
        LinearLayout c1 = new LinearLayout(act), c2 = new LinearLayout(act), c3 = new LinearLayout(act);
        for (LinearLayout x : new LinearLayout[]{c1, c2, c3}) x.setOrientation(LinearLayout.VERTICAL);
        c1.addView(etiqueta("Largo mm")); c1.addView(an);
        c2.addView(etiqueta("Ancho mm")); c2.addView(al);
        c3.addView(etiqueta("Tengo (vacío=0)")); c3.addView(tg);
        medidas.addView(c1, peso()); medidas.addView(c2, peso()); medidas.addView(c3, peso());
        l.addView(medidas);
        t1.setOnClickListener(v -> { an.setText("2440"); al.setText("1220"); });
        t2.setOnClickListener(v -> { an.setText("5500"); al.setText("1500"); });
        l.addView(etiqueta("Grueso de la sierra (mm)"));
        EditText sierra = campo(Pieza.n((float) sierraL), "4", true, false);
        l.addView(sierra);
        final boolean[] girar = {m.girar};
        TextView gb = boton(girar[0] ? "↻ Las piezas SÍ se pueden girar" : "⇅ NO girar (cuidar la veta)", girar[0] ? 0xFF00897B : 0xFF6D4C41, null);
        gb.setOnClickListener(v -> {
            girar[0] = !girar[0];
            gb.setText(girar[0] ? "↻ Las piezas SÍ se pueden girar" : "⇅ NO girar (cuidar la veta)");
            GradientDrawable g = new GradientDrawable();
            g.setColor(girar[0] ? 0xFF00897B : 0xFF6D4C41);
            g.setCornerRadius(dp(9));
            gb.setBackground(g);
        });
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = dp(8);
        l.addView(gb, gp);
        l.addView(etiqueta("Piezas, una por renglón: nombre, medida x cuántas y el canto (F frente, A atrás, I izquierdo, D derecho)\nEj: Lateral 600x300x2 F\n    Entrepaño 570x300 F"));
        EditText pz = campo(m.piezas, "Lateral 600x300x2 F", false, true);
        pz.setMinLines(5);
        l.addView(pz);
        l.addView(etiqueta("Retales que hay (ej.: 800x600x1; 500x400) — vacío = ninguno"));
        EditText rt = campo(m.retales, "800x600x1; 500x400", false, false);
        l.addView(rt);
        Runnable leer = () -> {
            m.nombre = nom.getText().toString().trim().isEmpty() ? "Lámina" : nom.getText().toString().trim();
            m.ancho = Math.max(1, num(an, 2440));
            m.alto = Math.max(1, num(al, 1220));
            m.tengo = (int) Math.max(0, num(tg, 0));
            m.girar = girar[0];
            m.piezas = pz.getText().toString();
            m.retales = rt.getText().toString();
            sierraL = num(sierra, 4);
        };
        new AlertDialog.Builder(act).setTitle("🪟 Corte de láminas").setView(sv)
                .setPositiveButton("✂ Calcular", (d, w) -> { leer.run(); guardar(); resultadoLaminas(m); })
                .setNeutralButton("💾 Guardar", (d, w) -> { leer.run(); guardar(); aviso("✔ Guardado"); })
                .setNegativeButton("Cerrar", null).show();
    }

    private void resultadoLaminas(Mat m) {
        ResLam r = cortarLaminas(m, sierraL);
        if (r.hojas.isEmpty()) { aviso(r.error != null ? r.error : "Escriba las piezas"); return; }
        double area = 0;
        for (Hoja2 h : r.hojas) area += h.ancho * h.alto;
        StringBuilder sb = new StringBuilder();
        sb.append(m.nombre).append(": ").append(r.hojas.size()).append(r.hojas.size() == 1 ? " lámina" : " láminas");
        if (r.retalesUsados > 0) sb.append(" · ").append(r.retalesUsados).append(" retal").append(r.retalesUsados == 1 ? "" : "es");
        if (r.existUsadas > 0) sb.append(" · ").append(r.existUsadas).append(" de las que tiene");
        sb.append("\nCOMPRAR ").append(r.nuevas).append(r.nuevas == 1 ? " lámina" : " láminas").append(" de ").append(Pieza.n((float) m.ancho)).append(" x ").append(Pieza.n((float) m.alto));
        sb.append("\nAprovechamiento: ").append(Math.round(100 * r.piezasArea / Math.max(1, area))).append(" %");
        if (r.cantoMm > 0) sb.append("\nCanto: ").append(String.format(Locale.US, "%.2f", r.cantoMm / 1000)).append(" metros lineales");
        if (r.error != null) sb.append("\n⚠ ").append(r.error);
        dibujo(sb.toString(), new DibujoLaminas(r), () -> pdfLaminas(m, r));
    }

    // ---------------- Mostrar e imprimir ----------------

    private void dibujo(String resumen, View v, Runnable pdf) {
        ScrollView sv = new ScrollView(act);
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(10), dp(6), dp(10), dp(6));
        TextView t = new TextView(act);
        t.setText(resumen);
        t.setTextSize(15);
        t.setTextColor(Color.WHITE);
        l.addView(t);
        l.addView(v, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(l);
        new AlertDialog.Builder(act).setTitle("✂ Listado de corte").setView(sv)
                .setPositiveButton("🖨 PDF carta", (d, w) -> pdf.run())
                .setNegativeButton("Cerrar", null).show();
    }

    /** Las barras, una debajo de otra. */
    private final class DibujoBarras extends View {
        final List<ResBarras> rs;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        DibujoBarras(List<ResBarras> rs) {
            super(act);
            this.rs = rs;
            int n = 0;
            for (ResBarras x : rs) n += x.barras.size() + 1;
            setMinimumHeight(dp(40) * n + dp(10));
        }

        @Override
        protected void onDraw(Canvas c) {
            pintarBarras(c, rs, 0, Integer.MAX_VALUE, getWidth(), dp(40), dp(11), false);
        }
    }

    /** Dibuja barras desde la fila "desde" hasta "hasta"; devuelve cuántas filas usó. */
    private int pintarBarras(Canvas c, List<ResBarras> rs, int desde, int hasta, float ancho, float alto, float letra, boolean papel) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int fila = 0, pintadas = 0;
        float y = 0;
        for (ResBarras x : rs) {
            for (int i = -1; i < x.barras.size(); i++) {
                if (fila < desde) { fila++; continue; }
                if (pintadas >= hasta) return pintadas;
                p.setStyle(Paint.Style.FILL);
                p.setTextSize(letra);
                p.setFakeBoldText(true);
                p.setColor(papel ? Color.BLACK : Color.WHITE);
                if (i < 0) {
                    c.drawText("Referencia " + x.ref + " · " + x.barras.size() + " barras · comprar " + x.nuevas, 4, y + alto * 0.7f, p);
                } else {
                    Barra b = x.barras.get(i);
                    float x0 = 4, w = ancho - 8, top = y + letra * 1.25f, h = alto - letra * 1.6f;
                    float k = (float) (w / Math.max(b.largo, 1));
                    p.setFakeBoldText(false);
                    c.drawText("#" + (i + 1) + " " + b.origen + " " + Pieza.n((float) b.largo) + " · sobra " + Pieza.n((float) b.sobra()), x0, y + letra, p);
                    float cx = x0;
                    for (double pz : b.piezas) {
                        float pw = (float) pz * k;
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(papel ? 0xFFE0E0E0 : 0xFF1E88E5);
                        c.drawRect(cx, top, cx + pw, top + h, p);
                        p.setStyle(Paint.Style.STROKE);
                        p.setColor(Color.BLACK);
                        p.setStrokeWidth(papel ? 0.8f : dp(1));
                        c.drawRect(cx, top, cx + pw, top + h, p);
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(papel ? Color.BLACK : Color.WHITE);
                        String t = Pieza.n((float) pz);
                        if (p.measureText(t) < pw - 2) c.drawText(t, cx + (pw - p.measureText(t)) / 2, top + h / 2 + letra * 0.35f, p);
                        cx += pw + (float) sierraB * k;
                    }
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(papel ? Color.BLACK : 0xFF90A4AE);
                    c.drawRect(x0, top, x0 + w, top + h, p);
                }
                y += alto;
                fila++;
                pintadas++;
            }
        }
        return pintadas;
    }

    private void pdfBarras(List<ResBarras> rs) {
        try {
            PdfDocument doc = new PdfDocument();
            int total = 0;
            for (ResBarras x : rs) total += x.barras.size() + 1;
            int porHoja = 22, hecho = 0, num = 1;
            while (hecho < total) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.BLACK);
                p.setTextSize(13);
                p.setFakeBoldText(true);
                c.drawText("CHEPE CAD · LISTADO DE CORTE DE BARRAS · sierra " + Pieza.n((float) sierraB) + " mm · hoja " + num, 36, 40, p);
                c.save();
                c.translate(36, 56);
                hecho += pintarBarras(c, rs, hecho, porHoja, 540, 31, 9, true);
                c.restore();
                doc.finishPage(pg);
                num++;
            }
            act.guardarPdf(doc, "MiInventor_CorteBarras_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    private final class DibujoLaminas extends View {
        final ResLam r;

        DibujoLaminas(ResLam r) {
            super(act);
            this.r = r;
            float w = act.getResources().getDisplayMetrics().widthPixels - dp(60);
            float h = 0;
            for (Hoja2 hj : r.hojas) h += w * hj.alto / hj.ancho + dp(26);
            setMinimumHeight((int) h + dp(10));
        }

        @Override
        protected void onDraw(Canvas c) {
            float y = 0;
            for (int i = 0; i < r.hojas.size(); i++) {
                Hoja2 hj = r.hojas.get(i);
                float w = getWidth() - 8;
                y += pintarHoja(c, hj, i + 1, 4, y, w, dp(11), false);
            }
        }
    }

    /** Dibuja una lámina con sus piezas; devuelve el alto que usó. */
    private float pintarHoja(Canvas c, Hoja2 hj, int n, float x0, float y0, float w, float letra, boolean papel) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float k = (float) (w / hj.ancho);
        float top = y0 + letra * 1.6f;
        p.setTextSize(letra);
        p.setFakeBoldText(true);
        p.setColor(papel ? Color.BLACK : Color.WHITE);
        c.drawText("#" + n + " " + hj.origen + " " + Pieza.n((float) hj.ancho) + " x " + Pieza.n((float) hj.alto)
                + " · aprovecha " + Math.round(100 * hj.usado() / (hj.ancho * hj.alto)) + " %", x0, y0 + letra * 1.1f, p);
        p.setFakeBoldText(false);
        p.setStyle(Paint.Style.FILL);
        p.setColor(papel ? 0xFFFFFFFF : 0xFF37474F);
        c.drawRect(x0, top, x0 + w, top + (float) hj.alto * k, p);
        for (Puesta pu : hj.puestas) {
            float a = x0 + (float) pu.x * k, b = top + (float) pu.y * k, wa = (float) pu.w * k, hb = (float) pu.h * k;
            p.setStyle(Paint.Style.FILL);
            p.setColor(papel ? 0xFFE6E6E6 : 0xFF4FC3F7);
            c.drawRect(a, b, a + wa, b + hb, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(papel ? 0.7f : dp(1));
            p.setColor(Color.BLACK);
            c.drawRect(a, b, a + wa, b + hb, p);
            // canto: una raya gruesa al lado del borde que lo lleva
            p.setStrokeWidth(papel ? 2f : dp(3));
            float g = papel ? 2f : dp(3);
            boolean f = pu.girada ? pu.pz.i : pu.pz.f, at = pu.girada ? pu.pz.d : pu.pz.a, iz = pu.girada ? pu.pz.f : pu.pz.i, de = pu.girada ? pu.pz.a : pu.pz.d;
            if (f) c.drawLine(a + g, b + hb - g, a + wa - g, b + hb - g, p);
            if (at) c.drawLine(a + g, b + g, a + wa - g, b + g, p);
            if (iz) c.drawLine(a + g, b + g, a + g, b + hb - g, p);
            if (de) c.drawLine(a + wa - g, b + g, a + wa - g, b + hb - g, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            String t1 = pu.pz.nombre, t2 = Pieza.n((float) pu.pz.w) + "x" + Pieza.n((float) pu.pz.h) + (pu.girada ? " ↻" : "");
            float ts = Math.min(letra, Math.max(5, hb / 3));
            p.setTextSize(ts);
            if (p.measureText(t2) < wa - 2 && hb > ts * 1.2f) c.drawText(t2, a + (wa - p.measureText(t2)) / 2, b + hb / 2 + ts * (hb > ts * 2.6f ? 1.0f : 0.35f), p);
            if (!t1.equals(t2) && p.measureText(t1) < wa - 2 && hb > ts * 2.6f) c.drawText(t1, a + (wa - p.measureText(t1)) / 2, b + hb / 2 - ts * 0.2f, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(papel ? 1 : dp(1.5f));
        p.setColor(papel ? Color.BLACK : 0xFFB0BEC5);
        c.drawRect(x0, top, x0 + w, top + (float) hj.alto * k, p);
        return (float) hj.alto * k + letra * 1.6f + (papel ? 14 : dp(12));
    }

    private void pdfLaminas(Mat m, ResLam r) {
        try {
            PdfDocument doc = new PdfDocument();
            int num = 1, i = 0;
            while (i < r.hojas.size()) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, num).create());
                Canvas c = pg.getCanvas();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.BLACK);
                p.setTextSize(13);
                p.setFakeBoldText(true);
                c.drawText("CHEPE CAD · CORTE DE " + m.nombre.toUpperCase(Locale.ROOT) + " · sierra " + Pieza.n((float) sierraL) + " mm · hoja " + num, 36, 40, p);
                p.setFakeBoldText(false);
                p.setTextSize(9);
                c.drawText("Raya gruesa = lleva canto · ↻ = pieza girada · " + (m.girar ? "se permitió girar" : "sin girar (veta)")
                        + (r.cantoMm > 0 ? " · canto total " + String.format(Locale.US, "%.2f", r.cantoMm / 1000) + " m" : ""), 36, 54, p);
                float y = 66;
                boolean alguna = false;
                while (i < r.hojas.size()) {
                    Hoja2 hj = r.hojas.get(i);
                    float h = (float) (540 * hj.alto / hj.ancho) + 30;
                    if (alguna && y + h > 760) break;
                    y += pintarHoja(c, hj, i + 1, 36, y, 540, 9, true);
                    alguna = true;
                    i++;
                }
                doc.finishPage(pg);
                num++;
            }
            act.guardarPdf(doc, "MiInventor_CorteLaminas_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    // ---------------- Guardar ----------------

    private File archivo() { return new File(carpeta, "_cortes.json"); }

    private void guardar() {
        try {
            JSONObject o = new JSONObject();
            o.put("sierraB", sierraB); o.put("sierraL", sierraL);
            JSONArray a = new JSONArray();
            for (Ref r : refs) {
                JSONObject x = new JSONObject();
                x.put("n", r.nombre); x.put("b", r.barra); x.put("t", r.tengo); x.put("r", r.retales); x.put("p", r.piezas);
                a.put(x);
            }
            o.put("refs", a);
            JSONArray b = new JSONArray();
            for (Mat m : mats) {
                JSONObject x = new JSONObject();
                x.put("n", m.nombre); x.put("an", m.ancho); x.put("al", m.alto); x.put("t", m.tengo); x.put("g", m.girar); x.put("r", m.retales); x.put("p", m.piezas);
                b.put(x);
            }
            o.put("mats", b);
            try (FileWriter w = new FileWriter(archivo())) { w.write(o.toString()); }
        } catch (Exception ignored) { }
    }

    private void cargar() {
        try {
            File f = archivo();
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            sierraB = o.optDouble("sierraB", 4); sierraL = o.optDouble("sierraL", 4);
            JSONArray a = o.optJSONArray("refs");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.getJSONObject(i);
                Ref r = new Ref();
                r.nombre = x.optString("n", "P" + (i + 1)); r.barra = x.optDouble("b", 6000); r.tengo = x.optInt("t", 0);
                r.retales = x.optString("r", ""); r.piezas = x.optString("p", "");
                refs.add(r);
            }
            JSONArray b = o.optJSONArray("mats");
            if (b != null) for (int i = 0; i < b.length(); i++) {
                JSONObject x = b.getJSONObject(i);
                Mat m = new Mat();
                m.nombre = x.optString("n", "Vidrio"); m.ancho = x.optDouble("an", 2440); m.alto = x.optDouble("al", 1220); m.tengo = x.optInt("t", 0);
                m.girar = x.optBoolean("g", true); m.retales = x.optString("r", ""); m.piezas = x.optString("p", "");
                mats.add(m);
            }
        } catch (Exception ignored) { }
    }
}
