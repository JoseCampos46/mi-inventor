package co.jose.miinventor;

import android.app.AlertDialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v6.4 Chepe CAD: la sección Casa con su editor propio de planta (como Floor Plan, con medidas que mandan),
 * su 3D con huecos, corte para ver adentro, recorrido para grabar con Mi Barra y plano en PDF carta.
 */
final class CasaEditor implements VistaPlano.Oyente {

    private final InventorActivity act;
    final String nombre;
    final CasaPlano p;
    private final File carpeta;
    private final List<String> atras = new ArrayList<>(), adelante = new ArrayList<>();

    private LinearLayout raiz;
    private VistaPlano plano;
    private Vista3D v3;
    private TextView cabeza;
    private LinearLayout barra2D, barra3D, filaSel;
    private float corte = 0;
    private boolean en3D, grabando;
    private int tipoPoner = -1;          // 0..4 abertura, 10 mueble
    private String muebleClave;

    CasaEditor(InventorActivity act, String nombre, CasaPlano p, File carpeta) {
        this.act = act;
        this.nombre = nombre;
        this.p = p;
        this.carpeta = carpeta;
        armar();
    }

    View vista() { return raiz; }

    private int dp(float v) { return Math.round(v * act.getResources().getDisplayMetrics().density); }

    private void aviso(String s) { Toast.makeText(act, s, Toast.LENGTH_LONG).show(); }

    private TextView boton(String t, int color, Runnable r) {
        TextView b = new TextView(act);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setIncludeFontPadding(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(9));
        b.setBackground(g);
        if (r != null) b.setOnClickListener(v -> r.run());
        return b;
    }

    private LinearLayout fila(Object[][] bs) {
        LinearLayout f = new LinearLayout(act);
        for (Object[] b : bs) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            f.addView(boton((String) b[0], (Integer) b[1], (Runnable) b[2]), lp);
        }
        return f;
    }

    private LinearLayout.LayoutParams alto(int h) { return new LinearLayout.LayoutParams(-1, dp(h)); }

    // =====================================================================
    //                                Pantalla
    // =====================================================================

    private void armar() {
        int gris = 0xFF455A64;
        raiz = new LinearLayout(act);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF161B22);
        raiz.setPadding(dp(4), dp(4), dp(4), dp(4));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        TextView menu = boton("☰", 0xEE263238, act::menuPrincipal);
        menu.setTextSize(24);
        arriba.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(44)));
        cabeza = new TextView(act);
        cabeza.setTextColor(0xFFFFB300);
        cabeza.setTextSize(15);
        cabeza.setTypeface(Typeface.DEFAULT_BOLD);
        cabeza.setPadding(dp(10), 0, 0, 0);
        arriba.addView(cabeza, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mas = boton("⋮", 0xEE263238, act::menuMas);   // v6.5: ⋮ a la derecha
        mas.setTextSize(24);
        arriba.addView(mas, new LinearLayout.LayoutParams(dp(48), dp(44)));
        raiz.addView(arriba);
        FrameLayout centro = new FrameLayout(act);
        plano = new VistaPlano(act);
        plano.p = p;
        plano.oyente = this;
        v3 = new Vista3D(act);
        v3.setVisibility(View.GONE);
        centro.addView(plano, new FrameLayout.LayoutParams(-1, -1));
        centro.addView(v3, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1);
        cp.topMargin = dp(4);
        raiz.addView(centro, cp);
        barra2D = new LinearLayout(act);
        barra2D.setOrientation(LinearLayout.VERTICAL);
        barra2D.addView(fila(new Object[][]{
                {"🏠\nCasa", gris, (Runnable) this::medidasCasa},
                {"➕\nCuarto", gris, (Runnable) this::nuevoCuarto},
                {"🚪\nPuerta", gris, (Runnable) () -> poner(0)},
                {"🪟\nVentana", gris, (Runnable) () -> poner(1)},
                {"⬜\nPaso", gris, (Runnable) () -> poner(2)}}), alto(54));
        barra2D.addView(fila(new Object[][]{
                {"🛋\nMuebles", gris, (Runnable) this::muebles},
                {"🛁\nBaño listo", gris, (Runnable) this::banoListo},
                {"🧱\nMuro suelto", gris, (Runnable) this::muroSuelto},
                {"⛶\nVer todo", gris, (Runnable) plano::encuadrar},
                {"🧊\n3D", 0xFF1565C0, (Runnable) this::a3D},
                {"🖨\nPDF", gris, (Runnable) this::pdf}}), alto(54));
        filaSel = new LinearLayout(act);
        barra2D.addView(filaSel, alto(54));
        raiz.addView(barra2D);
        barra3D = new LinearLayout(act);
        barra3D.setOrientation(LinearLayout.VERTICAL);
        barra3D.addView(fila(new Object[][]{
                {"✏\nPlanta", 0xFF1565C0, (Runnable) this::a2D},
                {"✂\nCorte 1,20", gris, (Runnable) this::corte},
                {"🎥\nRecorrido", 0xFF6A1B9A, (Runnable) this::recorrido},
                {"⛶\nVer todo", gris, (Runnable) () -> v3.vista(-35, 30)}}), alto(54));
        barra3D.setVisibility(View.GONE);
        raiz.addView(barra3D);
        pintarSel();
        cabecera();
    }

    private void cabecera() {
        double area = p.ancho * (double) p.fondo / 1e6;
        cabeza.setText(InventorActivity.VERSION + " · 🏠 Casa «" + nombre + "» · " + String.format(Locale.US, "%.1f m²", area));
    }

    /** La fila de abajo cambia con lo escogido; si no hay nada escogido: atrás, adelante y guardar. */
    private void pintarSel() {
        filaSel.removeAllViews();
        int gris = 0xFF455A64;
        Object[][] bs;
        if (plano.tipoSel == 1) bs = new Object[][]{
                {"📏\nMedidas", 0xFF2E7D32, (Runnable) this::medidasSel},
                {"✏\nNombre", gris, (Runnable) this::nombreCuarto},
                {"⧉\nCopiar", gris, (Runnable) this::copiarCuarto},
                {"🗑\nBorrar", 0xFFB71C1C, (Runnable) this::borrarSel},
                {"↶\nAtrás", gris, (Runnable) this::deshacer}};
        else if (plano.tipoSel == 2) bs = new Object[][]{
                {"📏\nMedidas", 0xFF2E7D32, (Runnable) this::medidasSel},
                {"⇄\nAbre", gris, (Runnable) this::voltearPuerta},
                {"🔩\nBisagra", gris, (Runnable) this::bisagra},
                {"🗑\nBorrar", 0xFFB71C1C, (Runnable) this::borrarSel},
                {"↶\nAtrás", gris, (Runnable) this::deshacer}};
        else if (plano.tipoSel == 3) bs = new Object[][]{
                {"📏\nMedidas", 0xFF2E7D32, (Runnable) this::medidasSel},
                {"↻\nGirar", gris, (Runnable) this::girarMueble},
                {"🗑\nBorrar", 0xFFB71C1C, (Runnable) this::borrarSel},
                {"↶\nAtrás", gris, (Runnable) this::deshacer}};
        else if (plano.tipoSel == 4) bs = new Object[][]{
                {"📏\nMedidas", 0xFF2E7D32, (Runnable) this::medidasSel},
                {"🗑\nBorrar", 0xFFB71C1C, (Runnable) this::borrarSel},
                {"↶\nAtrás", gris, (Runnable) this::deshacer}};
        else bs = new Object[][]{
                {"↶\nAtrás", gris, (Runnable) this::deshacer},
                {"↷\nAdelante", gris, (Runnable) this::rehacer},
                {"📋\nOperaciones", gris, (Runnable) this::operaciones},
                {"💾\nGuardar", 0xFF2E7D32, (Runnable) () -> { guardar(); aviso("✔ Guardada en la librería"); }}};
        for (Object[] b : bs) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            filaSel.addView(boton((String) b[0], (Integer) b[1], (Runnable) b[2]), lp);
        }
    }

    // ---------------- Oyente de la planta ----------------

    @Override public void escogio() { pintarSel(); }

    @Override public void cambio() { guardar(); cabecera(); }

    @Override public void antes() {
        try { atras.add(p.json().toString()); adelante.clear(); if (atras.size() > 40) atras.remove(0); } catch (Exception ignored) { }
    }

    @Override
    public void tocoParaPoner(float x, float y) {
        if (tipoPoner == 10) { ponerMueble(x, y); return; }
        if (tipoPoner < 0) return;
        // el lado más cercano: de un cuarto o de la cara de adentro de la casa
        int mejorC = -2, mejorL = -1;
        float mejorD = 700;
        float along = 0;
        for (CasaPlano.Cuarto k : p.cuartos) {
            float[][] lados = {{k.x, k.y, k.x + k.w, k.y}, {k.x + k.w, k.y, k.x + k.w, k.y + k.h}, {k.x, k.y + k.h, k.x + k.w, k.y + k.h}, {k.x, k.y, k.x, k.y + k.h}};
            for (int l = 0; l < 4; l++) {
                float[] s = lados[l];
                boolean enX = l == 0 || l == 2;
                float t = enX ? x : y, a0 = enX ? s[0] : s[1], a1 = enX ? s[2] : s[3];
                if (t < a0 || t > a1) continue;
                float d = enX ? Math.abs(y - s[1]) : Math.abs(x - s[0]);
                if (d < mejorD) { mejorD = d; mejorC = k.id; mejorL = l; along = t - a0; }
            }
        }
        if (mejorC == -2) {
            float[][] lados = {{p.inX0(), p.inY0(), p.inX1(), p.inY0()}, {p.inX1(), p.inY0(), p.inX1(), p.inY1()}, {p.inX0(), p.inY1(), p.inX1(), p.inY1()}, {p.inX0(), p.inY0(), p.inX0(), p.inY1()}};
            for (int l = 0; l < 4; l++) {
                float[] s = lados[l];
                boolean enX = l == 0 || l == 2;
                float t = enX ? x : y, a0 = enX ? s[0] : s[1], a1 = enX ? s[2] : s[3];
                if (t < a0 || t > a1) continue;
                float d = enX ? Math.abs(y - s[1]) : Math.abs(x - s[0]);
                if (d < mejorD) { mejorD = d; mejorC = -1; mejorL = l; along = t - a0; }
            }
        }
        if (mejorC == -2) { aviso("Toque más cerca de un muro"); return; }
        final int tipo = tipoPoner, cId = mejorC, lado = mejorL;
        final float donde = along;
        tipoPoner = -1;
        plano.aviso = "";
        // v6.5: al ponerla se pregunta lo que hace falta (como Floor Plan)
        float an0 = tipo == 1 ? 1200 : tipo == 2 ? 900 : tipo == 3 ? 1400 : tipo == 4 ? 1600 : 800;
        String nom = CasaPlano.TIPOS[tipo];
        pedir(nom + ": ancho del hueco", an0, an -> {
            if (tipo == 1) pedir("Ventana: alto", 1100, al -> pedir("Ventana: altura desde el piso", 1000, ante ->
                    crearAbertura(tipo, cId, lado, donde, (float) an, (float) al, (float) ante, false, false)));
            else if (tipo == 0 || tipo == 3) new AlertDialog.Builder(act).setTitle("🚪 ¿Hacia dónde abre?")
                    .setItems(new String[]{"Hacia adentro del cuarto", "Hacia afuera"}, (d, w) -> {
                        if (tipo == 3) { crearAbertura(tipo, cId, lado, donde, (float) an, 2100, 0, w == 1, false); return; }
                        new AlertDialog.Builder(act).setTitle("🔩 ¿De qué lado van las bisagras?")
                                .setItems(new String[]{"Bisagras a la izquierda", "Bisagras a la derecha"}, (d2, b) ->
                                        crearAbertura(tipo, cId, lado, donde, (float) an, 2100, 0, w == 1, b == 1)).show();
                    }).show();
            else crearAbertura(tipo, cId, lado, donde, (float) an, 2100, 0, false, false);
        });
    }

    private void crearAbertura(int tipo, int cuarto, int lado, float along, float an, float al, float ante, boolean afuera, boolean bisDer) {
        antes();
        an = Math.max(200, an);
        CasaPlano.Abertura a = p.abertura(cuarto, lado, tipo, 0, an, al, ante);
        a.abreOtroLado = afuera;
        a.bisagraDer = bisDer;
        a.pos = Math.max(0, Math.min(p.largoLado(a) - an, Math.round((along - an / 2) / 10f) * 10f));
        plano.escoger(2, a.id);
        aviso("Toque la cota roja para cambiar la distancia a la esquina");
        cambio();
    }

    // ---------------- v6.5: cota tocable, muro suelto y lista de operaciones ----------------

    @Override
    public void tocoCota() {
        CasaPlano.Abertura a = aberturaSel();
        if (a != null) {
            pedir("De la esquina al borde del hueco", a.pos, v -> { antes(); a.pos = (float) Math.max(0, Math.min(p.largoLado(a) - a.ancho, v)); listo(); });
            return;
        }
        CasaPlano.Muro m = muroSel();
        if (m != null) pedir("Largo del muro", m.largo(), v -> { antes(); largoMuro(m, (float) v); listo(); });
    }

    private void muroSuelto() {
        plano.trazando = true;
        plano.escoger(0, -1);
        plano.aviso = "🧱 Arrastre el dedo desde donde arranca el muro hasta donde llega";
        plano.invalidate();
    }

    @Override
    public void muroNuevo(float x0, float y0, float x1, float y1) {
        antes();
        CasaPlano.Muro m = p.muro(x0, y0, x1, y1);
        plano.escoger(4, m.id);
        aviso("Muro de " + Pieza.n(m.largo()) + " (grueso " + Pieza.n(p.gInt) + "). Toque la cota roja para cambiar el largo");
        cambio();
    }

    private CasaPlano.Muro muroSel() {
        if (plano.tipoSel != 4) return null;
        for (CasaPlano.Muro m : p.muros) if (m.id == plano.idSel) return m;
        return null;
    }

    /** Cambia el largo dejando quieto el arranque. */
    private void largoMuro(CasaPlano.Muro m, float l) {
        l = Math.max(100, l);
        float L = m.largo();
        if (L < 1) return;
        m.x1 = m.x0 + (m.x1 - m.x0) / L * l;
        m.y1 = m.y0 + (m.y1 - m.y0) / L * l;
    }

    private void bisagra() {
        CasaPlano.Abertura a = aberturaSel();
        if (a == null) return;
        antes();
        a.bisagraDer = !a.bisagraDer;
        listo();
    }

    /** Lista de operaciones de la casa: tocar una la escoge y abre sus medidas. */
    void operaciones() {
        List<String> op = new ArrayList<>();
        List<Runnable> ac = new ArrayList<>();
        op.add("🏠 Casa " + Pieza.n(p.ancho) + " × " + Pieza.n(p.fondo) + " · muros " + Pieza.n(p.gExt) + "/" + Pieza.n(p.gInt)); ac.add(this::medidasCasa);
        for (CasaPlano.Cuarto k : p.cuartos) { op.add("▭ " + k.nombre + "  " + Pieza.n(k.w) + " × " + Pieza.n(k.h)); ac.add(() -> { plano.escoger(1, k.id); medidasSel(); }); }
        for (CasaPlano.Abertura a : p.aberturas) {
            CasaPlano.Cuarto k = p.cuarto(a.cuarto);
            op.add((a.tipo == 1 ? "🪟 " : "🚪 ") + CasaPlano.TIPOS[a.tipo] + " " + Pieza.n(a.ancho) + " · " + (k == null ? "casa" : k.nombre));
            ac.add(() -> { plano.escoger(2, a.id); medidasSel(); });
        }
        for (CasaPlano.Muro m : p.muros) { op.add("🧱 Muro suelto " + Pieza.n(m.largo())); ac.add(() -> { plano.escoger(4, m.id); medidasSel(); }); }
        for (CasaPlano.Mueble m : p.muebles) { op.add("🛋 " + m.nombre); ac.add(() -> { plano.escoger(3, m.id); medidasSel(); }); }
        new AlertDialog.Builder(act).setTitle("📋 Operaciones de «" + nombre + "»")
                .setItems(op.toArray(new String[0]), (d, w) -> ac.get(w).run()).setNegativeButton("Cerrar", null).show();
    }

    // =====================================================================
    //                                Acciones
    // =====================================================================

    private void poner(int tipo) {
        tipoPoner = tipo;
        plano.poniendo = true;
        plano.aviso = "Toque el muro donde va la " + CasaPlano.TIPOS[tipo].toLowerCase(Locale.ROOT);
        plano.invalidate();
    }

    private void pedir(String titulo, double valor, Teclado.Listo l) { Teclado.pedir(act, titulo, valor, l); }

    private void medidasCasa() {
        String[] op = {"Ancho por fuera: " + Pieza.n(p.ancho), "Fondo por fuera: " + Pieza.n(p.fondo), "Muro de afuera: " + Pieza.n(p.gExt),
                "Muros de adentro: " + Pieza.n(p.gInt), "Alto de las paredes: " + Pieza.n(p.alto),
                p.verSobrepiso ? "Sobrepiso: se ve (tocar para esconder)" : "Sobrepiso: escondido (tocar para ver)"};
        new AlertDialog.Builder(act).setTitle("🏠 Medidas de la casa (mm)").setItems(op, (d, w) -> {
            switch (w) {
                case 0: pedir("Ancho por fuera", p.ancho, v -> { antes(); p.ancho = (float) Math.max(1000, v); listo(); }); break;
                case 1: pedir("Fondo por fuera", p.fondo, v -> { antes(); p.fondo = (float) Math.max(1000, v); listo(); }); break;
                case 2: pedir("Grueso del muro de afuera", p.gExt, v -> { antes(); p.gExt = (float) Math.max(50, v); listo(); }); break;
                case 3: pedir("Grueso de los muros de adentro", p.gInt, v -> { antes(); p.gInt = (float) Math.max(50, v); listo(); }); break;
                case 4: pedir("Alto de las paredes desde el sobrepiso", p.alto, v -> { antes(); p.alto = (float) Math.max(1000, v); listo(); }); break;
                default: antes(); p.verSobrepiso = !p.verSobrepiso; listo();
            }
        }).show();
    }

    private void listo() { plano.invalidate(); cambio(); if (en3D) armar3D(); }

    private void nuevoCuarto() {
        String[] nombres = {"Alcoba", "Cocina", "Baño", "Sala-comedor", "Patio de ropas", "Estudio", "Otro nombre…"};
        new AlertDialog.Builder(act).setTitle("➕ ¿Qué cuarto?").setItems(nombres, (d, w) -> {
            if (w == nombres.length - 1) {
                EditText e = new EditText(act);
                e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                new AlertDialog.Builder(act).setTitle("Nombre del cuarto").setView(e)
                        .setPositiveButton("OK", (d2, w2) -> medirNuevo(e.getText().toString().trim().isEmpty() ? "Cuarto" : e.getText().toString().trim()))
                        .setNegativeButton("Cancelar", null).show();
            } else medirNuevo(nombres[w]);
        }).show();
    }

    private void medirNuevo(String n) {
        pedir(n + ": ancho por dentro", 3000, w -> pedir(n + ": fondo por dentro", 3000, h -> {
            antes();
            // nace afuera, a la derecha de la casa: usted lo mete donde va
            float x = p.ancho + 600;
            for (CasaPlano.Cuarto k : p.cuartos) if (!p.adentro(k)) x = Math.max(x, k.x + k.w + 600);
            CasaPlano.Cuarto k = p.nuevoCuarto(n, x, 0, (float) Math.max(300, w), (float) Math.max(300, h));
            plano.escoger(1, k.id);
            plano.encuadrar();
            aviso("Arrástrelo adentro de la casa: se pega solo a los muros");
            cambio();
        }));
    }

    private void banoListo() {
        antes();
        float x = p.ancho + 600;
        for (CasaPlano.Cuarto k : p.cuartos) if (!p.adentro(k)) x = Math.max(x, k.x + k.w + 600);
        CasaPlano.Cuarto k = p.banoDeSiempre(x, 0);
        plano.escoger(1, k.id);
        plano.encuadrar();
        aviso("Su baño de siempre: 1,20 × 1,70 con ducha recta. Arrástrelo a su sitio");
        cambio();
    }

    private CasaPlano.Cuarto cuartoSel() { return plano.tipoSel == 1 ? p.cuarto(plano.idSel) : null; }

    private CasaPlano.Abertura aberturaSel() {
        if (plano.tipoSel != 2) return null;
        for (CasaPlano.Abertura a : p.aberturas) if (a.id == plano.idSel) return a;
        return null;
    }

    private CasaPlano.Mueble muebleSel() {
        if (plano.tipoSel != 3) return null;
        for (CasaPlano.Mueble m : p.muebles) if (m.id == plano.idSel) return m;
        return null;
    }

    private void medidasSel() {
        CasaPlano.Cuarto k = cuartoSel();
        if (k != null) {
            String[] op = {"Ancho por dentro: " + Pieza.n(k.w), "Fondo por dentro: " + Pieza.n(k.h),
                    "De la cara izquierda de la casa: " + Pieza.n(k.x - p.inX0()), "De la cara de abajo de la casa: " + Pieza.n(k.y - p.inY0())};
            new AlertDialog.Builder(act).setTitle("📏 " + k.nombre).setItems(op, (d, w) -> {
                switch (w) {
                    case 0: pedir("Ancho por dentro", k.w, v -> { antes(); k.w = (float) Math.max(300, v); listo(); }); break;
                    case 1: pedir("Fondo por dentro", k.h, v -> { antes(); k.h = (float) Math.max(300, v); listo(); }); break;
                    case 2: pedir("Distancia a la cara izquierda", k.x - p.inX0(), v -> { antes(); k.x = (float) (p.inX0() + v); listo(); }); break;
                    default: pedir("Distancia a la cara de abajo", k.y - p.inY0(), v -> { antes(); k.y = (float) (p.inY0() + v); listo(); });
                }
            }).show();
            return;
        }
        CasaPlano.Abertura a = aberturaSel();
        if (a != null) {
            String[] op = {"Ancho: " + Pieza.n(a.ancho), "Alto: " + Pieza.n(a.alto), "Altura desde el sobrepiso: " + Pieza.n(a.ante),
                    "De la esquina al borde del hueco: " + Pieza.n(a.pos), "Tipo: " + CasaPlano.TIPOS[a.tipo]};
            new AlertDialog.Builder(act).setTitle("📏 " + CasaPlano.TIPOS[a.tipo]).setItems(op, (d, w) -> {
                switch (w) {
                    case 0: pedir("Ancho del hueco", a.ancho, v -> { antes(); a.ancho = (float) Math.max(200, v); listo(); }); break;
                    case 1: pedir("Alto del hueco", a.alto, v -> { antes(); a.alto = (float) Math.max(200, v); listo(); }); break;
                    case 2: pedir("Altura desde el sobrepiso", a.ante, v -> { antes(); a.ante = (float) Math.max(0, v); listo(); }); break;
                    case 3: pedir("De la esquina al borde del hueco", a.pos, v -> { antes(); a.pos = (float) Math.max(0, Math.min(p.largoLado(a) - a.ancho, v)); listo(); }); break;
                    default: new AlertDialog.Builder(act).setTitle("Tipo").setItems(CasaPlano.TIPOS, (d2, t) -> {
                        antes(); a.tipo = t;
                        if (t == 1 && a.ante == 0) { a.ante = 1000; a.alto = 1100; }
                        if (t != 1) a.ante = 0;
                        listo();
                    }).show();
                }
            }).show();
            return;
        }
        CasaPlano.Muro mu = muroSel();
        if (mu != null) {
            float x0 = Math.min(mu.x0, mu.x1), y0 = Math.min(mu.y0, mu.y1);
            String[] op = {"Largo: " + Pieza.n(mu.largo()), "De la cara izquierda de la casa: " + Pieza.n(x0 - p.inX0()), "De la cara de abajo de la casa: " + Pieza.n(y0 - p.inY0())};
            new AlertDialog.Builder(act).setTitle("📏 Muro suelto").setItems(op, (d, w) -> {
                switch (w) {
                    case 0: pedir("Largo del muro", mu.largo(), v -> { antes(); largoMuro(mu, (float) v); listo(); }); break;
                    case 1: pedir("De la cara izquierda de la casa", x0 - p.inX0(), v -> { antes(); float dx = (float) (p.inX0() + v - x0); mu.x0 += dx; mu.x1 += dx; listo(); }); break;
                    default: pedir("De la cara de abajo de la casa", y0 - p.inY0(), v -> { antes(); float dy = (float) (p.inY0() + v - y0); mu.y0 += dy; mu.y1 += dy; listo(); });
                }
            }).show();
            return;
        }
        CasaPlano.Mueble m = muebleSel();
        if (m != null) {
            String[] op = {"Ancho: " + Pieza.n(m.w), "Fondo: " + Pieza.n(m.h), "Alto: " + Pieza.n(m.z)};
            new AlertDialog.Builder(act).setTitle("📏 " + m.nombre).setItems(op, (d, w) -> {
                switch (w) {
                    case 0: pedir("Ancho", m.w, v -> { antes(); m.w = (float) Math.max(50, v); listo(); }); break;
                    case 1: pedir("Fondo", m.h, v -> { antes(); m.h = (float) Math.max(50, v); listo(); }); break;
                    default: pedir("Alto", m.z, v -> { antes(); m.z = (float) Math.max(10, v); listo(); });
                }
            }).show();
        }
    }

    private void nombreCuarto() {
        CasaPlano.Cuarto k = cuartoSel();
        if (k == null) return;
        EditText e = new EditText(act);
        e.setText(k.nombre);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(act).setTitle("✏ Nombre del cuarto").setView(e)
                .setPositiveButton("OK", (d, w) -> { antes(); k.nombre = e.getText().toString().trim(); listo(); })
                .setNegativeButton("Cancelar", null).show();
    }

    /** Copia el cuarto con todo lo de adentro, afuera de la casa. */
    private void copiarCuarto() {
        CasaPlano.Cuarto k = cuartoSel();
        if (k == null) return;
        antes();
        float x = p.ancho + 600;
        for (CasaPlano.Cuarto o : p.cuartos) if (!p.adentro(o)) x = Math.max(x, o.x + o.w + 600);
        CasaPlano.Cuarto n = p.nuevoCuarto(k.nombre, x, 0, k.w, k.h);
        for (CasaPlano.Abertura a : new ArrayList<>(p.aberturas)) if (a.cuarto == k.id) {
            CasaPlano.Abertura b = p.abertura(n.id, a.lado, a.tipo, a.pos, a.ancho, a.alto, a.ante);
            b.abreOtroLado = a.abreOtroLado; b.bisagraDer = a.bisagraDer;
        }
        for (CasaPlano.Mueble m : new ArrayList<>(p.muebles)) if (m.cuarto == k.id) {
            CasaPlano.Mueble c = p.mueble(n.id, m.clave, m.x, m.y);
            c.w = m.w; c.h = m.h; c.z = m.z; c.giro = m.giro; c.nombre = m.nombre;
        }
        plano.escoger(1, n.id);
        plano.encuadrar();
        cambio();
    }

    private void borrarSel() {
        antes();
        if (plano.tipoSel == 1) {
            int id = plano.idSel;
            p.cuartos.removeIf(c -> c.id == id);
            p.aberturas.removeIf(a -> a.cuarto == id);
            p.muebles.removeIf(m -> m.cuarto == id);
        } else if (plano.tipoSel == 2) p.aberturas.removeIf(a -> a.id == plano.idSel);
        else if (plano.tipoSel == 3) p.muebles.removeIf(m -> m.id == plano.idSel);
        else if (plano.tipoSel == 4) p.muros.removeIf(m -> m.id == plano.idSel);
        plano.escoger(0, -1);
        cambio();
    }

    private void voltearPuerta() {
        CasaPlano.Abertura a = aberturaSel();
        if (a == null) return;
        antes();
        a.abreOtroLado = !a.abreOtroLado;
        listo();
    }

    private void girarMueble() {
        CasaPlano.Mueble m = muebleSel();
        if (m == null) return;
        antes();
        m.giro = (m.giro + 90) % 360;
        listo();
    }

    private void muebles() {
        new AlertDialog.Builder(act).setTitle("🛋 Librería").setItems(Libreria.CATEGORIAS, (d, w) -> {
            List<Libreria.Item> its = Libreria.de(Libreria.CATEGORIAS[w]);
            String[] ns = new String[its.size()];
            for (int i = 0; i < ns.length; i++) ns[i] = its.get(i).nombre + "  (" + Pieza.n(its.get(i).w) + " × " + Pieza.n(its.get(i).h) + ")";
            new AlertDialog.Builder(act).setTitle(Libreria.CATEGORIAS[w]).setItems(ns, (d2, k) -> {
                muebleClave = its.get(k).clave;
                tipoPoner = 10;
                plano.poniendo = true;
                plano.aviso = "Toque dentro del cuarto donde va: " + its.get(k).nombre;
                plano.invalidate();
            }).show();
        }).show();
    }

    private void ponerMueble(float x, float y) {
        tipoPoner = -1;
        plano.aviso = "";
        CasaPlano.Cuarto en = null;
        for (CasaPlano.Cuarto k : p.cuartos) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) en = k;
        antes();
        Libreria.Item it = Libreria.item(muebleClave);
        float w = it == null ? 500 : it.w, h = it == null ? 500 : it.h;
        CasaPlano.Mueble m;
        if (en != null) m = p.mueble(en.id, muebleClave, Math.round((x - en.x - w / 2) / 10f) * 10f, Math.round((y - en.y - h / 2) / 10f) * 10f);
        else { m = p.mueble(-1, muebleClave, 0, 0); m.x = Math.round((x - w / 2) / 10f) * 10f; m.y = Math.round((y - h / 2) / 10f) * 10f; }
        plano.escoger(3, m.id);
        cambio();
    }

    private void deshacer() {
        if (atras.isEmpty()) { aviso("No hay más para atrás"); return; }
        try {
            adelante.add(p.json().toString());
            cargarEstado(atras.remove(atras.size() - 1));
        } catch (Exception ignored) { }
    }

    private void rehacer() {
        if (adelante.isEmpty()) return;
        try {
            atras.add(p.json().toString());
            cargarEstado(adelante.remove(adelante.size() - 1));
        } catch (Exception ignored) { }
    }

    private void cargarEstado(String s) throws Exception {
        CasaPlano n = CasaPlano.deJson(new JSONObject(s));
        p.ancho = n.ancho; p.fondo = n.fondo; p.gExt = n.gExt; p.gInt = n.gInt; p.alto = n.alto; p.verSobrepiso = n.verSobrepiso; p.sigId = n.sigId;
        p.cuartos.clear(); p.cuartos.addAll(n.cuartos);
        p.aberturas.clear(); p.aberturas.addAll(n.aberturas);
        p.muebles.clear(); p.muebles.addAll(n.muebles);
        plano.escoger(0, -1);
        cambio();
        plano.invalidate();
    }

    // =====================================================================
    //                                3D
    // =====================================================================

    private void a3D() {
        en3D = true;
        plano.setVisibility(View.GONE);
        v3.setVisibility(View.VISIBLE);
        barra2D.setVisibility(View.GONE);
        barra3D.setVisibility(View.VISIBLE);
        armar3D();
        v3.post(() -> v3.vista(-35, 30));
    }

    private void a2D() {
        parar();
        en3D = false;
        v3.setVisibility(View.GONE);
        plano.setVisibility(View.VISIBLE);
        barra3D.setVisibility(View.GONE);
        barra2D.setVisibility(View.VISIBLE);
    }

    private void armar3D() {
        v3.piezas = Casa3D.piezas(p, corte);
        v3.version = InventorActivity.VERSION + " · 🏠 " + nombre + (corte > 0 ? " · corte a 1,20 m" : "");
        v3.invalidate();
    }

    private void corte() {
        corte = corte > 0 ? 0 : 1200;
        armar3D();
        aviso(corte > 0 ? "✂ Paredes cortadas a 1,20 m para ver adentro" : "Paredes completas");
    }

    // ---------------- Recorrido para grabar con Mi Barra ----------------

    private long t0;

    private float corteAntes;

    private void recorrido() {
        if (grabando) { parar(); aviso("Recorrido parado"); return; }
        corteAntes = corte;
        aviso("🎥 Prenda la grabadora de pantalla de Mi Barra. El recorrido arranca en 3 segundos");
        grabando = true;
        v3.vista(-35, 30);
        v3.postDelayed(() -> { if (!grabando) return; t0 = System.currentTimeMillis(); paso(); }, 3000);
    }

    private void parar() {
        if (!grabando) return;
        grabando = false;
        corte = corteAntes;
        armar3D();
        v3.vista(-35, 30);
    }

    /** 0-24 s: una vuelta lenta alrededor de la casa; luego 5 s por cada cuarto, mirándolo desde arriba con las paredes cortadas. */
    private void paso() {
        if (!grabando) return;
        float t = (System.currentTimeMillis() - t0) / 1000f;
        float cx = p.ancho / 2, cy = p.fondo / 2;
        List<CasaPlano.Cuarto> adentro = new ArrayList<>();
        for (CasaPlano.Cuarto k : p.cuartos) if (p.adentro(k)) adentro.add(k);
        float vuelta = 24, porCuarto = 5;
        if (t < vuelta) {
            v3.camara(-35 + 360 * t / vuelta, 28, 1, cx, cy, p.alto / 2);
        } else {
            int i = (int) ((t - vuelta) / porCuarto);
            if (i >= adentro.size()) { parar(); aviso("✔ Recorrido terminado. Pare la grabadora de Mi Barra"); return; }
            if (corte == 0) { corte = 1200; armar3D(); }
            CasaPlano.Cuarto k = adentro.get(i);
            float f = (t - vuelta - i * porCuarto) / porCuarto;
            float z = Math.min(4f, Math.max(1.4f, Math.max(p.ancho, p.fondo) / Math.max(k.w, k.h) * 0.75f));
            v3.camara(-35 + 70 * f + i * 40, 55, z, k.x + k.w / 2, k.y + k.h / 2, 600);
            v3.version = "🎥 " + k.nombre + " · " + Pieza.n(k.w) + " x " + Pieza.n(k.h);
        }
        v3.postDelayed(this::paso, 40);
    }

    // =====================================================================
    //                                PDF y guardar
    // =====================================================================

    void pdf() {
        try {
            PdfDocument doc = new PdfDocument();
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(612, 792, 1).create());
            Canvas c = pg.getCanvas();
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(Color.BLACK);
            t.setTextSize(13);
            t.setFakeBoldText(true);
            c.drawText("CHEPE CAD · Casa «" + nombre + "» · planta", 36, 40, t);
            t.setFakeBoldText(false);
            t.setTextSize(9);
            c.drawText("Medidas en mm · muro de afuera " + Pieza.n(p.gExt) + " · muros de adentro " + Pieza.n(p.gInt) + " · paredes de " + Pieza.n(p.alto) + " desde el sobrepiso", 36, 54, t);
            // la planta en el recuadro de la hoja
            float ex = plano.esc, ox = plano.offX, oy = plano.offY;
            float x0 = -1100, y0 = -1100, x1 = p.ancho + 1100, y1 = p.fondo + 1100;
            for (CasaPlano.Cuarto k : p.cuartos) { x1 = Math.max(x1, k.x + k.w + 400); y1 = Math.max(y1, k.y + k.h + 400); }
            float W = 540, H = 520;
            plano.esc = Math.min(W / (x1 - x0), H / (y1 - y0));
            plano.offX = 36 + (W - (x1 - x0) * plano.esc) / 2 - x0 * plano.esc;
            plano.offY = 66 + H - (H - (y1 - y0) * plano.esc) / 2 + y0 * plano.esc;
            int ts = plano.tipoSel;
            plano.tipoSel = 0;
            plano.pintar(c, true);
            plano.tipoSel = ts;
            plano.esc = ex; plano.offX = ox; plano.offY = oy;
            // cuadro de áreas
            float y = 610;
            t.setFakeBoldText(true);
            c.drawText("Cuartos (medida por dentro)", 36, y, t);
            t.setFakeBoldText(false);
            double total = 0;
            int col = 0;
            for (CasaPlano.Cuarto k : p.cuartos) {
                if (!p.adentro(k)) continue;
                total += CasaPlano.m2(k);
                y += 12;
                if (y > 760) { y = 622; col++; }
                c.drawText(k.nombre + ": " + Pieza.n(k.w) + " x " + Pieza.n(k.h) + " = " + String.format(Locale.US, "%.2f m²", CasaPlano.m2(k)), 36 + col * 270, y, t);
            }
            t.setFakeBoldText(true);
            c.drawText("Área construida (por fuera): " + String.format(Locale.US, "%.2f m²", p.ancho * (double) p.fondo / 1e6)
                    + " · útil de cuartos: " + String.format(Locale.US, "%.2f m²", total), 36, 780, t);
            doc.finishPage(pg);
            act.guardarPdf(doc, "ChepeCAD_Casa_");
        } catch (Exception e) {
            aviso("No se pudo hacer el PDF");
        }
    }

    void guardar() {
        try {
            JSONObject o = new JSONObject();
            o.put("v", 7);
            o.put("modo", InventorActivity.PLANTA);
            o.put("nombre", nombre);
            o.put("plano", p.json());
            try (FileWriter w = new FileWriter(new File(carpeta, nombre + ".json"))) { w.write(o.toString()); }
        } catch (Exception e) {
            aviso("No se pudo guardar la casa");
        }
    }
}
