package co.jose.miinventor;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v6.9 · Gabinetes: librería de gabinetes de cocina tradicionales.
 * Inferiores: se pone la luz entre muro y muro, se acomodan los módulos y el mesón va encima.
 * Superiores: ancho y cuántos compartimientos.
 * Cada gabinete es su propio archivo (Libreria/_gabinetes). El despiece se manda a Corte Lámina (madera).
 */
final class Gabinetes {

    static final String[] TIPOS = {"2 puertas", "1 puerta", "Cajonero (3 cajones)", "Fregadero (2 puertas)"};

    static final class Modulo {
        int tipo;
        double ancho;
        Modulo(int t, double a) { tipo = t; ancho = a; }
    }

    static final class Gab {
        String nombre = "Cocina 1";
        boolean superior;
        double luz = 2400, alto = 720, fondo = 560, zocalo = 100, meson = 30, tablero = 15;
        int compartimientos = 3;
        final List<Modulo> modulos = new ArrayList<>();

        double usado() { double t = 0; for (Modulo m : modulos) t += m.ancho; return t; }

        JSONObject json() throws Exception {
            JSONObject o = new JSONObject();
            o.put("n", nombre); o.put("sup", superior); o.put("luz", luz); o.put("alto", alto); o.put("fondo", fondo);
            o.put("zoc", zocalo); o.put("mes", meson); o.put("tab", tablero); o.put("comp", compartimientos);
            JSONArray a = new JSONArray();
            for (Modulo m : modulos) a.put(new JSONArray().put(m.tipo).put(m.ancho));
            o.put("mod", a);
            return o;
        }

        static Gab de(JSONObject o) {
            Gab g = new Gab();
            g.nombre = o.optString("n", "Cocina 1"); g.superior = o.optBoolean("sup", false);
            g.luz = o.optDouble("luz", 2400); g.alto = o.optDouble("alto", g.superior ? 700 : 720); g.fondo = o.optDouble("fondo", g.superior ? 330 : 560);
            g.zocalo = o.optDouble("zoc", 100); g.meson = o.optDouble("mes", 30); g.tablero = o.optDouble("tab", 15);
            g.compartimientos = o.optInt("comp", 3);
            JSONArray a = o.optJSONArray("mod");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONArray m = a.optJSONArray(i);
                if (m != null) g.modulos.add(new Modulo(m.optInt(0), m.optDouble(1)));
            }
            return g;
        }
    }

    /** Una pieza del despiece: nombre, largo, ancho, cuántas y el canto (F A I D). */
    static final class Pz {
        String nombre, canto;
        double l, a;
        int n;
        Pz(String nombre, double l, double a, int n, String canto) { this.nombre = nombre; this.l = l; this.a = a; this.n = n; this.canto = canto; }
    }

    private static double r1(double x) { return Math.round(x * 10) / 10.0; }

    /** El despiece de un gabinete (tableros del grueso escogido). */
    static List<Pz> despiece(Gab g, List<String> aparte) {
        List<Pz> r = new ArrayList<>();
        double t = g.tablero, H = g.alto, D = g.fondo;
        if (g.superior) {
            int n = Math.max(1, g.compartimientos);
            double W = g.luz, interior = W - 2 * t, comp = (interior - (n - 1) * t) / n;
            r.add(new Pz("Lateral", H, D, 2, "F"));
            r.add(new Pz("Techo y piso", r1(interior), D, 2, "F"));
            if (n > 1) r.add(new Pz("División", r1(H - 2 * t), D, n - 1, "F"));
            r.add(new Pz("Entrepaño", r1(comp), r1(D - 20), n, "F"));
            r.add(new Pz("Puerta", r1(H - 3), r1(comp + t - 3), n, "F A I D"));
            aparte.add("Fondo (triplex 4 mm): " + Pieza.n((float) r1(W)) + " × " + Pieza.n((float) r1(H)) + " × 1");
            return r;
        }
        int k = 1;
        for (Modulo m : g.modulos) {
            double W = m.ancho, in = W - 2 * t;
            String s = "M" + k++;
            r.add(new Pz(s + " lateral", H, D, 2, "F"));
            r.add(new Pz(s + " piso", r1(in), D, 1, "F"));
            r.add(new Pz(s + " amarre", r1(in), 100, 2, "F"));
            switch (m.tipo) {
                case 0:
                    r.add(new Pz(s + " entrepaño", r1(in), r1(D - 20), 1, "F"));
                    r.add(new Pz(s + " puerta", r1(H - 3), r1(W / 2 - 3), 2, "F A I D"));
                    break;
                case 1:
                    r.add(new Pz(s + " entrepaño", r1(in), r1(D - 20), 1, "F"));
                    r.add(new Pz(s + " puerta", r1(H - 3), r1(W - 3), 1, "F A I D"));
                    break;
                case 2:
                    r.add(new Pz(s + " frente cajón", r1(H / 3 - 3), r1(W - 3), 3, "F A I D"));
                    aparte.add(s + ": 3 cajones de " + Pieza.n((float) r1(in - 26)) + " de ancho (correderas de " + Pieza.n((float) (Math.floor((D - 20) / 50) * 50)) + ")");
                    break;
                default:
                    r.add(new Pz(s + " puerta", r1(H - 3), r1(W / 2 - 3), 2, "F A I D"));
            }
            aparte.add(s + " fondo (triplex 4 mm): " + Pieza.n((float) r1(W)) + " × " + Pieza.n((float) r1(H)) + " × 1");
        }
        if (!g.modulos.isEmpty()) {
            r.add(new Pz("Zócalo", r1(g.usado()), g.zocalo, 1, "F"));
            aparte.add("Mesón: " + Pieza.n((float) r1(g.luz)) + " × " + Pieza.n((float) r1(D + 30)) + " · " + Pieza.n((float) g.meson) + " mm de grueso");
        }
        return r;
    }

    static String textoCorte(List<Pz> ps) {
        StringBuilder sb = new StringBuilder();
        for (Pz p : ps) sb.append(p.nombre).append(' ').append(Pieza.n((float) p.l)).append('x').append(Pieza.n((float) p.a)).append('x').append(p.n).append(' ').append(p.canto).append('\n');
        return sb.toString();
    }

    // =====================================================================
    //                              La pantalla
    // =====================================================================

    private final InventorActivity act;
    private final File carpeta;
    private Gab g;

    Gabinetes(InventorActivity act, File libreria) {
        this.act = act;
        this.carpeta = new File(libreria, "_gabinetes");
        if (!carpeta.exists()) carpeta.mkdirs();
    }

    private int dp(float v) { return Math.round(v * act.getResources().getDisplayMetrics().density); }

    private void aviso(String s) { Toast.makeText(act, s, Toast.LENGTH_LONG).show(); }

    /** La librería: los gabinetes guardados (cada uno su archivo) o uno nuevo. */
    void abrir() {
        File[] fs = carpeta.listFiles(x -> x.getName().endsWith(".json"));
        List<File> l = new ArrayList<>();
        if (fs != null) for (File f : fs) l.add(f);
        l.sort((x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] it = new String[l.size() + 2];
        it[0] = "➕ Gabinete INFERIOR nuevo (entre muro y muro)";
        it[1] = "➕ Gabinete SUPERIOR nuevo (ancho y compartimientos)";
        for (int i = 0; i < l.size(); i++) it[i + 2] = "🗄 " + l.get(i).getName().replace(".json", "");
        new AlertDialog.Builder(act).setTitle("🗄 Gabinetes · librería").setItems(it, (d, w) -> {
            if (w < 2) {
                g = new Gab();
                g.superior = w == 1;
                if (g.superior) { g.luz = 1200; g.alto = 700; g.fondo = 330; }
                else { g.modulos.add(new Modulo(0, 800)); g.modulos.add(new Modulo(2, 500)); g.modulos.add(new Modulo(3, 1100)); }
                int n = 1;
                while (new File(carpeta, (g.superior ? "Superior " : "Cocina ") + n + ".json").exists()) n++;
                g.nombre = (g.superior ? "Superior " : "Cocina ") + n;
                pantalla();
            } else {
                try {
                    File f = l.get(w - 2);
                    g = Gab.de(new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8)));
                    pantalla();
                } catch (Exception e) { aviso("No se pudo abrir ese gabinete"); }
            }
        }).setNegativeButton("Cerrar", null).show();
    }

    private void guardar() {
        try (FileWriter w = new FileWriter(new File(carpeta, g.nombre.replaceAll("[/\\\\:*?\"<>|]", "-") + ".json"))) { w.write(g.json().toString()); }
        catch (Exception e) { aviso("No se pudo guardar"); }
    }

    private TextView boton(String txt, int color, Runnable r) {
        TextView t = new TextView(act);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(9));
        t.setBackground(gd);
        if (r != null) t.setOnClickListener(v -> r.run());
        return t;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextSize(14);
        t.setTextColor(Color.WHITE);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(8), 0, dp(2));
        return t;
    }

    private EditText numero(double v, String titulo) {
        EditText e = new EditText(act);
        e.setTextSize(17);
        e.setTextColor(Color.BLACK);
        e.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.WHITE);
        gd.setCornerRadius(dp(7));
        e.setBackground(gd);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        String s = Pieza.n((float) v);
        Teclado.numero(act, e, titulo, s);
        e.setText(s);
        return e;
    }

    private static double num(EditText e, double def) {
        try { return Formula.calcular(Teclado.tx(e).trim(), k -> null); } catch (Exception x) { return def; }
    }

    private LinearLayout columna(String titulo, View v) {
        LinearLayout c = new LinearLayout(act);
        c.setOrientation(LinearLayout.VERTICAL);
        c.addView(etiqueta(titulo));
        c.addView(v);
        return c;
    }

    private LinearLayout.LayoutParams peso(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, w);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private void pantalla() {
        android.app.Dialog dlg = new android.app.Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout raiz = new LinearLayout(act);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF151A26);
        raiz.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout arriba = new LinearLayout(act);
        arriba.setGravity(Gravity.CENTER_VERTICAL);
        arriba.addView(boton("⬅", 0xFF37474F, () -> pregunteGuardar(dlg)), new LinearLayout.LayoutParams(dp(52), dp(46)));
        TextView tt = new TextView(act);
        tt.setText("🗄 Gabinetes · " + (g.superior ? "superior" : "inferior") + "\n" + InventorActivity.VERSION + " · «" + g.nombre + "»");
        tt.setTextColor(0xFFFFB300);
        tt.setTextSize(16);
        tt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tt.setPadding(dp(10), 0, 0, 0);
        arriba.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        Dibujo dib = new Dibujo(act);
        // v7: el gabinete en 3D (un dedo gira, dos dedos acercan) o de frente con sus cotas
        TextView b3d = boton(dib.en3d ? "▭ Frente" : "🧊 3D", 0xFF00897B, null);
        b3d.setOnClickListener(v -> { dib.en3d = !dib.en3d; b3d.setText(dib.en3d ? "▭ Frente" : "🧊 3D"); dib.invalidate(); });
        arriba.addView(b3d, new LinearLayout.LayoutParams(dp(84), dp(46)));
        arriba.addView(boton("📖", 0xFFFFB300, () -> Tutorial.mostrar(act, Tutorial.GABINETES)), new LinearLayout.LayoutParams(dp(52), dp(46)));
        raiz.addView(arriba);

        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(-1, dp(260));
        dp1.topMargin = dp(6);
        raiz.addView(dib, dp1);

        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(act);
        sv.addView(l);
        raiz.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout f1 = new LinearLayout(act);
        EditText luz = numero(g.luz, g.superior ? "Ancho del gabinete (mm)" : "Luz entre muro y muro (mm)");
        EditText tab = numero(g.tablero, "Grueso del tablero (15 o 9 mm)");
        f1.addView(columna(g.superior ? "Ancho total" : "Luz muro a muro", luz), peso(1.3f));
        f1.addView(columna("Tablero (mm)", tab), peso(1));
        l.addView(f1);
        LinearLayout f2 = new LinearLayout(act);
        EditText alto = numero(g.alto, "Alto del cuerpo (mm)"), fondo = numero(g.fondo, "Fondo (mm)");
        f2.addView(columna(g.superior ? "Alto" : "Alto cuerpo", alto), peso(1));
        f2.addView(columna("Fondo", fondo), peso(1));
        EditText zoc = numero(g.zocalo, "Zócalo (mm)"), mes = numero(g.meson, "Grueso del mesón (mm)"), comp = numero(g.compartimientos, "¿Cuántos compartimientos?");
        if (g.superior) f2.addView(columna("Compartimientos", comp), peso(1));
        else { f2.addView(columna("Zócalo", zoc), peso(1)); f2.addView(columna("Mesón", mes), peso(1)); }
        l.addView(f2);

        TextView estado = etiqueta("");
        LinearLayout lista = new LinearLayout(act);
        lista.setOrientation(LinearLayout.VERTICAL);
        List<EditText> anchos = new ArrayList<>();
        Runnable leer = () -> {
            g.luz = Math.max(100, num(luz, g.luz));
            g.tablero = Math.max(3, num(tab, g.tablero));
            g.alto = Math.max(100, num(alto, g.alto));
            g.fondo = Math.max(100, num(fondo, g.fondo));
            g.zocalo = Math.max(0, num(zoc, g.zocalo));
            g.meson = Math.max(0, num(mes, g.meson));
            g.compartimientos = (int) Math.max(1, Math.min(8, Math.round(num(comp, g.compartimientos))));
            for (int i = 0; i < anchos.size() && i < g.modulos.size(); i++) g.modulos.get(i).ancho = Math.max(150, num(anchos.get(i), g.modulos.get(i).ancho));
        };
        Runnable[] pintar = new Runnable[1];
        Runnable refrescar = () -> {
            leer.run();
            if (!g.superior) {
                double falta = g.luz - g.usado();
                estado.setText(Math.abs(falta) < 0.5 ? "✔ Los módulos llenan la luz entre muros" : falta > 0 ? "⚠ Faltan " + Pieza.n((float) r1(falta)) + " mm para llegar al otro muro" : "⚠ Se pasan " + Pieza.n((float) r1(-falta)) + " mm de la luz entre muros");
                estado.setTextColor(Math.abs(falta) < 0.5 ? 0xFF81C784 : 0xFFFF8A65);
            }
            dib.invalidate();
        };
        pintar[0] = () -> {
            lista.removeAllViews();
            anchos.clear();
            int k = 1;
            for (Modulo m : g.modulos) {
                LinearLayout f = new LinearLayout(act);
                f.setGravity(Gravity.CENTER_VERTICAL);
                TextView tipo = boton("M" + k++ + " · " + TIPOS[m.tipo], 0xFF5D4037, null);
                tipo.setTextSize(13);
                tipo.setOnClickListener(v -> new AlertDialog.Builder(act).setTitle("¿Qué módulo es?").setItems(TIPOS, (d, w) -> { leer.run(); m.tipo = w; pintar[0].run(); refrescar.run(); }).show());
                f.addView(tipo, peso(1.6f));
                EditText an = numero(m.ancho, "Ancho del módulo (mm)");
                an.addTextChangedListener(new android.text.TextWatcher() {
                    public void beforeTextChanged(CharSequence a, int b, int c, int e) { }
                    public void onTextChanged(CharSequence a, int b, int c, int e) { }
                    public void afterTextChanged(android.text.Editable e) { refrescar.run(); }
                });
                anchos.add(an);
                f.addView(an, peso(1));
                f.addView(boton("🗑", 0xFFC62828, () -> { leer.run(); g.modulos.remove(m); pintar[0].run(); refrescar.run(); }), new LinearLayout.LayoutParams(dp(46), dp(44)));
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
                fp.topMargin = dp(4);
                lista.addView(f, fp);
            }
        };
        if (!g.superior) {
            l.addView(etiqueta("Módulos (de izquierda a derecha) — toque el nombre para cambiarlo"));
            l.addView(lista);
            LinearLayout f3 = new LinearLayout(act);
            f3.addView(boton("➕ Módulo", 0xFF1565C0, () -> { leer.run(); g.modulos.add(new Modulo(0, 600)); pintar[0].run(); refrescar.run(); }), peso(1));
            f3.addView(boton("↔ Ajustar el último a la luz", 0xFF00897B, () -> {
                leer.run();
                if (g.modulos.isEmpty()) return;
                Modulo u = g.modulos.get(g.modulos.size() - 1);
                double nuevo = u.ancho + g.luz - g.usado();
                if (nuevo < 150) { aviso("El último módulo quedaría muy angosto"); return; }
                u.ancho = r1(nuevo);
                pintar[0].run(); refrescar.run();
            }), peso(1.4f));
            LinearLayout.LayoutParams f3p = new LinearLayout.LayoutParams(-1, -2);
            f3p.topMargin = dp(6);
            l.addView(f3, f3p);
            l.addView(estado);
        }
        for (EditText e : new EditText[]{luz, tab, alto, fondo, zoc, mes, comp})
            e.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence a, int b, int c, int e2) { }
                public void onTextChanged(CharSequence a, int b, int c, int e2) { }
                public void afterTextChanged(android.text.Editable x) { refrescar.run(); }
            });
        pintar[0].run();
        refrescar.run();

        LinearLayout abajo = new LinearLayout(act);
        abajo.addView(boton("💾 Guardar", 0xFF2E7D32, () -> { leer.run(); guardar(); aviso("✔ Guardado «" + g.nombre + "»"); }), peso(1));
        abajo.addView(boton("📋 Despiece", 0xFF6A1B9A, () -> { leer.run(); verDespiece(); }), peso(1));
        abajo.addView(boton("✂ A Corte", 0xFFC62828, () -> {
            leer.run();
            guardar();
            new Cortes(act, carpeta.getParentFile()).abrirConPiezas(2, g.nombre, textoCorte(despiece(g, new ArrayList<>())));
        }), peso(1));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(6);
        raiz.addView(abajo, ap);
        dlg.setContentView(raiz);
        dlg.setOnCancelListener(d -> { });
        dlg.show();
    }

    private void pregunteGuardar(android.app.Dialog dlg) {
        new AlertDialog.Builder(act).setTitle("¿Guardar los cambios?").setMessage("«" + g.nombre + "»")
                .setPositiveButton("💾 Guardar", (d, w) -> { guardar(); dlg.dismiss(); })
                .setNegativeButton("No guardar", (d, w) -> dlg.dismiss())
                .setNeutralButton("Seguir aquí", null).show();
    }

    private void verDespiece() {
        List<String> aparte = new ArrayList<>();
        List<Pz> ps = despiece(g, aparte);
        StringBuilder sb = new StringBuilder();
        sb.append("Tablero de ").append(Pieza.n((float) g.tablero)).append(" mm (largo × ancho × cuántas · canto)\n\n");
        double canto = 0;
        for (Pz p : ps) {
            sb.append("• ").append(p.nombre).append(": ").append(Pieza.n((float) p.l)).append(" × ").append(Pieza.n((float) p.a)).append(" × ").append(p.n).append("  ").append(p.canto).append('\n');
            for (String c : p.canto.split(" ")) {
                if (c.equals("F") || c.equals("A")) canto += p.l * p.n;
                else if (c.equals("I") || c.equals("D")) canto += p.a * p.n;
            }
        }
        sb.append(String.format(Locale.US, "\nCanto: %.2f metros lineales\n", canto / 1000));
        if (!aparte.isEmpty()) { sb.append("\nAparte:\n"); for (String s : aparte) sb.append("• ").append(s).append('\n'); }
        new AlertDialog.Builder(act).setTitle("📋 Despiece · " + g.nombre).setMessage(sb.toString())
                .setPositiveButton("✂ Enviar a Corte Láminas", (d, w) -> { guardar(); new Cortes(act, carpeta.getParentFile()).abrirConPiezas(2, g.nombre, textoCorte(ps)); })
                .setNegativeButton("Cerrar", null).show();
    }

    /** Vista de frente con sus cotas (letras y medidas nítidas). v7: o en 3D, girando con el dedo. */
    private final class Dibujo extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean en3d = true;
        private float giro = -35, inclin = 22, zoom = 1, tx0, ty0, dist0;

        Dibujo(Context c) { super(c); }

        @Override
        public boolean onTouchEvent(android.view.MotionEvent e) {
            if (!en3d) return false;
            getParent().requestDisallowInterceptTouchEvent(true);
            int a = e.getActionMasked();
            if (e.getPointerCount() >= 2) {
                float dx = e.getX(0) - e.getX(1), dy = e.getY(0) - e.getY(1), dd = (float) Math.hypot(dx, dy);
                if (a == android.view.MotionEvent.ACTION_POINTER_DOWN || dist0 <= 0) dist0 = dd;
                else if (dist0 > 0) { zoom = Math.max(0.4f, Math.min(5f, zoom * dd / dist0)); dist0 = dd; invalidate(); }
                return true;
            }
            if (a == android.view.MotionEvent.ACTION_DOWN) { tx0 = e.getX(); ty0 = e.getY(); dist0 = 0; return true; }
            if (a == android.view.MotionEvent.ACTION_MOVE && dist0 <= 0) {
                giro += (e.getX() - tx0) * 0.35f;
                inclin = Math.max(-80, Math.min(80, inclin + (e.getY() - ty0) * 0.25f));
                tx0 = e.getX(); ty0 = e.getY();
                invalidate();
            }
            if (a == android.view.MotionEvent.ACTION_UP) dist0 = 0;
            return true;
        }

        /** Una cara de una caja: 4 esquinas (x, y, z en mm), su color y rayas encima (puertas, cajones). */
        private final class Cara {
            float[][] q; int color; float[] n; List<float[][]> rayas = new ArrayList<>(); float hondo;
        }

        private void caja(List<Cara> l, float x0, float y0, float z0, float x1, float y1, float z1, int color, List<float[][]> rayasFrente) {
            float[][] v = {{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}};
            int[][] f = {{0, 1, 5, 4}, {2, 3, 7, 6}, {3, 0, 4, 7}, {1, 2, 6, 5}, {4, 5, 6, 7}, {3, 2, 1, 0}};
            float[][] n = {{0, -1, 0}, {0, 1, 0}, {-1, 0, 0}, {1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
            for (int i = 0; i < 6; i++) {
                Cara c = new Cara();
                c.q = new float[][]{v[f[i][0]], v[f[i][1]], v[f[i][2]], v[f[i][3]]};
                c.n = n[i];
                c.color = color;
                if (i == 0 && rayasFrente != null) c.rayas = rayasFrente;
                l.add(c);
            }
        }

        private List<Cara> armar() {
            List<Cara> l = new ArrayList<>();
            float t = (float) g.tablero, D = (float) g.fondo;
            int madera = 0xFFA1683A;
            if (g.superior) {
                int n = Math.max(1, g.compartimientos);
                float W = (float) g.luz, H = (float) g.alto;
                List<float[][]> r = new ArrayList<>();
                for (int i = 1; i < n; i++) { float x = W * i / n; r.add(new float[][]{{x, 0, 3}, {x, 0, H - 3}}); }
                for (int i = 0; i < n; i++) { float x = W * i / n + W / n * 0.85f; r.add(new float[][]{{x, 0, H * 0.15f}, {x, 0, H * 0.3f}}); }   // manijas
                caja(l, 0, 0, 0, W, D, H, madera, r);
                return l;
            }
            float Z = (float) g.zocalo, H = (float) g.alto, M = (float) g.meson, L = (float) g.luz;
            float x = 0;
            for (Modulo mo : g.modulos) {
                float w = (float) mo.ancho;
                List<float[][]> r = new ArrayList<>();
                if (mo.tipo == 0 || mo.tipo == 3) {
                    r.add(new float[][]{{x + w / 2, 0, Z + 3}, {x + w / 2, 0, Z + H - 3}});
                    r.add(new float[][]{{x + w / 2 - 25, 0, Z + H - 60}, {x + w / 2 - 25, 0, Z + H - 160}});
                    r.add(new float[][]{{x + w / 2 + 25, 0, Z + H - 60}, {x + w / 2 + 25, 0, Z + H - 160}});
                } else if (mo.tipo == 1) r.add(new float[][]{{x + w - 30, 0, Z + H - 60}, {x + w - 30, 0, Z + H - 160}});
                else if (mo.tipo == 2) for (int i = 0; i < 3; i++) {
                    float zz = Z + H * i / 3;
                    if (i > 0) r.add(new float[][]{{x + 3, 0, zz}, {x + w - 3, 0, zz}});
                    r.add(new float[][]{{x + w / 2 - 60, 0, zz + H / 6}, {x + w / 2 + 60, 0, zz + H / 6}});
                }
                r.add(new float[][]{{x, 0, Z}, {x, 0, Z + H}});
                caja(l, x, 0, Z, x + w, D, Z + H, madera, r);
                x += w;
            }
            if (x > 0) caja(l, 0, 50, 0, x, D, Z, 0xFF424242, null);   // zócalo (metido 5 cm)
            caja(l, 0, -30, Z + H, L, D, Z + H + M, 0xFFBDBDBD, null);   // mesón (sale 3 cm)
            float Ht = Z + H + M + 600;
            caja(l, -120, -30, 0, 0, D + 100, Ht, 0xFF8D6E63, null);      // muros
            caja(l, L, -30, 0, L + 120, D + 100, Ht, 0xFF8D6E63, null);
            return l;
        }

        private final float RAD = (float) (Math.PI / 180);

        /** Gira el punto: primero alrededor de Z (giro) y luego se inclina (inclin). Devuelve x, alto, hondo. */
        private float[] ver(float[] v, float cx, float cy, float cz) {
            float x = v[0] - cx, y = v[1] - cy, z = v[2] - cz;
            float cg = (float) Math.cos(giro * RAD), sg = (float) Math.sin(giro * RAD);
            float x1 = x * cg - y * sg, y1 = x * sg + y * cg;
            float ci = (float) Math.cos(inclin * RAD), si = (float) Math.sin(inclin * RAD);
            float y2 = y1 * ci - z * si, z2 = y1 * si + z * ci;
            return new float[]{x1, z2, y2};
        }

        private void pintar3D(Canvas c, int linea) {
            List<Cara> l = armar();
            if (l.isEmpty()) return;
            float mnx = Float.MAX_VALUE, mny = Float.MAX_VALUE, mnz = Float.MAX_VALUE, mxx = -Float.MAX_VALUE, mxy = -Float.MAX_VALUE, mxz = -Float.MAX_VALUE;
            for (Cara f : l) for (float[] v : f.q) { mnx = Math.min(mnx, v[0]); mxx = Math.max(mxx, v[0]); mny = Math.min(mny, v[1]); mxy = Math.max(mxy, v[1]); mnz = Math.min(mnz, v[2]); mxz = Math.max(mxz, v[2]); }
            float cx = (mnx + mxx) / 2, cy = (mny + mxy) / 2, cz = (mnz + mxz) / 2;
            float rad = (float) Math.sqrt((mxx - mnx) * (mxx - mnx) + (mxy - mny) * (mxy - mny) + (mxz - mnz) * (mxz - mnz)) / 2;
            float esc = Math.min(getWidth(), getHeight()) * 0.48f / Math.max(1, rad) * zoom;
            float ox = getWidth() / 2f, oy = getHeight() / 2f;
            List<float[][]> proy = new ArrayList<>();
            List<Cara> vis = new ArrayList<>();
            for (Cara f : l) {
                float[] nn = ver(new float[]{f.n[0] + cx, f.n[1] + cy, f.n[2] + cz}, cx, cy, cz);
                if (nn[2] > -0.01f) continue;   // mira para atrás
                float[][] q = new float[4][];
                float h = 0;
                for (int i = 0; i < 4; i++) { q[i] = ver(f.q[i], cx, cy, cz); h += q[i][2]; }
                f.hondo = h / 4;
                vis.add(f);
                proy.add(q);
            }
            Integer[] orden = new Integer[vis.size()];
            for (int i = 0; i < orden.length; i++) orden[i] = i;
            java.util.Arrays.sort(orden, (a, b) -> Float.compare(vis.get(b).hondo, vis.get(a).hondo));
            android.graphics.Path path = new android.graphics.Path();
            for (int k : orden) {
                Cara f = vis.get(k);
                float[][] q = proy.get(k);
                path.reset();
                for (int i = 0; i < 4; i++) { float sx = ox + q[i][0] * esc, sy = oy - q[i][1] * esc; if (i == 0) path.moveTo(sx, sy); else path.lineTo(sx, sy); }
                path.close();
                float luz = f.n[2] > 0.5f ? 1f : f.n[1] < -0.5f ? 0.88f : 0.72f;
                int col = f.color;
                int rr = (int) (((col >> 16) & 255) * luz), gg = (int) (((col >> 8) & 255) * luz), bb = (int) ((col & 255) * luz);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.rgb(rr, gg, bb));
                c.drawPath(path, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(linea);
                p.setStrokeWidth(1.2f * getResources().getDisplayMetrics().density);
                c.drawPath(path, p);
                p.setColor(0xFFFFE0B2);
                for (float[][] ry : f.rayas) {
                    float[] a = ver(ry[0], cx, cy, cz), b = ver(ry[1], cx, cy, cz);
                    c.drawLine(ox + a[0] * esc, oy - a[1] * esc, ox + b[0] * esc, oy - b[1] * esc, p);
                }
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(linea);
            p.setTextSize(11 * getResources().getDisplayMetrics().density);
            String s = "Un dedo gira · dos dedos acercan";
            c.drawText(s, 8 * getResources().getDisplayMetrics().density, getHeight() - 8 * getResources().getDisplayMetrics().density, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            boolean negro = Tema.negro;
            int fondo = negro ? 0xFF0D1018 : Color.WHITE, linea = negro ? Color.WHITE : Color.BLACK;
            c.drawColor(fondo);
            if (g == null) return;
            if (en3d) { pintar3D(c, linea); return; }
            float d = getResources().getDisplayMetrics().density;
            double W = g.superior ? g.luz : Math.max(g.luz, g.usado());
            double Ht = g.superior ? g.alto : g.zocalo + g.alto + g.meson;
            float m = 34 * d;
            float esc = (float) Math.min((getWidth() - 2 * m) / W, (getHeight() - 2 * m) / Ht);
            float x0 = (getWidth() - (float) W * esc) / 2, yb = getHeight() - m;
            p.setStrokeWidth(1.6f * d);
            p.setTextSize(11 * d);
            p.setFakeBoldText(true);
            if (g.superior) {
                int n = Math.max(1, g.compartimientos);
                float top = yb - (float) g.alto * esc;
                RectF r = new RectF(x0, top, x0 + (float) W * esc, yb);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFA1683A);
                c.drawRect(r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(linea);
                c.drawRect(r, p);
                for (int i = 1; i < n; i++) { float x = r.left + r.width() * i / n; c.drawLine(x, top, x, yb, p); }
                cota(c, r.left, r.right, top - 14 * d, Pieza.n((float) W), linea, d);
                cotaV(c, r.right + 14 * d, top, yb, Pieza.n((float) g.alto), linea, d);
                return;
            }
            // muros
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF8D6E63);
            float luzPx = (float) g.luz * esc;
            c.drawRect(x0 - 8 * d, yb - (float) Ht * esc - 10 * d, x0, yb, p);
            c.drawRect(x0 + luzPx, yb - (float) Ht * esc - 10 * d, x0 + luzPx + 8 * d, yb, p);
            float zTop = yb - (float) g.zocalo * esc, cTop = zTop - (float) g.alto * esc, mTop = cTop - (float) g.meson * esc;
            // mesón
            p.setColor(0xFFBDBDBD);
            c.drawRect(x0, mTop, x0 + luzPx, cTop, p);
            // zócalo
            p.setColor(0xFF424242);
            c.drawRect(x0, zTop, x0 + (float) g.usado() * esc, yb, p);
            float x = x0;
            int k = 1;
            for (Modulo mo : g.modulos) {
                float w = (float) mo.ancho * esc;
                RectF r = new RectF(x, cTop, x + w, zTop);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFA1683A);
                c.drawRect(r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(linea);
                c.drawRect(r, p);
                p.setColor(0xFFFFE0B2);
                if (mo.tipo == 0 || mo.tipo == 3) c.drawLine(r.centerX(), r.top + 3 * d, r.centerX(), r.bottom - 3 * d, p);
                if (mo.tipo == 2) for (int i = 1; i < 3; i++) { float y = r.top + r.height() * i / 3; c.drawLine(r.left + 3 * d, y, r.right - 3 * d, y, p); }
                p.setStyle(Paint.Style.FILL);
                p.setColor(linea);
                String s = "M" + k++;
                c.drawText(s, r.centerX() - p.measureText(s) / 2, r.top + 14 * d, p);
                cota(c, r.left, r.right, zTop + 0, "", linea, d);
                cota(c, r.left, r.right, yb + 14 * d, Pieza.n((float) mo.ancho), linea, d);
                x += w;
            }
            cota(c, x0, x0 + luzPx, mTop - 14 * d, "luz " + Pieza.n((float) g.luz), linea, d);
            cotaV(c, x0 + Math.max(luzPx, (float) g.usado() * esc) + 18 * d, mTop, yb, Pieza.n((float) Ht), linea, d);
        }

        private void cota(Canvas c, float a, float b, float y, String s, int col, float d) {
            if (s.isEmpty()) return;
            p.setStyle(Paint.Style.STROKE);
            p.setColor(col);
            p.setStrokeWidth(1 * d);
            c.drawLine(a, y, b, y, p);
            c.drawLine(a, y - 4 * d, a, y + 4 * d, p);
            c.drawLine(b, y - 4 * d, b, y + 4 * d, p);
            p.setStyle(Paint.Style.FILL);
            float tw = p.measureText(s);
            c.drawText(s, (a + b) / 2 - tw / 2, y - 3 * d, p);
            p.setStrokeWidth(1.6f * d);
        }

        private void cotaV(Canvas c, float x, float a, float b, String s, int col, float d) {
            p.setStyle(Paint.Style.STROKE);
            p.setColor(col);
            p.setStrokeWidth(1 * d);
            c.drawLine(x, a, x, b, p);
            c.drawLine(x - 4 * d, a, x + 4 * d, a, p);
            c.drawLine(x - 4 * d, b, x + 4 * d, b, p);
            p.setStyle(Paint.Style.FILL);
            c.save();
            c.rotate(-90, x - 3 * d, (a + b) / 2);
            c.drawText(s, x - 3 * d - p.measureText(s) / 2, (a + b) / 2, p);
            c.restore();
            p.setStrokeWidth(1.6f * d);
        }
    }
}
