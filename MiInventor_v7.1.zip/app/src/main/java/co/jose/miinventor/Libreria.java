package co.jose.miinventor;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

/**
 * v6.4 ChpWork: librería de muebles y aparatos para la casa, por categorías.
 * Cada cosa es liviana: un dibujo sencillo en planta y una caja en 3D (alto z), para que el archivo siga pesando poco.
 */
final class Libreria {

    static final class Item {
        final String clave, nombre, cat;
        final float w, h, z;
        final int color;
        Item(String clave, String nombre, String cat, float w, float h, float z, int color) {
            this.clave = clave; this.nombre = nombre; this.cat = cat; this.w = w; this.h = h; this.z = z; this.color = color;
        }
    }

    static final String[] CATEGORIAS = {"Dormitorio", "Cocina", "Baño", "Patio de ropas", "Sala y comedor", "Estructura", "Exterior"};

    static final List<Item> ITEMS = new ArrayList<>();

    static {
        int madera = 0xFFA1887F, blanco = 0xFFECEFF1, tela = 0xFF90A4AE, metal = 0xFFB0BEC5, verde = 0xFF81C784, concreto = 0xFF9E9E9E;
        add("cama2", "Cama doble 1,40", "Dormitorio", 1400, 1900, 500, tela);
        add("cama1", "Cama sencilla 1,00", "Dormitorio", 1000, 1900, 500, tela);
        add("cama120", "Cama 1,20", "Dormitorio", 1200, 1900, 500, tela);
        add("closet", "Clóset", "Dormitorio", 1200, 600, 2200, madera);
        add("mnoche", "Mesa de noche", "Dormitorio", 450, 400, 550, madera);
        add("escritorio", "Escritorio", "Dormitorio", 1000, 500, 750, madera);
        add("meson", "Mesón con gabinete", "Cocina", 1200, 600, 900, madera);
        add("gabalto", "Gabinete alto", "Cocina", 1200, 350, 700, madera);
        add("estufa", "Estufa", "Cocina", 600, 600, 900, metal);
        add("lavaplatos", "Lavaplatos", "Cocina", 800, 600, 900, metal);
        add("nevera", "Nevera", "Cocina", 700, 700, 1800, blanco);
        add("sanitario", "Sanitario", "Baño", 400, 700, 750, blanco);
        add("lavamanos", "Lavamanos", "Baño", 500, 400, 850, blanco);
        add("ducha120", "Ducha recta 1,20 × 0,80", "Baño", 1200, 800, 50, 0xFF81D4FA);
        add("ducha80", "Ducha 0,80 × 0,80", "Baño", 800, 800, 50, 0xFF81D4FA);
        add("lavadero", "Lavadero", "Patio de ropas", 700, 600, 900, concreto);
        add("lavadora", "Lavadora", "Patio de ropas", 600, 600, 900, blanco);
        add("sofa", "Sofá 3 puestos", "Sala y comedor", 2000, 850, 800, tela);
        add("sofa2", "Sofá 2 puestos", "Sala y comedor", 1500, 850, 800, tela);
        add("mueble_tv", "Mueble del TV", "Sala y comedor", 1500, 450, 500, madera);
        add("comedor4", "Comedor 4 puestos", "Sala y comedor", 1200, 800, 750, madera);
        add("comedor6", "Comedor 6 puestos", "Sala y comedor", 1600, 900, 750, madera);
        add("columna", "Columna 20 × 20", "Estructura", 200, 200, 2500, concreto);
        add("escalera", "Escalera recta", "Estructura", 900, 3000, 2500, concreto);
        add("arbol", "Árbol", "Exterior", 1500, 1500, 3000, verde);
        add("carro", "Carro", "Exterior", 1800, 4300, 1450, 0xFF64B5F6);
        add("moto", "Moto", "Exterior", 800, 2000, 1100, 0xFFE57373);
    }

    private static void add(String k, String n, String c, float w, float h, float z, int color) { ITEMS.add(new Item(k, n, c, w, h, z, color)); }

    static Item item(String clave) { for (Item i : ITEMS) if (i.clave.equals(clave)) return i; return null; }

    static List<Item> de(String cat) {
        List<Item> r = new ArrayList<>();
        for (Item i : ITEMS) if (i.cat.equals(cat)) r.add(i);
        return r;
    }

    /** El dibujo en planta dentro del rectángulo (pantalla); trazo negro, como en un plano. */
    static void dibujar(Canvas c, String clave, RectF r, Paint p) {
        float w = r.width(), h = r.height(), m = Math.min(w, h);
        p.setStyle(Paint.Style.STROKE);
        c.drawRect(r, p);
        switch (clave == null ? "" : clave) {
            case "cama1": case "cama2": case "cama120": {   // cabecera y almohadas
                float lado = w > h ? 0 : 1;
                if (lado == 1) {
                    c.drawLine(r.left, r.top + h * 0.12f, r.right, r.top + h * 0.12f, p);
                    float aw = (w - m * 0.15f) / (clave.equals("cama1") ? 1 : 2);
                    for (int i = 0; i < (clave.equals("cama1") ? 1 : 2); i++)
                        c.drawRoundRect(r.left + m * 0.06f + i * (aw + m * 0.03f), r.top + h * 0.15f, r.left + m * 0.06f + i * (aw + m * 0.03f) + aw - m * 0.03f, r.top + h * 0.27f, m * 0.04f, m * 0.04f, p);
                    c.drawLine(r.left, r.top + h * 0.35f, r.right, r.top + h * 0.35f, p);
                } else {
                    c.drawLine(r.left + w * 0.12f, r.top, r.left + w * 0.12f, r.bottom, p);
                    c.drawLine(r.left + w * 0.35f, r.top, r.left + w * 0.35f, r.bottom, p);
                }
                break;
            }
            case "sanitario":
                c.drawRect(r.left + w * 0.1f, r.top, r.right - w * 0.1f, r.top + h * 0.28f, p);
                c.drawOval(new RectF(r.left + w * 0.08f, r.top + h * 0.32f, r.right - w * 0.08f, r.bottom - h * 0.04f), p);
                break;
            case "lavamanos": case "lavaplatos":
                c.drawOval(new RectF(r.left + w * 0.15f, r.top + h * 0.2f, r.right - w * 0.15f, r.bottom - h * 0.12f), p);
                break;
            case "estufa":
                for (int i = 0; i < 4; i++) c.drawCircle(r.left + w * (i % 2 == 0 ? 0.3f : 0.7f), r.top + h * (i < 2 ? 0.3f : 0.7f), m * 0.14f, p);
                break;
            case "ducha120": case "ducha80":
                c.drawLine(r.left, r.top, r.right, r.bottom, p);
                c.drawLine(r.right, r.top, r.left, r.bottom, p);
                c.drawCircle(r.centerX(), r.centerY(), m * 0.08f, p);
                break;
            case "sofa": case "sofa2":
                c.drawRect(r.left, r.top, r.right, r.top + h * 0.25f, p);
                c.drawRect(r.left, r.top, r.left + w * 0.1f, r.bottom, p);
                c.drawRect(r.right - w * 0.1f, r.top, r.right, r.bottom, p);
                break;
            case "comedor4": case "comedor6":
                c.drawRect(r.left + w * 0.15f, r.top + h * 0.2f, r.right - w * 0.15f, r.bottom - h * 0.2f, p);
                break;
            case "nevera": case "lavadora":
                c.drawLine(r.left, r.top + h * 0.15f, r.right, r.top + h * 0.15f, p);
                if (clave.equals("lavadora")) c.drawCircle(r.centerX(), r.centerY() + h * 0.05f, m * 0.3f, p);
                break;
            case "lavadero":
                c.drawRect(r.left + w * 0.08f, r.top + h * 0.1f, r.left + w * 0.55f, r.bottom - h * 0.1f, p);
                c.drawLine(r.left + w * 0.62f, r.top + h * 0.2f, r.right - w * 0.08f, r.top + h * 0.2f, p);
                c.drawLine(r.left + w * 0.62f, r.top + h * 0.45f, r.right - w * 0.08f, r.top + h * 0.45f, p);
                break;
            case "closet":
                c.drawLine(r.left, r.centerY(), r.right, r.centerY(), p);
                break;
            case "escalera": {
                int n = 12;
                if (h >= w) for (int i = 1; i < n; i++) c.drawLine(r.left, r.top + h * i / n, r.right, r.top + h * i / n, p);
                else for (int i = 1; i < n; i++) c.drawLine(r.left + w * i / n, r.top, r.left + w * i / n, r.bottom, p);
                break;
            }
            case "arbol":
                c.drawCircle(r.centerX(), r.centerY(), m * 0.48f, p);
                c.drawCircle(r.centerX(), r.centerY(), m * 0.12f, p);
                break;
            case "columna":
                c.drawLine(r.left, r.top, r.right, r.bottom, p);
                break;
            default:
                break;
        }
    }
}
