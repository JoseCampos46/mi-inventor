package co.jose.miinventor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * v6.6 ChpWork: grabadora de pantalla liviana, SIN sonido, a 360 de ancho (≈ 7 MB por minuto).
 * Corre como servicio en primer plano (Android lo exige) con un aviso que tiene «Detener».
 * El video queda en Descargas/MiBarra/ChpWork y la app ofrece mandarlo a Claude.
 */
public class Grabadora extends Service {

    interface Fin { void listo(Uri video, String nombre, long bytes); }

    /** Lo que deja la pantalla de Android cuando el usuario toca «Empezar». */
    static int codigo;
    static Intent permiso;
    static Fin alTerminar;
    static volatile boolean grabando;
    /** v6.7: sin sonido por defecto (pesa poco); en ⋮ se puede activar el micrófono. */
    static boolean conSonido;
    static long inicio;

    private MediaRecorder rec;
    private MediaProjection mp;
    private VirtualDisplay vd;
    private ParcelFileDescriptor pfd;
    private Uri uri;
    private String nombre;

    private static final String CANAL = "grabadora", PARAR = "co.jose.miinventor.PARAR";

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && PARAR.equals(i.getAction())) { parar(); return START_NOT_STICKY; }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(new NotificationChannel(CANAL, "Grabadora de ChpWork", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getService(this, 1, new Intent(this, Grabadora.class).setAction(PARAR), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CANAL)
                .setContentTitle("ChpWork está grabando la pantalla")
                .setContentText((conSonido ? "Con sonido" : "Sin sonido") + " · toque Detener para terminar")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setOngoing(true)
                .addAction(R.mipmap.ic_launcher, "⏹ Detener", pi)
                .build();
        boolean mic = conSonido && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        conSonido = mic;
        startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION | (mic ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0));
        try {
            empezar();
        } catch (Throwable t) {
            limpiar();
            grabando = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void empezar() throws Exception {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = 360;
        int h = Math.round(360f * dm.heightPixels / Math.max(1, dm.widthPixels));
        h -= h % 2;
        nombre = "ChpWork_video_" + new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()) + ".mp4";
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MiBarra/ChpWork");
        uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        pfd = getContentResolver().openFileDescriptor(uri, "w");
        rec = android.os.Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
        if (conSonido) rec.setAudioSource(MediaRecorder.AudioSource.MIC);
        rec.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        if (conSonido) {   // voz liviana: un canal, 48 kbps
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            rec.setAudioChannels(1);
            rec.setAudioSamplingRate(44100);
            rec.setAudioEncodingBitRate(48_000);
        }
        rec.setVideoSize(w, h);
        rec.setVideoFrameRate(20);
        rec.setVideoEncodingBitRate(900_000);
        rec.setOutputFile(pfd.getFileDescriptor());
        rec.prepare();
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mp = mpm.getMediaProjection(codigo, permiso);
        mp.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { if (grabando) parar(); }
        }, null);
        vd = mp.createVirtualDisplay("ChepeCAD", w, h, Math.max(120, dm.densityDpi / 2), DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.getSurface(), null, null);
        rec.start();
        grabando = true;
        inicio = System.currentTimeMillis();
    }

    private void parar() {
        if (!grabando) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return; }
        grabando = false;
        boolean bien = true;
        try { rec.stop(); } catch (Throwable t) { bien = false; }
        limpiar();
        stopForeground(STOP_FOREGROUND_REMOVE);
        long bytes = 0;
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) bytes = c.getLong(0);
        } catch (Throwable ignored) { }
        Fin f = alTerminar;
        if (f != null && bien) f.listo(uri, nombre, bytes);
        stopSelf();
    }

    private void limpiar() {
        try { if (rec != null) rec.release(); } catch (Throwable ignored) { }
        try { if (vd != null) vd.release(); } catch (Throwable ignored) { }
        try { if (mp != null) mp.stop(); } catch (Throwable ignored) { }
        try { if (pfd != null) pfd.close(); } catch (Throwable ignored) { }
        rec = null; vd = null; mp = null; pfd = null;
        permiso = null;   // en Android 14 cada permiso sirve una sola vez
    }

    /** Desde la app: el botón ⏹ DETENER. */
    static void detener(Context c) {
        c.startService(new Intent(c, Grabadora.class).setAction(PARAR));
    }
}
